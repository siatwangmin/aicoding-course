import cloudbase from '@cloudbase/js-sdk';

// Adapt in the existing client module; configuration contains public values only.
export function createWebPgAccess({ envId, publishableKey }) {
  if (!envId || !publishableKey) throw new Error('PUBLIC_CONNECTION_REQUIRED');
  const app = cloudbase.init({
    env: envId,
    accessKey: publishableKey,
    auth: { detectSessionInUrl: true },
  });
  const auth = app.auth;
  const db = app.rdb();

  function check(error, stage) {
    if (!error) return;
    const failure = new Error(stage);
    // Keep a bounded provider code for diagnosis, never the raw response/message.
    if (typeof error.code === 'string' && /^[A-Za-z0-9_.:-]{1,64}$/.test(error.code)) {
      failure.code = error.code;
    }
    throw failure;
  }

  function activeSession(data) {
    const session = data?.session;
    return session?.user?.id && !session.user.is_anonymous ? session : null;
  }

  return {
    async restoreSession() {
      const { data, error } = await auth.getSession();
      check(error, 'SESSION_RESTORE_FAILED');
      return activeSession(data);
    },
    async signIn(username, password) {
      const { data, error } = await auth.signInWithPassword({ username, password });
      check(error, 'SIGN_IN_FAILED');
      const session = activeSession(data);
      if (!session) throw new Error('AUTHENTICATED_SESSION_REQUIRED');
      return session;
    },
    async readPage(table, from = 0, to = 49) {
      const { data, error } = await db.from(table).select('*').range(from, to);
      check(error, 'PG_READ_FAILED');
      return data ?? [];
    },
    async insertAndRead(table, row, keyColumn, keyValue) {
      // Caller supplies a verified unique key and reconciles unknown writes before retry.
      const written = await db.from(table).insert(row);
      check(written.error, 'PG_WRITE_FAILED_OR_UNKNOWN');
      const read = await db.from(table).select('*').eq(keyColumn, keyValue).single();
      check(read.error, 'PG_WRITE_READBACK_FAILED_OR_UNKNOWN');
      if (!read.data) throw new Error('PG_WRITE_READBACK_MISSING');
      return read.data;
    },
    async uploadPrivateImage(bucketName, objectKey, file) {
      const bucket = app.storage.from(bucketName);
      const uploaded = await bucket.upload(objectKey, file, { upsert: false });
      check(uploaded.error, 'IMAGE_UPLOAD_FAILED_OR_UNKNOWN');
      const signed = await bucket.createSignedUrl(objectKey, 3600);
      check(signed.error, 'IMAGE_SIGN_FAILED');
      const url = signed.data?.fullSignedURL;
      if (typeof url !== 'string' || !url.startsWith('https://')) {
        throw new Error('IMAGE_SIGN_RESPONSE_MISMATCH');
      }
      return { bucket: bucketName, key: objectKey, url };
    },
  };
}
