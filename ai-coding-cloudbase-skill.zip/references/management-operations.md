# 当前管理工具与结果判断

仅在当前管理入口缺失或排障时读取。优先保持已登记的官方MCP/CLI路线；浏览器登录、help或旧部署记录不能代替当前目标访问。不要扫描HOME或解析登录Token。

CLI能力检查可用 scripts/Test-CloudBaseManagement.ps1 -CliPath <已登记官方exe/ps1> -WorkingDirectory <当前A或B>；它只检查版本/help并记录非秘密能力，不登录、不证明部署授权。按当前子命令help执行具体动作，不猜旧命令或将MCP工具名当CLI命令；入口/版本变化重新核能力。

scripts/Course-CloudBase.ps1的ConvertFrom-CourseCloudBaseResult将实际结果分类：SuccessPredicate依据当前操作的真实响应schema校验；业务错误不能因exit=0通过，非零JSON或超时保留outcome-unknown。必要时VerifyOutcome执行独立只读目标查询，只有readOnly/targetMatched/status均证实才解除未知；不能直接填常量替代查询。接口不返回原始payload，避免管理返回中的凭证泄漏。

MCP按当前schema调用，由助手归并实际结果，不能伪装成PowerShell可直接调用MCP。原任务未知先查实际状态，不自动重新提交。需本人登录时沿官方原路线完成一个动作后接续；不全局加--yes，不将授权/费用确认当普通技术提示跳过。

阶段完成后按环境Skill references/preparation-workflow.md调用Save-PreparationEvidence记录实际观察，时间/路径/登记由脚本负责，不手填未来时间。管理授权与应用登录、后端服务身份分别验证；V4私有配置访问另读development的ai-settings-access.md。

PG结构变更以当前管理工具契约为准：当execute返回DDL_USE_APPLY_MIGRATION时，在项目B保存显式版本SQL，使用planMigration→applyMigration并核原TaskId/远端历史；不改用绕过迁移历史的开关。工具默认可能在调用checkout写SQL副本，核真实路径与B的来源一致，不能误把操作流程维护仓库当使用者工程。

更新已有云函数时先核工具是否保留环境配置。默认详情可能把所有环境变量变成***，绝不能将其合并写回；scripts/Course-CloudBase.ps1的Assert-CourseCloudBaseEnvironmentValues可拒绝占位值。确需合并时，使用当前官方工具显式读取实际配置，仅在受保护的工具内存合并并结构化提交，不输出原始响应、不落普通临时文件。代码更新也可能重建环境配置：显式传递已确认的原环境变量、运行时和类型，更新后核变量集合/值的内部比较和实际功能；不以Active代替。只有配置来源丢失且原加密数据不存在时才可重新生成加密材料，已有密文不能随意换解密材料。
