# 官方技能路由

本技能负责项目绑定、执行顺序、复用和证据；平台 API 的依据是当前实际安装的腾讯云官方技能与锁定 SDK。不要把其他项目的 envId、表名、用户或凭证当通用默认值。

先读本地官方 `cloudbase/SKILL.md`，从其相对路径或当前客户端已发现的技能定位下表，仅加载当前任务需要的分支。表内为技能 frontmatter 的稳定名称，不是 MCP 工具名或 CLI 子命令；官方版本使用别名时以实际入口路由为准，不硬编码某个用户的安装绝对路径。

| 当前工作 | 读取的官方技能/引用 | 本轮应取得的结论 |
| --- | --- | --- |
| PG 表、字段、CRUD、RLS | `postgresql-development-cloudbase`；其 `references/app-workflow.md`、`references/auth-and-rls.md` 按需读 | 实际 schema/迁移、会话归属与 app.rdb() 路线；不转 MySQL/NoSQL 探索 |
| 登录方式与账号可用性 | `auth-tool-cloudbase`，随后 `auth-web-cloudbase` | provider 是否启用、SDK 提示、有效会话与注册边界；管理登录不替代应用登录 |
| PG 图片桶、上传、链接 | PG 技能的 `references/storage-pg.md` | 实际 PG 桶、对象 key、权限、签名链接返回字段；不混用旧 COS/NoSQL 存储 API |
| 已有 NoSQL 存储 | `cloud-storage-web`；数据需要时另读 `cloudbase-document-database-web-sdk` | 沿已有存储模式处理，不擅自迁移到 PG |
| MCP 未在本会话加载、当前使用 CLI | `cloudbase-cli` 的 `references/core.md` 和相应 db/storage/user/hosting 域引用 | 保持已登记 CLI 路线，按实际 help 指定 EnvId，不猜命令或并行摸索另一套工具 |
| 真实服务端逻辑、私密配置或 AI | `cloud-functions`；本技能的 AI/服务身份指南 | 仅把确需服务端执行的部分放后端；纯业务 PG CRUD 不自动增加函数 |
| 页面接线和发布后检查 | `web-development`；完成后按官方 `cloudbase-code-review` 核相关问题 | 实际业务页面、错误恢复、权限和 SDK 边界；不重新设计已确认页面 |

已安装包缺少某个子技能时，先依据 [官方接入](cloudbase-connection.md) 补齐同一来源的完整引用；不只下载一个根 SKILL.md，也不重新安装到另一作用域。官方子技能未安装与 MCP 当前不可用是不同问题：已登记 CLI 可用时继续管理动作，不让 MCP 配置拖住本轮任务。

优先复用已有项目的适配与当前验证证据。版本不变且没有具体失败时，不反复读整套文档；需要定位方法差异时先看已锁版本的类型/错误与对应章节，避免反复枚举压缩 JS 或在 Node 中强行初始化浏览器 SDK。REST 只有在 SDK 缺失能力或已证明故障时才按官方 HTTP/OpenAPI 分支处理，不类推其他平台地址。
