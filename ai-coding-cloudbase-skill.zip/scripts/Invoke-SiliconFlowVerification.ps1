﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$WorkingDirectory,[Parameter(Mandatory=$true)][string]$ModelsPath,[ValidateSet('text','vision','both')][string]$Kind='both',[switch]$Invoke)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $PSScriptRoot 'Credential-Store.ps1')
$context=Join-Path $executionRoot 'scripts/Course-Context.ps1'
. $context
$projectPath=Join-Path $WorkingDirectory '.ai-coding\project.json'
if(Test-Path -LiteralPath $projectPath){$execution=Read-CourseJson $projectPath}else{$execution=(Find-CoursePreparation).record}
if($execution.containerRuntime -ne 'docker'){throw 'Use the recorded Podman compatibility route; do not switch engines.'}
$image=$execution.image
if($image -notmatch '^[a-zA-Z0-9./:_@-]+$'){throw 'Invalid prepared image.'}
$workspace=(Resolve-Path -LiteralPath $WorkingDirectory).Path;Assert-AiPlainPath $workspace
$models=Get-Content -Raw -Encoding UTF8 -LiteralPath $ModelsPath|ConvertFrom-Json
$previousPath=Join-Path $workspace '.ai-setup\verification.json'
$previous=if(Test-Path -LiteralPath $previousPath){Assert-AiPlainPath $previousPath;Get-Content -Raw -Encoding UTF8 -LiteralPath $previousPath|ConvertFrom-Json}else{$null}
$secure=Get-AiSecureCredential;$pointer=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
$process=$null
try{
    $plain=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)
    $skillRoot=Split-Path $PSScriptRoot -Parent
    if($skillRoot.Contains('"') -or $skillRoot.Contains(',')){throw 'Unsupported skill mount path.'}
    $args=@('--host','npipe:////./pipe/dockerDesktopLinuxEngine','run','--rm','-i','--entrypoint','node','--mount',('type=bind,source='+$skillRoot+',target=/skill,readonly'),$image,'/skill/scripts/verify-siliconflow.mjs','--workspace','/tmp','--models','stdin','--config-stdin')
    if($Kind -ne 'both'){$args+=@('--kind',$Kind)};if($Invoke){$args+='--invoke'}
    $info=New-Object Diagnostics.ProcessStartInfo
    $info.FileName=(Get-Command docker.exe -ErrorAction Stop).Source
    $info.Arguments=($args|ForEach-Object{'"'+($_ -replace '(\\*)"','$1$1\"' -replace '(\\+)$','$1$1')+'"'}) -join ' '
    $info.UseShellExecute=$false;$info.CreateNoWindow=$true
    $info.RedirectStandardInput=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
    $process=New-Object Diagnostics.Process;$process.StartInfo=$info;[void]$process.Start()
    $outputTask=$process.StandardOutput.ReadToEndAsync();$errorTask=$process.StandardError.ReadToEndAsync()
    $payload=@{key=$plain;baseUrl='https://api.siliconflow.cn/v1';directory='/tmp';models=$models;previous=$previous}|ConvertTo-Json -Depth 12 -Compress
    $process.StandardInput.Write($payload);$process.StandardInput.Close();$payload=$null;$plain=$null
    if(-not $process.WaitForExit(150000)){$process.Kill();throw 'Verification timeout.'}
    if($process.ExitCode -ne 0){throw 'Model verification failed; raw output suppressed.'}
    $report=$outputTask.Result|ConvertFrom-Json
    if($report.provider -ne 'siliconflow' -or $report.credentials -notin @('passed','failed')){throw 'Invalid verification report.'}
    Write-CourseJson $previousPath $report
    $report|ConvertTo-Json -Depth 8
}finally{
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer);$secure.Dispose();$plain=$null;$payload=$null
    if($process){$process.Dispose()}
}
