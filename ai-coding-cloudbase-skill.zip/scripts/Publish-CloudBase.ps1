﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,[string]$CliPath,[switch]$Publish,[switch]$Recover)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $executionRoot 'scripts/Course-Runtime.ps1')
$ctx=Get-CourseProjectRuntime $ProjectDirectory -Start
$services=Read-CourseJson (Join-Path $ctx.Root '.ai-coding\services.json');$envId=$services.cloudbase.envId;$url=$services.cloudbase.hostingUrl
if(-not $envId -or $envId -notmatch '^[a-zA-Z0-9-]+$'){throw 'Confirmed CloudBase binding required.'}
if(-not $url -or ([uri]$url).Scheme -ne 'https'){throw 'Record the actual official hosting URL in services.cloudbase.hostingUrl before publishing.'}
$source=$ctx.Source;$output=Join-Path $source 'dist';Assert-CoursePlainPath $output
$scripts=$PSScriptRoot;$recordPath=Join-Path $ctx.Root 'docs\progress\cloudbase-publish.json'
function Invoke-PublicAssets([string]$Action){
 $a=$ctx.Prefix+@('run','--rm','--mount',("type=bind,source=$output,target=/public"),'--mount',("type=bind,source=$scripts,target=/course,readonly"),'--entrypoint','node',$ctx.Project.image,'/course/publish-assets.mjs',$Action)
 if($Action -eq 'manifest'){$a+=@('--directory','/public')}else{$a+=@('--url',$url,'--manifest','/public/course-publish.json')}
 $r=Invoke-SetupNative $ctx.Cli $a 180 $ctx.Root
 if($r.ExitCode -ne 0){throw ('PUBLIC_ASSET_CHECK_FAILED:'+ $Action)}
 return $(if($r.Stdout){$r.Stdout}else{$r.Output})|ConvertFrom-Json
}
if($Recover){
 $record=Read-CourseJson $recordPath
 if($record.envId -ne $envId -or $record.url -ne $url){throw 'Recovery target differs; preserve prior publication.'}
 if((Read-CourseJson (Join-Path $output 'course-publish.json')).buildId -ne $record.buildId){throw 'Local build differs from interrupted publication; restore its manifest before recovery.'}
 $verified=Invoke-PublicAssets 'verify';$record.status='assets-verified';$record.checkedAt=$verified.checkedAt
 Write-CourseJson $recordPath $record;Write-Output 'Published assets verified. Application data and learner trial remain separate.';exit 0
}
if(Test-Path -LiteralPath $recordPath){if((Read-CourseJson $recordPath).status -eq 'deployment-unknown'){throw 'Prior deployment outcome unknown. Query official remote state and use -Recover; do not blindly redeploy.'}}
# Vite production env precedence; public config only, never echo values.
$values=@{}
foreach($name in @('.env','.env.local','.env.production','.env.production.local')){
 $path=Join-Path $source $name
 if(Test-Path -LiteralPath $path){Assert-CoursePlainPath $path;foreach($line in [IO.File]::ReadAllLines($path)){if($line -match '^\s*(VITE_DATA_MODE|VITE_CLOUDBASE_ENV_ID)\s*=\s*(.*?)\s*$'){$values[$Matches[1]]=$Matches[2].Trim('"',"'")}}}
}
if($values.VITE_DATA_MODE -ne 'cloudbase' -or $values.VITE_CLOUDBASE_ENV_ID -ne $envId){throw 'Production client data mode/environment does not match confirmed CloudBase target.'}
$cliExe=$null;$cliPrefix=@()
if($Publish){
 if(-not $CliPath -or -not(Test-Path -LiteralPath $CliPath)){throw 'Use the recorded official CLI entry or the existing MCP route. Do not install another toolchain.'}
 Assert-CoursePlainPath $CliPath
 if([IO.Path]::GetExtension($CliPath) -eq '.ps1'){$cliExe=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe';$cliPrefix=@('-NoProfile','-File',$CliPath)}
 elseif([IO.Path]::GetExtension($CliPath) -eq '.exe'){$cliExe=$CliPath}else{throw 'Use the official .ps1/.exe entry; do not compose cmd shell quoting.'}
 foreach($checkArgs in @(@('--version'),@('hosting','deploy','--help'),@('hosting','list','--env-id',$envId,'--json'))){
  $r=Invoke-SetupNative $cliExe ($cliPrefix+$checkArgs) 60 $ctx.Root;if($r.ExitCode -ne 0){throw 'Official CLI help/current target access failed; restore service authorization first.'}
 }
}
$built=Invoke-SetupNative $ctx.Cli ($ctx.Prefix+@('compose','exec','-T','app','npm','run','build')) 180 $ctx.Root
if($built.ExitCode -ne 0){throw 'Container Web build failed; no publication.'}
$manifest=Invoke-PublicAssets 'manifest'
$record=@{schemaVersion=2;status='prepared';envId=$envId;url=$url;buildId=$manifest.buildId;image=$ctx.Project.image;preparedAt=(Get-Date).ToString('o');applicationData='pending';learnerTried='pending'}
Write-CourseJson $recordPath $record
if(-not $Publish){Write-Output 'Current Web assets prepared; remote unchanged. Use the confirmed official route for publication.';exit 0}
$record.status='deployment-unknown';Write-CourseJson $recordPath $record
$deployed=Invoke-SetupNative $cliExe ($cliPrefix+@('hosting','deploy',$output,'--env-id',$envId,'--json')) 600 $ctx.Root
if($deployed.ExitCode -ne 0){throw 'Deployment failed or timed out; query actual remote state before retrying.'}
$verified=Invoke-PublicAssets 'verify';$record.status='assets-verified';$record.checkedAt=$verified.checkedAt
Write-CourseJson $recordPath $record
Write-Output ('Hosting assets verified: '+$url)
Write-Output 'Application sessions, data/images, permissions and learner trial still require their own actual results.'
