---
name: ai-coding-development
description: 在已初始化的作品中实现本地网页、github.io 静态展示、CloudBase 数据与发布、服务端 AI；维护技术方案和进度。Android 构建交 ai-coding-android；不预设业务页面或案例。
---

# 通用作品开发

先读项目根 AGENTS.md、.ai-coding/project.json、services.json、docs/engineering/baseline.md、当前 PRD/Canvas、当前 spec 和 docs/progress/current.md。旧工程按实际目录接入，不重建。

先按 [执行路线](implementation/execution-route.md) 将用户功能目标映射到本地/原型发布/正式云端/Android/AI，只读当前指南；“生成安装文件”等自然表达已足够触发对应技能。按实际目录读取材料，不要求本人给技术长提示。先落本轮实现方案，再依其步骤连续实施；已有确认和普通修复直接继续。

每轮按功能目标 → 已确认需求/设计 → 助手维护技术方案 → 实现与检查 → 本人试用 → 记录反馈推进。已确认的本轮文件直接使用；实现缺陷直接修复。技术 spec 由助手维护，不向学员索要技术文档。

所有项目开发服务、Web 编译和检查使用准备阶段登记的同一 Docker 镜像。读取 manifest 的 image、containerRuntime 与 Compose，不能在宿主机安装 Node/Java/Android SDK，也不能换 latest、临时 npx 下载工具或另建工具镜像。既有 Podman 工程按原记录兼容，不切引擎。

实施前执行用户级 ai-coding-project/scripts/Test-ProjectRuntime.ps1 -ProjectDirectory <B> -Start，复用本机引擎/镜像/挂载及实际依赖卷检查。它只证明运行前提，不证明授权/产品通过；失败按下文恢复，不绕开执行。

引擎离线先恢复原引擎/Compose，缺依赖先核独立卷、锁文件和平台模块，在同镜像修复；权限失败核身份和GRANT/RLS。不能用宿主编译、关版本约束、换appId/remote、开放匿名写或前端秘密来绕行。实际API与示例不符先查当前版本及工程适配，确需改基线再记录原因/影响/授权边界，普通技术恢复无需反复问本人。

按当前目标只读一项：[本地](implementation/local.md)、[静态发布](implementation/publishing.md)、[CloudBase](implementation/cloudbase.md)、[AI](implementation/ai.md)。安卓调用用户级 ai-coding-android。首次服务配置应已由 ai-coding-project 完成；失效时调用对应服务技能只补缺项。

新增AI或更换模型时同时读取 [模型设置](implementation/model-settings.md)：本项目默认值只用于首次配置，V4设置入口持久化服务端有效模型/revision，网页与Android共享。禁止将唯一模型硬编码进产品；不能把前端可编辑字段当作配置已生效，必须核函数实际路由。初始化只准备默认值，具体功能随本轮实现。

通用检查在 [agent-step-checks.json](implementation/agent-step-checks.json)，分工见 [learner-responsibilities.md](implementation/learner-responsibilities.md)。选定案例后再合并案例检查，不能以案例取代通用门槛。不要因安装了案例技能就选择案例。

结束更新项目 docs/progress/current.md 与阶段记录：范围、实际文件、镜像身份、检查证据、本人反馈、缺项和下一步。普通技术操作连续完成；本人只确认产品、授权费用和亲自试用。准备、构建、部署、真实运行和本人试用分别报告。
