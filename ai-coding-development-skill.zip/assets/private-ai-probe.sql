-- Versioned, server-only technical probe. No application model/Key/revision is changed.
CREATE TABLE IF NOT EXISTS public.ai_service_probes (
  project_id text NOT NULL, probe_id uuid NOT NULL, marker uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY(project_id,probe_id)
);
ALTER TABLE public.ai_service_probes ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.ai_service_probes FROM PUBLIC,anon,authenticated;
GRANT SELECT,INSERT,DELETE ON public.ai_service_probes TO service_role;
-- Adapt only through a project migration after inspecting the actual schema.
