-- Versioned PG quota implementation. Policies are explicitly supplied by the PROJECT migration.
-- No case-specific window, limit, identity or resource ID is provided by this public asset.
CREATE TABLE IF NOT EXISTS public.ai_quota_policy (
  project_id text PRIMARY KEY,
  window_seconds integer NOT NULL DEFAULT 0 CHECK(window_seconds BETWEEN 0 AND 86400),
  window_limit integer NOT NULL DEFAULT 0 CHECK(window_limit >= 0),
  user_daily_limit integer CHECK(user_daily_limit > 0),
  project_daily_limit integer CHECK(project_daily_limit > 0),
  day_utc date, project_attempts integer NOT NULL DEFAULT 0 CHECK(project_attempts >= 0),
  CHECK((window_seconds=0 AND window_limit=0) OR (window_seconds>0 AND window_limit>0)),
  CHECK(window_limit>0 OR user_daily_limit IS NOT NULL OR project_daily_limit IS NOT NULL)
);
CREATE TABLE IF NOT EXISTS public.ai_quota_state (
  project_id text NOT NULL REFERENCES public.ai_quota_policy(project_id), subject_id text NOT NULL,
  recent_attempts timestamptz[] NOT NULL DEFAULT '{}', day_utc date,
  attempts integer NOT NULL DEFAULT 0 CHECK(attempts >= 0),
  PRIMARY KEY(project_id,subject_id)
);
CREATE TABLE IF NOT EXISTS public.ai_quota_requests (
  project_id text NOT NULL REFERENCES public.ai_quota_policy(project_id), request_id text NOT NULL,
  subject_id text NOT NULL, status text NOT NULL CHECK(status IN ('reserved','completed','failed','unknown')),
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(), updated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY(project_id,request_id)
);
ALTER TABLE public.ai_quota_policy ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_quota_state ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_quota_requests ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.ai_quota_policy,public.ai_quota_state,public.ai_quota_requests FROM PUBLIC,anon,authenticated;
GRANT SELECT,INSERT,UPDATE ON public.ai_quota_policy,public.ai_quota_state,public.ai_quota_requests TO service_role;
CREATE OR REPLACE FUNCTION public.reserve_ai_quota(p_project text,p_subject text,p_request text)
RETURNS jsonb LANGUAGE plpgsql SECURITY INVOKER SET search_path=pg_catalog,public AS $$
DECLARE policy public.ai_quota_policy%ROWTYPE; state public.ai_quota_state%ROWTYPE;
  previous public.ai_quota_requests%ROWTYPE; instant timestamptz; today date; recent timestamptz[];
BEGIN
  IF p_project IS NULL OR length(p_project) NOT BETWEEN 1 AND 128 OR p_subject IS NULL OR length(p_subject) NOT BETWEEN 1 AND 128
    OR p_request IS NULL OR p_request !~ '^[A-Za-z0-9_-]{16,128}$' THEN RAISE EXCEPTION 'QUOTA_IDENTITY_REQUIRED'; END IF;
  -- Serializes one project's reservations (small classroom workload); no separate instances can race.
  SELECT * INTO policy FROM public.ai_quota_policy WHERE project_id=p_project FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'QUOTA_POLICY_REQUIRED'; END IF;
  instant:=clock_timestamp(); today:=(instant AT TIME ZONE 'UTC')::date;
  SELECT * INTO previous FROM public.ai_quota_requests WHERE project_id=p_project AND request_id=p_request;
  IF FOUND THEN
    IF previous.subject_id<>p_subject THEN RAISE EXCEPTION 'QUOTA_REQUEST_OWNER_MISMATCH'; END IF;
    RETURN jsonb_build_object('allowed',false,'status','duplicate','previousStatus',previous.status);
  END IF;
  INSERT INTO public.ai_quota_state(project_id,subject_id) VALUES(p_project,p_subject) ON CONFLICT DO NOTHING;
  SELECT * INTO state FROM public.ai_quota_state WHERE project_id=p_project AND subject_id=p_subject FOR UPDATE;
  IF state.day_utc IS DISTINCT FROM today THEN state.attempts:=0; END IF;
  IF policy.day_utc IS DISTINCT FROM today THEN policy.project_attempts:=0; END IF;
  SELECT coalesce(array_agg(t ORDER BY t),'{}'::timestamptz[]) INTO recent
    FROM unnest(state.recent_attempts) AS t WHERE policy.window_seconds>0 AND t>instant-make_interval(secs=>policy.window_seconds);
  IF (policy.window_limit>0 AND cardinality(recent)>=policy.window_limit)
    OR (policy.user_daily_limit IS NOT NULL AND state.attempts>=policy.user_daily_limit)
    OR (policy.project_daily_limit IS NOT NULL AND policy.project_attempts>=policy.project_daily_limit)
    THEN RETURN jsonb_build_object('allowed',false,'status','limited'); END IF;
  UPDATE public.ai_quota_state SET recent_attempts=CASE WHEN policy.window_seconds>0 THEN array_append(recent,instant) ELSE '{}'::timestamptz[] END,
    attempts=state.attempts+1,day_utc=today WHERE project_id=p_project AND subject_id=p_subject;
  UPDATE public.ai_quota_policy SET project_attempts=policy.project_attempts+1,day_utc=today WHERE project_id=p_project;
  INSERT INTO public.ai_quota_requests(project_id,request_id,subject_id,status) VALUES(p_project,p_request,p_subject,'reserved');
  RETURN jsonb_build_object('allowed',true,'status','reserved');
END $$;
REVOKE ALL ON FUNCTION public.reserve_ai_quota(text,text,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.reserve_ai_quota(text,text,text) TO service_role;
-- Do not reset counts on reinstall/upgrade. Do not drop these tables for application rollback.
-- Policy and retention decisions belong to the project's Spec and explicit versioned migrations.
