// Server-only diagnostics. Resource names/callbacks are server bindings, never event input.
const {randomUUID}=require('node:crypto');
const {requireEditor}=require('./private-ai-config.cjs');
function failure(code){return Object.assign(new Error(code),{code});}
async function verifyPrivateAccess({db,actor,readPrivateConfig,table='ai_service_probes'}){
  requireEditor(actor);
  if(!/^[A-Za-z_][A-Za-z0-9_]*$/.test(table)||typeof readPrivateConfig!=='function')throw failure('PROBE_BINDING_REQUIRED');
  const projectId=actor.projectId,probeId=randomUUID(),marker=randomUUID();
  let inserted=false,verified=false;
  try{
    await readPrivateConfig(); // Same deployed adapter/identity as the real configuration path.
    const {error}=await db.from(table).insert({project_id:projectId,probe_id:probeId,marker});
    if(error)throw failure('PRIVATE_PROBE_WRITE_FAILED');
    inserted=true;
    const read=await db.from(table).select('marker').eq('project_id',projectId).eq('probe_id',probeId);
    if(read.error||read.data?.length!==1||read.data[0].marker!==marker)throw failure('PRIVATE_PROBE_READBACK_FAILED');
    verified=true;
  }finally{
    if(inserted){
      const removed=await db.from(table).delete().eq('project_id',projectId).eq('probe_id',probeId).select('probe_id');
      if(removed.error||removed.data?.length!==1)throw failure('PRIVATE_PROBE_CLEANUP_FAILED');
    }
  }
  return {status:verified?'verified':'pending',configurationRead:true,probeWriteReadCleanup:true};
}
module.exports={verifyPrivateAccess};
