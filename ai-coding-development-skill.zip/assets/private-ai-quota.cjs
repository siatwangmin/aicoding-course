// Service-side adapter: actor comes from trusted invocation context, never event.uid/limit.
function failure(code){return Object.assign(new Error(code),{code});}
function assertIdentity(actor){
  if(!actor?.uid||actor.isAnonymous!==false||!actor.projectId||actor.projectId!==actor.authorizedProjectId)throw failure('UNAUTHORIZED');
}
async function reserveQuota({db,actor,requestId}){
  assertIdentity(actor);
  if(typeof requestId!=='string'||!/^[A-Za-z0-9_-]{16,128}$/.test(requestId))throw failure('REQUEST_ID_REQUIRED');
  let response;
  try{response=await db.rpc('reserve_ai_quota',{p_project:actor.projectId,p_subject:actor.uid,p_request:requestId});}catch{throw failure('QUOTA_UNAVAILABLE');}
  const result=Array.isArray(response?.data)?response.data[0]:response?.data;
  if(response?.error||!result||typeof result.allowed!=='boolean'||!['reserved','duplicate','limited'].includes(result.status))throw failure('QUOTA_UNAVAILABLE');
  if(!result.allowed)throw failure(result.status==='duplicate'?'REQUEST_ALREADY_SUBMITTED':'RATE_LIMITED');
  if(result.status!=='reserved')throw failure('QUOTA_UNAVAILABLE');
}
async function runWithQuota({db,actor,requestId,invoke}){
  await reserveQuota({db,actor,requestId});
  async function mark(status){
    const result=await db.from('ai_quota_requests').update({status,updated_at:new Date().toISOString()}).eq('project_id',actor.projectId).eq('subject_id',actor.uid).eq('request_id',requestId).eq('status','reserved').select('request_id');
    if(result.error||result.data?.length!==1)throw failure('QUOTA_STATUS_UNAVAILABLE');
  }
  let value;
  try{value=await invoke();}catch(error){
    // Network/provider errors may have been billed: never refund or automatically re-send.
    try{await mark('unknown');}catch{throw failure('AI_REQUEST_RESULT_UNKNOWN');}
    throw error;
  }
  try{await mark(value?.code==='AI_REQUEST_RESULT_UNKNOWN'?'unknown':value?.ok===false?'failed':'completed');}
  catch{throw failure('AI_REQUEST_RESULT_UNKNOWN');}
  return value;
}
module.exports={reserveQuota,runWithQuota};
