-- Reference migration for a server-only, cross-instance attempt budget.
-- Adapt resource names in the project's versioned migration; do not execute automatically.
CREATE TABLE public.ai_usage (
  project_id text NOT NULL, subject_id text NOT NULL,
  day_utc date NOT NULL, attempts integer NOT NULL CHECK (attempts > 0),
  PRIMARY KEY (project_id, subject_id, day_utc)
);
ALTER TABLE public.ai_usage ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.ai_usage FROM PUBLIC, anon, authenticated;
GRANT SELECT, INSERT, UPDATE ON public.ai_usage TO service_role;
CREATE FUNCTION public.reserve_ai_attempt(p_project text,p_subject text,p_limit integer)
RETURNS boolean LANGUAGE plpgsql SECURITY INVOKER SET search_path=pg_catalog,public AS $$
DECLARE reserved integer;
BEGIN
  IF p_project IS NULL OR p_subject IS NULL OR p_limit <= 0 THEN RETURN false; END IF;
  INSERT INTO public.ai_usage AS quota(project_id,subject_id,day_utc,attempts)
  VALUES(p_project,p_subject,(CURRENT_TIMESTAMP AT TIME ZONE 'UTC')::date,1)
  ON CONFLICT(project_id,subject_id,day_utc) DO UPDATE SET attempts=quota.attempts+1
  WHERE quota.attempts < p_limit RETURNING attempts INTO reserved;
  RETURN reserved IS NOT NULL;
END $$;
REVOKE ALL ON FUNCTION public.reserve_ai_attempt(text,text,integer) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.reserve_ai_attempt(text,text,integer) TO service_role;
-- The function server derives project/subject/limit from trusted configuration.
-- Reserve BEFORE provider invocation; attempts remain counted on failure. Do not retry paid calls blindly.
