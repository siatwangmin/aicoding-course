// Server-only reusable adapter. No case names, credentials, resource IDs or frontend imports.
function failure(code) { return Object.assign(new Error(code), {code}); }
function createPrivatePg(sdk, options = {}) {
  const env=options.env || process.env.TCB_ENV;
  const accessKey=options.accessKey || process.env.CLOUDBASE_APIKEY;
  if(!env)throw failure('PROJECT_ENV_REQUIRED');
  if(!accessKey)throw failure('PG_SERVER_IDENTITY_REQUIRED');
  const app=sdk.init({env,accessKey});
  return {app,db:app.rdb({database:options.schema || 'public'})};
}
function requireEditor({uid,isAnonymous,projectId,authorizedProjectId,editorUids}) {
  if(!uid || isAnonymous !== false)throw failure('UNAUTHORIZED');
  if(!projectId || projectId !== authorizedProjectId || !Array.isArray(editorUids) || !editorUids.includes(uid))throw failure('FORBIDDEN');
}
async function readConfig(db, table, projectId) {
  if(!projectId || !/^[A-Za-z_][A-Za-z0-9_]*$/.test(table))throw failure('CONFIG_BINDING_REQUIRED');
  const {data,error}=await db.from(table).select('*').eq('project_id',projectId).limit(1);
  if(error)throw failure('AI_CONFIG_UNAVAILABLE');
  return data?.[0] || null;
}
async function saveModels({db,table,projectId,expectedRevision,textModel,visionModel,actor,validateModels}) {
  // actor must be derived from the trusted invocation; never pass event.uid/role/canEdit.
  requireEditor({...actor,projectId});
  if(!Number.isInteger(expectedRevision) || expectedRevision < 1)throw failure('REVISION_REQUIRED');
  const valid=id=>typeof id==='string' && /^[A-Za-z0-9._/-]{1,128}$/.test(id);
  if(!valid(textModel)||!valid(visionModel))throw failure('INVALID_MODEL');
  if(typeof validateModels!=='function'||await validateModels({textModel,visionModel})!==true)throw failure('MODEL_CAPABILITY_OR_COST_NOT_VERIFIED');
  await readConfig(db,table,projectId); // binding validation and fail-closed read
  const {data,error}=await db.from(table).update({text_model:textModel,vision_model:visionModel,revision:expectedRevision+1,updated_by:actor.uid,updated_at:new Date().toISOString()}).eq('project_id',projectId).eq('revision',expectedRevision).select('revision');
  if(error)throw failure('AI_CONFIG_WRITE_FAILED');
  if(!data?.length)throw failure('REVISION_CONFLICT');
  return {revision:data[0].revision};
}
module.exports={createPrivatePg,requireEditor,readConfig,saveModels};
