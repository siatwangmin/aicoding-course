// Server-only fallback for installed SDKs without rpc(). Bind at startup, never from event.
// Contract: CloudBase pgdb OpenAPI /v1/rdb/rest/rpc/{function_name}.
function createPgRpc({envId,apiKey,schema='public',fetchImpl=globalThis.fetch}){
  if(!/^[a-z0-9][a-z0-9-]{2,127}$/.test(envId||'')||!apiKey||!/^[a-z_][a-z0-9_]*$/.test(schema))throw new Error('PG_RPC_BINDING_REQUIRED');
  return async function rpc(name,args){
    if(!/^[a-z_][a-z0-9_]*$/.test(name))throw new Error('PG_RPC_FUNCTION_INVALID');
    const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),15000);
    try{
      const response=await fetchImpl(`https://${envId}.api.tcloudbasegateway.com/v1/rdb/rest/rpc/${name}`,{
        method:'POST',redirect:'error',signal:controller.signal,
        headers:{Authorization:`Bearer ${apiKey}`,'Content-Type':'application/json',Accept:'application/json','Accept-Profile':schema,'Content-Profile':schema},body:JSON.stringify(args)
      });
      if(!response.ok)return {error:{code:'PG_RPC_FAILED',status:response.status}};
      return {data:await response.json()};
    }catch{return {error:{code:'PG_RPC_UNAVAILABLE'}};}
    finally{clearTimeout(timer);}
  };
}
module.exports={createPgRpc};
