﻿#Requires -Version 5.1
function Get-CoursePagesConfiguration([string]$Gh,[string]$Repository,[string]$Branch,[string]$WorkingDirectory) {
    $r=Invoke-SetupNative $Gh @('api',('repos/'+$Repository+'/pages')) 30 $WorkingDirectory
    $body=if($r.Stdout){$r.Stdout}else{$r.Output}
    if($r.ExitCode -ne 0){
        if(($r.Output+' '+$r.Stderr) -match 'HTTP 404'){return $null}
        throw 'Pages configuration query failed; do not interpret authorization/network errors as an absent site.'
    }
    $page=$body|ConvertFrom-Json
    if($page.source.branch -cne $Branch -or $page.source.path -ne '/' -or $page.build_type -eq 'workflow'){
        throw 'Existing Pages source differs from the selected branch/root route; preserve it and resolve the project target before publishing.'
    }
    return $page
}
