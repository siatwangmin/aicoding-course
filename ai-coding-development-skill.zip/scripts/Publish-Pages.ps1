﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,[string]$HtmlPath,[string]$ResourceRoot,[switch]$Publish,[switch]$Recover)
$ErrorActionPreference='Stop'
. (Join-Path $env:USERPROFILE '.trae-cn\skills\ai-coding-env\scripts\Course-Runtime.ps1')
$ctx=Get-CourseProjectRuntime $ProjectDirectory -Start
. (Join-Path $PSScriptRoot 'Pages-Configuration.ps1')
$services=Read-CourseJson (Join-Path $ctx.Root '.ai-coding\services.json')
$repo=([string]$services.githubPages.repository) -replace '^https://github.com/',''
if($repo -notmatch '^[a-zA-Z0-9-]+/[a-zA-Z0-9._-]+$'){throw 'Confirmed dedicated static repository required.'}
$scripts=$PSScriptRoot;$recordPath=Join-Path $ctx.Root 'docs\progress\pages-publish.json'
if($Recover){
 $record=Read-CourseJson $recordPath
 if($record.repository -ne $repo -or -not $record.commit){throw 'No matching interrupted publication.'}
 $gh=(Get-Command gh.exe -ErrorAction Stop).Source;$out=$record.stagingDirectory;Assert-CoursePlainPath $out
 if(-not $out.StartsWith((Join-Path $ctx.Root '.local\pages-stage\'),[StringComparison]::OrdinalIgnoreCase)){throw 'Recorded static staging path invalid.'}
 if($record.branch -notmatch '^[a-zA-Z0-9/_-]+$'){throw 'Recorded branch missing; inspect the existing publication before recovery.'}
 $ref=Invoke-SetupNative $gh @('api',('repos/'+$repo+'/git/ref/heads/'+$record.branch),'--jq','.object.sha') 30 $ctx.Root
 if($ref.ExitCode -ne 0 -or $(if($ref.Stdout){$ref.Stdout}else{$ref.Output}).Trim() -ne $record.commit){throw 'Recorded commit is not the current remote branch head; preserve the publication and inspect official state.'}
 $configuration=Get-CoursePagesConfiguration $gh $repo $record.branch $ctx.Root
 if(-not $configuration){
  $body=Join-Path $out 'pages-request.json';Write-CourseJson $body @{source=@{branch=$record.branch;path='/'}}
  $enabled=Invoke-SetupNative $gh @('api',('repos/'+$repo+'/pages'),'--method','POST','--input',$body) 30 $ctx.Root
  if($enabled.ExitCode -ne 0){throw 'Pages enablement is not verified; inspect official state before recovery.'}
 }
 $status=Invoke-SetupNative $gh @('api',('repos/'+$repo+'/pages/builds/latest')) 30 $ctx.Root
 if($status.ExitCode -ne 0){throw 'Query current official Pages state; no new push performed.'}
 $build=$(if($status.Stdout){$status.Stdout}else{$status.Output})|ConvertFrom-Json
 if($build.commit -ne $record.commit -or $build.status -ne 'built'){throw 'Recorded commit has not finished deploying; no new push performed.'}
 $page=Invoke-SetupNative $gh @('api',('repos/'+$repo+'/pages'),'--jq','.html_url') 30 $ctx.Root
 if($page.ExitCode -ne 0){throw 'Official Pages URL unavailable.'};$url=$(if($page.Stdout){$page.Stdout}else{$page.Output}).Trim()
 $verified=Invoke-SetupNative $ctx.Cli ($ctx.Prefix+@('run','--rm','--mount',("type=bind,source=$out,target=/public,readonly"),'--mount',("type=bind,source=$scripts,target=/course,readonly"),'--entrypoint','node',$ctx.Project.image,'/course/publish-assets.mjs','verify','--url',$url,'--manifest','/public/course-publish.json')) 180 $ctx.Root
 if($verified.ExitCode -ne 0){throw 'Recorded deployment assets not verified; no new push performed.'}
 $record.status='assets-verified';$record|Add-Member -MemberType NoteProperty -Name url -Value $url -Force;$record.checkedAt=(Get-Date).ToString('o');Write-CourseJson $recordPath $record
 Write-Output ('Recovered and verified Pages assets: '+$url);exit 0
}
if(Test-Path -LiteralPath $recordPath){if((Read-CourseJson $recordPath).status -in @('push-started','pushed','deployment-pending')){throw 'Prior Pages publication is pending. Use -Recover before another push.'}}
if(-not $HtmlPath){throw 'Confirmed prototype HTML path required.'}
$html=(Resolve-Path -LiteralPath $HtmlPath).Path;Assert-CoursePlainPath $html
if(-not $ResourceRoot){$ResourceRoot=Split-Path $html -Parent};$ResourceRoot=(Resolve-Path -LiteralPath $ResourceRoot).Path;Assert-CoursePlainPath $ResourceRoot
if(-not $html.StartsWith($ResourceRoot.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Prototype must belong to the supplied public resource root.'}
$relativeHtml=$html.Substring($ResourceRoot.TrimEnd('\').Length+1).Replace('\','/')
$out=Join-Path $ctx.Root ('.local\pages-stage\'+[guid]::NewGuid().ToString('N'));Assert-CoursePlainPath $out;[void](New-Item -ItemType Directory -Path $out -Force)
$prepared=Invoke-SetupNative $ctx.Cli ($ctx.Prefix+@('run','--rm','--network','none','--mount',("type=bind,source=$ResourceRoot,target=/input,readonly"),'--mount',("type=bind,source=$out,target=/public"),'--mount',("type=bind,source=$scripts,target=/course,readonly"),'--entrypoint','node',$ctx.Project.image,'/course/publish-assets.mjs','static','--root','/input','--html',('/input/'+$relativeHtml),'--out','/public')) 90 $ctx.Root
if($prepared.ExitCode -ne 0){throw ('Static prototype preparation failed: '+$prepared.Output)}
$manifest=Read-CourseJson (Join-Path $out 'course-publish.json')
$record=@{schemaVersion=2;repository=$repo;status='prepared';buildId=$manifest.buildId;designSource=$html;stagingDirectory=$out;learnerTried='pending';checkedAt=(Get-Date).ToString('o')}
Write-CourseJson $recordPath $record
if(-not $Publish){Write-Output ('Static copy prepared: '+$out);exit 0}
$gh=(Get-Command gh.exe -ErrorAction Stop).Source;$git=(Get-Command git.exe -ErrorAction Stop).Source
function Invoke-PagesNative($Exe,[string[]]$Arguments,[int]$Timeout=60){$r=Invoke-SetupNative $Exe $Arguments $Timeout $ctx.Root;if($r.ExitCode -ne 0){throw 'GitHub publication operation failed; inspect official current state before retrying.'};return $(if($r.Stdout){$r.Stdout}else{$r.Output})}
[void](Invoke-PagesNative $gh @('auth','status'))
$identity=(Invoke-PagesNative $gh @('api','user','--jq','.login')).Trim()
if($identity -ine $repo.Split('/')[0]){throw 'Current GitHub identity differs from the course personal repository owner.'}
$branch=(Invoke-PagesNative $gh @('api',('repos/'+$repo),'--jq','.default_branch')).Trim()
if($branch -notmatch '^[a-zA-Z0-9/_-]+$'){throw 'Unsupported repository branch; preserve and inspect.'}
$configuration=Get-CoursePagesConfiguration $gh $repo $branch $ctx.Root
$checkout=Join-Path $ctx.Root ('.local\pages-repository-'+[guid]::NewGuid().ToString('N'));Assert-CoursePlainPath $checkout
[void](Invoke-PagesNative $git @('clone',('https://github.com/'+$repo+'.git'),$checkout) 180)
[void](Invoke-PagesNative $git @('-C',$checkout,'checkout','-B',$branch))
$oldManifest=Join-Path $checkout 'course-publish.json';$managed=@()
if(Test-Path -LiteralPath $oldManifest){$old=Read-CourseJson $oldManifest;$managed=@($old.files.PSObject.Properties.Name)+@('course-publish.json')}
$files=@($manifest.files.PSObject.Properties.Name)+@('course-publish.json')
$tracked=(Invoke-PagesNative $git @('-C',$checkout,'ls-files')).Split(@("`r`n","`n"),[StringSplitOptions]::RemoveEmptyEntries)
if(@($tracked|Where-Object {$managed -notcontains $_ -and $_ -notin @('README.md','LICENSE')}).Count){throw 'Unknown repository content preserved; select a dedicated course-managed static repository.'}
foreach($name in @($managed+$files|Select-Object -Unique)){
 $target=[IO.Path]::GetFullPath((Join-Path $checkout $name));Assert-CoursePlainPath $target
 if(-not $target.StartsWith($checkout+'\',[StringComparison]::OrdinalIgnoreCase) -or $name -match '[\x00-\x1f\x7f\\]|(^|/)\.(?!nojekyll$)'){throw 'Unsafe public repository path.'}
 if(Test-Path -LiteralPath $target){
  if($managed -notcontains $name){throw 'Unknown existing public content preserved; choose/confirm a dedicated managed target.'}
  if($name -ne 'course-publish.json' -and (Get-FileHash -LiteralPath $target).Hash.ToLowerInvariant() -ne $old.files.$name){throw 'Existing managed content changed independently; preserved.'}
 }
}
foreach($name in $managed){if($files -notcontains $name){$target=[IO.Path]::GetFullPath((Join-Path $checkout $name));if(Test-Path -LiteralPath $target){Remove-Item -LiteralPath $target -Force}}}
foreach($name in $files){$target=Join-Path $checkout $name;[void](New-Item -ItemType Directory -Path (Split-Path $target -Parent) -Force);Copy-Item -LiteralPath (Join-Path $out $name) -Destination $target -Force}
[void](Invoke-PagesNative $git (@('-C',$checkout,'add','--')+@($files+$managed|Select-Object -Unique)))
[void](Invoke-PagesNative $git @('-C',$checkout,'commit','-m',('Publish confirmed prototype '+$manifest.buildId)))
$commit=(Invoke-PagesNative $git @('-C',$checkout,'rev-parse','HEAD')).Trim();$record.commit=$commit;$record.branch=$branch;$record.status='push-started';Write-CourseJson $recordPath $record
[void](Invoke-PagesNative $git @('-C',$checkout,'push','origin',$branch) 180)
$record.status='pushed';Write-CourseJson $recordPath $record
if(-not $configuration){
 $body=Join-Path $out 'pages-request.json';Write-CourseJson $body @{source=@{branch=$branch;path='/'}}
 [void](Invoke-PagesNative $gh @('api',('repos/'+$repo+'/pages'),'--method','POST','--input',$body))
}
$url=(Invoke-PagesNative $gh @('api',('repos/'+$repo+'/pages'),'--jq','.html_url')).Trim()
if(-not $url.StartsWith('https://')){throw 'Official Pages URL unavailable.'}
$built=$false
for($i=0;$i -lt 12;$i++){
 $last=Invoke-SetupNative $gh @('api',('repos/'+$repo+'/pages/builds/latest')) 30 $ctx.Root
 if($last.ExitCode -eq 0){$build=$(if($last.Stdout){$last.Stdout}else{$last.Output})|ConvertFrom-Json;if($build.commit -eq $commit -and $build.status -eq 'built'){$built=$true;break};if($build.commit -eq $commit -and $build.status -eq 'errored'){throw 'Pages build failed for this commit.'}}
 Start-Sleep -Seconds 5
}
if(-not $built){$record.status='deployment-pending';$record.url=$url;Write-CourseJson $recordPath $record;Write-Output 'Push completed; current Pages deployment still pending. Query this commit before any retry.';exit 2}
$verified=Invoke-SetupNative $ctx.Cli ($ctx.Prefix+@('run','--rm','--mount',("type=bind,source=$out,target=/public,readonly"),'--mount',("type=bind,source=$scripts,target=/course,readonly"),'--entrypoint','node',$ctx.Project.image,'/course/publish-assets.mjs','verify','--url',$url,'--manifest','/public/course-publish.json')) 180 $ctx.Root
if($verified.ExitCode -ne 0){throw 'Pages deployed but exact public assets not verified.'}
$record.status='assets-verified';$record.url=$url;$record.checkedAt=(Get-Date).ToString('o');Write-CourseJson $recordPath $record
Write-Output ('Pages assets verified: '+$url+'; browser interaction and learner confirmation remain separate.')
