# AI Coding 实操课

**学员：解压资料包，双击根目录的 `index.html`。** 本工程入口是[课程网页](course/index.html)。

当前资料版本见 [VERSION.json](VERSION.json)，变化见 [更新记录](CHANGELOG.md)。每个正式版本都有固定资料包；在线旧版入口见 [版本下载](https://siatwangmin.github.io/aicoding-course/releases/course/)。

网页按七个阶段带你操作：环境准备、建立作品、需求与原型、本地网页、云端网页、安卓、AI。课前先准备工具、云服务和 GitHub 账号；已有作品从当前未完成步骤继续。

每步都写清：**在哪操作 → 这样做 → 复制发送 → 完成后 → 检查**。通过后再继续。

- 你看网页，Trae 读课程助手；准备阶段会安装助手，不用打开技能文件。
- 在 Gemini 写需求，在 Canvas 试页面；保存 `PRD.md` 和 `know-star.html`，交给 Trae 实现与测试。
- 每次增加功能，先更新需求和原型，再开发、亲自检查。
- 知错星是练习案例。工具可复用，做自己的作品时另建项目。

## 发给学员什么

发 [knowstar-student-kit.zip](knowstar-student-kit.zip) 即可。两个大安装包单独下载，按[安装包说明](installation-downloads.md)放好。资料不含成品、账号密码或 AI 凭证。

环境由 Trae 按 `setup-guide.md` 准备。学员处理需要本人完成的授权、条款和重启，最后检查报告是否显示“已完成”。

课前按网页“接好云服务”调用随包安装的云服务助手；注册、实名和授权在本人页面完成，配置与连接检查交给助手。还没有作品也可以准备，建立作品后由助手接入；V2 只检查和补齐缺项。单独安装助手也可让 Trae 读取 [setup-guide.md](setup-guide.md)，直接安装本地技能。

课前“准备 GitHub 账号”由注册陪练一步一步引导，已有账号直接复用并检查邮箱验证。V2 作品演示账号由助手准备，学员打开后直接练习保存和同步，不用设置账号或密码。
