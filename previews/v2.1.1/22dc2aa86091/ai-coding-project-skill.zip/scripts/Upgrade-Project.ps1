﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,[string]$PreparationDirectory)
$ErrorActionPreference='Stop'
$helper=Join-Path $env:USERPROFILE '.trae-cn\skills\ai-coding-env\scripts\Course-Context.ps1'
if(-not(Test-Path -LiteralPath $helper)){throw 'Restore user-level ai-coding-env first.'};. $helper
$root=(Resolve-Path -LiteralPath $ProjectDirectory).Path;Assert-CoursePlainPath $root
$manifest=Join-Path $root '.ai-coding\project.json'
if(-not(Test-Path -LiteralPath $manifest)){throw 'Agent must inspect this existing project and record its real sourceDirectory/runtime/image/appId before adoption. Do not run the empty-project generator.'}
$project=Read-CourseJson $manifest;$prepared=Find-CourseProjectPreparation $root $PreparationDirectory
if($project.image -ne $prepared.record.image -or $project.containerRuntime -ne $prepared.record.containerRuntime){throw 'Existing toolchain differs; preserve project and resolve compatibility before upgrade.'}
$source=[IO.Path]::GetFullPath((Join-Path $root $project.sourceDirectory));Assert-CoursePlainPath $source
if(($source -ne $root -and -not $source.StartsWith($root.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)) -or -not(Test-Path -LiteralPath $source -PathType Container) -or -not $project.appId){throw 'Existing source/appId not confirmed.'}
$backup=Join-Path $root ('.local\course-upgrades\'+[guid]::NewGuid().ToString('N'))
Assert-CoursePlainPath $backup;[void](New-Item -ItemType Directory -Path $backup -Force)
Copy-Item -LiteralPath $manifest -Destination (Join-Path $backup 'project.json')
$rootAgents=Join-Path $root 'AGENTS.md';Assert-CoursePlainPath $rootAgents
if(Test-Path -LiteralPath $rootAgents){Copy-Item -LiteralPath $rootAgents -Destination (Join-Path $backup 'AGENTS.root.md')}
$legacyDesign=Join-Path $source 'docs\design'
$designDirectory=if($project.designDirectory){$project.designDirectory}elseif(Test-Path -LiteralPath $legacyDesign){($project.sourceDirectory.TrimEnd('/','\')+'/docs/design')}else{'docs/design'}
$initStatus=if($project.schemaVersion -eq 2 -and $project.initializationStatus){$project.initializationStatus}else{'pending'}
foreach($item in @(@('schemaVersion',2),@('baselineVersion','2.1.1'),@('initializationStatus',$initStatus),@('designDirectory',$designDirectory))){$project|Add-Member -MemberType NoteProperty -Name $item[0] -Value $item[1] -Force}
if(-not $project.storageRoot){$project|Add-Member -MemberType NoteProperty -Name storageRoot -Value $prepared.record.storageRoot -Force}
$project|Add-Member -MemberType NoteProperty -Name preparationId -Value $prepared.record.preparationId -Force
$toolchain=@{imageDigest=$prepared.record.imageDigest;verificationMethod=$prepared.record.verificationMethod;imageId=$prepared.record.imageId;archiveSha256=$prepared.record.archiveSha256;verifiedAt=$prepared.record.verifiedAt}
$project|Add-Member -MemberType NoteProperty -Name toolchain -Value $toolchain -Force
if(-not $project.connection -and $prepared.record.connection){$project|Add-Member -MemberType NoteProperty -Name connection -Value $prepared.record.connection -Force}
$assets=Join-Path $PSScriptRoot '..\assets'
. (Join-Path $PSScriptRoot 'Install-ProjectGuidance.ps1')
Install-ProjectGuidance $root $backup
$servicesPath=Join-Path $root '.ai-coding\services.json'
if(-not(Test-Path -LiteralPath $servicesPath)){
    Write-CourseJson $servicesPath @{schemaVersion=2;githubPages=@{repository=$null;bindingStatus='pending';authorizationStatus='pending'};cloudbase=@{envId=$null;bindingStatus='pending';authorizationStatus='pending';clientStatus='pending'};ai=@{provider='siliconflow';credentialRef=$null;bindingStatus='pending';serviceStatus='pending'};android=@{skill='ai-coding-android';appId=$project.appId;preparationStatus='configured';buildStatus='pending';learnerTried='pending'}}
}
$progress=Join-Path $root 'docs\progress\current.md';Assert-CoursePlainPath $progress
if(-not(Test-Path -LiteralPath $progress)){
    [void](New-Item -ItemType Directory -Path (Split-Path $progress -Parent) -Force)
    [IO.File]::WriteAllText($progress,"# 工程接续`n`n旧作品增量接入 2.0，原需求和进度保持原位。服务当前授权与初始化门槛待检查，不代表功能重新完成。`n",[Text.UTF8Encoding]::new($false))
}
foreach($ignoreName in @('.gitignore','.dockerignore','.containerignore')){
    $ignore=Join-Path $root $ignoreName;Assert-CoursePlainPath $ignore
    $ignored=if(Test-Path -LiteralPath $ignore){[IO.File]::ReadAllText($ignore)}else{''}
    foreach($rule in @('.local/','.ai-coding/command.json','.ai-coding/web-build.json','.ai-coding/progress.json','.ai-coding/guidance-upgrade.json','.ai-coding/dependencies.json','.ai-coding/initialization-plan.json','.ai-coding/runtime-check.json','.ai-coding/local.json','.ai-coding/preparation.json','.ai-coding/initialization.json','.ai-coding/evidence/','.ai-setup/','.cloudbase-setup/','.github-setup/','.course-setup/','**/.env','**/.env.*','!**/.env.example')){if(@($ignored -split '\r?\n') -notcontains $rule){$ignored+="`n$rule`n"}}
    [IO.File]::WriteAllText($ignore,$ignored,[Text.UTF8Encoding]::new($false))
}
Write-CourseJson $manifest $project
Write-Output 'Existing project adopted. Source, identity, runtime and product rules preserved; run Connect-Project and actual initialization checks next.'
