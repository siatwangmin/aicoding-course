# 阶段执行、验证复用与可接续记录

按当前阶段读取，不把全课程资料每轮重新加载。A保存原始准备，用户级索引发现，B保存项目事实；从实际preparationId恢复，不猜默认目录。

新会话尚无当前检查或排障时用环境 Skill/scripts/Test-CourseReadiness.ps1 -ProjectDirectory <B> 一次核当前绑定、引擎/镜像和依赖；失败返回下一Skill/动作。依赖或Node版本错误先核执行位置，调用 Invoke-CourseProject -Action Repair，不能宿主安装或关engine约束。标准命令刚完成当前检查时直接接续，避免重复预检。所有项目脚本用 RunScript；构建、发布、Android继续既有入口。

调用环境 scripts/Update-CourseProgress.ps1 -ProjectDirectory <B> -Stage <本轮标识> -Objective <本轮目标> -NextAction <下一动作> 开始记录并定位具名Spec。重新开始同名阶段用 -NewRun；本人试用等待沿同一轮继续计时。新建Spec只填事实和目标，由助手按模板补本轮有序步骤/恢复，不能把初建文档当方案已完成。方案记录决定，镜像/依赖/产物事实引用脚本证据，避免手抄大报告。

长等待按 -Status waiting -WaitKind download|migration|deployment|model|learner|diagnosis 记录原因；完成动作后接续同阶段。技术完成用 -Status verified -EvidencePath <B内实际结果>；本人/手机未试用 learner-pending。该记录是接续，不代替证据内容核验。当前状态在 .ai-coding/progress.json，追加历史在 .local/course-execution.jsonl，不覆写用户的进度备注。

## 复用与失效

已有准备、镜像、健康容器与Linux卷直接复用；包清单/锁文件未变不重装。源码、依赖、镜像、服务绑定、授权、产物或版本变化时只重验受影响范围；不能以缓存跳过当前引擎/挂载、授权、正式网址内容或真实会话权限核验。更换Key/模型也要验证实际配置与路由；模型配置变化不自动重打APK。旧通过和本次失败分别保存。

版本适配先读实际锁文件与工程实现。PG schema、图片签名URL返回字段、CAS更新返回行和CLI参数使用已验证方法；从当前官方接口核差异，普通修复不升级主版本。发布先固定真实dist/资源清单，云端Updating时查原任务终态，不反复提交。Pages沿Publish-Pages.ps1及Recover，CloudBase沿已验证官方路线和Publish-CloudBase产物检查。

## 稳定浏览器验证

按当前可见容器与控件定位，用label/role或案例测试ID；同名toast不能代替新增卡片，3D翻牌后操作可见面。等待真实保存完成/回读/可见状态，不靠固定延时刷绿；立即刷新丢数据可能是产品缺陷，必须辨别。失败保存截图、当前状态和首个错误，修后先跑相关用例；保留阶段必要验收。会话恢复、两独立会话、匿名拒绝、多用户隔离、SQL管理员操作分别说明，不能互相替代。业务未要求删除UI时记不适用，不能SQL删行冒充应用删除通过。

## 时间与等待

读assets/course-timing.json报告首次/复用及迁移范围。入口自动记录命令真实起止/耗时，包括预检失败；阶段时间使用真实时钟，不手填未来时间、不用日志字数或文件mtime推算。下载/搬盘/平台/本人等待与排障分开；并发窗口不重复累计。相同条件2—3次无新证据停止重复尝试，转最小探针并保存排除项，继续独立工作。阶段结束/会话中断更新Spec、current及下一动作，不能因超时降低权限或省验收。
