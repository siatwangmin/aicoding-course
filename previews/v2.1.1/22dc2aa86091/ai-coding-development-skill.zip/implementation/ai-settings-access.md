# AI 设置接入：用户授权与后端数据库身份

V4 开发/恢复设置时读取，配合 model-settings.md、ai-service-setup.md。这里给通用方法；案例用户名、UID、环境、表和函数由项目事实或明确选定案例提供。

## 先区分三种凭证与两层身份

Publishable Key 用于公开客户端连接；CloudBase API Key 用于后端 PG 服务访问；硅基流动 API Key 用于模型调用。本人在程序填写的是模型 Key。后两种秘密只在受保护后端使用，管理查询也不得打印 Token、完整 JWT、headers、env/event/context。

调用者的应用身份决定能否使用功能、编辑配置；函数的数据库服务身份决定能否访问私有配置表。两者独立。不能根据 client_server、is_system_admin、部署 Active 或管理工具可查数据推断实际 PG 角色。

已验证参考：Node SDK 3.18.3 的既有工程，通过服务端 CLOUDBASE_APIKEY 和 init({env,accessKey:process.env.CLOUDBASE_APIKEY}) 访问 PG，rdb({database:'public'}) 显式设置实际 schema。读取实际 SDK/环境后适配，不能盲目升级或把一个版本的默认凭证行为泛化。官方依据：[PG 身份](https://docs.cloudbase.net/authentication-v2/auth/auth-pg)、[Node 初始化](https://docs.cloudbase.net/en/api-reference/server/node-sdk/initialization)。

## 实施顺序

1. 在本轮 Spec 记录绑定环境、实际 SDK/函数类型、schema/表结构、projectId、真实应用 UID、配置编辑者及授权依据。管理授权不代替应用登录。
2. 按项目已确认身份策略选择配置编辑者；明确案例允许指定课程用户配置时，助手核真实登录 UID 并在服务端绑定，不另建管理员课堂流程。未选案例不预置演示用户；未授权用户、匿名和其他项目用户仍拒绝。
3. 私有配置使用验证过的后端访问身份。可复用 assets/private-ai-config.cjs 的适配方法，部署时安全合并原环境配置，保留有效供应商 Key/加密材料。缺服务身份明确失败，不能悄悄使用另一种凭证。不能以 Git 忽略目录为理由落明文临时配置。
4. 用实际部署函数先完成无秘密的配置读取、受控写入和回读；验证客户端直访私有表被拒。业务数据继续用用户会话/RLS，不能全部升级管理权限。service_role 绕过 RLS，函数必须另核调用者、指定编辑者、项目归属并约束每条查询的项目范围。
5. 实现读取公开模型/revision/来源/canEdit，模型保存、Key更新、恢复默认和连接测试分别处理。模型按可用性、任务能力及费用范围验证后再激活；设置打开不付费试调用。CAS 带 expectedRevision 并显式 .select('revision')，无返回行时先核 SDK 语义，不能无条件再写。
6. 接程序遮罩输入，由本人填写 Key、选择模型，真实保存后重开设置回读。Key 在数据库加密，解密材料分开。恢复默认保留 Key；失败保留旧有效配置，超时先查原状态。旧环境 Key 来源准确标注，不把沿用旧 Key 当成本人已保存新 Key。
7. 业务函数只读共享有效模型/revision；常规验证用替身，最小真实请求在费用授权内。持久限额先于付费请求，可参考 assets/private-ai-quota.sql 的原子配额方法并按版本迁移接入；单实例 Map 不能当全环境限额。
8. 两独立网页读取同配置；APK 已有设置时换模型无需重打包。前端/原生内容更新才构建新 APK，安装、同步、本人试用单独记录。

## 权限与失败恢复

| 情况 | 下一步 |
| --- | --- |
| 指定课程用户设置只读 | 核当前真实 UID、环境、服务端编辑者配置和部署终态；按已确认案例授权恢复，不能只改前端 canEdit |
| permission denied | 核函数数据库服务身份，再查表 ACL/GRANT/RLS；用同后端路径回读。禁止猜角色轮流放权、开放 anon 或关闭 RLS |
| 保存成功却报冲突 | 查返回行语义、实际 revision；修 CAS 返回，不降低 revision 或反复无条件写 |
| 配置读取失败 | 返回配置阶段错误，保留输入；不引导充值/重注册/开内置AI，不把读取失败当首次未配置 |
| Key保存失败 | 核真实编辑权、加密材料、CAS；不打印 Key 或用假 Key 覆盖有效值 |
| 已保存模型未生效 | 查共享读取、缓存失效和函数实际模型/revision，不改页面标签伪装完成 |

同条件2—3次失败没有新证据时，转最小探针并保存已排除项，继续可独立完成的工作。新设置权限、后端访问、真实保存、模型输出、手机和本人试用分别留证；替身收到 accessKey 不证明真实网关角色正确。
