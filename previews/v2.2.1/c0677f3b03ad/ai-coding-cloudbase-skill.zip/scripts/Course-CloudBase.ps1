#Requires -Version 5.1
# Result adapter only. It never searches credential files or changes the selected environment.
function Assert-CourseCloudBaseEnvironmentValues {
    param([Parameter(Mandatory=$true)][System.Collections.IDictionary]$Values)
    foreach($name in $Values.Keys){
        if([string]$Values[$name] -match '^\s*(\*{3,}|<redacted>|\[redacted\])\s*$'){throw 'MASKED_ENVIRONMENT_VALUES_CANNOT_BE_WRITTEN'}
    }
    # No values or names are returned. Use only with protected actual server configuration.
}
function ConvertFrom-CourseCloudBaseResult {
    param($Result,[scriptblock]$SuccessPredicate,[scriptblock]$VerifyOutcome)
    $payload=$null;$parsed=$false
    $output=if($Result.Stdout){[string]$Result.Stdout}else{[string]$Result.Output}
    try{$payload=ConvertFrom-Json -InputObject $output -ErrorAction Stop;$parsed=$true}catch{}
    $businessError=$parsed -and (($payload.error -and $payload.error -ne $false) -or ($payload.success -eq $false) -or ($null -ne $payload.code -and [string]$payload.code -notin @('0','SUCCESS','Success','OK','200')))
    $authRequired=([string]$Result.Output -match '(?i)NOT_LOGGED_IN|LOGIN_REQUIRED|UNAUTHORIZED|请先登录')
    $status=if($authRequired){'authorization-required'}elseif($businessError){'failed'}elseif($Result.TimedOut){'outcome-unknown'}elseif($Result.ExitCode -eq 0 -and $parsed -and $SuccessPredicate -and (& $SuccessPredicate $payload)){'verified'}elseif($Result.ExitCode -eq 0){'outcome-unknown'}else{'outcome-unknown'}
    # A second, actual read-only query may confirm a nonzero/unknown result. JSON alone cannot.
    $confirmed=$false
    if($status -eq 'outcome-unknown' -and $VerifyOutcome){
        $check=& $VerifyOutcome
        if($check -and $check.status -eq 'verified' -and $check.targetMatched -eq $true -and $check.readOnly -eq $true){$status='verified';$confirmed=$true}
    }
    # Do not return the raw CLI/MCP payload: management responses may contain credentials.
    return [pscustomobject]@{status=$status;exitCode=$Result.ExitCode;timedOut=[bool]$Result.TimedOut;jsonParsed=$parsed;businessError=[bool]$businessError;independentlyConfirmed=$confirmed;nextAction=$(switch($status){verified{'Continue the original operation.'}authorization-required{'Restore the recorded official login route.'}failed{'Inspect the specific business error through the official tool.'}default{'Query the original resource/task read-only before retrying any write.'}})}
}
function Get-CourseCloudBaseCapabilities {
    param([string]$CliPath,[string]$Workspace,[scriptblock]$Run)
    if(-not(Test-Path -LiteralPath $CliPath -PathType Leaf)){throw 'RECORDED_CLOUDBASE_CLI_REQUIRED'}
    $path=(Resolve-Path -LiteralPath $CliPath).Path
    if([IO.Path]::GetExtension($path) -notin @('.exe','.ps1')){throw 'OFFICIAL_EXE_OR_POWERSHELL_ENTRY_REQUIRED'}
    if(-not $Run){throw 'NATIVE_RUNNER_REQUIRED'}
    $version=& $Run $path @('--version')
    $help=& $Run $path @('--help')
    if($version.ExitCode -ne 0 -or $help.ExitCode -ne 0){throw 'CLOUDBASE_VERSION_OR_HELP_UNAVAILABLE'}
    $v=[regex]::Match([string]$version.Output,'\b\d+\.\d+\.\d+(?:[-+][a-zA-Z0-9.-]+)?\b').Value
    if(-not $v){throw 'CLOUDBASE_VERSION_UNRECOGNIZED'}
    return [pscustomobject]@{path=$path;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant();version=$v;checkedAt=[datetimeoffset]::UtcNow.ToString('o');scope='capabilities-only';envAdvertised=([string]$help.Output -match '(?m)\benv\b');fnAdvertised=([string]$help.Output -match '(?m)\bfn\b');nextAction='Read the current subcommand help, then verify actual target access. No login or permission has been inferred.'}
}
