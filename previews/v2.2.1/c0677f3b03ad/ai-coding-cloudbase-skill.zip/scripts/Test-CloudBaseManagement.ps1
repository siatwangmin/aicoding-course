#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$CliPath,[Parameter(Mandatory=$true)][string]$WorkingDirectory)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-CloudBase.ps1')
$native=Join-Path (Split-Path (Split-Path $PSScriptRoot -Parent) -Parent) 'ai-coding-env\scripts\Course-Native.ps1'
if(-not(Test-Path -LiteralPath $native)){throw 'INSTALLED_COURSE_NATIVE_RUNNER_REQUIRED'}
. $native
$runner={param($path,$arguments)
    if([IO.Path]::GetExtension($path) -eq '.ps1'){
        Invoke-SetupNative (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') (@('-NoProfile','-File',$path)+$arguments) 30 $WorkingDirectory
    }else{Invoke-SetupNative $path $arguments 30 $WorkingDirectory}
}
$result=Get-CourseCloudBaseCapabilities $CliPath $WorkingDirectory $runner
$root=(Resolve-Path -LiteralPath $WorkingDirectory).Path
Assert-CoursePlainPath $root
Write-CourseJson (Join-Path $root '.cloudbase-setup\management-capabilities.json') $result
$result|ConvertTo-Json
