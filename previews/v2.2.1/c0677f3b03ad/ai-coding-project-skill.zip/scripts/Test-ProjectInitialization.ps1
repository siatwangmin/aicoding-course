﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,[ValidateSet('Check','Record')][string]$Action='Check',
      [ValidateSet('github','githubPages','cloudbase','ai','android','browser','rules')][string]$Service,[string]$EvidencePath,[ValidateSet('Initialization','Capability')][string]$Scope='Initialization')
$ErrorActionPreference='Stop'
. (Join-Path $env:USERPROFILE '.trae-cn\skills\ai-coding-env\scripts\Course-Runtime.ps1')
. (Join-Path $env:USERPROFILE '.trae-cn\skills\ai-coding-env\scripts\Course-Storage.ps1')
$root=(Resolve-Path -LiteralPath $ProjectDirectory).Path;Assert-CoursePlainPath $root
$p=Read-CourseJson (Join-Path $root '.ai-coding\project.json');$services=Read-CourseJson (Join-Path $root '.ai-coding\services.json')
$required=@{github=@('identityVerified','authorizationVerified','targetVerified');githubPages=@('identityVerified','authorizationVerified','targetVerified');cloudbase=@('envIdVerified','managementAccessVerified','clientConfigVerified');ai=@('credentialDecrypted','serviceEvidenceVerified','feesScopeKnown');android=@('configVerified','toolchainVerified');rules=@('projectEntryObserved','skillsObserved');browser=@('pageSeen','hotReloadVerified')}
if($services.ai.setupMode -eq 'application-settings'){$required.ai=@('defaultModelsVerified','configurationRouteRecorded')}
function Convert-CourseCanonical($Value){
 if($null -eq $Value){return $null}
 if($Value -is [System.Collections.IDictionary]){$r=[ordered]@{};foreach($k in @($Value.Keys|Sort-Object)){$r[$k]=Convert-CourseCanonical $Value[$k]};return $r}
 if($Value -is [System.Management.Automation.PSCustomObject]){$r=[ordered]@{};foreach($k in @($Value.PSObject.Properties.Name|Sort-Object)){$r[$k]=Convert-CourseCanonical $Value.$k};return $r}
 if($Value -is [array]){return ,@($Value|ForEach-Object {Convert-CourseCanonical $_})};return $Value
}
function Test-CurrentEvidence($e,[string]$Name){
 try{$age=((Get-Date)-[datetime]::Parse($e.checkedAt)).TotalHours}catch{return $false}
 return $e.status -eq 'verified' -and $age -ge 0 -and $age -le 24 -and @($e.evidence).Count -gt 0 -and @($required[$Name]|Where-Object {$e.checks.$_ -ne $true}).Count -eq 0
}
function Get-ServiceBinding([string]$Name){
 if($Name -eq 'rules'){
  $buffer=[IO.MemoryStream]::new();$sha=[Security.Cryptography.SHA256]::Create()
  try{foreach($relative in @('AGENTS.md','.trae/rules/course-entry.md','docs/engineering/workflow.md')){$bytes=[IO.File]::ReadAllBytes((Join-Path $root $relative));$buffer.Write($bytes,0,$bytes.Length)};$hash=([BitConverter]::ToString($sha.ComputeHash($buffer.ToArray()))).Replace('-','').ToLowerInvariant()}finally{$buffer.Dispose();$sha.Dispose()}
  return @{image=$p.image;port=$p.port;guidanceSha256=$hash}
 }
 if($Name -eq 'browser'){return @{image=$p.image;port=$p.port}}
 if($Name -eq 'ai' -and $services.ai.setupMode -eq 'application-settings'){
  $file=Join-Path $root 'config\ai-models.defaults.json';$models=Read-CourseJson $file
  if(-not $models.textModel -or -not $models.visionModel){throw 'DEFAULT_MODELS_REQUIRED'}
  return @{setupMode='application-settings';defaultModelsSha256=(Get-FileHash -LiteralPath $file).Hash.ToLowerInvariant()}
 }
 return $services.$Name
}
if($Action -eq 'Record'){
 if(-not $Service -or -not $EvidencePath){throw 'Actual service evidence and name required.'}
 $e=Read-CourseJson $EvidencePath;if(-not(Test-CurrentEvidence $e $Service)){throw 'Incomplete/outdated evidence not recorded.'}
 $binding=Get-ServiceBinding $Service
 if(($Service -in @('github','githubPages') -and $binding.repository -notmatch '^(https://github.com/)?[a-zA-Z0-9-]+/[a-zA-Z0-9._-]+$') -or ($Service -eq 'cloudbase' -and -not $binding.envId) -or ($Service -eq 'ai' -and $binding.setupMode -ne 'application-settings' -and -not $binding.credentialRef) -or ($Service -eq 'android' -and $binding.appId -ne $p.appId)){throw 'Service binding missing.'}
 $e|Add-Member -MemberType NoteProperty -Name binding -Value $binding -Force
 $e|Add-Member -MemberType NoteProperty -Name toolchainImage -Value $p.image -Force
 Write-CourseJson (Join-Path $root ('.ai-coding\evidence\'+$Service+'.json')) $e
 Write-Output 'Actual evidence recorded; this is not overall initialization acceptance.';exit 0
}
if($Scope -eq 'Capability' -and $Service -notin @('github','githubPages','cloudbase','ai','android')){throw 'EXPLICIT_CAPABILITY_SERVICE_REQUIRED'}
$missing=@();if($Scope -eq 'Initialization'){
$upgradeReport=Join-Path $root '.ai-coding/guidance-upgrade.json';if(Test-Path -LiteralPath $upgradeReport){if((Read-CourseJson $upgradeReport).status -ne 'updated'){$missing+='custom-guidance-merge'}}
try{$ctx=Get-CourseProjectRuntime $root -Start}catch{$missing+='current-runtime'}
$storageRoot=if($p.storageRoot){$p.storageRoot}else{'D:\AI-Practice'}
try{$storage=Test-CourseStorageLocation $root $p.containerRuntime $storageRoot;if($storage.status -ne 'verified'){$missing+='actual-storage-location'}}catch{$missing+='actual-storage-location'}
try{$page=Invoke-WebRequest -UseBasicParsing -Uri ('http://127.0.0.1:'+$p.port) -TimeoutSec 5;if($page.StatusCode -ne 200){$missing+='local-page'}}catch{$missing+='local-page'}
}
$names=if($Scope -eq 'Capability'){@($Service)}else{@('browser','rules')}
foreach($name in $names){
 try{
  $e=Read-CourseJson (Join-Path $root ('.ai-coding\evidence\'+$name+'.json'))
  $a=(Convert-CourseCanonical $e.binding)|ConvertTo-Json -Depth 20 -Compress
  $b=(Convert-CourseCanonical (Get-ServiceBinding $name))|ConvertTo-Json -Depth 20 -Compress
  if(-not(Test-CurrentEvidence $e $name) -or $e.toolchainImage -ne $p.image -or $a -cne $b){throw 'Evidence binding changed.'}
 }catch{$missing+=($name+'-current-check')}
}
if($Scope -eq 'Capability' -and $Service -eq 'ai' -and $services.ai.setupMode -ne 'application-settings' -and $services.ai.credentialRef){
 try{
  $vault=Read-CourseJson (Join-Path (Get-CourseUserRoot) 'credentials\siliconflow-course-default.json')
  if(-not $services.ai.credentialRevision -or $vault.revision -ne $services.ai.credentialRevision -or $vault.userSid -ne [Security.Principal.WindowsIdentity]::GetCurrent().User.Value){throw 'Credential revision/owner changed.'}
 }catch{$missing+='credential-binding-refresh'}
}
$result=@{schemaVersion=2;checkedAt=(Get-Date).ToString('o');status=$(if($missing.Count){'pending'}else{'verified'});missing=$missing;scope=$Scope}
if($Scope -eq 'Capability'){Write-CourseJson (Join-Path $root ('.ai-coding\capabilities\'+$Service+'.json')) $result;$result|ConvertTo-Json;if($missing.Count){exit 2};exit 0}
Write-CourseJson (Join-Path $root '.ai-coding\initialization.json') $result
$p.initializationStatus=$result.status;Write-CourseJson (Join-Path $root '.ai-coding\project.json') $p
$current=Join-Path $root 'docs\progress\current.md'
if(Test-Path -LiteralPath $current){$text=[IO.File]::ReadAllText($current);$old='工程已生成；本地构建、起始网页、热更新与规则加载待检查。外部能力按需求在对应阶段接入。';if($text.Contains($old)){$new=if($result.status -eq 'verified'){'初始化技术检查通过；业务开发和本人试用分别记录。下一步按已确认设计维护本轮Spec。'}else{'初始化仍有待办：'+($missing -join '、')+'；助手沿原入口接续。'};[IO.File]::WriteAllText($current,$text.Replace($old,$new),[Text.UTF8Encoding]::new($false))}}
Write-CourseEvent $root @{stage='P-01';action='InitializationCheck';status=$result.status;evidence='.ai-coding/initialization.json'}
$result|ConvertTo-Json
if($missing.Count){exit 2}
