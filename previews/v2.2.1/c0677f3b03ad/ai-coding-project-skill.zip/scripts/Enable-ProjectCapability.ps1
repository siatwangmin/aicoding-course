#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,
      [Parameter(Mandatory=$true)][ValidateSet('github','github-pages','cloudbase','android','ai')][string]$Capability,
      [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$Reason,
      [string]$PreparationDirectory)
$ErrorActionPreference='Stop'
$context=Join-Path $env:USERPROFILE '.trae-cn\skills\ai-coding-env\scripts\Course-Context.ps1'
. $context
. (Join-Path (Split-Path $context -Parent) 'Course-ProjectRoot.ps1')
$root=Resolve-CourseProjectRoot $ProjectDirectory
$projectPath=Join-Path $root '.ai-coding\project.json';$project=Read-CourseJson $projectPath
$source=[IO.Path]::GetFullPath((Join-Path $root $project.sourceDirectory));Assert-CoursePlainPath $source
$servicesPath=Join-Path $root '.ai-coding\services.json';$services=Read-CourseJson $servicesPath
$selected=@($Capability);if($Capability -eq 'ai'){$selected=@('cloudbase','ai')}
$mapping=@{'github'='github';'github-pages'='githubPages';'cloudbase'='cloudbase';'android'='android';'ai'='ai'}
foreach($name in $selected){
    $key=$mapping[$name]
    if(-not $services.$key){
        $value=switch($name){
            github {@{repository=$null;bindingStatus='pending';authorizationStatus='pending';purpose='source-code'}}
            github-pages {@{repository=$null;bindingStatus='pending';authorizationStatus='pending';purpose='static-site'}}
            cloudbase {@{envId=$null;bindingStatus='pending';authorizationStatus='pending';clientStatus='pending'}}
            android {@{skill='ai-coding-android';appId=$project.appId;preparationStatus='pending';buildStatus='pending';learnerTried='pending'}}
            ai {@{provider='siliconflow';setupMode='application-settings';credentialRef=$null;bindingStatus='pending';serviceStatus='pending'}}
        }
        $services|Add-Member NoteProperty $key ([pscustomobject]$value)
    }
    $services.$key|Add-Member NoteProperty requestedReason (Protect-CourseOutput $Reason) -Force
}
if($Capability -eq 'ai'){
    $defaults=Join-Path $root 'config\ai-models.defaults.json';Assert-CoursePlainPath $defaults
    if(-not(Test-Path -LiteralPath $defaults)){[void](New-Item -ItemType Directory -Path (Split-Path $defaults -Parent) -Force);Copy-Item -LiteralPath (Join-Path $PSScriptRoot '..\assets\default-models.json') -Destination $defaults}
}
if($Capability -eq 'android'){
    $config=Join-Path $source 'capacitor.config.ts';Assert-CoursePlainPath $config
    if(-not(Test-Path -LiteralPath $config)){
        $body=@{appId=$project.appId;appName=$project.name;webDir=$project.android.webDir;server=@{hostname='localhost';androidScheme='https'}}|ConvertTo-Json -Depth 5
        [IO.File]::WriteAllText($config,"import type { CapacitorConfig } from '@capacitor/cli';`nconst config: CapacitorConfig = $body;`nexport default config;`n",[Text.UTF8Encoding]::new($false))
    }
}
$capabilities=@(@('local')+@($project.capabilities)+$selected|Where-Object {$_}|Select-Object -Unique)
$project|Add-Member NoteProperty capabilities $capabilities -Force
$project|Add-Member NoteProperty capabilityMode 'on-demand' -Force
Write-CourseJson $servicesPath $services;Write-CourseJson $projectPath $project
& (Join-Path $PSScriptRoot 'Connect-Project.ps1') -ProjectDirectory $root -PreparationDirectory $PreparationDirectory -Services @($selected|ForEach-Object {$mapping[$_]})|Out-Host
$next=switch($Capability){github{@('ai-coding-github')}github-pages{@('ai-coding-github')}cloudbase{@('ai-coding-cloudbase')}android{@('ai-coding-android')}ai{@('ai-coding-cloudbase','ai-coding-siliconflow')}}
Write-CourseEvent $root @{stage='capability';action=('Enable-'+$Capability);status='pending';nextAction=($next -join ',')}
[pscustomobject]@{status='pending';capability=$Capability;reason=(Protect-CourseOutput $Reason);selected=$selected;nextSkills=@($next);nextAction='Continue the requested capability Skill in this task; inspect current bindings and authorization. No remote resource or APK was created by this entry.'}|ConvertTo-Json -Depth 5
