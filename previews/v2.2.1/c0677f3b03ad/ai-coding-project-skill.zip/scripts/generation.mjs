// Transactional generation: preserve design-only folders and resume an interrupted copy.
import { mkdir, readdir, readFile, writeFile, lstat, cp } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { createHash } from 'node:crypto';
import { plainPath, within } from './project-context.mjs';
const hash = b => createHash('sha256').update(b).digest('hex');
async function exists(path) { try { await lstat(path); return true; } catch (e) { if(e.code==='ENOENT')return false;throw e; } }
export async function beginGeneration(root, binding) {
  await plainPath(root); await mkdir(root,{recursive:true});
  if(await exists(join(root,'.ai-coding/project.json')))throw new Error('EXISTING_PROJECT_USE_UPGRADE');
  const journal=join(root,'.local/course-generation/state.json');
  const stage=join(root,'.local/course-generation/staging');
  if(await exists(journal)){
    const state=JSON.parse(await readFile(journal,'utf8'));
    if(state.image!==binding.image||state.runtime!==binding.runtime||state.port!==binding.port)throw new Error('GENERATION_BINDING_CONFLICT');
    if(!['ready','preparing'].includes(state.status))throw new Error('GENERATION_STATE_REQUIRES_INSPECTION');
    return {root,stage,journal,state,resume:state.status==='ready',designDirectory:state.designDirectory};
  }
  for(const name of await readdir(root)){
    const path=await plainPath(join(root,name));
    if(name==='.local'){
      if((await readdir(path)).some(n=>!['course-execution.jsonl','course-command.log'].includes(n)))throw new Error('EXISTING_LOCAL_FILES_PRESERVED');
      continue;
    }
    if(['design','docs'].includes(name)){
      if(!(await lstat(path)).isDirectory())throw new Error('EXISTING_WORK_REQUIRES_ADOPTION');
      if(name==='docs'&&(await readdir(path)).some(n=>n!=='design'))throw new Error('EXISTING_DOCS_PRESERVED');
      continue;
    }
    if(name==='.env'&&(await readFile(path)).length===0)continue;
    if(/^(?:PRD\.md|[^.][^/\\]*\.html)$/i.test(name)&&(await lstat(path)).isFile())continue;
    throw new Error('EXISTING_WORK_REQUIRES_ADOPTION: '+name);
  }
  const designDirectory=await exists(join(root,'design'))?'design':await exists(join(root,'PRD.md'))?'.':'docs/design';
  await mkdir(stage,{recursive:true});
  const state={...binding,designDirectory,status:'preparing'};
  await writeFile(journal,JSON.stringify(state,null,2));
  return {root,stage,journal,state,resume:false,designDirectory};
}
async function inventory(root, rel='') {
  const result=[];
  for(const entry of await readdir(join(root,rel),{withFileTypes:true})){
    const name=rel?`${rel}/${entry.name}`:entry.name;
    await plainPath(join(root,name));
    if(entry.isDirectory())result.push(...await inventory(root,name));
    else if(entry.isFile())result.push({path:name,sha256:hash(await readFile(join(root,name)))});
    else throw new Error('GENERATION_LINK_REFUSED');
  }
  return result;
}
export async function commitGeneration(generation) {
  const {root,stage,journal}=generation;
  let state=generation.state;
  if(!generation.resume){state={...state,status:'ready',files:await inventory(stage)};await writeFile(journal,JSON.stringify(state,null,2));}
  // Validate all collisions before copying anything. Existing design files are not generated.
  for(const item of state.files){
    const source=within(stage,item.path),dest=within(root,item.path);
    await plainPath(source);await plainPath(dest);
    if(hash(await readFile(source))!==item.sha256)throw new Error('GENERATION_STAGE_CHANGED');
    if(await exists(dest)){
      const bytes=await readFile(dest);
      if(hash(bytes)!==item.sha256&&!(item.path==='.env'&&bytes.length===0))throw new Error('GENERATION_COLLISION_PRESERVED: '+item.path);
    }
  }
  const ordered=[...state.files].sort((a,b)=>(a.path==='.ai-coding/project.json')-(b.path==='.ai-coding/project.json'));
  for(const item of ordered){const dest=within(root,item.path);await mkdir(dirname(dest),{recursive:true});await cp(within(stage,item.path),dest);}
  for(const rel of ['docs/design','docs/progress','docs/specs','app/docs/design','app/docs/progress'])await mkdir(join(root,rel),{recursive:true});
  await writeFile(journal,JSON.stringify({...state,status:'committed',finishedAt:new Date().toISOString()},null,2));
}
