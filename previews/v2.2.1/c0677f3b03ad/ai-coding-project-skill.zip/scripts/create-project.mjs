#!/usr/bin/env node
// Run with the prepared toolchain container; no host npm install is needed.
import { access, cp, mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import { beginGeneration, commitGeneration } from './generation.mjs';

const args = process.argv.slice(2);
const option = (key, fallback) => {
  const index = args.indexOf(key);
  if (index < 0) return fallback;
  if (!args[index + 1] || args[index + 1].startsWith('--')) throw new Error(`Missing value: ${key}`);
  return args[index + 1];
};
const requestedTarget = resolve(option('--target', '/project'));
let target = requestedTarget;
const template = resolve(option('--template', '/opt/knowstar/template'));
const name = option('--name', '我的作品');
const nameSource = args.includes('--name') ? 'user' : 'placeholder';
let slug = option('--slug', `aicoding-${randomUUID().slice(0, 8)}`);
const image = option('--image', '');
const preparationPath = option('--preparation', '');
let preparation = null;
if (preparationPath) {
  preparation = JSON.parse((await readFile(resolve(preparationPath), 'utf8')).replace(/^\uFEFF/, ''));
  if (preparation.schemaVersion !== 2 || !preparation.verifiedAt || preparation.image !== image) throw new Error('Preparation image mismatch or unverified');
}
const containerRuntime = option('--runtime', preparation?.containerRuntime || 'podman');
if (!['docker', 'podman'].includes(containerRuntime)) throw new Error('Invalid container runtime');
const networkMode = option('--network-mode', 'pasta');
if (!['pasta', 'bridge'].includes(networkMode)) throw new Error('Invalid network mode');
const port = Number(option('--port', '5187'));
if (!/^[a-z][a-z0-9-]{1,47}$/.test(slug)) throw new Error('Invalid project slug');
if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('Invalid port');
if (!image) throw new Error('The prepared image reference is required');
if (process.versions.node !== '22.12.0') throw new Error('Use the prepared toolchain Node 22.12.0');
if (preparation && preparation.containerRuntime !== containerRuntime) throw new Error('Preparation runtime conflict');
await access(join(template, 'package-lock.json'));
const generation = await beginGeneration(requestedTarget,{image,runtime:containerRuntime,slug,port});
if(generation.resume){await commitGeneration(generation);console.log(JSON.stringify({status:'resumed',next:'Continue project connection and verification'}));process.exit(0);}
slug=generation.state.slug;target=generation.stage;
const app = join(target, 'app');
await mkdir(app,{recursive:true});
for (const relative of ['package.json', 'package-lock.json', '.npmrc', '.nvmrc', 'tsconfig.json', 'vite.config.ts', 'tailwind.config.js', 'postcss.config.js', 'src/main.tsx']) {
  await mkdir(dirname(join(app, relative)), { recursive: true });
  await cp(join(template, relative), join(app, relative));
}
const packageJson = JSON.parse(await readFile(join(app, 'package.json'), 'utf8'));
packageJson.name = slug;
for(const hook of ['preinstall','prebuild','pretypecheck','pretest']){const old=packageJson.scripts?.[hook];packageJson.scripts ||= {};packageJson.scripts[hook]='node scripts/course-runtime-guard.cjs'+(old?' && '+old:'');}
await writeFile(join(app, 'package.json'), JSON.stringify(packageJson, null, 2) + '\n');
const lock = JSON.parse(await readFile(join(app, 'package-lock.json'), 'utf8'));
lock.name = slug;
lock.packages[''].name = slug;
await writeFile(join(app, 'package-lock.json'), JSON.stringify(lock, null, 2) + '\n');
const appId = `com.aicoding.${slug.replaceAll('-', '')}`;
await writeFile(join(app,'vite.config.ts'), "import { defineConfig } from 'vite';\nimport react from '@vitejs/plugin-react';\nexport default defineConfig({plugins:[react()],server:{host:'0.0.0.0',port:5187,watch:{usePolling:true,interval:1000}}});\n");
const files = {
  'scripts/course-runtime-guard.cjs': await readFile(new URL('../assets/course-runtime-guard.cjs',import.meta.url),'utf8'),
  'src/App.tsx': 'export default function App() { return <main className="starter"><h1>工作空间已就绪</h1><p>下一步：完成需求和页面原型设计，确认后交给 Trae 继续实现。</p></main>; }\n',
  'src/style.css': '@tailwind base;\n@tailwind components;\n@tailwind utilities;\n\n:root { color: #222; background: #fff; font-family: system-ui, sans-serif; } body { margin: 0; } .starter { max-width: 48rem; margin: 10vh auto; padding: 2rem; }\n',
  'index.html': '<!doctype html>\n<html lang="zh-CN"><head><meta charset="UTF-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /><title>我的作品</title></head><body><div id="root"></div><script type="module" src="/src/main.tsx"></script></body></html>\n',
  '.env.example': 'VITE_DATA_MODE=local\n',
  '.gitignore': 'node_modules/\ndist/\nandroid/\n.env\n.env.*\n!.env.example\ncloudbaserc.json\n*.apk\n*.aab\n*.keystore\n*.jks\n.local/\n',
  'README.md': '# 我的作品\n\n这是刚创建的空白工作空间。每一轮先说清功能目标，在 Gemini 新建或更新 PRD.md，在 Canvas 更新并试用设计，确认后交给 Trae 分步实现与测试，再亲自验收、记录反馈。后续增加云端、安卓或 AI 功能也用同一流程。课程工具不预设业务、登录方式或 AI 功能。\n',
  'AGENTS.md': '# 源码执行入口\n\n先读取上一级根 AGENTS.md、.ai-coding/project.json、工程基线与当前进度。此目录只补源码局部约束，不复制通用教程。\n',
};
files['AGENTS.md'] += `\n当前工具：${containerRuntime === 'podman' ? 'Podman CLI + 独立 Docker Compose' : 'Docker Desktop（旧工程）'}。沿用根manifest/Compose与准备镜像，不能宿主构建或重建工程绕过失败。\n`;
files['README.md'] += '\n项目名称和用途可以在需求与原型设计确认后补充，现在无需填写。\n';
files['README.md'] += `\n当前容器工具：${containerRuntime === 'podman' ? 'Podman CLI + 独立 Docker Compose' : 'Docker Desktop（旧工程）'}。由助手经用户级 Course-Runtime.ps1 的固定 provider/connection 在作品根目录运行 \`${containerRuntime} compose up -d --wait\`，由助手检查起始网页。\n`;
for (const [relative, content] of Object.entries(files)) {await mkdir(dirname(join(app,relative)),{recursive:true});await writeFile(join(app, relative), content);}
await mkdir(join(app, 'docs/design'), { recursive: true });
await mkdir(join(app, 'docs/progress'), { recursive: true });
await mkdir(join(target, '.ai-coding'), { recursive: true });
const project = { schemaVersion: 2, baselineVersion: '2.1.1', preparationId: preparation?.preparationId || null, initializationStatus: 'pending', toolchain: preparation ? { capabilities: preparation.capabilities || null, imageDigest: preparation.imageDigest, verificationMethod: preparation.verificationMethod || 'registry-digest', imageId: preparation.imageId || null, archiveSha256: preparation.archiveSha256 || null, verifiedAt: preparation.verifiedAt } : null, connection: preparation?.connection || null, compose: containerRuntime === 'podman' ? (preparation?.compose || {provider:'docker-compose',verificationStatus:'pending'}) : null, name, nameSource, purpose: null, identityStatus: 'pending-design', storageRoot: preparation?.storageRoot || null, slug, appId, sourceDirectory: 'app', designDirectory: generation.designDirectory, specDirectory: 'docs/specs', progressDirectory: 'docs/progress', image, port, containerRuntime, networkMode: containerRuntime === 'podman' ? networkMode : 'bridge', capabilityMode: 'on-demand', capabilities: ['local'], android: { webDir: 'dist', iconReviewRequired: false }, businessProfile: null };
await writeFile(join(target, '.ai-coding/project.json'), JSON.stringify(project, null, 2) + '\n');
await writeFile(join(target, '.env'), `AI_CODING_IMAGE=${image}\nAI_CODING_PORT=${port}\nAI_CODING_RUNTIME=${containerRuntime}\nAI_CODING_NETWORK_MODE=${networkMode}\nCOMPOSE_PROJECT_NAME=${slug}-${randomUUID().slice(0, 8)}\n`);
await writeFile(join(target, '.gitignore'), '.env\n.local/\n.cloudbase-setup/\n.github-setup/\n.ai-setup/\n.course-setup/\n.docker-setup/\n.podman-setup/\ntoolchain-verification.json\nenvironment-checklist.md\napp/node_modules/\napp/dist/\napp/android/\n*.apk\n');
const resources = resolve(dirname(fileURLToPath(import.meta.url)), '..');
await cp(join(resources, containerRuntime === 'podman' ? 'assets/compose.podman.yaml' : 'assets/compose.yaml'), join(target, 'compose.yaml'));
await cp(join(resources, 'assets/AGENTS.project.md'), join(target, 'AGENTS.md'));
await mkdir(join(target, '.trae/rules'), { recursive: true });
await cp(join(resources, 'assets/trae-entry.md'), join(target, '.trae/rules/course-entry.md'));
await cp(join(resources, 'assets/engineering'), join(target, 'docs/engineering'), { recursive: true });
await mkdir(join(target, 'docs/design'), { recursive: true });
await mkdir(join(target, 'docs/specs'), { recursive: true });
await cp(join(resources, 'assets/spec-template.md'), join(target, 'docs/specs/_template.md'));
await mkdir(join(target, 'docs/progress'), { recursive: true });
await writeFile(join(target, 'docs/progress/current.md'), '# 当前进度\n\n工程已生成；本地构建、起始网页、热更新与规则加载待检查。外部能力按需求在对应阶段接入。\n');
await writeFile(join(target, 'README.md'), '# 我的作品\n\n助手从 AGENTS.md 恢复。源码在 app/，需求设计放 docs/design，工程基线在 docs/engineering。运行与构建使用准备阶段镜像。本人只确认需求、授权与亲自试用。\n');
await writeFile(join(target, '.ai-coding/services.json'), JSON.stringify({ schemaVersion: 2 }, null, 2) + '\n');
const exclusions = '.ai-coding/command.json\n.ai-coding/web-build.json\n.ai-coding/guidance-upgrade.json\n.ai-coding/diagnostics.json\n.ai-coding/progress.json\n.ai-coding/dependencies.json\n.ai-coding/initialization-plan.json\n.ai-coding/runtime-check.json\n.ai-coding/local.json\n.ai-coding/preparation.json\n.ai-coding/initialization.json\n.ai-coding/evidence/\n.ai-setup/\n.cloudbase-setup/\n.github-setup/\n.course-setup/\n.local/\n**/.env\n**/.env.*\n!**/.env.example\n*.apk\n*.aab\n*.jks\n*.keystore\n';
await writeFile(join(target, '.gitignore'), (await readFile(join(target, '.gitignore'), 'utf8')) + exclusions);
await writeFile(join(target, '.dockerignore'), exclusions);
await writeFile(join(target, '.containerignore'), exclusions);
await commitGeneration(generation);
console.log(JSON.stringify({ status: 'created', project, next: 'Start the project container and verify the blank page' }));
