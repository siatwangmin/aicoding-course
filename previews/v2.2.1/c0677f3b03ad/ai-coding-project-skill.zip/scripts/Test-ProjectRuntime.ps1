﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,[switch]$Start)
$ErrorActionPreference='Stop'
. (Join-Path $env:USERPROFILE '.trae-cn\skills\ai-coding-env\scripts\Course-Runtime.ps1')
$runtime=Get-CourseProjectRuntime $ProjectDirectory -Start:$Start
Write-CourseJson (Join-Path $runtime.Root '.ai-coding\runtime-check.json') @{schemaVersion=2;checkedAt=$runtime.CheckedAt;status='verified';image=$runtime.Project.image;imageId=$runtime.ImageId;scope='local-engine-image-mount-dependencies'}
Write-Output 'Runtime verified. This does not verify cloud services, product behavior or phone installation.'
