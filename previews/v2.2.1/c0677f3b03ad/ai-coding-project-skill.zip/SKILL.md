---
name: ai-coding-project
description: 在新目录初始化或恢复作品，复用课前准备的同一课程镜像，只完成本地工程与开发规范；GitHub、CloudBase、Android、AI 按实际需求在对应阶段接入，不预设业务。
---

# 项目初始化与恢复

用户说“调用ai-coding-project技能创建项目工程。”即可开始并连续完成本节，不要求技术长提示。保存位置已明确不重复问。本人只选择作品位置、必要授权和费用；名称用途未定保持中性占位，设计确认后补展示信息，不改 slug/appId/端口。

“创建工程/在新文件夹开始作品/恢复已有作品”也触发本技能。先判空目录或已有工程，读实际根规则、manifest和进度；准备缺项恢复env，服务缺项恢复对应服务技能，不在B临场发明另一套环境。根AGENTS是入口，Trae项目规则只引用它；按[Trae官方规则](https://docs.trae.cn/ide_rules)使用 `.trae/rules/course-entry.md` 的 alwaysApply，并在新会话观察实际加载。文件存在不代表已加载。

## 新目录 B

标准技术编排入口为 scripts/Initialize-Project.ps1 -ProjectDirectory <B>（必要时 -PreparationDirectory <A>、可用 -Port）。它负责发现/脱敏摘要挂载/创建或升级/连接/运行与Web构建，生成初始化接续计划。返回pending后由本助手立即继续本地浏览器、挂载热更新和规则检查，不把技术入口的结束当整节完成；它不代办账号授权，也不要求本人第二条提示。下面步骤用于理解/排障，正常优先使用入口，保留实际工程。

1. 读取已有 AGENTS/manifest/源码，已有工程按恢复流程，不能覆盖或重建。新工程可为空或仅含设计资料；标准生成器保留设计和空.env，未知工程内容进入实际结构接管，不搬走资料。
2. 从当前用户 ai-coding-env/scripts/Course-Context.ps1 的 Find-CourseProjectPreparation 优先按已有 B 绑定、全新 B 按用户级索引定位 A。缺旧登记时在明确 A 调 Register-CoursePreparation.ps1；无有效证据恢复环境助手，只补缺项。不扫描 HOME 找秘密。
3. 复查实际所选引擎、准备镜像和 D 盘数据位置；镜像来自准备记录，不能换 latest、另建镜像或在宿主机装 Node/Java。新准备用 Podman CLI + 独立 Docker Compose；已有 Docker/Podman 工程保留原选择，不自动切换。
4. 用已验证镜像挂载 B 为 /project、技能根为 /skill:ro、脱敏 preparation.json 为 /prepared.json:ro，覆盖入口 node，运行 scripts/create-project.mjs --target /project --image <实际引用> --preparation /prepared.json --runtime <准备记录的runtime> --port <可用端口>。A暂不可访问时用环境脚本 Export-CoursePreparation.ps1 从允许的用户摘要物化文件，复查实际引擎/镜像后挂载；不挂不存在的A路径。Podman 再传 NetworkMode；不把整个 A 或凭证目录挂进容器。模板依赖从镜像复制，不联网重新选工具链。
5. 宿主运行 scripts/Connect-Project.ps1 -ProjectDirectory <B>，只关联准备环境与发现索引。默认不读取/写入云端、GitHub或AI项目绑定，不解密凭证；旧绑定与配置保持。
6. 新工程仅启用local；不调用外部服务Skill、不创建仓库/云资源/原生工程、不物化AI默认文件。需求尚未确定也可完成初始化。后续当前需求触发时按[按需接入](implementation/capability-activation.md)调用Enable-ProjectCapability，再接续对应Skill；安装了Skill、A有账号或选择完整案例都不代表立即启用全部能力。
7. 技术入口启动/复用原app并核镜像/源码/独立依赖卷，在容器内构建；再检查起始网页和实际热更新。按 [证据格式](implementation/initialization-evidence.md) 使用 scripts/Test-ProjectInitialization.ps1 记录并校验本地构建/网页/热更新/规则与实际存储证据，不要求宿主装Node。本地运行、规则加载或存储未通过，初始化整体保持待完成。最后集中交付起始网页、作品位置、已打开设计目录与准确缺项，不要求本人再发“打开设计文件夹”。

## 记录与开发交接

项目根 AGENTS 是入口；技术规范在 docs/engineering，需求/原型在 docs/design，助手技术 spec 在 docs/specs，结果在 docs/progress。服务实际检查保存到 .ai-coding/initialization.json，配置与检查状态分开。秘密只引用用户级凭证，机器私有记录忽略 Git/压缩/镜像。

新B同时生成工程workflow、spec模板和Trae引用入口；旧B通过Upgrade增量接入，实际设计路径从manifest读取。技术spec须给出默认技术方案、复用、具体改动和有序步骤/失败分支，不能只列检查。中性起始页不做业务；以后用户确认名称/用途/能力变化时同步展示与manifest，保留稳定标识。

AI首次启用时由Enable-ProjectCapability生成非秘密config/ai-models.defaults.json；来源为硅基流动默认模型资产。已有默认文件/有效模型不覆盖。初始化不要求AI、Key或模型调用，也不提前创建设置UI/业务表/函数。按开发技能落实可配置模型和“设置 → AI 服务”，Key只在服务端。

工程生成后调用 ai-coding-development；Android 构建调用 ai-coding-android。每轮材料已确认后连续实现，技术文档不转为学员作业。PRD 与 Canvas 是业务来源；明确选案例才合并案例规则，不因 Skill 已安装或存在 case-profile.json 推断选择。

## 恢复已有作品

保留源码、remote、稳定标识、运行时、端口、凭证和进度。先读根/局部 AGENTS、manifest、实际 Compose 和最新记录，健康容器复用。旧版 manifest 缺新字段时从明确准备结果增量补齐并备份原文件；用 connect 工具接入配置，不能运行空目录生成器重建。工程规范按实际目录落地，不能为符合 app/ 示例迁移源码。

已有 manifest 时先用 [Upgrade-Project.ps1](scripts/Upgrade-Project.ps1) 增量接入，再 Connect-Project；无 manifest 先检查真实结构并记录，不猜字段或运行空目录生成器。旧工程已有设计位置与产品约束保持，升级脚本不会重启容器。

技术默认与验证细节读 ai-coding-development；[capabilities.md](implementation/capabilities.md) 是能力索引。云函数在 CloudBase 运行、APK 在手机运行；本机编译和开发服务使用准备镜像。

新 Podman 工程通过用户级 ai-coding-env/scripts/Course-Runtime.ps1 的共同入口执行，复用其受管 Docker Compose EXE、显式 connection、API 转发验证与超时，不依赖 Desktop 或默认 PATH。构建失败保留原镜像/工程/身份并按对应层恢复。旧 Docker 工程继续按原绑定。

## 估时与等待

读取本技能 assets/course-timing.json，按当前阶段/步骤说明首次或复用的预计时间。长下载、编译、部署说明真实等待原因及本人是否需要操作；超过预计上限说明已完成部分、阻塞和处理，有依据才更新剩余时间。教学估算不代替实际证据，不展示虚假百分比；实际等待计入墙钟。

## 2.1 环境与项目执行约定

通用资料与案例资料可以统一下载、Skill 可以统一安装；已安装不代表已选案例。仅明确选择后加载案例需求，不能由 case-profile.json 的存在推断。A 保存原报告，用户级登记跨目录发现，默认 D:\AI-Practice 保存大资源，B 独立保存项目绑定。已有 B 按 preparationId 恢复，不受全局新选择影响；正常复用不拉镜像、不重装、不复制 A 资料。

日常安装依赖、更新锁文件、运行项目脚本和依赖恢复，调用当前用户 ai-coding-env/scripts/Invoke-CourseProject.ps1；按需读取该技能 references/project-execution.md 的命令及失败分支。已有关联 Web/发布/Android 脚本继续复用公共运行检查。宿主只负责编辑、Git、引擎控制、官方授权及手机连接，不安装项目编译工具链。

AI 的 E-08/P-01/V4 分工按当前用户 ai-coding-development/implementation/ai-service-setup.md：本人注册、查看可用优惠、决定充值、在程序配置 Key 和模型；助手负责工程与保密。P-01只完成本地基础；首次启用AI时再生成默认文件、接设置路线，Key解密或模型调用不作为初始化门槛。


2.1.1：设计-only B 在原位生成，内部暂存事务保存稳定标识，中断后从受管state接续；未知文件冲突保留并报告。新模板开启Vite轮询并带容器脚本保护。初始化证据额外记录B会话真实读取AGENTS/用户Skill的rules结果；调用Record -Service rules时按当前事实填写projectEntryObserved/skillsObserved，不把文件存在或A旧会话当B加载。
