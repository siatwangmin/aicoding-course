---
name: ai-coding-env
description: 为非技术用户准备可复用的 AI Coding 工具箱；检查 Windows CPU 虚拟化、虚拟机平台与 WSL，使用本地安装包引导完成 Docker Desktop 安装及验收，预装网页与安卓编译工具。用于安装 Docker、准备编程环境或检查课程工具，不创建业务工程。
---

# 通用开发环境助手

面向学员每次只给当前一步：在哪个窗口操作、做什么、完成后看到什么。正常技术操作连续执行，结束只给检查结论和报告入口。版本、命令、摘要和技术诊断保存在验收记录；出现具体阻塞时再说明原因和处理动作。此表达方式同样适用于安装、重启恢复与最终检查。

用户负责目标、账号授权和试用判断。解压、提权、启动程序、验证、镜像拉取、容器内检查和写记录由助手连续执行，中途不暂停征询，不拆成多轮对话。只在 UAC 窗口出现前说明“请点击是，随后助手会继续”，以及首次条款页面出现时说明“请本人阅读并决定是否接受，接受后助手自动验证”。不要让用户选择框架、版本或后端。BIOS 未开启、必须重启、权限策略拒绝或材料缺失属于实际阻塞，依据检测结果报告，不能虚构已自动完成。

## 只准备能力

本 Skill 检查工具并拉取固定环境，完成后可供任意兼容的网页、云端、安卓和 AI 作品使用。不要创建产品目录、写入业务规则、生成产品原型、创建云资源或指定产品账号与 AI 功能。环境可以按能力配置保留框架和 SDK；它们不决定用户产品的业务。

读取 [assets/toolchain.json](assets/toolchain.json)。当前使用已经发布并验证的固定镜像；其历史仓库名称和镜像内工具路径含案例名称，只是兼容标识，不作为产品名或业务默认值。不要更换未验证镜像。镜像包含 Node/npm/JDK、Ionic React/Vite/Capacitor、Tailwind 3/PostCSS/Autoprefixer、CloudBase SDK 和 Android/Gradle 缓存；不包含已授权的用户云账号或 Trae CloudBase MCP 连接。

## 检查与准备

1. 保存当前工作目录为 workspace，保持它不变。资料包根目录优先取当前目录；没有 `setup-guide.md` 时，使用 [scripts/Install-CourseSkills.ps1](scripts/Install-CourseSkills.ps1) 的 `Find-CoursePackageRoot` 向上及向子目录按距离搜索最近的说明。等距离多个完整包、搜索上限或缺 ZIP 时报告实际路径/缺文件，不猜测盘符或桌面位置。按 `setup-guide.md` 将两个技能 ZIP 校验并自动解压到 `<workspace>\.trae-cn\skills\<技能名>\`，保留脚本与资产。只有外层 ZIP 时先检查其包含说明和两个技能包，再解压到当前目录中的资料子目录；不得把任意 ZIP 当作课程包。
2. 在 Windows 宿主机本地任务中读 [Windows 安装路线](references/windows-docker-setup.md)。直接通过 `Start-Process powershell.exe ... -Verb RunAs -Wait` 发起 [scripts/Setup-DockerDesktop.ps1](scripts/Setup-DockerDesktop.ps1) 的 `-Mode Prepare`，传入动态资料路径和 `-WorkingDirectory workspace`。Prepare 与 Verify **始终默认以管理员身份运行**，不得先非管理员跑失败再重试；脚本对直接调用也会在检查之前主动提权。原学员与提升后账号不同则停下报告，不把另一人的环境算作学员环境。不可访问宿主机时标为未检查，不使用隔离环境、WSL/Linux Docker 或远程 context 的结果替代。
3. 脚本检测虚拟化/SLAT、Windows/x64/内存、虚拟机平台、待重启、WSL 与本机 Docker。按[安装包下载与摆放说明](references/installation-downloads.md)，优先在资料文件夹旁的 `release` 查找本地包，兼容目录内的 `release` 和旧 `releases`；缺少目录或所需文件时直接从 [assets/windows-installers.json](assets/windows-installers.json) 的官方地址下载并校验，不等待用户另发指令。WSL 固定 3.0.1.0 x64 且 SHA-256 精确匹配；已有合格 WSL 不降级。Docker 官网入口会更新，课程摘要匹配的本地包直接使用，其他版本必须 Authenticode=Valid 且签发主体精确为 Docker Inc；实际来源、版本、摘要和签名保存在 workspace 的 `.docker-setup/installer-<种类>.json`。下载失败或签名/摘要失败时报告实际错误，不能用 HTML 页面、临时链接或未验证文件继续安装。自动安装、动态探测并启动 Docker Desktop，首次法律条款由本人决定。找不到启动程序时才请求实际安装路径，通过 `-DockerDesktopPath` 传入，不能让用户先去开始菜单搜索。BIOS/重启未满足就保留阻塞状态；不要循环重装或重置已有 Docker/WSL。
4. 主动提权运行 `-Mode Verify`，用 `-PassThru` 读取进程退出码，并读取 `workspace\.docker-setup\report.json`；确认本次退出码为 0、CheckedAt 不早于本次发起时间、Decision=Ready、本机 Linux Server 与 Compose 可用，不把取消提权后的旧 Ready 报告当作本次通过。不要求用户观察或报告 Engine running 字样。Verify 可独立验收；管理员查询的虚拟机平台确认结果保存在报告中，非管理员兼容调用只复用同机、同用户、同一次启动的有效确认，不能跨重启沿用或把 Unknown 猜成 Enabled。
5. 连续执行 [scripts/Verify-Toolchain.ps1](scripts/Verify-Toolchain.ps1)，传入 `-WorkingDirectory workspace`。读取 toolchain.json 的 `imageDigest`，固定用 `docker --host <已验证本机 endpoint> pull <image@sha256:...>`，随后 `image inspect`：**RepoDigests 中存在该 digest 的精确匹配，Architecture==amd64，Os==linux** 才通过。containerd snapshotter 下 `.Id` 可能是清单摘要而非配置摘要；`imageId` 仅参考，不作为验收条件。镜像公开，无需 ACR 密码。离线传 `-ImageArchive` 与 `-SkipPull`；导入后仍按 RepoDigests 验证，缺摘要时明确未验证，不能凭标签或 `.Id` 报告通过。
6. 验收脚本用临时容器运行 [scripts/check-environment.sh](scripts/check-environment.sh)，显式 `--entrypoint sh --network none`，仅只读挂载技能脚本目录，不挂载业务目录。覆盖镜像自动生成旧脚手架的默认入口，不创建案例产品。容器检查通过后自动写记录，直接继续完成环境准备。

## 验收记录

工具验收记录固定写在**当前工作目录** `./toolchain-verification.json`（Windows：`.\toolchain-verification.json`）。固定字段为 `VerifiedAt`、`Image`、`imageDigest`、`Architecture`、`Os`、`DockerEndpoint`、`DockerServerVersion`、`ComposeVersion`、`ToolchainCheck`、`NotVerified`。失败时 `VerifiedAt=null`，实际错误写入未验证项，不能报告通过。

Docker 诊断、安装日志、重启状态和虚拟机平台确认固定写在当前目录的 `.docker-setup/`。**不得把任何这些记录写入 AppData 或其他工作目录外路径，不得写死任何用户/机器相关的绝对路径。** 提权后保持原 workspace，通过参数传递，不能将管理员进程的 System32 起始目录当作工作区。技能只解压到原 workspace 的 `.trae-cn/skills/`，不得安装到用户目录；资料包位置不作为项目位置。

学员可读的 checklist 固定写在当前工作目录的 `environment-checklist.md`，由 Docker 与工具箱脚本自动生成，列出每项结果和实际证据。Docker 阶段只完成系统检查时，镜像与容器项显示“未检查”，总结为“未完成”；工具箱检查全部通过后才显示“已完成”。失败会更新清单并保留未通过项，不能沿用旧成功结果。结束时给学员打开或链接这份清单，无需让学员理解命令或手工勾选。

容器检查只证明工具存在且可执行。没有实际构建作品时，网页/APK、云账号和 AI 授权留在 `NotVerified`；具体作品的构建由项目助手另验收。

## 完成结果

Docker 报告的 `Decision=Ready` 仅表示 Docker 就绪，不表示课程环境完成。不得在 Prepare/Verify 返回 0 后结束任务、要求用户再说“继续”，或将技能安装成功当作工具箱验收成功。必须实际执行 `Verify-Toolchain.ps1` 并读取它的退出码和本次生成的 `workspace\toolchain-verification.json`。

报告完成前逐项核对：验收脚本退出码为 0；记录的 `VerifiedAt` 不为空且不早于本次工具箱验收开始时间；`Image`、`imageDigest` 与 toolchain.json 一致；`Architecture=amd64`、`Os=linux`；`ToolchainCheck.ExitCode=0` 且有实际检查输出；本机 `DockerEndpoint` 与当前 Docker 报告一致。记录缺失、过期或任一条件不满足，都必须报告“环境准备未完成”及实际停在哪一步，不能报告成功。项目构建与云账号尚未验证不影响工具箱验收，但镜像和容器检查未通过必须阻止完成。

镜像在 Desktop 界面可能以摘要形式显示，不能凭列表中是否有熟悉的标签判断是否拉取。诊断时先读取原任务目录的两份记录：只有 Docker 报告、没有工具记录，表示工具箱验收没有留下结果，先检查是否漏执行或脚本启动前报错；工具记录的 `VerifiedAt=null` 时读取 `NotVerified` 和 `ToolchainCheck`，据实际错误判断拉取、镜像核对或容器检查失败。不得把未获得的远端日志推测成已确认的原因。

向用户报告“工具箱已准备，可以创建新作品”与工具记录位置。还没有业务工程或网页产品是预期结果。不要要求用户现在开通 CloudBase 或模型服务；仅说明联网共享和 AI 功能需要在对应阶段本人授权。

CloudBase 官方 Skill/MCP 应配置在实际运行 Trae 的环境；V2/联网请求时再按 [官方入口](https://docs.cloudbase.net/skill.md)执行。若本地 MCP 用 npx，必须核对它所在环境的 Node/npx 和首次下载条件；容器有 Node 不能替代宿主机检查。工具箱离线编译与云服务联网接入是不同能力，逐项标注真实状态。
