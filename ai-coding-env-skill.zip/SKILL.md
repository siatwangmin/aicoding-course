---
name: ai-coding-env
description: 在准备工作目录安装、验证、恢复或卸载开发环境；编排本目录的 GitHub 与 CloudBase 准备，登记可复用工具，不创建业务工程。
---

# 环境准备与卸载

本技能仅安装于准备目录 A/.trae/skills，不全局安装。先读取 .course-setup/materials.json、运行时、存储和原报告；新准备默认 Podman CLI 与独立 Docker Compose，旧工程沿原绑定，不自动切换。

完整准备读取 references/preparation-workflow.md，后台启动 scripts/Start-CourseToolPreparation.ps1；前台在 A 中依次接续 GitHub 与 CloudBase 准备技能，必要本人动作完成后继续。只做工具排障的请求保持范围。不准备模型供应商账号，不索取模型 Key，不产生模型调用门槛。

资料获取与作用域安装由 scripts/Get-CourseMaterials.ps1、Install-CourseSkills.ps1 执行：用户级安装 project/github/cloudbase/android；A 内仅 env；公共执行包保存在技能发现目录之外。按本次准备名单核安装与真实 Trae 加载，四项用户级技能可跨项目发现；案例不进入默认准备链。

工具镜像按 assets/toolchain.json 核真实身份与断网检查；软件、实际存储、容器、授权和服务分别留证。使用原 runtime/connection/provider；缺哪个修哪个，不宿主构建、不更换镜像绕过失败。原报告保存 A，用户索引仅作发现，作品 B 独立绑定公共执行包和资源。

卸载先读 references/uninstall.md，沿 scripts/Uninstall-Course.ps1 的 Plan→Apply→Verify，失败用 Resume。按资源归属处理，保留作品与共享资源，不临场拼删除命令。资料升级读 references/course-updates.md，不重走安装。

重新安装遇到 partial 或中断卸载记录时，当前安装入口自动清理独占且摘要未变的旧文件和无依赖备份，再接续安装；共享、用户修改、归属不明及仍需恢复的备份保留并报告。不手改 catalog，不清空准备目录，不删除工具、容器、数据或项目绑定。

准备完成调用 Register-CoursePreparation 与 Register-CourseServices；工具、平台与汇总分别记录，未知状态保留待办。作品初始化交用户级 ai-coding-project。

宿主 Git for Windows 由后台 Git/GitVerify 阶段准备，独立于 GitHub CLI（gh）。已有有效 Git 直接复用；缺失时 scripts/Setup-Git.ps1 从 npmmirror、华为镜像、官方源顺序获取固定官方完整便携包，核摘要后安装到原环境目录并加入用户 PATH。核 .course-setup/git.json 的版本与实际路径，缺失或失败不能记工具通过。已有 Trae/终端重开后加载新增 PATH；当前操作可用公共执行包的 Resolve-CourseGit 定位，不能重复安装或改已有 Git 配置。
