# 开始准备课程环境

在线阅读 https://siatwangmin.github.io/aicoding-course/preparation.html ，按网页发送一次提示。助手连续准备课程所需工具、云服务、GitHub 和 AI 账号及必要授权并汇总，已有结果复用。

此执行资料供助手安装和恢复，不要求本人阅读技术文件。中断后在原准备文件夹告诉 Trae“请读取已有记录，继续未完成的课前准备”。项目初始化时按本项目需求接入已有能力。
