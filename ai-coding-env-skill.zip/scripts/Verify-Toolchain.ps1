﻿#Requires -Version 5.1
[CmdletBinding()]
param([string]$WorkingDirectory, [string]$ToolchainPath, [string]$ImageArchive, [switch]$SkipPull,
      [ValidateSet('docker','podman')][string]$ContainerRuntime='docker')

function Test-ToolchainImage {
    param($Image, [string]$Digest)
    return $Image.Architecture -eq 'amd64' -and $Image.Os -eq 'linux' -and
        @($Image.RepoDigests | Where-Object { ($_ -split '@')[-1] -ceq $Digest }).Count -gt 0
}

function Invoke-ToolchainVerification {
    param([string]$Workspace, [string]$ConfigPath, [string]$Archive, [bool]$NoPull)
    if (-not (Get-Command Invoke-SetupNative -ErrorAction SilentlyContinue)) { . (Join-Path $PSScriptRoot 'Setup-DockerDesktop.ps1') }
    $record = [ordered]@{
        VerifiedAt = $null; Image = $null; imageDigest = $null; Architecture = $null; Os = $null
        DockerEndpoint = $null; DockerServerVersion = $null; ComposeVersion = $null
        ToolchainCheck = @{ ExitCode = $null; Output = '' }
        NotVerified = @('尚未构建当前作品的网页/APK', '尚未验证用户的云账号与 AI 授权')
    }
    $target = Join-Path $Workspace 'toolchain-verification.json'
    $steps = [ordered]@{}
    $setup = $null; $docker = $null
    try {
        $config = Get-Content -LiteralPath $ConfigPath -Raw -ErrorAction Stop | ConvertFrom-Json
        if ($config.imageDigest -cnotmatch '^sha256:[0-9a-f]{64}$' -or $config.image -cnotmatch ('@' + [regex]::Escape($config.imageDigest) + '$')) {
            throw 'toolchain.json 必须提供匹配的 image@sha256 引用和 imageDigest；不能使用可变标签或 imageId 代替。'
        }
        $record.Image = $config.image; $record.imageDigest = $config.imageDigest
        $setup = Get-Content -LiteralPath (Join-Path $Workspace '.docker-setup\report.json') -Raw -ErrorAction Stop | ConvertFrom-Json
        if ($setup.Decision -ne 'Ready') { throw 'Docker 尚未完成 Prepare/Verify；请先主动提权验证到 Decision=Ready。' }
        $endpoint = $setup.Snapshot.Docker.Endpoint
        if ($endpoint -notin @('npipe:////./pipe/dockerDesktopLinuxEngine', 'npipe:////./pipe/docker_engine')) { throw '报告没有已验证的本机 Docker endpoint。' }
        $DockerDesktopPath = $setup.Snapshot.Docker.Desktop
        # Fresh local probe, not just an old report's success or the shell's remote context.
        $docker = Get-SetupDocker
        if (-not $docker.Ready -or $docker.Endpoint -ne $endpoint) { throw '本机 Docker 引擎状态已经改变，请重新主动验证。' }
        $record.DockerEndpoint = $endpoint; $record.DockerServerVersion = $docker.ServerVersion; $record.ComposeVersion = $docker.Compose
        if ($Archive) {
            $steps['镜像获取'] = @{ State = '未通过'; Detail = '正在导入离线镜像' }
            $load = Invoke-SetupNative $docker.Cli @('--host', $endpoint, 'load', '--input', $Archive) 900
            $steps['镜像获取'] = @{ State = $(if ($load.ExitCode -eq 0) { '通过' } else { '未通过' }); Detail = "离线导入退出码=$($load.ExitCode)；$($load.Output)" }
            if ($load.ExitCode -ne 0) { throw "离线镜像导入失败：$($load.Output)" }
        }
        if (-not $NoPull) {
            Write-Host '正在按不可变 digest 拉取工具箱镜像。'
            $steps['镜像获取'] = @{ State = '未通过'; Detail = '正在按固定 digest 拉取镜像' }
            $pull = Invoke-SetupNative $docker.Cli @('--host', $endpoint, 'pull', $config.image) 1800
            $steps['镜像获取'] = @{ State = $(if ($pull.ExitCode -eq 0) { '通过' } else { '未通过' }); Detail = "pull 退出码=$($pull.ExitCode)；$($pull.Output)" }
            if ($pull.ExitCode -ne 0) { throw "镜像拉取失败：$($pull.Output)" }
        } elseif (-not $Archive) {
            $steps['镜像获取'] = @{ State = '已跳过'; Detail = '显式 SkipPull：使用本地镜像，仍须通过以下摘要与容器检查。' }
        }
        $steps['镜像摘要精确匹配'] = @{ State = '未通过'; Detail = '尚未取得可验证的 RepoDigests' }
        $inspect = Invoke-SetupNative $docker.Cli @('--host', $endpoint, 'image', 'inspect', $config.image)
        if ($inspect.ExitCode -ne 0) { throw "镜像检查失败：$($inspect.Output)" }
        $images = @($inspect.Output | ConvertFrom-Json -ErrorAction Stop)
        $digestOk = $images.Count -eq 1 -and @($images[0].RepoDigests | Where-Object { ($_ -split '@')[-1] -ceq $config.imageDigest }).Count -gt 0
        $platformOk = $images.Count -eq 1 -and $images[0].Architecture -eq 'amd64' -and $images[0].Os -eq 'linux'
        $steps['镜像摘要精确匹配'] = @{ State = $(if ($digestOk) { '通过' } else { '未通过' }); Detail = "期望=$($config.imageDigest)；RepoDigests=$($images[0].RepoDigests -join ', ')" }
        $steps['镜像平台 linux/amd64'] = @{ State = $(if ($platformOk) { '通过' } else { '未通过' }); Detail = "Architecture=$($images[0].Architecture)，Os=$($images[0].Os)" }
        if ($images.Count -ne 1 -or -not (Test-ToolchainImage $images[0] $config.imageDigest)) {
            throw '镜像的 RepoDigests 未精确包含指定 digest，或 Architecture/Os 不符合 amd64/linux；.Id 和本地标签不能替代验收。离线导入缺少 RepoDigests 时保留未验证状态。'
        }
        $record.Architecture = $images[0].Architecture; $record.Os = $images[0].Os
        $scripts = (Resolve-Path -LiteralPath $PSScriptRoot).Path
        Write-Host '正在断网容器内检查工具，不挂载任何业务目录。'
        $steps['临时容器内开发工具'] = @{ State = '未通过'; Detail = '尚未取得容器检查结果' }
        $check = Invoke-SetupNative $docker.Cli @('--host', $endpoint, 'run', '--rm', '--network', 'none', '--entrypoint', 'sh', '--mount', "type=bind,source=$scripts,target=/course-check,readonly", $config.image, '/course-check/check-environment.sh') 600
        $record.ToolchainCheck = @{ ExitCode = $check.ExitCode; Output = $check.Output }
        $steps['临时容器内开发工具'] = @{ State = $(if ($check.ExitCode -eq 0) { '通过' } else { '未通过' }); Detail = "容器退出码=$($check.ExitCode)；$($check.Output)" }
        if ($check.ExitCode -ne 0) { throw '容器内工具检查未通过，实际输出见 ToolchainCheck。' }
        $record.VerifiedAt = (Get-Date).ToString('o')
        Write-Host '工具箱检查通过，可以开始创建作品。'
        return 0
    } catch {
        $record.NotVerified += $_.Exception.Message
        Write-Host "工具箱尚未验收：$($_.Exception.Message)" -ForegroundColor Yellow
        return 2
    } finally {
        $record | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $target -Encoding UTF8
        Write-EnvironmentChecklist $Workspace $setup $record $steps $docker
        Write-Host "工具验收记录：$target"
        Write-Host "学员验收清单：$(Join-Path $Workspace 'environment-checklist.md')"
    }
}

if ($MyInvocation.InvocationName -ne '.') {
    $ErrorActionPreference = 'Stop'
    if ($ContainerRuntime -eq 'podman') {
        & (Join-Path $PSScriptRoot 'Verify-PodmanToolchain.ps1') -WorkingDirectory $WorkingDirectory -ToolchainPath $ToolchainPath -ImageArchive $ImageArchive -SkipPull:$SkipPull
        exit $LASTEXITCODE
    }
    $ErrorActionPreference = 'Stop'
    [Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
    if (-not $WorkingDirectory) { $WorkingDirectory = (Get-Location).Path }
    $WorkingDirectory = (Resolve-Path -LiteralPath $WorkingDirectory).Path
    if (-not $ToolchainPath) { $ToolchainPath = Join-Path $PSScriptRoot '..\assets\toolchain.json' }
    exit (Invoke-ToolchainVerification $WorkingDirectory $ToolchainPath $ImageArchive ([bool]$SkipPull))
}
