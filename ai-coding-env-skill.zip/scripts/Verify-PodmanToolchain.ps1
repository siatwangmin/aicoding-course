﻿#Requires -Version 5.1
[CmdletBinding()]
param([string]$WorkingDirectory, [string]$ToolchainPath, [string]$ImageArchive, [switch]$SkipPull)

$podmanVerification=@{Workspace=$WorkingDirectory;Config=$ToolchainPath;Archive=$ImageArchive;NoPull=[bool]$SkipPull}
. (Join-Path $PSScriptRoot 'Course-Podman.ps1')

function Test-PodmanImageEvidence {
    param($Image, $Config, [string]$ArchiveHash)
    if ($Image.Architecture -ne 'amd64' -or $Image.Os -ne 'linux') { return $null }
    if (@($Image.RepoDigests | Where-Object {($_ -split '@')[-1] -ceq $Config.imageDigest}).Count) { return 'registry-digest' }
    if ($Config.offlineArchive -and $ArchiveHash -ceq $Config.offlineArchive.sha256 -and
        ($Image.Id -replace '^sha256:','') -ceq ($Config.imageId -replace '^sha256:','')) { return 'archive-sha256+image-config' }
    return $null
}
function Assert-PodmanImageStorage([string]$Workspace){
    . (Join-Path $PSScriptRoot 'Course-Storage.ps1')
    $target=Resolve-CourseStorageRoot $Workspace 'podman'
    $storage=Test-CourseStorageLocation $Workspace 'podman' $target
    if($storage.status -ne 'verified'){throw 'PODMAN_STORAGE_REQUIRED_BEFORE_IMAGE_DOWNLOAD: verify actual VHD/program/cache locations first.'}
}

function Invoke-PodmanToolchainVerification {
    param([string]$Workspace, [string]$ConfigPath, [string]$Archive, [bool]$NoPull)
    if (-not (Get-Command Get-WorkspaceSkillsVerification -ErrorAction SilentlyContinue)) { . (Join-Path $PSScriptRoot 'Install-CourseSkills.ps1') }
    $record=[ordered]@{VerifiedAt=$null;ContainerRuntime='podman';Image=$null;imageDigest=$null;Architecture=$null;Os=$null;
        Endpoint=$null;ServerVersion=$null;ComposeVersion=$null;Machine=$null;Connection=$null;Rootless=$null;NetworkMode=$null;
        VerificationMethod=$null;RegistryDigestVerified=$false;ArchiveSha256=$null;
        ToolchainCheck=@{ExitCode=$null;Output=''};SkillInstallationVerified=$false;SkillsVerificationPath='.course-setup/skills-verification.json';NotVerified=@('当前作品网页/APK','云账号与 AI 授权')}
    $skillsVerification=$null
    $lifecycleInstallation=if(Get-Command Find-CourseInstallation -ErrorAction SilentlyContinue){Find-CourseInstallation $Workspace}else{$null}
    $lifecycleLease=$null;$lifecycleImageCreated=$false;$lifecycleImageIntent=$null
    if($lifecycleInstallation){$lifecycleLease=Enter-CourseOperation $Workspace 'VerifyToolchain'}
    try {
        $skillsVerification=Get-WorkspaceSkillsVerification $Workspace
        $record.SkillInstallationVerified=[bool]$skillsVerification.UserInstallationVerified
        if (-not $record.SkillInstallationVerified) {throw '技能作用域安装未通过；先修复 skills-verification.json 中的缺项或错误作用域，再继续工具验收。'}
        $config=Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
        if ($config.imageDigest -cnotmatch '^sha256:[a-f0-9]{64}$' -or -not $config.image.EndsWith('@'+$config.imageDigest)) {throw 'Invalid pinned toolchain image.'}
        $setup=Get-Content (Join-Path $Workspace '.podman-setup/report.json') -Raw | ConvertFrom-Json
        if ($setup.ContainerRuntime -ne 'podman' -or $setup.Decision -ne 'Ready') {throw 'Run Podman Prepare/Verify first.'}
        $podman=Get-SetupPodman $setup.Machine
        if ($podman.Connection -ne $setup.Snapshot.Connection -or $podman.Endpoint -ne $setup.Snapshot.Endpoint) {throw 'Local Podman connection changed; repeat setup verification.'}
        $record.Machine=$podman.Machine; $record.Connection=$podman.Connection; $record.Endpoint=$podman.Endpoint
        $record.Rootless=$podman.Rootless; $record.NetworkMode=$podman.NetworkMode
        $record['ComposeBinding']=$podman.ComposeBinding; $record['ApiEndpoint']=$podman.ApiEndpoint
        $record.ServerVersion=$podman.ServerVersion; $record.ComposeVersion=$podman.Compose; $record.imageDigest=$config.imageDigest
        $prefix=@('--connection',$podman.Connection)
        $image=$config.image; $archiveHash=$null
        $priorEvidence=Get-CoursePriorToolchain $Workspace
        if(-not $Archive -and $priorEvidence){
            $prior=$priorEvidence.report
            if($prior.VerifiedAt -and $prior.VerificationMethod -eq 'archive-sha256+image-config' -and $prior.Connection -eq $podman.Connection -and $prior.Image -eq $config.offlineArchive.imageReference -and $prior.ArchiveSha256 -ceq $config.offlineArchive.sha256 -and ($prior.ImageId -replace '^sha256:','') -ceq ($config.imageId -replace '^sha256:','')){
                $candidate=Invoke-SetupNative $podman.Cli ($prefix+@('image','inspect',$prior.Image))
                if($candidate.ExitCode -eq 0){
                    $candidateImages=@($(if($candidate.Stdout){$candidate.Stdout}else{$candidate.Output})|ConvertFrom-Json)
                    if($candidateImages.Count -eq 1 -and (Test-PodmanImageEvidence $candidateImages[0] $config $prior.ArchiveSha256)){
                        $image=$prior.Image;$archiveHash=$prior.ArchiveSha256;$record.ArchiveSha256=$archiveHash;$record['ArchiveEvidenceReused']=$true;$record['ArchiveEvidenceSource']=$priorEvidence.path
                    }
                }
            }
        }
        if ($Archive) {
            $archiveHash=(Get-FileHash -LiteralPath $Archive -Algorithm SHA256).Hash.ToLowerInvariant()
            if (-not $config.offlineArchive -or $archiveHash -cne $config.offlineArchive.sha256) {throw 'Offline toolchain archive SHA-256 mismatch.'}
            $record.ArchiveSha256=$archiveHash
            $image=$config.offlineArchive.imageReference
            $existing=Invoke-SetupNative $podman.Cli ($prefix+@('image','inspect',$image))
            $reuse=$false
            if ($existing.ExitCode -eq 0) {
                $existingImages=ConvertFrom-Json -InputObject $existing.Output
                $reuse=@($existingImages).Count -eq 1 -and [bool](Test-PodmanImageEvidence @($existingImages)[0] $config $archiveHash)
            }
            if (-not $reuse) {
                $lifecycleImageCreated=$existing.ExitCode -ne 0
                if($lifecycleInstallation){$lifecycleImageIntent=Assert-CourseCreationIntentOutput @(Start-CourseCreationIntent $lifecycleInstallation.installationId image $image (-not $lifecycleImageCreated)) 'Verify-PodmanToolchain'}
                Assert-PodmanImageStorage $Workspace
                $loaded=Invoke-SetupNative $podman.Cli ($prefix+@('load','-i',$Archive)) 900
                if ($loaded.ExitCode -ne 0) {throw $loaded.Output}
            }
        } elseif (-not $NoPull) {
            $local=Invoke-SetupNative $podman.Cli ($prefix+@('image','inspect',$image))
            if($local.ExitCode -eq 0){
                $localImages=@($(if($local.Stdout){$local.Stdout}else{$local.Output})|ConvertFrom-Json)
                if($localImages.Count -ne 1 -or -not(Test-PodmanImageEvidence $localImages[0] $config $archiveHash)){throw 'Local image mismatch; preserve and inspect, no silent replacement.'}
            }else{
                Assert-PodmanImageStorage $Workspace
                $lifecycleImageCreated=$true
                if($lifecycleInstallation){$lifecycleImageIntent=Assert-CourseCreationIntentOutput @(Start-CourseCreationIntent $lifecycleInstallation.installationId image $image $false) 'Verify-PodmanToolchain'}
                $pulled=Invoke-SetupNative $podman.Cli ($prefix+@('pull',$image)) 1800
                if ($pulled.ExitCode -ne 0) {throw $pulled.Output}
            }
        }
        $inspection=Invoke-SetupNative $podman.Cli ($prefix+@('image','inspect',$image))
        if ($inspection.ExitCode -ne 0) {throw $inspection.Output}
        $imageList=ConvertFrom-Json -InputObject $inspection.Output
        $images=@($imageList)
        if ($images.Count -ne 1) {throw 'Expected one toolchain image.'}
        $method=Test-PodmanImageEvidence $images[0] $config $archiveHash
        if (-not $method) {throw 'Image identity/platform unverified: require exact RepoDigest OR a freshly verified approved archive SHA-256 plus image config ID.'}
        $record.Image=$image; $record.VerificationMethod=$method; $record.RegistryDigestVerified=$method -eq 'registry-digest'
        $record['ImageId']=$images[0].Id
        $record.Architecture=$images[0].Architecture; $record.Os=$images[0].Os
        if($lifecycleInstallation){
            if(-not(Get-Command Register-CourseEngineResource -ErrorAction SilentlyContinue)){. (Join-Path $PSScriptRoot 'Course-UninstallAdapters.ps1')}
            $null=Register-CourseEngineResource $lifecycleInstallation.installationId image $images[0].Id $(if($lifecycleImageCreated){'created'}else{'reused'}) rebuildable $podman.Cli podman $podman.Connection ''
            Complete-CourseCreationIntent $lifecycleImageIntent
        }
        $scripts=(Resolve-Path -LiteralPath $PSScriptRoot).Path
        $check=Invoke-SetupNative $podman.Cli ($prefix+@('run','--rm','--pull=never','--network','none','--entrypoint','sh','--mount',"type=bind,source=$scripts,target=/course-check,readonly",$image,'/course-check/check-environment.sh')) 600
        $record.ToolchainCheck=@{ExitCode=$check.ExitCode;Output=$check.Output}
        if ($check.ExitCode -ne 0 -or $check.Output -notmatch 'TOOLCHAIN_READY') {throw 'Toolchain container check failed.'}
        $record.VerifiedAt=(Get-Date).ToString('o')
        return 0
    } catch {$record.NotVerified+=$_.Exception.Message; Write-Host $_.Exception.Message; return 2}
    finally {
        if($lifecycleLease){Exit-CourseOperation $lifecycleLease}
        $record | ConvertTo-Json -Depth 7 | Set-Content (Join-Path $Workspace 'toolchain-verification.json') -Encoding UTF8
        $status=if($record.VerifiedAt -and $record.SkillInstallationVerified){'已完成'}else{'未完成'}
        $checklistLines=@("# 容器工具准备：$status",'', '所选工具：Podman CLI + 独立 Docker Compose', "检查时间：$($record.VerifiedAt)", "镜像证据：$($record.VerificationMethod)", "远端 RepoDigest 已验证：$($record.RegistryDigestVerified)", "容器检查退出码：$($record.ToolchainCheck.ExitCode)",'', ('尚未验证：'+($record.NotVerified -join '；')))
        Set-Content -LiteralPath (Join-Path $Workspace 'environment-checklist.md') -Value $checklistLines -Encoding UTF8
        if (-not $skillsVerification) {$skillsVerification=Get-WorkspaceSkillsVerification $Workspace}
        Update-ExistingSkillsChecklist -Workspace $Workspace -Verification $skillsVerification
    }
}

if ($MyInvocation.InvocationName -ne '.') {
    $ErrorActionPreference='Stop'
    $workspace=$podmanVerification.Workspace
    if (-not $workspace) {$workspace=(Get-Location).Path}
    $configPath=$podmanVerification.Config
    if (-not $configPath) {$configPath=Join-Path $PSScriptRoot '..\assets\toolchain.json'}
    $result=Invoke-PodmanToolchainVerification (Resolve-Path -LiteralPath $workspace).Path $configPath $podmanVerification.Archive $podmanVerification.NoPull
    if($result -eq 0){. (Join-Path $PSScriptRoot 'Course-Context.ps1');Register-CoursePreparation $workspace|Out-Host}
    exit $result
}
