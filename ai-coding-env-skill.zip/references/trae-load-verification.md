# Trae 实际加载验收

文件安装通过后，在 A 的 Trae 新会话核对实际发现与规则识别。四项用户级 project/github/cloudbase/android 和 A 本地 env 均应可发现；应识别根 AGENTS.md 与 .trae/rules/course-preparation.md。其他作品或旧会话的结果不能代替当前 A。

证据只能来自 Trae 会话实际报告（kind=tool、method=trae-session）或本人明确确认（kind=learner、method=learner-confirmation）。文件列表、读取 SKILL.md、打开网站均不能证明加载。无法读取 Trae 界面或没有本人确认时记录 pending，继续其他已授权工作，不虚构会话或成功结果。

确认后，助手在 A/.course-setup/observations/trae-session.json 保存结构化记录：

- schemaVersion=1、workspace=当前 A 绝对路径、newSession=true、sessionLabel=实际会话标识或本人确认的会话描述、observedAt=真实观察的 ISO 时间（不刷新旧观察时间）。
- method 取上述对应值。loadedSkills 逐项包含 name、scope（User 或 Preparation）、directory（实际发现目录）、sha256（该目录 SKILL.md 摘要）。目录需与本次 skills-verification.json 一致。
- loadedRules 逐项包含 path（AGENTS.md 或 .trae/rules/course-preparation.md）与 sha256。只在实际确认识别后记录；摘要用于防止文件变更后沿用旧结果，不能作为加载证明。

使用同一入口登记，例如本人确认后：

```powershell
& '<执行包>/Save-PreparationEvidence.ps1' -WorkingDirectory '<A>' -Stage summary -Check traeLoadObserved -Outcome passed -Kind learner -Reference '本人在当前 A 的 Trae 新会话确认上述五项技能与两份规则已识别' -TraeObservationFile '<A>/.course-setup/observations/trae-session.json'
```

该输入只能与 summary/traeLoadObserved 配合。汇总仍需 skillsVerified 与 currentResultsReviewed；工具和平台缺项不会被这条记录覆盖。Status 会重新校验当前作用域、内容摘要、会话与时间；只有浏览器来源的旧成功记录不再通过，原证据保留供复核。
