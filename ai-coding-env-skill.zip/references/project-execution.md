# 跨目录环境复用与容器开发入口（2.1）

A 保存原始准备报告；当前用户 .ai-coding 保存索引和允许摘要；D:\AI-Practice 默认承载大型环境资源；B 保存项目绑定与源码，位置可以独立选择。A 通常固定，不扩展目录迁移或全盘搜寻。用户级 Skill 已安装不代表项目选择了某个案例；案例需求必须有明确选择及需求/设计来源。

全新 B 从用户索引发现已选准备，已有 B 用 preparationId 查原准备；显式来源与已有绑定冲突时保留工程，不能用全局新选择覆盖。复用前检查实际引擎、连接、镜像和挂载；报告不是当前可用性证明。有效本地镜像不拉取，不因换目录重装；缺失交环境助手恢复原镜像。

## 日常命令

在宿主 PowerShell 调用当前用户本技能 scripts/Invoke-CourseProject.ps1，传 B 的实际绝对路径。脚本在绑定容器内执行项目命令，宿主不用安装项目 Node/Java/Gradle。

```powershell
& "$env:USERPROFILE\.trae-cn\skills\ai-coding-env\scripts\Invoke-CourseProject.ps1" -ProjectDirectory <B> -Action Start
& "$env:USERPROFILE\.trae-cn\skills\ai-coding-env\scripts\Invoke-CourseProject.ps1" -ProjectDirectory <B> -Action RunScript -Script build
& "$env:USERPROFILE\.trae-cn\skills\ai-coding-env\scripts\Invoke-CourseProject.ps1" -ProjectDirectory <B> -Action RunScript -Script test
& "$env:USERPROFILE\.trae-cn\skills\ai-coding-env\scripts\Invoke-CourseProject.ps1" -ProjectDirectory <B> -Action Install
& "$env:USERPROFILE\.trae-cn\skills\ai-coding-env\scripts\Invoke-CourseProject.ps1" -ProjectDirectory <B> -Action Add -Packages <本轮需要的包及版本>
& "$env:USERPROFILE\.trae-cn\skills\ai-coding-env\scripts\Invoke-CourseProject.ps1" -ProjectDirectory <B> -Action Repair
```

RunScript 只调用实际 package.json 已有脚本；没有 test 脚本时按本轮有意义的验证补齐，不伪造成功。Add/Remove 只处理本轮需要的依赖；涉及主要框架版本变化时先更新已确认的工程方案，不借修复擅自升级。Android 使用 ai-coding-android 的 Build-Android.ps1，发布使用现有发布脚本；它们复用同一运行核验，不改为手写宿主命令。

入口在写记录前用Course-ProjectRoot.ps1确认真实B；传入已绑定源码子目录可解析唯一父工程，歧义/越界给明确纠错，不在子目录建第二套.ai-coding。工程不存在时回初始化Skill，不拿根解析器重建。端口被其他工程占用时先核归属，保留其他工程；按项目Spec使用可恢复的空闲绑定或记录待恢复，不直接停止别人的容器。

## 依赖异常恢复

先检查绑定镜像、源码挂载和独立依赖卷，再执行 Repair。脚本停止本项目 app、备份 package.json/lockfile，在同镜像临时容器和原卷内按锁文件恢复，再启动并核验。开发容器不健康也能进入这条路径；不删除整个项目、不清空无关卷。失败记录 .ai-coding/command.json 与 .local/course-command.log，保留备份；未恢复一致不能继续构建，也不能转宿主编译。日志由助手核对并脱敏，不让学员看日志排障。

## 估时和等待

读取当前 Skill assets/course-timing.json，按阶段/步骤取首次或复用时间。开始说明本次工作和估时；长下载、编译、平台部署时说明当前真实等待及是否需要本人操作；超过上限说明已完成部分、阻塞和处理。没有依据不报剩余时间或百分比。实际等待计入墙钟；估时与案例内部预算分别维护，配置/构建/网页/真机证据不能互代。


RunScript -Script build 可显式加 -ReuseBuild：入口仍核当前runtime、镜像、挂载、依赖，再比较源码/锁文件/配置及实际dist摘要；任何变化重新构建。记录 .ai-coding/web-build.json 与 .local/course-execution.jsonl。它不证明线上内容、权限或手机通过。Update-CourseProgress.ps1 提供阶段/等待/接续记录，方法见开发Skill implementation/efficient-execution.md。
