# 完整课前准备与恢复

课前短提示请求“全部准备”时，env是总编排入口，工具检查通过后连续调用当前用户cloudbase→github→siliconflow，最后汇总，不停在E-01让本人再说继续。只明确请求工具排障/复查时保持该范围，不擅自创建云资源或产生模型费用。没有作品时不创建业务工程/表/函数/APK。

1. 保存A和所选引擎，读取materials/runtime/原工具与服务记录。缺资料按setup-guide零资料入口下载/安装用户级技能，保留已有内容。
2. 按所选引擎指南安装/恢复并实际Verify，记录D盘计划和实际位置；引擎/镜像/容器检查各自完成。准备记录登记用户索引，不复制原始日志到用户目录。
3. 调ai-coding-cloudbase复用本人账号/实名/官方工具授权/环境，真实核PG能力及公开连接；无目标时才在本人已决定费用范围准备环境。
4. 调ai-coding-github核本人登录/邮箱；推送和Pages权限在B绑定时另核，不把头像当管理授权。保留官方登录缓存，不索取token。
5. 调ai-coding-siliconflow引导本人注册/登录、查看当前优惠及费用，由本人决定是否领取、是否充值。保存无秘密 account-readiness.json；不提前存Key或调用模型。V4程序设置就绪后由本人填写Key和模型。
6. 用 Register-CourseServices.ps1 登记允许摘要；最后E-05实际复查所选引擎/完整用户级Skill/存储/服务状态，明确每项范围和缺项。步骤勾选不代替工具结果。

每阶段记录本次结果、检查时间、实际入口、当前本人动作与下一阶段。发生本人授权/费用/条款/重启时一次引导一个动作并保存接续点；完成后继续。正常技术操作不暂停让本人重复发提示，也不自动批准其身份/费用。

用 scripts/Invoke-CoursePreparation.ps1 -WorkingDirectory <A> -Action Status 取得下一阶段/Skill。tools实际核验后调用 Save-PreparationEvidence.ps1 -WorkingDirectory <A> -Stage tools，脚本定位真实报告并登记；不手填路径。其余阶段每完成一个真实检查，调用同一入口的 -Stage <阶段> -Check <检查名> -Outcome passed|failed|pending -Kind command|tool|browser|learner -Reference <脱敏工具结果或页面/本人确认引用>。脚本自动取时、保存观察、列缺项；本阶段齐备后自动产规范证据并登记。AI阶段须有真实本人确认，summary的Trae加载必须实际观察；脚本不替代这些动作。

已有明确来源可以 -ObservationFile <A内实际观察文件> 导入，检查原时间/来源而不刷成新成功；旧Record -EvidencePath仍兼容，省略路径则用当前阶段标准位置。没有实际检查不能调用passed，不让本人填写JSON。缺项由Agent接续nextSkill。重启后运行本A已生成的 .course-setup/resume-preparation.ps1；它使用验证过的解释器绝对路径及原参数，不依赖PATH、不重新搬盘。

cloudbase checks为identityVerified/managementAccessVerified/pgCapabilityVerified/publicConfigSaved；github为identityVerified/emailVerified；summary为skillsVerified/traeLoadObserved/currentResultsReviewed。没有观察到Trae加载不得填true。证据改动/超过24小时需当前复查后重新登记，模型调用有效旧证据仍可按授权范围复用；刷新记录不意味着重调付费模型。

恢复先查A与用户级准备索引，仅补失效项；多环境冲突保留工程并核对目标。Podman不在PATH使用实际验证的绝对路径；缺CLI/Compose按官方安装链补齐，不把Desktop安装等同Ready。引擎离线恢复所选引擎，不切另一个；TLS失败核可信CA/出口，不禁用证书。下载慢按实测恢复，不能承诺可越过客户端网络策略。

PS5.1清单必须完整写入头部、技能逐项行及未验证项；核本次退出码/时间/内容，不能只看文件存在。旧通过留历史，本次失败不得沿用。费用/模型变化先核已授权范围，普通恢复不反复要求本人批准。

给学员的结果用功能语言：“工具已准备，接下来完成云服务授权”“课前还差AI验证”等；不把技术检查变成学员作业，不承诺固定审批次数或理想耗时。完整课前通过与作品可运行/已部署/手机通过分开。


2.1 镜像获取前先验实际存储：新 machine 的 VHDX、受管程序与 dataHome 必须落在选定非系统盘，再执行大镜像拉取/导入。已有有效本地镜像直接核验，不联系仓库。旧离线镜像在原归档摘要、固定配置ID、原connection和实际镜像ID均匹配时可复用历史归档证据，报告明确 ArchiveEvidenceReused，不声称本轮重验归档或在线RepoDigest。旧C盘环境保留资源并进入定位/迁移流程，不在C盘继续获取大镜像。


重启收尾和当前CLI/Compose绑定纳入tools判定；报告已通过但绑定被删时按原准备恢复，不能用旧报告替代。迁移复查restartStatus，完成后同步状态与时间。用真实时钟记录，首次/健康复用/旧环境迁移分别说明；本人拒绝领券或充值后立即接续。
