# 按需求启用能力

P-01先验本地底座，并按当前已确认需求接入能力。工具箱安装、A账号准备、PRD未来计划、B本轮启用和实际通过分别记录；未启用项不作为初始化缺项。已有明确需求可在初始化时接入，案例选择本身不授权一次性创建所有服务。

## 入口与顺序

1. 从已确认需求识别当前目标；未知时先完成本地工程，不让使用者选择技术组件。已有需求直接复用，不重复要求更新PRD/Canvas或批准技术配置。
2. 助手在当前Spec说明本轮能力、已有绑定、必要依赖、数据/权限/费用范围、实施与验收。未来计划留PRD/Spec。
3. 调用项目Skill/scripts/Enable-ProjectCapability.ps1 -ProjectDirectory <B> -Capability <下表值> -Reason <本轮目标>。脚本增量登记选择、物化必要公开配置、仅为所选服务调用Connect；返回pending与下一Skill，助手同一任务立即接续。这个入口不创建远程资源、不调用模型、不生成APK。
4. 对应Skill复用用户级索引定位A的账号准备，核实际授权/目标；缺项才恢复相应服务。账号准备不等于授权，更不等于项目资源已创建；必要本人动作一次一个。
5. 按目标实现并验证；可用Test-ProjectInitialization.ps1 -Scope Capability -Service <服务名>核接入证据。能力接入、实际功能/发布、本人试用分别记录；失败不改变本地初始化通过状态，不阻塞不相关能力。

| 当前目标 | Capability | 接续方法 |
| --- | --- | --- |
| 代码备份/协作 | github | ai-coding-github的代码仓库模式；services.github记录源码目标，不自动开Pages |
| github.io展示 | github-pages | ai-coding-github的Pages目标模式，再按development/publishing；services.githubPages独立记录静态目标，不改原remote |
| 云端保存/同步/服务端 | cloudbase | ai-coding-cloudbase，再按development/cloudbase；只启用所需数据、身份、存储/函数/托管 |
| 安装到安卓 | android | ai-coding-android及Build-Android；物化Capacitor配置后在原镜像创建/同步原生工程，不强制云账号或同步 |
| AI识图/对话等 | ai | 同时登记必要cloudbase依赖，接CloudBase服务身份/配置存储/持久配额与硅基流动；按ai-service-setup/model-settings实现设置和调用 |

AI依赖CloudBase不意味着启用业务数据同步或网页托管。GitHub代码仓库与Pages可分别选择，不以其中一个替代另一个。离线APK仅需local+android；浏览器预览是开发工具，不代表发布Web站点。

## 状态和恢复

project.json.capabilities保存已选择能力，capabilityMode=on-demand；services.json只在启用后创建对应接入项。pending表示该项接入中，不能冒充功能已通过；未启用项不生成pending作业。本地底座核环境、当前工程/构建、网页热更新与规则读取；本轮已请求接入的能力另报状态与证据，未完成不得写为已接入。

旧工程保留全部绑定、旧能力声明、模型、Key、appId/签名、remote与数据；旧声明不作为创建新资源的授权。旧规范精确匹配或受管块才增量更新，自定义冲突保留待合并。重复启用不清空目标或有效配置；Connect目标冲突时保留原值，不换环境/建仓库绕过。未完成操作查原状态后接续，不重建B。

初始化按当前需求启用AI/Android时生成相应默认文件或Capacitor配置；未启用时不生成，已存在的文件不覆盖。镜像可预置这些工具/依赖，工具可用不等于项目已接入。


## 当前准备与项目接入分工（2.2.3）

环境准备完成所需工具、云服务、GitHub、AI账号及必要授权并汇总；明确工具排障或缩小范围时才仅做该范围。项目初始化按当前已确认需求复用并接入能力，可在初始化时启用所需云服务/GitHub/AI；需求未明确时先建本地工程，不自动创建未来资源。AI Key在程序设置入口就绪后由本人填写；准备、接入、调用、发布和本人试用分别留证。
