---
name: ai-coding-development
description: 在已初始化的作品中实现本地网页、github.io 静态展示、CloudBase 数据与发布、服务端 AI；维护技术方案和进度。Android 构建交 ai-coding-android；不预设业务页面或案例。
---

# 通用作品开发

先读项目根 AGENTS.md、.ai-coding/project.json、services.json、docs/engineering/baseline.md、当前 PRD/Canvas、当前 spec 和 docs/progress/current.md。旧工程按实际目录接入，不重建。

先按 [执行路线](implementation/execution-route.md) 将用户功能目标映射到本地/原型发布/正式云端/Android/AI，只读当前指南；“生成安装文件”等自然表达已足够触发对应技能。按实际目录读取材料，不要求本人给技术长提示。先落本轮实现方案，再依其步骤连续实施；已有确认和普通修复直接继续。

每轮按功能目标 → 已确认需求/设计 → 助手维护技术方案 → 实现与检查 → 本人试用 → 记录反馈推进。已确认的本轮文件直接使用；实现缺陷直接修复。技术 spec 由助手维护，不向使用者索要技术文档。

所有项目开发服务、Web 编译和检查使用准备阶段登记的同一工具链镜像。读取 manifest 的 image、containerRuntime 与 Compose，不能在宿主机安装 Node/Java/Android SDK，也不能换 latest、临时 npx 下载工具或另建工具镜像。既有 Podman 工程按原记录兼容，不切引擎。

开始本轮且尚无当前检查时，用环境Skill的Test-CourseReadiness或Invoke-CourseProject -Action Verify核本机引擎/镜像/挂载及依赖。标准命令已返回当前核验时直接接续，不连续重复另一套预检。它只证明运行前提，不证明授权/产品通过；失败按下文恢复，不绕开执行。

引擎离线先恢复原引擎/Compose，缺依赖先核独立卷、锁文件和平台模块，在同镜像修复；权限失败核身份和GRANT/RLS。不能用宿主编译、关版本约束、换appId/remote、开放匿名写或前端秘密来绕行。实际API与示例不符先查当前版本及工程适配，确需改基线再记录原因/影响/授权边界，普通技术恢复无需反复问本人。

按当前目标只读一项：[本地](implementation/local.md)、[静态发布](implementation/publishing.md)、[CloudBase](implementation/cloudbase.md)、[AI](implementation/ai.md)。github.io/GitHub Pages 发布自动调用 ai-coding-github 的 references/pages-cli.md，以 Git/GitHub CLI 完成仓库及 Pages 设置；本技能准备静态副本与验证产物，不要求使用者改提示词或指挥浏览器设置。安卓调用用户级 ai-coding-android。首次服务配置应已由 ai-coding-project 完成；失效时调用对应服务技能只补缺项。

新增AI或更换模型时同时读取 [模型设置](implementation/model-settings.md)：本项目默认值只用于首次配置，V4设置入口持久化服务端有效模型/revision，网页与Android共享。禁止将唯一模型硬编码进产品；不能把前端可编辑字段当作配置已生效，必须核函数实际路由。初始化只准备默认值，具体功能随本轮实现。

通用检查在 [agent-step-checks.json](implementation/agent-step-checks.json)，分工见 [learner-responsibilities.md](implementation/learner-responsibilities.md)。选定案例后再合并案例检查，不能以案例取代通用门槛。不要因安装了案例技能就选择案例。

结束更新项目 docs/progress/current.md 与阶段记录：范围、实际文件、镜像身份、检查证据、本人反馈、缺项和下一步。普通技术操作连续完成；本人只确认产品、授权费用和亲自试用。准备、构建、部署、真实运行和本人试用分别报告。

新 Podman 工程通过用户级 ai-coding-env/scripts/Course-Runtime.ps1 的共同入口执行，复用其受管 Docker Compose EXE、显式 connection、API 转发验证与超时，不依赖 Desktop 或默认 PATH。构建失败保留原镜像/工程/身份并按对应层恢复。旧 Docker 工程继续按原绑定。

## 估时与等待

读取本技能 assets/course-timing.json，按当前阶段/步骤说明首次或复用的预计时间。长下载、编译、部署说明真实等待原因及本人是否需要操作；超过预计上限说明已完成部分、阻塞和处理，有依据才更新剩余时间。时间估算不代替实际证据，不展示虚假百分比；实际等待计入墙钟。

## 2.1 环境与项目执行约定

通用资料与案例资料可以统一下载、Skill 可以统一安装；已安装不代表已选案例。仅明确选择后加载案例需求，不能由 case-profile.json 的存在推断。A 保存原报告，用户级登记跨目录发现，新安装优先非系统盘（如 D:\ENV），只有 C 盘时用 C:\ENV 保存大资源，B 独立保存项目绑定。已有 B 按 preparationId 恢复，不受全局新选择影响；正常复用不拉镜像、不重装、不复制 A 资料。

日常安装依赖、更新锁文件、运行项目脚本和依赖恢复，调用当前用户 ai-coding-env/scripts/Invoke-CourseProject.ps1；按需读取该技能 references/project-execution.md 的命令及失败分支。已有关联 Web/发布/Android 脚本继续复用公共运行检查。宿主只负责编辑、Git、引擎控制、官方授权及手机连接，不安装项目编译工具链。

AI 的 E-08/P-01/V4 分工按当前用户 ai-coding-development/implementation/ai-service-setup.md：本人注册、查看可用优惠、决定充值、在程序配置 Key 和模型；助手负责工程与保密。P-01只完成本地基础；首次启用AI时再生成默认文件、接设置路线，Key解密或模型调用不作为初始化门槛。


开始本轮及恢复长任务时读取 [阶段执行与复用](implementation/efficient-execution.md)，用 Update-CourseProgress.ps1 记录真实阶段和等待，填具名Spec。V4设置同时读取 [配置授权和PG身份](implementation/ai-settings-access.md)。项目已明确授权用户的配置权限在恢复/升级后保留；方法通用，业务身份仅来自选定案例。
