﻿#Requires -Version 5.1
# Compatibility entrypoint: Pages configuration is owned by ai-coding-github.
. (Join-Path $PSScriptRoot '..\..\ai-coding-github\scripts\GitHub-Pages.ps1')
