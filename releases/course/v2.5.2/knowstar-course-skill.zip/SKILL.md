---
name: knowstar-course
description: 在本人明确选择学生错题本案例的当前作品中，引导需求原型、本地网页、云端共享、安卓与逐项AI迭代；提供案例业务规则和真实验收要求。
---

# 学生错题本示例指南

本案例只安装到已明确选择它的作品 .trae/skills/knowstar-course，不在环境准备或用户级安装。先读取作品根AGENTS、manifest、已确认PRD/Canvas和当前进度；案例包已缓存不代表本人选定。案例规则不能覆盖当前已确认设计或渗入通用工具。

环境在A由本地env准备，初始化由用户级ai-coding-project完成。作品的通用开发工作流在docs/engineering，助手据此直接实现；静态发布调用用户级 ai-coding-github，云端/AI 调用用户级 ai-coding-cloudbase，安卓交付调用用户级 ai-coding-android。按本轮需要登记项目资源绑定，不复制平台技能，也不提前启用后续能力。

## 示例接续

按 [步骤数据](references/course-steps.json) 的当前displayId定位，再用稳定id查 [内部检查](implementation/agent-step-checks.json)。旧准备中的模型供应商阶段只留历史，不恢复为准备门槛。用户网页勾选只代表本人记录，不能作为Agent检查通过的证据。

每一轮和每一项AI功能遵循：目标 → Gemini更新需求 → Canvas更新完整设计HTML → 本人确认 → 助手维护Spec并实现检查 → 本人试用 → 保存反馈。已确认本轮材料直接使用，不重复询问，不让本人补技术长提示或Spec。旧需求文件和完整HTML保持原位，按manifest定位，修改前保留前版。

只读取当前阶段指南：

| 当前目标 | 案例实施与验收 |
| --- | --- |
| 本地网页、保存与V1 | [V1](implementation/v1.md) |
| GitHub Pages静态展示、CloudBase共享与V2 | [V2](implementation/v2.md)、[静态发布](implementation/publishing.md) |
| 安卓安装与同步、V3 | [V3](implementation/v3.md) |
| 当前一项AI功能、V4 | [V4](implementation/v4.md)；选图识题另读 [节奏与验收](implementation/v4-vision-pace.md) |

保留已确认的原操作预算，实际平台等待和本人等待计入墙钟，不为赶时间减少功能或验收。V1按连续实现与集中试用推进；V2先做最小真实会话读写再增量接线；每项AI单独迭代，不一次实现未来任务。具体计时从当前指南读取，不向其他业务推广本案例预算。

## 案例产品约束

Ionic React、TypeScript、Vite、Capacitor；本地Tailwind 3/PostCSS/Autoprefixer使用准备镜像。IndexedDB通过Repository访问。Canvas是V1视觉与交互依据，保持单页Monster Deck、Weekend Trial、Add Monster Modal、暖奶油粗描边与硬阴影、学科胶囊、3D翻牌、LV1–LV3、画板、错因胶囊、礼花、Web Audio和A4试炼，不加五Tab。

V2区分GitHub Pages纯静态HTML展示和CloudBase正式作品，分别验证地址和结果。云端使用本项目PostgreSQL/Storage与确认的身份策略。按 [演示账号指南](implementation/course-demo-auth.md) 核真实UID、授权与负向测试；指定示例用户具有已明确授权的完整作品与AI设置能力，不额外增加管理员操作流程，其他未授权身份仍拒绝。

V3沿原Web/Capacitor工程与同一准备镜像构建，保留appId。交付新APK的实际绝对路径、可点击文件链接、版本/hash；构建、传输、安装、启动、同步和本人试用分开留证。

V4当前路线为Web/APK callFunction→CloudBase云函数→硅基流动HTTPS。供应商账号和费用仅在本轮AI需要时处理；设置UI和受保护后端先实现，再由本人在程序配置Key与模型。默认值来自用户级 ai-coding-cloudbase 的 assets/default-models.json；服务端有效配置和revision优先，两端共享。Key仅服务端保管，不进聊天、Git、前端、镜像、APK或日志。真实调用、失败回退与人工确认分别验证。

## 记录与交付

按 [分工](implementation/learner-responsibilities.md) 由本人决定业务、需求和试用结果，助手承担配置、实现、技术检查和故障恢复。普通技术工作连续执行，需要本人时给入口、一个动作和预期画面；完成后继续。

在实际docs/progress/course-progress.md记录阶段、稳定步骤id、当前AI任务、两份材料真实路径、Spec、技术结果和本人反馈。网页访问与数据共享、真实模型与手机结果各自留证；未验证不得报通过。结束给真实网址或APK文件链接、当前必要动作和缺项，并提供可回到设计阶段的简短反馈。
