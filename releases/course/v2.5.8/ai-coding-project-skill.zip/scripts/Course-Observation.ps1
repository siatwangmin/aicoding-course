﻿#Requires -Version 5.1
# Structural validation only: never manufactures or independently proves observations.
function ConvertTo-CourseProjectObservationTime($Value) {
    # PS7 can deserialize ISO timestamps as DateTime; avoid lossy string coercion.
    if($Value -is [datetimeoffset]){return $Value}
    if($Value -is [datetime]){
        if($Value.Kind -eq [DateTimeKind]::Unspecified){throw 'OBSERVATION_TIMEZONE_REQUIRED'}
        return [datetimeoffset]$Value
    }
    if(-not $Value -or [string]$Value -notmatch '(Z|[+-]\d{2}:\d{2})$'){throw 'OBSERVATION_TIMEZONE_REQUIRED'}
    return [DateTimeOffset]::Parse([string]$Value,[Globalization.CultureInfo]::InvariantCulture)
}
function Get-CourseObservationWindow($Observation) {
    $hasPoint=[bool]$Observation.observedAt
    $hasRange=[bool]$Observation.observedFrom -or [bool]$Observation.observedTo
    if($hasPoint -eq $hasRange){throw 'OBSERVATION_POINT_OR_RANGE_REQUIRED'}
    $from=if($hasPoint){$Observation.observedAt}else{$Observation.observedFrom}
    $to=if($hasPoint){$Observation.observedAt}else{$Observation.observedTo}
    $start=ConvertTo-CourseProjectObservationTime $from;$end=ConvertTo-CourseProjectObservationTime $to
    if($end -lt $start){throw 'OBSERVATION_RANGE_REVERSED'}
    return @{start=$start;end=$end}
}
function Test-CourseLocalObservation($Evidence,[string]$Name) {
    try{
        if($Evidence.schemaVersion -ne 4 -or @($Evidence.evidence).Count -eq 0){return $false}
        $checked=ConvertTo-CourseProjectObservationTime $Evidence.checkedAt
        foreach($o in @($Evidence.evidence)){
            $w=Get-CourseObservationWindow $o
            if([string]::IsNullOrWhiteSpace($o.reference) -or $o.actor -ne 'agent' -or $w.end -gt $checked -or ($checked-$w.start).TotalHours -gt 24){return $false}
        }
        if($Name -eq 'browser'){
            if($Evidence.checks.sourceRestored -ne $true){return $false}
            $last=$null;$document=$null
            foreach($step in @('baseline','changed','restored')){
                $items=@($Evidence.evidence|Where-Object step -eq $step)
                if($items.Count -ne 1){return $false}
                $item=$items[0];$w=Get-CourseObservationWindow $item
                if($item.method -ne 'dom' -or [string]::IsNullOrWhiteSpace($item.documentId) -or [string]::IsNullOrWhiteSpace($item.observedText)){return $false}
                if($last -and $w.start -lt $last){return $false}
                if($document -and $item.documentId -cne $document){return $false}
                $document=$item.documentId;$last=$w.end
            }
        }elseif($Name -eq 'rules'){
            $entry=@($Evidence.evidence|Where-Object step -eq 'projectEntry')
            if($entry.Count -ne 1 -or $entry[0].method -ne 'session-rule-injection'){return $false}
            if(@($Evidence.skills).Count -eq 0){return $false}
            $names=@($Evidence.skills|ForEach-Object {$_.name})
            if(@($names|Select-Object -Unique).Count -ne $names.Count){return $false}
            foreach($s in @($Evidence.skills)){
                if(-not $s.name -or [string]::IsNullOrWhiteSpace($s.reference)){return $false}
                $expected=switch($s.state){
                    'installed' {'filesystem'}
                    'discovered' {'session-skill-list'}
                    'loaded' {'session-skill-content'}
                    'invoked' {'skill-tool'}
                    'script-executed' {'command'}
                    'not-observed' {'unavailable'}
                    'not-applicable' {'scope'}
                    default {return $false}
                }
                if($s.method -ne $expected){return $false}
            }
            $project=@($Evidence.skills|Where-Object {$_.name -eq 'ai-coding-project' -and $_.state -in @('loaded','invoked')})
            if($project.Count -ne 1){return $false}
        }else{return $false}
        return $true
    }catch{return $false}
}
