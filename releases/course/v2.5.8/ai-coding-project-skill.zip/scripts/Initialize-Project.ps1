﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,[string]$PreparationDirectory,[string]$Name,[int]$Port=5187,
      [string]$ManagementNode,
      [ValidateSet('Initialize','Resume','Verify')][string]$Action='Initialize',
      [string[]]$Capabilities,[string]$CapabilityReason,[string]$CaseSkill,[string]$CasePackageRoot)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$root=[IO.Path]::GetFullPath($ProjectDirectory)
$manifest=Join-Path $root '.ai-coding/project.json'
if($Action -eq 'Initialize'){
    $entryFile=Join-Path $root 'AGENTS.md'
    $preparationFile=Join-Path $root '.course-setup/materials.json'
    if((Test-Path -LiteralPath $preparationFile) -or ((Test-Path -LiteralPath $entryFile -PathType Leaf) -and ([IO.File]::ReadAllText($entryFile).Contains('<!-- local-course:entry -->') -or [IO.File]::ReadAllText($entryFile).Contains('<!-- ai-coding:materials-entry:1 -->')))){
        throw 'PROJECT_TARGET_IS_PREPARATION_WORKSPACE: preserve course files; open a separate empty project directory. Do not rename or merge the preparation AGENTS.md.'
    }
}
if($Action -eq 'Initialize' -and (Test-Path -LiteralPath $manifest)){throw 'PROJECT_ALREADY_EXISTS: use Resume, Verify or explicit Upgrade; Initialize does not upgrade.'}
if($Capabilities.Count -or $CaseSkill){throw 'LOCAL_INITIALIZATION_ONLY: invoke the user-level platform skill or explicit case entry after local initialization.'}
$executionRoot=if($Action -eq 'Initialize'){Resolve-CourseExecutionRoot ''}else{Resolve-CourseExecutionRoot $root}
. (Join-Path $executionRoot 'scripts/Course-Runtime.ps1')
. (Join-Path $executionRoot 'scripts/Course-NodeJs.ps1')
Assert-CoursePlainPath $root
$projectMutex=[Threading.Mutex]::new($false,('Local\course-initialize-'+(Get-CourseLifecycleHash $root.ToLowerInvariant())))
try{$projectEntered=$projectMutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{$projectEntered=$true}
if(-not $projectEntered){$projectMutex.Dispose();throw 'PROJECT_INITIALIZATION_BUSY'}
try{
$generator=Join-Path $PSScriptRoot 'create-project.mjs'
# No project writes, preparation recovery or engine operations before this full path plan.
if($Action -eq 'Initialize'){
    $node=Resolve-CourseManagementNode $ManagementNode
    $plan=Invoke-SetupNative $node @($generator,'--target',$root,'--plan') 30
    if($plan.ExitCode -ne 0){throw ('PROJECT_PREFLIGHT_FAILED: '+(Protect-CourseOutput $plan.Output))}
}
if($Action -eq 'Verify'){
    $ctx=Get-CourseProjectRuntime $root
    [pscustomobject]@{status='verified';scope='runtime';projectDirectory=$root;url=$ctx.Url;port=$ctx.Project.port;evidence='.ai-coding/runtime-check.json'}|ConvertTo-Json
    return
}
$node=Resolve-CourseManagementNode $ManagementNode
$timer=[Diagnostics.Stopwatch]::StartNew();$started=(Get-Date).ToUniversalTime().ToString('o');$phase='PreparationBinding';$outcome='failed';$lease=$null
try{
    $prepared=Find-CourseProjectPreparation $root $PreparationDirectory;$p=$prepared.record
    $lease=Enter-CourseOperation $prepared.workspace 'InitializeProject'
    if(-not(Test-Path -LiteralPath $manifest)){
        $phase='TemplateCopy'
        $temporary=Join-Path (Get-CourseUserRoot) 'temporary';$null=Protect-CourseDirectory $temporary
        $transactions=Join-Path (Get-CourseUserRoot) 'project-transactions';$null=Protect-CourseDirectory $transactions
        $snapshot=Join-Path $temporary ([guid]::NewGuid().ToString('N')+'.json')
        try{
            & (Join-Path $executionRoot 'scripts/Export-CoursePreparation.ps1') -PreparationDirectory $prepared.workspace -Destination $snapshot|Out-Host
            $arguments=@($generator,'--target',$root,'--image',$p.image,'--preparation',$snapshot,'--runtime',$p.containerRuntime,'--port',[string]$Port,'--state-root',$transactions)
            if($p.containerRuntime -eq 'podman'){$arguments+=@('--network-mode',$p.networkMode)}
            if($Name){$arguments+=@('--name',$Name)}
            if($Action -eq 'Resume'){$arguments+='--resume'}
            $created=Invoke-SetupNative $node $arguments 90
            if($created.ExitCode -ne 0){throw ('PROJECT_COPY_FAILED: '+(Protect-CourseOutput $created.Output))}
        }finally{Remove-CourseTransientFile $snapshot}
    }
    $phase='ConnectRuntime'
    & (Join-Path $PSScriptRoot 'Connect-Project.ps1') -ProjectDirectory $root -PreparationDirectory $prepared.workspace|Out-Host
    $phase='ContainerBuildAndStart'
    # One runtime Start/mount/dependency verification inside the common command entry.
    $build=& (Join-Path $executionRoot 'scripts/Invoke-CourseProject.ps1') -ProjectDirectory $root -Action RunScript -Script build -ReuseBuild|ConvertFrom-Json
    $runtime=Read-CourseJson (Join-Path $root '.ai-coding/runtime-check.json')
    if($runtime.mountRoundtripAndHostHttp -ne 'verified' -or -not $runtime.url){throw 'VERIFIED_RUNTIME_URL_REQUIRED'}
    $project=Read-CourseJson $manifest
    $progress=Join-Path $root '.ai-coding/initialization-plan.json'
    Write-CourseJson $progress @{schemaVersion=2;checkedAt=(Get-Date).ToString('o');status='pending';localBuild='verified';scope='local-initialization';url=$runtime.url;hostPort=$runtime.hostPort;requestedCapabilities=@();capabilityStatus='not-requested';nextSkills=@();remaining=@('browser and mounted hot reload','Trae rule/skill load observation','initialization evidence gate')}
    $outcome='pending'
    [pscustomobject]@{status='pending';projectDirectory=$root;url=$runtime.url;port=$runtime.hostPort;designDirectory=$project.designDirectory;continuation=$progress}|ConvertTo-Json
    Write-Host ('本地网页：'+$runtime.url+' （端口 '+$runtime.hostPort+'）')
}catch{
    $primaryError=$_
    try{
        $diagnostic=Get-CourseErrorDiagnostic $primaryError $phase $executionRoot
        $folder=Join-Path (Get-CourseUserRoot) 'diagnostics';$null=Protect-CourseDirectory $folder
        $file=Join-Path $folder ('initialize-'+[guid]::NewGuid().ToString('N')+'.json');Write-CourseJson $file $diagnostic
        Write-Warning ('PROJECT_INITIALIZATION_FAILED: phase='+$phase+'; diagnostics='+$file) -WarningAction Continue
    }catch{Write-Warning ('DIAGNOSTIC_WRITE_FAILED: phase='+$phase+'; primary error follows.') -WarningAction Continue}
    throw $primaryError
}finally{
    # Secondary bookkeeping failures cannot replace the original business exception.
    if($lease){try{Exit-CourseOperation $lease}catch{Write-Warning 'OPERATION_RELEASE_FAILED' -WarningAction Continue}}
    try{
        if(Test-Path -LiteralPath $manifest){Write-CourseEvent $root @{stage='P-01';action=$Action;status=$outcome;startedAt=$started;finishedAt=(Get-Date).ToUniversalTime().ToString('o');durationMs=$timer.ElapsedMilliseconds;evidence='.ai-coding/initialization-plan.json'}}
    }catch{Write-Warning 'INITIALIZATION_EVENT_WRITE_FAILED' -WarningAction Continue}
}
}finally{$projectMutex.ReleaseMutex();$projectMutex.Dispose()}
