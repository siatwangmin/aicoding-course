﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,
      [ValidateSet('Begin','Status','Restore')][string]$Action='Status')
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $executionRoot 'scripts/Course-Context.ps1')
$root=[IO.Path]::GetFullPath($ProjectDirectory).TrimEnd('\')
Assert-CoursePlainPath $root
$folder=Join-Path $root '.local/hmr-probe'
$stateFile=Join-Path $folder 'state.json'
$backup=Join-Path $folder 'original.bin'
$mutex=[Threading.Mutex]::new($false,('Local\course-hmr-'+([BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($root.ToLowerInvariant())))).Replace('-','')))
$entered=$false
function HashBytes($bytes){$sha=[Security.Cryptography.SHA256]::Create();try{return ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}}
try{
 try{$entered=$mutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{$entered=$true}
 if(-not $entered){throw 'HMR_PROBE_BUSY'}
 Assert-CoursePlainPath $folder
 $state=if(Test-Path -LiteralPath $stateFile){Read-CourseJson $stateFile}else{$null}
 if($Action -eq 'Status'){
  if($state){$state|ConvertTo-Json -Depth 8}else{@{status='not-started'}|ConvertTo-Json};return
 }
 $project=Read-CourseJson (Join-Path $root '.ai-coding/project.json')
 $target=[IO.Path]::GetFullPath((Join-Path (Join-Path $root $project.sourceDirectory) 'src/App.tsx'))
 if(-not $target.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'HMR_SOURCE_ESCAPES_PROJECT'}
 Assert-CoursePlainPath $target
 if($Action -eq 'Begin'){
  if($state -and $state.status -ne 'restored'){throw 'HMR_PENDING_RESTORE: run Status and Restore before starting again.'}
  $bytes=[IO.File]::ReadAllBytes($target);$text=[Text.Encoding]::UTF8.GetString($bytes)
  $needle='工作空间已经就绪'
  if(-not $text.Contains($needle)){$needle='工作空间已就绪'}
  if(([regex]::Matches($text,[regex]::Escape($needle))).Count -ne 1){throw 'HMR_STANDARD_MARKER_UNAVAILABLE: preserve customized source; use an explicit reviewed probe.'}
  $marker='COURSE_HMR_'+[guid]::NewGuid().ToString('N')
  $changed=[Text.UTF8Encoding]::new($false).GetBytes($text.Replace($needle,$marker))
  [void](New-Item -ItemType Directory -Path $folder -Force)
  # Backup and intent persist before any source change, allowing recovery after API interruption.
  Assert-CoursePlainPath $backup;Assert-CoursePlainPath $stateFile
  [IO.File]::WriteAllBytes($backup,$bytes)
  $state=@{schemaVersion=1;status='prepared';source=$target;originalSha256=(HashBytes $bytes);probeSha256=(HashBytes $changed);marker=$marker;preparedAt=(Get-Date).ToString('o')}
  Write-CourseJson $stateFile $state
  if((HashBytes ([IO.File]::ReadAllBytes($target))) -ne $state.originalSha256){throw 'HMR_SOURCE_CHANGED_CONCURRENTLY'}
  [IO.File]::WriteAllBytes($target,$changed)
  $state.status='changed';$state.changedAt=(Get-Date).ToString('o');Write-CourseJson $stateFile $state
 }else{
  if(-not $state -or $state.source -ne $target){throw 'HMR_RECOVERY_BINDING_MISSING'}
  Assert-CoursePlainPath $backup
  $bytes=[IO.File]::ReadAllBytes($backup)
  if((HashBytes $bytes) -ne $state.originalSha256){throw 'HMR_BACKUP_MISMATCH'}
  $current=HashBytes ([IO.File]::ReadAllBytes($target))
  if($current -notin @($state.originalSha256,$state.probeSha256)){throw 'HMR_SOURCE_CHANGED: preserve user edits; manual reconciliation required.'}
  if($current -eq $state.probeSha256){[IO.File]::WriteAllBytes($target,$bytes)}
  if((HashBytes ([IO.File]::ReadAllBytes($target))) -ne $state.originalSha256){throw 'HMR_RESTORE_FAILED'}
  $state|Add-Member NoteProperty restoredAt ((Get-Date).ToString('o')) -Force
  $state.status='restored';Write-CourseJson $stateFile $state
 }
 $state|ConvertTo-Json -Depth 8
}finally{if($entered){$mutex.ReleaseMutex()};$mutex.Dispose()}
