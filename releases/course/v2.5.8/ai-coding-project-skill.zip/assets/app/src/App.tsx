export default function App() { return <main className="starter"><h1>AI Coding容器环境已经建立，工作空间已经就绪。</h1></main>; }
