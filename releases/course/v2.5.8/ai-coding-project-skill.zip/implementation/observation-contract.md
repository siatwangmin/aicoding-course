# 本地验收证据 v4

本文件是 browser/rules 的当前唯一字段规范。真实观察无法取得时保留 pending，不为了通过校验变更事实。Record 仍自动计算绑定/规则哈希并添加 recordedAt。校验字段不等于独立验证事实，禁止把文件读取重新标注为平台自动注入。

## 时间：一个准确时刻或一个真实区间，二选一

每项 evidence 使用 observedAt，或同时使用 observedFrom / observedTo；时间须带时区。区间必须来自工具调用起止或已有日志，不估算，不用保存时刻补齐。时刻和区间都在 checkedAt 之前，观察不超过24小时。baseline、changed、restored 的区间依次不重叠。

第一轮已经有真实观察和可靠区间时，直接使用该轮证据，不能仅因没有精确瞬时时刻重复 Begin/Restore。确无时间依据且源代码已恢复时，记录缺项；下一轮需要补观察时先捕获工具调用前后时间，不再临时研究计时方案。

## browser 输入示例

下面只展示结构，时间、文档身份、文字和引用必须取自真实观察。

```json
{
  "schemaVersion":4,"status":"verified","checkedAt":"2026-10-23T17:00:00+08:00",
  "checks":{"pageSeen":true,"hotReloadVerified":true,"sourceRestored":true},
  "evidence":[
    {"step":"baseline","actor":"agent","method":"dom","documentId":"同页面随机标识与timeOrigin","observedText":"原文","observedFrom":"2026-10-23T16:50:00+08:00","observedTo":"2026-10-23T16:50:05+08:00","reference":"实际工具观察记录"},
    {"step":"changed","actor":"agent","method":"dom","documentId":"同页面随机标识与timeOrigin","observedText":"实际唯一marker","observedFrom":"2026-10-23T16:51:00+08:00","observedTo":"2026-10-23T16:51:05+08:00","reference":"同文档自动变化记录"},
    {"step":"restored","actor":"agent","method":"dom","documentId":"同页面随机标识与timeOrigin","observedText":"原文","observedAt":"2026-10-23T16:52:00+08:00","reference":"源码哈希恢复及同文档自动恢复记录"}
  ]
}
```

资源条目只能证明模块请求/传输，不能代表 DOM 已更新或布局已呈现，不用其时间宣称“页面热更新小于一秒”。DOM观测晚于变更时，只报告观察区间，不把两次观察间隔当作精确渲染延迟。

## rules：磁盘、会话、脚本调用分开

rules 顶层同样使用 schemaVersion=4、status、checkedAt、evidence。checks 保留 projectEntryObserved 与 skillsObserved 两个兼容字段，但 true 现在必须有以下细分证据：

- evidence 中恰有一个 step=projectEntry，method=session-rule-injection：当前会话真实附带了项目规则。只执行 Get-Content 不满足此条件。无法查看平台注入状态就保留 pending，不重装、不把字段改成 true。
- skills 数组中的每项包含 name、state、method、reference，使用以下对应关系。

| state | method | 含义 |
| --- | --- | --- |
| installed | filesystem | 磁盘上存在，不代表会话发现 |
| discovered | session-skill-list | 当前会话可用技能列表中出现 |
| loaded | session-skill-content | 当前会话已加载技能正文 |
| invoked | skill-tool | 有实际技能调用事件 |
| script-executed | command | 仅执行脚本，不证明平台加载了 Skill |
| not-observed | unavailable | 未观察到 |
| not-applicable | scope | 当前作用域无需加载，例如作品会话的 env |

ai-coding-project 至少须 loaded 或 invoked。其他平台 Skill 可以 installed/discovered/not-observed，不为凑齐状态执行授权或业务；env 按真实作用域记录。evidence 时间使用上述时刻或区间形式，actor=agent。本人试用另记。

## 正式入口

```powershell
& '<Skill>/scripts/Test-ProjectInitialization.ps1' -ProjectDirectory '<B>' -Action Record -Service browser -EvidencePath '<真实浏览器观察.json>'
& '<Skill>/scripts/Test-ProjectInitialization.ps1' -ProjectDirectory '<B>' -Action Record -Service rules -EvidencePath '<真实规则观察.json>'
& '<Skill>/scripts/Test-ProjectInitialization.ps1' -ProjectDirectory '<B>' -Action Check
```

旧v3证据不能自动变为v4通过；保留原件。仅可在已有原始记录足够时如实转换，不补造会话加载事件。网页/HMR已通过而规则缺证时只报告规则待验证，不重跑整个初始化。
