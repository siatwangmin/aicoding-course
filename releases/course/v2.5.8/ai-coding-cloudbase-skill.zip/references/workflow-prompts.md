# 快路径提示词（优先）

调用 ai-coding-cloudbase。第一条命令 BeginTask，若已给出指令提交时间就传 TaskStartedAt。按根 AGENTS 读取当前工程必需入口与部署计划/验证配置，复用现有页面、Repository、资源和浏览器适配器；已有工程不重读全套原型和技能实现。统一入口 Run 用可轮询长任务，保持父进程并按依赖并行，失败按原节点恢复，禁止新建轮次抹掉失败时间。更新现有进度的简短结果，最后 CompleteTask。交付网址、双会话结论、整轮总耗时和阶段短表，不生成长报告。

以下旧场景模板仅在快路径存在具体缺项时按需读取。

# 项目执行提示词模板

供助手按当前已确认需求使用，不要求使用者复制所有提示词。先用 [并行工作流](../implementation/parallel-workflow.md) Measure 记录起点，选择首次/恢复/前端更新计划；Plan/Status 取得实际目标、ready、expectedInputStamp 和检查项。每个外部任务先Begin，实际完成后Record；Start/Resume会后台自动推进本地节点。花括号表示实际项目事实，不把样例路径或表名当默认业务。

## 预检与并行推进

“继续当前项目 {目标}。Measure后按所需能力填写计划，用查询模板一次核对当前绑定/授权/所需资源，按依赖并行处理缺项、SDK接口契约准备和验收准备。保持已选MCP/CLI、SDK、镜像与实际环境。已授权本地任务由后台协调进程自动接续；前台完成实际外部任务后Record，无独立工作时短Watch。等待/排障用事件入口记录；报告自动汇总真实总耗时和缺测项，约15分钟是待实测目标。”

## 资源差异与接续

“在 {envId} 通过当前官方工具读取本轮所需 {表/字段/桶/权限/函数}，对照 {已确认资源契约和迁移文件} 输出复用项与增量。资源已匹配则查回留证；有差异时按已授权范围执行增量并查回。平台返回 TaskId 时记录原任务并查询终态；结果未知先查询，避免重复提交。同一表/策略/托管目标的写入保持串行。证据中仅保留目标、摘要、时间、状态和必要检查结果。”

资源模板采用当前官方 PG/存储/函数技能与实际 schema；本技能不提供可盲目套用的通用建表/RLS SQL。将本项目审核后的 SQL 路径加入 resourceInputs，后端代码/配置路径加入 backendInputs，再用本轮计划执行。

## SDK 与页面接线

“沿 {现有适配文件} 对齐当前 SDK、会话和实际字段，复用 web-pg-client.mjs 的调用形态。adapterInputs 列出 SDK/Repository 适配文件；这些文件可用后记录 adapter。继续页面接线时可并行验证已稳定的最小链路；页面完成后记录 frontend，让后台构建启动。按设计实现等待、失败保留输入和重试，不重写页面或增加业务功能。适配层变化须重验相关链路。”

## 构建与部署

“通过原镜像构建一次并固定产物；已有指纹和完整摘要匹配时复用。CLI 路线使用已登记入口，由工作流后台发布；MCP 路线用官方工具上传本轮同一 dist，保存任务标识并查询终态。发布前确认已有部署授权；成功后记录 deploy，失败或结果未知分别记录，不把任务受理当部署完成。”

## 验收与交付

“本轮 {buildId} 上线后，让资源校验与浏览器冒烟并行。browser 默认用 scripts/verify-smoke.mjs 单会话完成五项检查（登录页/错误密码/正确登录/写入→刷新仍在/登出回登录门），结果包装为 kind=browser 证据 Record；仅计划 multiSession=true 才建 sessions 并按 A 保存→B 核对验证双向同步。相关真实失败、权限拒绝和恢复分别留证，记录未测项。本人试用仅按实际反馈登记。最后给完整可点击 https 网址、实际耗时、技术结果和一个明确下一动作。”

## 默认域名与错误接续

“若资源检查报响应头异常，先读本轮diagnostic/原始事件，按实际官方网关查询确认目标策略并填写platformPolicyFile。明确匹配的默认域名策略只影响头部判定，仍核全量摘要和真实浏览器；未知策略或摘要错误保留失败。验证失败只处理验证阶段，不重建、不重推。平台任务未知先查原TaskId；明确失败后才显式重试对应节点。”

## 一键首次部署（无登录+刷新同步）

适用于：无登录共享数据集、需双会话刷新同步验收的首次部署（计划样例 assets/examples/first-deploy-nologin-sync-plan.json，路径按项目改写）。

“继续当前项目 {目标}。在常驻终端串联项目执行包 Start 预热引擎，随后 Measure→按 first-deploy-nologin-sync-plan.json 填写实际 {adapterInputs/resourceInputs}→Plan→Start。Start 后三线并行：后台运行 scripts/Invoke-CloudBaseResources.ps1 一键执行迁移 SQL（输出作 reference，完成即 Gen-CloudBaseEvidence.ps1 -TaskId resources -Auto -Record 闭环）；同步改写 {适配文件} 并用 -Auto 登记 adapter；node scripts/prepare-sessions.mjs --root '<B>\.ai-coding\cb\sessions' --count 2 预建双会话。页面接线期间即跑 node scripts/verify-probe.mjs --base {hostingUrl} 前置验证最小链路，frontend 完成让后台 build 启动。deploy 后 assets 与 browser 并行：node scripts/verify-sync.mjs --base {hostingUrl} --profileA {profiles[0].dir} --profileB {profiles[1].dir} 完成五项同步检查并包装 kind=browser 证据 Record。所有任务 verified 后给完整 https 网址、实测耗时和一个下一动作。local worker 只在常驻终端拉起；事故按 parallel-workflow.md 恢复预案处理，不盲目重试。”

## 登录交付与报告

“本项目需要登录时启用login；提前确认provider、已有账号及授权安全凭据来源，缺凭据则说明具体缺项并继续独立工作。已有账号复用，不擅自改密/删除/创建。用实际正确登录证明可用后交付登录指引；普通证据只保存安全来源引用，不写密码或token。最终引用自动report.md/measurement.json，分别说明部署、文件、浏览器、业务和本人试用，不将部分通过写成全部通过。”

## 修复后部署提示词

调用当前用户级ai-coding-cloudbase，沿项目确认的环境部署并验证数据同步，记录各阶段耗时，不生成长报告。先Measure与只读Preflight -CheckRuntime；默认域策略用observe-policy.mjs自动观测。按ready调用Invoke-CloudBaseTask，Begin紧邻实际动作，不批量标running充当并行。frontend/probe保持父命令运行到Start、HTTP检查、冒烟及Record结束；机器State与API、端口分开判断。后台采用工具可轮询长任务，未知任务先查询原结果。保留现有用户/权限/数据与镜像，不重建机器或重装依赖。多端同步用独立会话的本项目适配脚本验证；无法自动验证时交付人工待验，不能把刷新持久化当双端同步通过。最后只给网址、阶段用时、通过项/未测项和记录位置。
# 优先：统一执行提示词

读取当前项目绑定、计划、cloudbase-verification.json。若已登记官方 CLI 且资源和页面接线就绪，调用 Invoke-CloudBaseDeploy.ps1 -Action Run -ProjectDirectory <B> -CliPath <已登记入口> -AllowPublish；用可轮询长任务保持父进程，等待原任务，不再手工逐个 Begin/Record。自动按依赖并行，失败查询原操作，不重复提交。记录实际阶段耗时，只输出网址、同步结果与短耗时表。项目 business adapter 保存在项目，公共技能不改业务选择器。

CLI 不可用、MCP 绑定或业务尚未接线时，先按原通道补当前缺项，再使用适合该通道的下列模板；不为了使用控制器而变更授权路线。

