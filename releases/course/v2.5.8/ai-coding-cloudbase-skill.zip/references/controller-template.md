# 部署与整轮计时模板

先 BeginTask，再读当前项目必要材料；最后 CompleteTask。若调用方能记录指令提交时间，可通过 -TaskStartedAt 传 ISO 时间；否则以第一条技能命令为起点，明确这不是 Trae 内部计时器的精确副本。

```powershell
$entry = '<用户技能目录>/scripts/Invoke-CloudBaseDeploy.ps1'
& $entry -ProjectDirectory '<B>' -Action BeginTask
# 读取 AGENTS 要求的工程入口、绑定与进度，以及 plan/verification；复用已有业务接线。
& $entry -ProjectDirectory '<B>' -Action Run -CliPath '<已登记tcb入口>' -AllowPublish
# 以上整条命令用可轮询长任务运行；父进程保持存活，不再逐个 Begin/Record。
# 成功后简短更新现有 Spec/进度。最后：
& $entry -ProjectDirectory '<B>' -Action CompleteTask
```

参数明确：Run 新建部署轮次；Resume 接续原轮次；Status 只读 controller；BeginTask 开始整条助手任务；CompleteTask 只有原工作流和控制器都 verified 才结束。Resume -RetryTask resources 或 build 只重置指定的明确失败节点；running/outcome-unknown 不可直接重试，先查询原操作。部署历史 summary 和每次成功/失败尝试保留。

配置 `.ai-coding/cloudbase-verification.json`（示例见 assets/examples/cloudbase-verification.json），配置和 adapter/script 都声明在计划 verificationInputs。probe/browser 的 runner 可选 probe/sync/smoke/project-script；通用骨架读取项目导出的 SITE、SEL、fillAndSubmit，业务控件不得写进公共技能。已有适配器不要重写。普通数据同步计划可 localProbe=false；登录/图片/后端项目保留专门检查。

自动同步：syncVerification=auto、multiSession=true、browser.runner=sync，必须两个独立 profile 的双向读写通过。人工模式用 manual、multiSession=false、browser.runner=smoke，结果只报同步待人工确认，不能伪装自动通过。

资源差异由项目 resourceInputs 驱动，声明 FORCE RLS 就校验 FORCE；JSON 表模板默认开启 RLS，forceRls=true 才额外强制。发现缺项先预览已确认的项目迁移，只补缺项；不自动增大业务权限，不因为失败而执行全量删除/重建。

任务计时在 .ai-coding/cb/task.json 及 task-<id>.json，包含 intake-and-adaptation、deployment-including-recovery、finalization；部署 measurement.json 包含子任务和 attempts。重叠阶段不相加；整轮总时长包括等待、排障和收尾，阶段细节未测就写未测。

交付仅网址、同步状态、整轮总耗时、阶段短表与两个 JSON 路径。默认不另写报告。
