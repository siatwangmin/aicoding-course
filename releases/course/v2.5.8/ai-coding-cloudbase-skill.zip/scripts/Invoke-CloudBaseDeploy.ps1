﻿#Requires -Version 5.1
# One owned parent for deterministic CLI tasks. Run this as a tool-managed long command.
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,
 [ValidateSet('BeginTask','CompleteTask','Run','Resume','Status')][string]$Action='Run',
 [string]$CliPath,[string]$PlanFile,[string]$VerificationFile,
 [string]$TaskSessionId,[string]$TaskStartedAt,[string]$RetryTask,
 [switch]$AllowPublish,[ValidateRange(60,3600)][int]$TimeoutSeconds=900,
 [ValidateRange(1,10)][int]$PollSeconds=2)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $executionRoot 'scripts/Course-Context.ps1')
. (Join-Path $PSScriptRoot 'Course-CloudBaseWorkflow.ps1')
$context=Get-CBProject $ProjectDirectory
. (Join-Path $PSScriptRoot 'Course-CloudBaseTaskClock.ps1')
$wf=Join-Path $PSScriptRoot 'Invoke-CloudBaseWorkflow.ps1'
$taskEntry=Join-Path $PSScriptRoot 'Invoke-CloudBaseTask.ps1'
$jobPath=Join-Path $context.Root '.ai-coding/cb/controller.json'
if($Action -eq 'BeginTask'){
 Start-CBTaskClock $context $TaskSessionId $TaskStartedAt|ConvertTo-Json -Depth 8
 return
}
if($Action -eq 'CompleteTask'){
 $final=(& $wf -ProjectDirectory $context.Root -Action Status|Out-String)|ConvertFrom-Json
 $job=Read-CBState $jobPath
 if($final.status -ne 'verified' -or $job.status -notin @('verified','deployment-verified-sync-pending-manual') -or $job.runId -ne $final.runId){throw 'VERIFIED_ORIGINAL_RUN_REQUIRED_BEFORE_TASK_FINISH'}
 Update-CBTaskClock $context 'finish' $final.runId $job.status $job.measurement|ConvertTo-Json -Depth 8
 return
}
if($Action -eq 'Status'){
 if(Test-Path -LiteralPath $jobPath){Read-CBState $jobPath|ConvertTo-Json -Depth 12}else{[pscustomobject]@{status='not-started'}|ConvertTo-Json}
 return
}
function Invoke-ControllerControl([string]$ControlAction,[hashtable]$Extra=@{}){
 $controlTimer=[Diagnostics.Stopwatch]::StartNew()
 do{
  try{return ((& $wf -ProjectDirectory $context.Root -Action $ControlAction @Extra|Out-String)|ConvertFrom-Json)}
  catch{if($_.Exception.Message -ne 'CLOUDBASE_OPERATION_ALREADY_RUNNING' -or $controlTimer.Elapsed.TotalSeconds -ge 30){throw};Start-Sleep -Milliseconds 150}
 }while($true)
}
function Resolve-ProjectInput([string]$Relative){
 if(-not $Relative -or [IO.Path]::IsPathRooted($Relative)){throw 'RELATIVE_PROJECT_VERIFICATION_INPUT_REQUIRED'}
 $full=[IO.Path]::GetFullPath((Join-Path $context.Root $Relative));Assert-CoursePlainPath $full
 if(-not $full.StartsWith($context.Root.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase) -or -not(Test-Path -LiteralPath $full -PathType Leaf)){throw ('PROJECT_VERIFICATION_INPUT_MISSING:'+ $Relative)}
 return $full
}
if(-not $VerificationFile){$VerificationFile=Join-Path $context.Root '.ai-coding/cloudbase-verification.json'}
Assert-CoursePlainPath $VerificationFile
$config=Read-CBState $VerificationFile
if($config.schemaVersion -ne 1 -or $config.syncVerification -notin @('auto','manual','not-requested')){throw 'PROJECT_VERIFICATION_CONFIG_INVALID'}
foreach($name in @($config.PSObject.Properties.Name)){if($name -notin @('schemaVersion','syncVerification','probe','browser','credentialEnvFile')){throw ('UNKNOWN_VERIFICATION_CONFIG_FIELD:'+ $name)}}
$configHash=(Get-FileHash -LiteralPath $VerificationFile).Hash
$configPaths=@($VerificationFile)
foreach($node in @($config.probe,$config.browser)|Where-Object {$_}){
 if($node.runner -notin @('probe','sync','smoke','project-script')){throw 'UNKNOWN_BROWSER_RUNNER'}
 if($node.adapter){$configPaths+=Resolve-ProjectInput $node.adapter}
 if($node.runner -eq 'project-script'){$configPaths+=Resolve-ProjectInput $node.script}
}
$configStamp=Get-CBHash (($configPaths|ForEach-Object {$_+':'+(Get-FileHash -LiteralPath $_).Hash}) -join '|')
if(-not $CliPath){$CliPath=Join-Path $env:APPDATA 'npm/tcb.ps1'}
if(-not(Test-Path -LiteralPath $CliPath -PathType Leaf)){throw 'REGISTERED_OFFICIAL_CLI_REQUIRED'}
if(-not $PlanFile){$PlanFile=Join-Path $context.Root '.ai-coding/cloudbase-plan.json'}
$plan=New-CBWorkflowPlan $context $PlanFile $CliPath
if($plan.options.route -ne 'CLI'){throw 'MCP_ROUTE_REQUIRES_CURRENT_SESSION_TOOLS_KEEP_ORIGINAL_ROUTE'}
if($plan.options.sync -and $config.syncVerification -eq 'not-requested'){throw 'SYNC_REQUEST_CANNOT_BE_SKIPPED'}
if($config.syncVerification -eq 'auto' -and $plan.options.sync -and -not $plan.options.multiSession){throw 'AUTO_SYNC_REQUIRES_ISOLATED_SESSION_PLAN'}
if($config.syncVerification -eq 'manual' -and $plan.options.multiSession){throw 'MANUAL_SYNC_PLAN_MUST_NOT_REQUIRE_AUTOMATED_MULTISESSION'}
foreach($file in $configPaths){
 $rel=$file.Substring($context.Root.Length+1).Replace('\','/')
 if($rel -notin @($plan.options.verificationInputs)){throw ('DECLARE_VERIFICATION_INPUT_IN_PLAN:'+ $rel)}
}
$controllerLease=Enter-CBFileLock (Join-Path $context.Root '.ai-coding/cb/controller.lock')
$jobs=@{};$controllerStarted=[datetimeoffset]::UtcNow;$controllerTimer=[Diagnostics.Stopwatch]::StartNew();$job=$null;$state=$null;$launchStopped=$false
try{
 $clockPath=Get-CBTaskClockPath $context
 if(-not(Test-Path -LiteralPath $clockPath) -or (Read-CBState $clockPath).status -ne 'running'){$null=Start-CBTaskClock $context $TaskSessionId $TaskStartedAt}
 if($Action -eq 'Run' -and (Read-CBState $clockPath).runId){throw 'USE_RESUME_FOR_CURRENT_TASK_OR_BEGIN_TASK_FOR_NEW_REQUEST'}
 $null=Update-CBTaskClock $context 'deployment-start' $null
 if($Action -eq 'Run'){
  $measurement=Invoke-ControllerControl 'Measure' @{NewRun=$true}
  $policyStart=[datetimeoffset]::UtcNow
  try{
   $policyText=& node (Join-Path $PSScriptRoot 'observe-policy.mjs') --project $context.Root --cli $CliPath
   if($LASTEXITCODE -ne 0){throw 'PLATFORM_POLICY_OBSERVATION_FAILED_NO_DEPLOY_STARTED'}
   $policy=$policyText|ConvertFrom-Json
  }finally{
   $null=Write-CBTiming $context ([ordered]@{runId=$measurement.runId;taskId='preflight';name='policy-observation';kind='work';status=$(if($LASTEXITCODE -eq 0){'completed'}else{'failed'});startedAt=$policyStart.ToString('o');finishedAt=[datetimeoffset]::UtcNow.ToString('o');durationSeconds=([datetimeoffset]::UtcNow-$policyStart).TotalSeconds})
  }
  $state=Invoke-ControllerControl 'Start' @{NewRun=$true;AllowPublish=[bool]$AllowPublish;NoAutoAdvance=$true;NoWait=$true;CliPath=$CliPath;PlanFile=$PlanFile}
 }else{
  $state=Invoke-ControllerControl 'Status'
  if(-not $state.runId){throw 'NO_WORKFLOW_TO_RESUME'}
  if(@($state.tasks|Where-Object status -in @('running','outcome-unknown')).Count){throw 'QUERY_ORIGINAL_OPERATIONS_BEFORE_RESUME'}
  if($RetryTask){$state=Invoke-ControllerControl 'Retry' @{RunId=$state.runId;TaskId=$RetryTask}}
  if(@($state.tasks|Where-Object status -eq 'failed').Count){throw 'FAILED_TASK_REQUIRES_EXPLICIT_ORIGINAL_RECOVERY'}
  if($state.autoAdvance){throw 'RESUME_WITH_THE_ORIGINAL_CONTROLLER_MODE'}
 }
 $runFolder=Join-Path $context.Root ('.ai-coding/cb/'+$state.runId.Substring(0,12))
 $logs=Join-Path $runFolder 'controller';[void][IO.Directory]::CreateDirectory($logs)
 if(Test-Path -LiteralPath (Join-Path $logs 'summary.json')){Copy-Item -LiteralPath (Join-Path $logs 'summary.json') -Destination (Join-Path $logs ('summary-'+[guid]::NewGuid().ToString('N')+'.json'))}
 $null=Update-CBTaskClock $context 'deployment-start' $state.runId 'running' (Join-Path $runFolder 'measurement.json')
 $job=[ordered]@{schemaVersion=1;runId=$state.runId;envId=$context.EnvId;url=$context.Url;status='running';processId=$PID;processStartedAt=(Get-Process -Id $PID).StartTime.ToUniversalTime().ToString('o');startedAt=$state.startedAt;controllerStartedAt=$controllerStarted.ToString('o');heartbeatAt=$null;finishedAt=$null;elapsedSeconds=$null;tasks=@();externalProcesses=@();syncVerification='pending';diagnostic=$null;measurement=(Join-Path $runFolder 'measurement.json')}
 while($true){
  $nowStamp=Get-CBHash (($configPaths|ForEach-Object {$_+':'+(Get-FileHash -LiteralPath $_).Hash}) -join '|')
  if($nowStamp -cne $configStamp){throw 'PROJECT_VERIFICATION_INPUT_CHANGED_STOP_AND_QUERY_ORIGINAL_OPERATIONS'}
  $state=if($launchStopped){Invoke-ControllerControl 'Status'}else{Invoke-ControllerControl 'Advance' @{NoWait=$true;RunId=$state.runId}}
  foreach($id in @($jobs.Keys)){
   $entry=$jobs[$id]
   if($entry.finishedAt){continue}
   $entry.process.Refresh()
   if($entry.process.HasExited){
    $entry.finishedAt=[datetimeoffset]::UtcNow.ToString('o');$entry.exitCode=$entry.process.ExitCode
    if($entry.exitCode -ne 0){
     $raw=if(Test-Path -LiteralPath $entry.stderr){[IO.File]::ReadAllText($entry.stderr)}else{'External task exited without stderr.'}
     $job.diagnostic=Protect-CBDetail ($id+': '+$raw);$launchStopped=$true
    }
   }
  }
  if(@($state.tasks|Where-Object status -in @('failed','outcome-unknown','interrupted')).Count){$launchStopped=$true;if(-not $job.diagnostic){$job.diagnostic='Inspect original task diagnostic; no automatic resubmission.'}}
  if($controllerTimer.Elapsed.TotalSeconds -gt $TimeoutSeconds){$launchStopped=$true;$job.diagnostic='Controller deadline reached; no new work launched. Waiting only for owned operations to finish; query unknown cloud results before retry.'}
  if(-not $launchStopped){
   foreach($task in @(Get-CBReadyTasks $state|Where-Object executor -eq 'external')){
    if($jobs.ContainsKey($task.id)){if($jobs[$task.id].finishedAt){$launchStopped=$true;$job.diagnostic='TASK_INPUT_CHANGED_AFTER_EXECUTION:'+ $task.id};continue}
    if($task.id -notin @('resources','adapter','credentials','frontend','probe','sessions','browser')){continue}
    if($task.id -eq 'probe' -and @($state.tasks|Where-Object {$_.id -eq 'frontend' -and $_.status -ne 'verified'}).Count){continue}
    $args=@('-NoProfile','-ExecutionPolicy','Bypass','-File',$taskEntry,'-ProjectDirectory',$context.Root,'-TaskId',$task.id,'-Orchestrated')
    if($task.id -in @('probe','browser')){
     $node=if($task.id -eq 'probe'){$config.probe}else{$config.browser}
     if(-not $node){$job.diagnostic='PROJECT_VERIFICATION_ADAPTER_REQUIRED:'+ $task.id;continue}
     $script=if($node.runner -eq 'project-script'){Resolve-ProjectInput $node.script}else{Join-Path $PSScriptRoot ('verify-'+$(if($node.runner -eq 'smoke'){'sync'}else{$node.runner})+'.mjs')}
     $args+=@('-SmokeScript',$script)
     if($node.adapter){$args+=@('-BrowserAdapter',(Resolve-ProjectInput $node.adapter))}
     if($node.runner -eq 'smoke'){$args+=@('-SmokeMode','single')}
    }
    if($task.id -eq 'credentials'){
     if(-not $config.credentialEnvFile){$job.diagnostic='SECURE_CREDENTIAL_SOURCE_REQUIRED';continue}
     $args+=@('-CredentialEnvFile',$config.credentialEnvFile)
    }
    $tag=$task.id+'-'+[guid]::NewGuid().ToString('N').Substring(0,8)
    $stdout=Join-Path $logs ($tag+'.log');$stderr=Join-Path $logs ($tag+'.error.log')
    $process=Start-Process -FilePath (Get-CBPowerShell) -ArgumentList (($args|ForEach-Object {ConvertTo-CBArgument ([string]$_)}) -join ' ') -WorkingDirectory $context.Root -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru
    $null=$process.Handle
    $jobs[$task.id]=[pscustomobject]@{taskId=$task.id;process=$process;processId=$process.Id;processStartedAt=$process.StartTime.ToUniversalTime().ToString('o');launchedAt=[datetimeoffset]::UtcNow.ToString('o');finishedAt=$null;exitCode=$null;stdout=$stdout;stderr=$stderr}
   }
  }
  $externalActive=@($jobs.Values|Where-Object {-not $_.finishedAt}).Count
  $localActive=@($state.tasks|Where-Object {$_.executor -eq 'local' -and $_.status -eq 'running'}).Count
  $job.tasks=@($state.tasks|Select-Object id,status,startedAt,finishedAt,durationSeconds,error,diagnostic)
  $job.externalProcesses=@($jobs.Values|Select-Object taskId,processId,processStartedAt,launchedAt,finishedAt,exitCode,stdout,stderr)
  $job.heartbeatAt=[datetimeoffset]::UtcNow.ToString('o');$job.elapsedSeconds=([datetimeoffset]::UtcNow-(ConvertTo-CBTime $state.startedAt)).TotalSeconds
  Write-CourseJson $jobPath $job;Write-CourseJson (Join-Path $logs 'summary.json') $job
  if($externalActive -eq 0 -and $localActive -eq 0){
   if($state.status -eq 'verified'){
    $job.syncVerification=if($config.syncVerification -eq 'manual'){'pending-manual'}elseif($state.options.sync){'verified-independent-sessions'}else{'not-requested'}
    $job.status=if($job.syncVerification -eq 'pending-manual'){'deployment-verified-sync-pending-manual'}else{'verified'}
    break
   }
   if($launchStopped){$job.status='attention';break}
   $readyExternal=@(Get-CBReadyTasks $state|Where-Object executor -eq 'external')
   $readyLocal=@(Get-CBReadyTasks $state|Where-Object {$_.executor -eq 'local' -and ($_.id -ne 'deploy' -or $state.allowPublish)})
   if(-not $readyLocal.Count -and -not @($readyExternal|Where-Object {-not $jobs.ContainsKey($_.id) -and $_.id -in @('resources','adapter','frontend','probe','sessions','browser','credentials')}).Count){$job.status='action-required';break}
   if($job.diagnostic -and -not $externalActive -and -not $readyLocal.Count){$job.status='action-required';break}
  }
  Start-Sleep -Seconds $PollSeconds
 }
 $job.finishedAt=[datetimeoffset]::UtcNow.ToString('o');$job.elapsedSeconds=[math]::Round(([datetimeoffset]::UtcNow-(ConvertTo-CBTime $state.startedAt)).TotalSeconds,3)
 Write-CourseJson $jobPath $job;Write-CourseJson (Join-Path $logs 'summary.json') $job
 if($job.status -in @('verified','deployment-verified-sync-pending-manual')){$null=Update-CBTaskClock $context 'deployment-end' $state.runId $job.status $job.measurement}
 $job|ConvertTo-Json -Depth 12
 if($job.status -notin @('verified','deployment-verified-sync-pending-manual')){throw 'DEPLOYMENT_CONTROLLER_NEEDS_ATTENTION_SEE_SUMMARY'}
}catch{
 if($job){$job.status='attention';if(-not $job.diagnostic){$job.diagnostic=Protect-CBDetail $_.Exception.Message};$job.finishedAt=[datetimeoffset]::UtcNow.ToString('o');Write-CourseJson $jobPath $job}
 throw
}finally{$controllerLease.Dispose()}
