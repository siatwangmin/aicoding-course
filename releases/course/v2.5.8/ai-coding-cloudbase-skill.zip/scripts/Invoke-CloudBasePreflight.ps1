﻿#Requires -Version 5.1
# Read-only preflight: validates the workflow plan, computes all fingerprints,
# summarizes any existing run, and lists ready tasks with exact next commands.
# Replaces session-style preparation (doc reading, plan trial-and-error) with
# one command. Never writes project state.
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,[string]$PlanFile,[string]$CliPath,[switch]$CheckRuntime)
$ErrorActionPreference='Stop'
$watch=[Diagnostics.Stopwatch]::StartNew()
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $executionRoot 'scripts/Course-Context.ps1')
. (Join-Path $PSScriptRoot 'Course-CloudBaseWorkflow.ps1')
. (Join-Path $PSScriptRoot 'Course-CloudBaseHealth.ps1')
$context=Get-CBProject $ProjectDirectory
$folder=Join-Path $context.Root '.ai-coding/cb'
$statePath=Join-Path $folder 'current.json'
if(-not $PlanFile){$PlanFile=Join-Path $context.Root '.ai-coding/cloudbase-plan.json'}
$wf=Join-Path $PSScriptRoot 'Invoke-CloudBaseWorkflow.ps1'
$gen=Join-Path $PSScriptRoot 'Gen-CloudBaseEvidence.ps1'
$findings=New-Object 'Collections.Generic.List[string]'

# CLI discovery (read-only existence checks only; no network calls).
$cliExists=$false
if($CliPath){
 $cliExists=Test-Path -LiteralPath $CliPath -PathType Leaf
 if(-not $cliExists){$findings.Add('CLI_PATH_NOT_FOUND')}
}elseif(Test-Path -LiteralPath (Join-Path $env:APPDATA 'npm/tcb.ps1') -PathType Leaf){$CliPath=Join-Path $env:APPDATA 'npm/tcb.ps1';$cliExists=$true}
else{$findings.Add('CLI_PATH_NOT_PROVIDED')}

# Plan validation and per-task expected stamps (same rules as the engine).
$plan=$null;$planError=$null
$planExists=Test-Path -LiteralPath $PlanFile -PathType Leaf
if($planExists){
 try{
  $plan=New-CBWorkflowPlan $context $PlanFile $CliPath
  foreach($task in $plan.tasks){
   try{$task|Add-Member NoteProperty expectedInputStamp (Get-CBTaskStamp $context $plan $task) -Force}
   catch{$task|Add-Member NoteProperty expectedInputStamp $null -Force}
  }
 }catch{$planError=$_.Exception.Message;$findings.Add('PLAN_INVALID:'+$planError)}
}else{
 $scenario='first-deploy'
 $publishPath=Join-Path $context.Root 'docs/progress/cloudbase-publish.json'
 if(Test-Path -LiteralPath $publishPath){
  try{if((Read-CourseJson $publishPath).status -eq 'deployed'){$scenario='frontend-update'}}catch{}
 }
 $findings.Add('PLAN_FILE_MISSING:create from '+$PSScriptRoot+'\..\assets\examples\'+$scenario+'-plan.json then rerun preflight')
}
if(-not $context.Url){$findings.Add('HOSTING_URL_NOT_BOUND:Start will throw QUERY_AND_BIND_ACTUAL_HOSTING_URL_BEFORE_START; bind the actual URL in services.json first')}

# Existing run summary (in-memory merge only; never writes).
$existingRun=$null
$readySource=$null
if(Test-Path -LiteralPath $statePath){
 $saved=Read-CBState $statePath
 $runFolder=Join-Path $folder $saved.runId.Substring(0,12)
 $bindingMatches=$null
 if($plan){$bindingMatches=($saved.binding -ceq $plan.binding)}
 $merged=$null
 try{$merged=Get-CBWorkflowStatus $context $saved $runFolder}
 catch{$findings.Add('WORKFLOW_STATUS_ERROR:'+([string]$_.Exception.Message))}
 $changed=@()
 if($plan){
  foreach($name in $plan.options.PSObject.Properties.Name){
   $a=($plan.options.$name|ConvertTo-Json -Compress);$_b=($saved.options.$name|ConvertTo-Json -Compress)
   if($a -cne $_b){$changed+=$name}
  }
 }
 $counts=@{}
 foreach($t in $saved.tasks){$counts[$t.status]=1+$(if($counts[$t.status]){$counts[$t.status]}else{0})}
 $existingRun=[pscustomobject]@{
  runId=$saved.runId;status=$saved.status;startedAt=$saved.startedAt;elapsedSeconds=$saved.elapsedSeconds
  allowPublish=$saved.allowPublish;autoAdvance=$saved.autoAdvance
  bindingMatchesPlan=$bindingMatches;changedOptions=@($changed);taskCounts=$counts
  incomplete=@($saved.tasks|Where-Object {$_.status -notin @('verified','failed')}|Select-Object id,status)
 }
 if($merged){$readySource=$merged}else{$readySource=$saved}
}else{$readySource=$plan}

# Ready tasks with copy-pasteable next commands.
$ready=@()
if($readySource){
 foreach($task in @(Get-CBReadyTasks $readySource)){
  $requiresPublish=$false
  if($task.id -eq 'deploy' -and -not $readySource.allowPublish){$requiresPublish=$true}
  $commands=@{}
  if($task.executor -eq 'external'){
   $commands.begin=("& '{0}' -ProjectDirectory '{1}' -Action Begin -TaskId '{2}'" -f $wf,$context.Root,$task.id)
   $commands.evidenceHint=("& '{0}' -ProjectDirectory '{1}' -TaskId '{2}'" -f $gen,$context.Root,$task.id)
  }else{
   $commands.advance=("& '{0}' -ProjectDirectory '{1}' -Action Advance" -f $wf,$context.Root)
  }
  $ready+=[pscustomobject]@{id=$task.id;executor=$task.executor;inputKind=$task.inputKind;checks=@($task.checks);expectedInputStamp=$task.expectedInputStamp;requiresAllowPublish=$requiresPublish;commands=$commands}
 }
}

# Fingerprints (each isolated so one missing input never aborts the report).
$fp=[ordered]@{source=$null;adapter=$null;resource=$null;policy='strict-no-policy'}
if($plan){
 $o=$plan.options
 try{$fp.source=Get-CBBuildFingerprint $context}catch{$findings.Add('SOURCE_FINGERPRINT_ERROR:'+([string]$_.Exception.Message))}
 if($o.data -or $o.images){try{$fp.adapter=Get-CBAdapterFingerprint $context @($o.adapterInputs)}catch{$findings.Add('ADAPTER_FINGERPRINT_ERROR:'+([string]$_.Exception.Message))}}
 try{$fp.resource=Get-CBDeclaredFingerprint $context @($o.resourceInputs)}catch{$fp.resource='not-declared'}
 $policyPath=Join-Path $context.Root $(if($o.platformPolicyFile){$o.platformPolicyFile}else{'.ai-coding/cloudbase-policy.json'})
 if(Test-Path -LiteralPath $policyPath){
  try{$null=Get-CBPlatformPolicy $context $policyPath;$fp.policy=(Get-FileHash -LiteralPath $policyPath).Hash}
  catch{$fp.policy='invalid';$findings.Add('PLATFORM_POLICY_INVALID:'+([string]$_.Exception.Message))}
 }
 elseif(([uri]$context.Url).Host -match '\.(tcloudbaseapp\.com|app\.tcloudbase\.com)$'){$findings.Add('PLATFORM_POLICY_OBSERVATION_REQUIRED')}
}

# Ordered next actions.
$next=New-Object 'Collections.Generic.List[string]'
if($fp.policy -in @('strict-no-policy','invalid') -and ([uri]$context.Url).Host -match '\.(tcloudbaseapp\.com|app\.tcloudbase\.com)$'){
 $next.Add(("node '{0}' --project '{1}' --cli '{2}'" -f (Join-Path $PSScriptRoot 'observe-policy.mjs'),$context.Root,$CliPath))
}
if(-not $planExists){$next.Add('Create the plan file from the recommended template, then rerun preflight.')}
elseif($planError){$next.Add('Fix the plan validation error, then rerun preflight.')}
elseif(-not $existingRun){
 $startCommand=("& '{0}' -ProjectDirectory '{1}' -Action Start" -f $wf,$context.Root)
 if($plan.options.route -eq 'CLI' -and $cliExists){$startCommand+=(" -CliPath '{0}'" -f $CliPath)}
 $next.Add('Confirm plan options, then start: '+$startCommand+' (add -AllowPublish to authorize deploy).')
 foreach($r in @($ready|Where-Object {$_.executor -eq 'external'})){$next.Add('After Start, begin external task '+$r.id+' and record with Gen-CloudBaseEvidence.ps1.')}
}else{
 if($existingRun.bindingMatchesPlan -eq $false){$next.Add('WORKFLOW_BINDING_CHANGED_CREATE_NEW_RUN: resolve changed options/inputs (changedOptions above), then Start -NewRun.')}
 if(-not $ready.Count -and $existingRun.status -eq 'verified' -and -not @($existingRun.incomplete).Count){$next.Add('Run complete and verified; no workflow action needed.')}
 foreach($r in @($ready|Where-Object {$_.executor -eq 'external'})){$next.Add('Begin '+$r.id+' then Record with Gen-CloudBaseEvidence.ps1.')}
 foreach($r in @($ready|Where-Object {$_.executor -eq 'local'})){$next.Add('Advance to spawn local task '+$r.id+' (inline wait).')}
 if(@($ready|Where-Object {$_.requiresAllowPublish}).Count){$next.Add('Deploy is ready but requires -AllowPublish authorization.')}
}

$runtimeHealth=if($CheckRuntime){Get-CBRuntimeHealth $context $executionRoot}else{[pscustomobject]@{reason='not-observed-use-CheckRuntime'}}
$watch.Stop()
$scenarioValue=$null
if($plan){$scenarioValue=$plan.options.scenario}
[pscustomobject]@{
 schemaVersion=1;kind='cloudbase-preflight'
 projectDirectory=$context.Root;envId=$context.EnvId;hostingUrl=$context.Url
 image=$context.Project.image;runtime=$context.Project.containerRuntime
 runtimeHealth=$runtimeHealth
 cli=[pscustomobject]@{path=$CliPath;exists=$cliExists}
 plan=[pscustomobject]@{planFile=$PlanFile;exists=$planExists;valid=[bool]$plan;scenario=$scenarioValue;options=$(if($plan){$plan.options}else{$null});binding=$(if($plan){$plan.binding}else{$null});error=$planError}
 fingerprints=$fp
 existingRun=$existingRun
 readyTasks=@($ready)
 findings=@($findings)
 nextActions=@($next)
 durationMs=[math]::Round($watch.Elapsed.TotalMilliseconds,0)
}|ConvertTo-Json -Depth 10
