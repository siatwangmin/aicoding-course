﻿#Requires -Version 5.1
function Get-CBIntervalSeconds($Items){
    $spans=@($Items|Where-Object {$_.startedAt -and $_.finishedAt}|ForEach-Object {[pscustomobject]@{start=(ConvertTo-CBTime $_.startedAt);end=(ConvertTo-CBTime $_.finishedAt)}}|Where-Object {$_.end -ge $_.start}|Sort-Object start)
    $total=0.0;$left=$null;$right=$null
    foreach($span in $spans){if($null -eq $left){$left=$span.start;$right=$span.end}elseif($span.start -le $right){if($span.end -gt $right){$right=$span.end}}else{$total+=($right-$left).TotalSeconds;$left=$span.start;$right=$span.end}}
    if($null -ne $left){$total+=($right-$left).TotalSeconds};return [math]::Round($total,3)
}
function Write-CBTransitionEvents($Context,$State,$Before){
    foreach($task in $State.tasks){
        $old=@($Before.tasks|Where-Object id -eq $task.id)
        if($old.Count -eq 1 -and $old[0].status -eq $task.status -and $old[0].attempt -eq $task.attempt -and $old[0].evidence -eq $task.evidence){continue}
        if($task.status -eq 'pending'){continue}
        $null=Write-CBTiming $Context ([ordered]@{runId=$State.runId;taskId=$task.id;attempt=$task.attempt;name='task-state';kind='work';status=$task.status;startedAt=$task.startedAt;finishedAt=$task.finishedAt;durationSeconds=$task.durationSeconds;detail=$task.error})
    }
}
function Export-CBWorkflowReport($Context,$State){
    $events=@();$folder=Join-Path $Context.Root '.ai-coding/cb-events'
    if(Test-Path -LiteralPath $folder){foreach($file in Get-ChildItem -LiteralPath $folder -Filter '*.json' -File){$e=Read-CBState $file.FullName;if($e.runId -eq $State.runId -and $e.envId -eq $State.envId -and $e.projectDirectory -eq $Context.Root){$events+=@($e)}}}
    $tasks=@($State.tasks|Select-Object id,executor,status,startedAt,finishedAt,durationSeconds,error,diagnostic,evidence)
    $windows=@($tasks|Where-Object {$_.startedAt -and $_.finishedAt})
    $sum=0.0;foreach($task in $windows){$sum+=((ConvertTo-CBTime $task.finishedAt)-(ConvertTo-CBTime $task.startedAt)).TotalSeconds}
    $union=Get-CBIntervalSeconds $windows
    function Outcome([string[]]$Ids){$found=@($State.tasks|Where-Object id -in $Ids);if(-not $found.Count){return 'not-requested'};if(@($found|Where-Object status -ne 'verified').Count){return 'pending-or-failed'};return 'verified'}
    $runFolder=Join-Path $Context.Root ('.ai-coding/cb/'+$State.runId.Substring(0,12))
    # Keep terminal attempt windows after a retry replaces the task's latest fields.
    $attempts=@($events|Where-Object {$_.name -eq 'task-state' -and $_.status -in @('failed','verified') -and $_.startedAt -and $_.finishedAt}|ForEach-Object {
      [pscustomobject]@{taskId=$_.taskId;status=$_.status;startedAt=$_.startedAt;finishedAt=$_.finishedAt;seconds=[math]::Round(((ConvertTo-CBTime $_.finishedAt)-(ConvertTo-CBTime $_.startedAt)).TotalSeconds,3)}
    }|Sort-Object taskId,startedAt,finishedAt,status -Unique)
    $report=[ordered]@{schemaVersion=2;workflowProtocol=$State.workflowProtocol;runId=$State.runId;envId=$State.envId;url=$State.hostingUrl;status=$State.status;startedAt=$State.startedAt;finishedAt=$State.finishedAt;recordedAt=[datetimeoffset]::UtcNow.ToString('o');elapsedSeconds=$State.elapsedSeconds;scope='From Measure (when used), otherwise Start; earlier conversation time is not measured.';preflightMeasured=[bool]@($events|Where-Object name -eq 'preflight').Count;taskWindowUnionSeconds=$union;overlapSeconds=[math]::Round([math]::Max(0,$sum-$union),3);recordedWaitWindowSeconds=(Get-CBIntervalSeconds @($events|Where-Object kind -eq 'wait'));recordedDiagnosisWindowSeconds=(Get-CBIntervalSeconds @($events|Where-Object kind -eq 'diagnosis'));unmeasuredWait='Not inferred from command duration; waiting must be explicitly recorded.';verification=@{deployment=(Outcome @('deploy'));artifact=(Outcome @('assets'));browser=(Outcome @('browser'));application=(Outcome @('probe'));learner=(Outcome @('learner'))};tasks=$tasks;events=$events;nextActions=$State.nextActions}
    $report['attempts']=$attempts
    $report['taskWindowScope']='Latest task attempts only; all recorded successful/failed attempts are retained separately. Assistant intake and finalization are in task.json.'
    Write-CourseJson (Join-Path $runFolder 'measurement.json') $report
    $lines=@('# CloudBase execution report','',('Run: '+$State.runId),('Status: '+$State.status),('URL: '+$State.hostingUrl),('Elapsed seconds: '+$State.elapsedSeconds),'','Task windows overlap; do not add them as total time. Unrecorded waits and missing task starts remain unknown.','','| Task | Status | Seconds |','| --- | --- | ---: |')
    foreach($task in $tasks){$duration=if($null -ne $task.durationSeconds){$task.durationSeconds}else{'unknown'};$lines+=('| '+$task.id+' | '+$task.status+' | '+$duration+' |')}
    $lines+=@('','Detailed command, wait and diagnosis events: measurement.json.','Deployment, artifacts, browser, application and learner results are separate.','Credentials are referenced through their secure source; passwords and tokens are not report content.')
    [IO.File]::WriteAllText((Join-Path $runFolder 'report.md'),($lines -join "`n"),[Text.UTF8Encoding]::new($false))
    return [pscustomobject]@{measurement=(Join-Path $runFolder 'measurement.json');report=(Join-Path $runFolder 'report.md')}
}
