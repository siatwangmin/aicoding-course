#!/usr/bin/env node
// verify-sync.mjs — CloudBase browser 任务冒烟模板（无登录项目，线上站点，双隔离会话刷新同步）
// 与登录版 verify-smoke.mjs 同构：【项目定制区】 + 通用骨架；profile 由 sessions 任务预建
// （scripts/prepare-sessions.mjs），本脚本不删除 profile。
// checks 与工作流 browser 任务白名单一致：
//   pageUsable          = 会话 A 加载进入应用态
//   dataPersisted       = A 写入 → 刷新仍在（云端持久化）
//   accessDenied        = 敏感配置路径不可泄露（默认 /.env、/.env.production）；
//                         无登录共享数据集的授权边界由 RLS+GRANT 承担，此处验证托管面不泄密
//   independentSessions = B 在独立 profile 首次加载即进入应用态（与 A 无共享存储）
//   dataSync            = A 写 → B 首载可见；B 写 → A 刷新可见（刷新同步语义，非实时推送）
// 用法:
//   node verify-sync.mjs --base <站点URL> --profileA <dir> --profileB <dir> [--out <结果json>]
//        [--portA 9225] [--portB 9226]
// 结果 JSON 的 checks 与 Gen-CloudBaseEvidence.ps1 -TaskId browser -SmokeFile 直接兼容。
//
// 换项目时只改下方【项目定制区】：1. SITE 文本与敏感路径；2. SEL 各步骤元素查找器；
// 3. fillAndSubmit() 业务填写顺序。

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';

import { loadBrowserAdapter } from './browser-adapter.mjs';
const { SITE, SEL, fillAndSubmit } = await loadBrowserAdapter(process.argv.slice(2));


const args = process.argv.slice(2);
const arg = (n, d) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : d; };
const BASE = arg('--base');
const SINGLE = args.includes('--single');
const PROFILE_A = arg('--profileA', SINGLE ? fs.mkdtempSync(path.join(os.tmpdir(), 'cb-single-')) : undefined);
const PROFILE_B = arg('--profileB');
const PORT_A = Number(arg('--portA', '9225'));
const PORT_B = Number(arg('--portB', '9226'));
const CHROME = arg('--chrome', 'C:/Program Files/Google/Chrome/Application/chrome.exe');
const OUT = arg('--out', 'verify-sync-last.json');
if (!BASE || !PROFILE_A || (!SINGLE && !PROFILE_B)) {
  console.error('USAGE: node verify-sync.mjs --base <URL> --profileA <dir> --profileB <dir> [--out <json>]');
  process.exit(1);
}

const t0 = Date.now();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---- 启动两个独立 headless Chrome（独立 user-data-dir = 独立会话存储） ----
const chromeA = spawn(CHROME, ['--headless=new', `--user-data-dir=${PROFILE_A}`,
  `--remote-debugging-port=${PORT_A}`, '--no-first-run', '--no-default-browser-check',
  '--window-size=1280,900', 'about:blank'], { detached: true, stdio: 'ignore' });
const chromeB = SINGLE ? null : spawn(CHROME, ['--headless=new', `--user-data-dir=${PROFILE_B}`,
  `--remote-debugging-port=${PORT_B}`, '--no-first-run', '--no-default-browser-check',
  '--window-size=1280,900', 'about:blank'], { detached: true, stdio: 'ignore' });
chromeA.unref(); chromeB?.unref();
process.once('exit', () => { for(const child of [chromeA,chromeB]) if(child?.pid) { try { spawn('taskkill', ['/pid',String(child.pid),'/T','/F'], {stdio:'ignore'}).unref(); } catch {} } });
const runnerDeadline=setTimeout(() => { console.error('BROWSER_RUNNER_TIMEOUT'); process.exit(1); }, 180000); runnerDeadline.unref();

async function waitCdp(port) {
  for (let i = 0; i < 40; i++) { try { if ((await fetch(`http://127.0.0.1:${port}/json/version`, { signal: AbortSignal.timeout(2000) })).ok) return true; } catch {} await sleep(500); }
  return false;
}
if (!(await waitCdp(PORT_A))) { console.error('CDP_TIMEOUT_A'); process.exit(1); }
if (!SINGLE && !(await waitCdp(PORT_B))) { console.error('CDP_TIMEOUT_B'); process.exit(1); }

function connect(port) {
  return (async () => {
    const list = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
    const ws = new WebSocket(list.find((x) => x.type === 'page').webSocketDebuggerUrl);
    await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
    let mid = 0; const pend = new Map();
    ws.onmessage = (e) => { const m = JSON.parse(e.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
    const send = (me, pa = {}) => new Promise((r) => { const i = ++mid; const timeout = setTimeout(() => { console.error('CDP_COMMAND_TIMEOUT:'+me); process.exit(1); }, 15000); pend.set(i, (value) => { clearTimeout(timeout); r(value); }); ws.send(JSON.stringify({ id: i, method: me, params: pa })); });
    const evalJs = async (ex) => {
      const r = await send('Runtime.evaluate', { expression: ex, awaitPromise: true, returnByValue: true });
      if (r.result?.exceptionDetails) return 'EVAL_ERR';
      return r.result?.result?.value;
    };
    await send('Page.enable');
    const typeExpr = async (finder, text) => {
      await evalJs(`(()=>{const el=${finder};if(!el)return;const p=(el.tagName==='TEXTAREA'?HTMLTextAreaElement:HTMLInputElement).prototype;Object.getOwnPropertyDescriptor(p,'value').set.call(el,'');el.dispatchEvent(new Event('input',{bubbles:true}));el.focus();})()`);
      await send('Input.insertText', { text });
    };
    const settle = async (timeoutMs = 30000) => {
      const t = Date.now();
      while (Date.now() - t < timeoutMs) {
        const st = await evalJs(`(()=>{
          const rb=[...document.querySelectorAll('button')].find(x=>(x.textContent||'').includes('${SITE.riskButtonText}'));
          if(rb) return rb.disabled?'risk_wait':'risk_click';
          if([...document.querySelectorAll('button')].some(x=>x.textContent.includes('${SITE.appButtonText}'))) return 'app';
          return 'loading';
        })()`);
        if (st === 'app') return st;
        if (st === 'risk_click') { await evalJs(`[...document.querySelectorAll('button')].find(x=>(x.textContent||'').includes('${SITE.riskButtonText}')).click()`); await sleep(2500); }
        else await sleep(1200);
      }
      return 'timeout';
    };
    const goto = async (url) => {
      await evalJs('window.__cbOldDocument = true');
      await send('Page.navigate', { url });
      for(let i=0;i<40;i++){ if(await evalJs('window.__cbOldDocument === true') === false) break; await sleep(100); }
      for(let i=0;i<40;i++){ if(await evalJs('document.readyState') === 'complete') break; await sleep(100); }
      return settle();
    };
    return { send, evalJs, typeExpr, settle, goto };
  })();
}

const A = await connect(PORT_A);
const B = SINGLE ? null : await connect(PORT_B);

const checks = {}; const steps = [];
const step = (n, d) => { steps.push({ step: n, ...d }); console.log('STEP ' + n + ' ' + JSON.stringify(d)); };
const waitText = async (ctx, text, timeoutMs) => {
  const t = Date.now();
  while (Date.now() - t < timeoutMs) {
    if ((await ctx.evalJs(`document.body.textContent.includes('${text}')`)) === true) return true;
    await sleep(500);
  }
  return false;
};

// 1) pageUsable（A 加载进入应用态）
let stA = await A.goto(BASE);
checks.pageUsable = stA === 'app';
step('pageUsable', { session: 'A', state: stA });

// 2) accessDenied（敏感配置路径不可泄露，在 A 会话执行）
if (checks.pageUsable) {
  const probes = [];
  for (const p of SITE.secretPaths) {
    const r = await A.evalJs(`(async()=>{try{const res=await fetch('${p}');return {status:res.status,text:(await res.text()).slice(0,400)}}catch(e){return {status:'ERR'}}})()`);
    probes.push({ path: p, status: r?.status, leaked: SITE.secretMarkers.some((m) => String(r?.text || '').includes(m)) });
  }
  checks.accessDenied = probes.every((x) => x.leaked === false);
  step('accessDenied', { probes: probes.map((x) => ({ path: x.path, status: x.status, leaked: x.leaked })) });
}

// 3) dataPersisted（A 写入 → 刷新仍在）
const markerA = 'SMOKE-A-' + Date.now();
if (checks.pageUsable) {
  const w = await fillAndSubmit({ evalJs: A.evalJs, typeExpr: A.typeExpr, sleep, step, marker: markerA, tag: 'A', SEL });
  let still = false;
  if (w.saved) {
    stA = await A.goto(BASE);
    still = await waitText(A, markerA, SITE.reloadVisibleTimeoutMs);
  }
  checks.dataPersisted = !!(w.saved && w.seen) && stA === 'app' && still;
  step('dataPersisted', { session: 'A', ...w, reloadState: stA, still });
}

if (!SINGLE) {
// 4) independentSessions（B 独立 profile 首载进入应用态）
let stB = await B.goto(BASE);
checks.independentSessions = stB === 'app' && PROFILE_A !== PROFILE_B;
step('independentSessions', { session: 'B', state: stB, profileA: PROFILE_A, profileB: PROFILE_B });

// 5) dataSync（B 首载可见 A 的写入；B 写入 → A 刷新可见）
const markerB = 'SMOKE-B-' + Date.now();
if (checks.independentSessions) {
  const bSawA = await waitText(B, markerA, SITE.reloadVisibleTimeoutMs);
  let w = { saved: false, seen: false };
  if (bSawA) {
    w = await fillAndSubmit({ evalJs: B.evalJs, typeExpr: B.typeExpr, sleep, step, marker: markerB, tag: 'B', SEL });
  }
  let aSawB = false;
  if (w.saved) {
    stA = await A.goto(BASE);
    aSawB = await waitText(A, markerB, SITE.reloadVisibleTimeoutMs);
  }
  checks.dataSync = !!(bSawA && w.saved && w.seen && aSawB);
  step('dataSync', { bSawA, bWrite: w, aReloadState: stA, aSawB });
}

}
const RESULT = { checks, verificationMode: SINGLE ? 'single-smoke-sync-unverified' : 'independent-sessions', elapsedMs: Date.now() - t0, markerA, base: BASE, profileA: PROFILE_A, profileB: PROFILE_B };
console.log('RESULT ' + JSON.stringify(RESULT));
fs.writeFileSync(OUT, JSON.stringify(RESULT, null, 2));

try { spawn('taskkill', ['/pid', String(chromeA.pid), '/T', '/F'], { stdio: 'ignore' }); } catch {}
try { if(chromeB) spawn('taskkill', ['/pid', String(chromeB.pid), '/T', '/F'], { stdio: 'ignore' }); } catch {}
setTimeout(() => process.exit(Object.values(checks).length >= (SINGLE ? 3 : 5) && Object.values(checks).every(Boolean) ? 0 : 1), 1500);
