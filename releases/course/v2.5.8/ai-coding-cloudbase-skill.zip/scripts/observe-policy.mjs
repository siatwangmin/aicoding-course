#!/usr/bin/env node
// Read-only official CLI observations. argv arrays avoid PowerShell JSON escaping.
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

export function parseCliJson(text) {
  const clean = text.replace(/\u001b\[[0-9;]*m/g, '').replace(/^\s*```(?:json)?\s*$/gm, '').trim();
  try { return JSON.parse(clean); } catch {
    const start = clean.indexOf('{'), end = clean.lastIndexOf('}');
    if (start < 0 || end < start) throw new Error('OFFICIAL_RESPONSE_NOT_JSON');
    return JSON.parse(clean.slice(start, end + 1));
  }
}
export function cliCommand(cli) {
  if (/\.(ps1|cmd)$/i.test(cli)) {
    const entry = path.join(path.dirname(cli), 'node_modules/@cloudbase/cli/bin/tcb');
    if (!fs.existsSync(entry)) throw new Error('NPM_CLI_ENTRY_MISSING_USE_OFFICIAL_MCP');
    return [process.execPath, [entry]];
  }
  return [cli, []];
}
export async function callCli(cli, args) {
  const [exe, prefix] = cliCommand(cli);
  return new Promise((resolve, reject) => {
    const child = spawn(exe, [...prefix, ...args], { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '', stderr = '';
    const timer = setTimeout(() => { child.kill(); reject(new Error('OFFICIAL_QUERY_TIMEOUT')); }, 45000);
    child.stdout.on('data', b => { stdout += b; }); child.stderr.on('data', b => { stderr += b; });
    child.on('error', e => { clearTimeout(timer); reject(e); });
    child.on('close', code => {
      clearTimeout(timer);
      if (code !== 0) return reject(new Error(`OFFICIAL_QUERY_FAILED:${code}:${stderr.slice(0, 250)}`));
      try { resolve(parseCliJson(stdout)); } catch (e) { reject(e); }
    });
  });
}
export function makePolicy(envId, url, envResult, headers, observedAt = new Date().toISOString()) {
  const u = new URL(url);
  if (u.protocol !== 'https:' || u.username || u.password || u.search || u.hash) throw new Error('CONFIRMED_HTTPS_URL_REQUIRED');
  const data = envResult.data ?? envResult.Response ?? envResult;
  const envs = data.EnvList ?? data.Envs ?? [];
  const target = envs.find(e => e.EnvId === envId);
  if (!target) throw new Error('OFFICIAL_ENV_TARGET_NOT_FOUND');
  const storage = (target.StaticStorages ?? []).find(s => {
    try { return new URL(s.StaticDomain.includes('://') ? s.StaticDomain : `https://${s.StaticDomain}`).hostname === u.hostname; } catch { return false; }
  });
  if (!storage || !/\.(tcloudbaseapp\.com|app\.tcloudbase\.com)$/.test(u.hostname)) throw new Error('OFFICIAL_DEFAULT_DOMAIN_NOT_CONFIRMED');
  if (headers.status !== 200 || !/text\/html/i.test(headers.contentType) || !/attachment/i.test(headers.contentDisposition)) throw new Error('DEFAULT_DOMAIN_POLICY_NOT_OBSERVED');
  return {
    schemaVersion: 1, kind: 'cloudbase-default-domain', envId, url: u.href, observedAt,
    source: { kind: 'command', reference: 'Official DescribeEnvs matched EnvId and StaticDomain; exact-URL HTTPS HEAD observed HTML attachment; https://docs.cloudbase.net/service/alias' },
    facts: { domain: u.hostname, isDefault: true, domainType: 'STATIC_STORE', enableSafeDomain: true },
    observation: { status: headers.status, contentType: headers.contentType, contentDisposition: headers.contentDisposition,
      safeDomainBasis: 'Observed attachment behavior plus official default-domain policy; not inferred from gateway Enable.',
      environmentRequestId: data.RequestId ?? null }
  };
}
export async function observe(project, cli) {
  const root = fs.realpathSync(project);
  const services = JSON.parse(fs.readFileSync(path.join(root, '.ai-coding/services.json'), 'utf8').replace(/^\uFEFF/, ''));
  const { envId, hostingUrl } = services.cloudbase;
  const u = new URL(hostingUrl);
  if (!/^[a-zA-Z0-9-]+$/.test(envId) || u.protocol !== 'https:' || u.username || u.password) throw new Error('CONFIRMED_CLOUDBASE_TARGET_REQUIRED');
  if (!/\.(tcloudbaseapp\.com|app\.tcloudbase\.com)$/.test(u.hostname)) return { status: 'strict-custom-domain', envId };
  const startedAt = new Date().toISOString();
  const [environment, response] = await Promise.all([
    callCli(cli, ['api', 'tcb', 'DescribeEnvs', '--body', JSON.stringify({ EnvId: envId }), '--json']),
    fetch(u, { method: 'HEAD', redirect: 'manual', signal: AbortSignal.timeout(20000) })
  ]);
  const headers = { status: response.status, contentType: response.headers.get('content-type') ?? '', contentDisposition: response.headers.get('content-disposition') ?? '' };
  const policy = makePolicy(envId, u.href, environment, headers);
  const output = path.join(root, '.ai-coding/cloudbase-policy.json');
  if (fs.existsSync(output)) fs.copyFileSync(output, output + '.previous');
  const tmp = output + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(policy, null, 2) + '\n'); fs.renameSync(tmp, output);
  return { status: 'observed', envId, output, startedAt, finishedAt: new Date().toISOString() };
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2), arg = n => args[args.indexOf(n) + 1];
  if (!args.includes('--project') || !args.includes('--cli')) { console.error('USAGE: observe-policy.mjs --project <B> --cli <registered-tcb>'); process.exitCode = 1; }
  else try { console.log(JSON.stringify(await observe(arg('--project'), arg('--cli')))); }
  catch (e) { console.error(e.message); process.exitCode = 1; }
}
