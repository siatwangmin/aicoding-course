#!/usr/bin/env node
// prepare-sessions.mjs — 预建 N 个隔离 Chrome profile 目录（sessions 任务代码化）
// 作用：把上轮对话串行的 sessions 任务（实测 1078s）压缩为秒级本地脚本。
// 每个 profile 是独立 user-data-dir：独立 localStorage/IndexedDB/cookie，
// 供 verify-sync.mjs 的 --profileA/--profileB 使用；本脚本只创建，不启动 Chrome、不删除 profile。
// checks 与工作流 sessions 任务白名单一致：
//   isolatedSessionsPrepared = 全部 profile 目录就绪且互不重叠
// 用法:
//   node prepare-sessions.mjs --root <目录> [--count 2] [--portStart 9225] [--out sessions-prepared.json]
// 证据接入:
//   Gen-CloudBaseEvidence.ps1 -TaskId sessions -ChecksJson <本脚本 --out 输出>
//   （输出的 checks.isolatedSessionsPrepared 与 -ChecksJson 分支直接兼容）
// 结果 JSON 同时携带 profiles[].dir 与 profiles[].port，可直接映射到
//   verify-sync.mjs --profileA <profiles[0].dir> --portA <profiles[0].port> …

import fs from 'node:fs';
import path from 'node:path';

const args = process.argv.slice(2);
const arg = (n, d) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : d; };
const ROOT = arg('--root');
const COUNT = Math.max(1, Number(arg('--count', '2')));
const PORT_START = Number(arg('--portStart', '9225'));
const OUT = arg('--out', 'sessions-prepared.json');
if (!ROOT) {
  console.error('USAGE: node prepare-sessions.mjs --root <目录> [--count 2] [--portStart 9225] [--out <json>]');
  process.exit(1);
}

const absRoot = path.resolve(ROOT);
fs.mkdirSync(absRoot, { recursive: true });

const profiles = [];
for (let i = 0; i < COUNT; i++) {
  const id = String.fromCharCode(97 + i); // a, b, c …
  const dir = path.join(absRoot, 'profile-' + id);
  // 全新空目录 = 独立会话存储；"First Run" 空文件抑制 Chrome 首启向导
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'First Run'), '', { flag: 'a' });
  // 保险：目录内若残留旧锁文件（上次异常退出），删除 Single 进程锁，避免 CDP 起不来
  for (const stale of ['SingletonLock', 'SingletonCookie', 'SingletonSocket', 'SingletonPid']) {
    const p = path.join(dir, stale);
    if (fs.existsSync(p)) { try { fs.rmSync(p); } catch {} }
  }
  profiles.push({ id, dir: dir.replace(/\\/g, '/'), port: PORT_START + i });
}

// 隔离性自检：目录互不相同、均存在且为绝对路径
const dirs = new Set(profiles.map((p) => p.dir));
const checks = {
  isolatedSessionsPrepared: dirs.size === COUNT && profiles.every((p) =>
    path.isAbsolute(p.dir) && fs.existsSync(p.dir) && fs.statSync(p.dir).isDirectory()),
};

const RESULT = { checks, root: absRoot.replace(/\\/g, '/'), count: COUNT, portStart: PORT_START, profiles, createdAt: new Date().toISOString() };
fs.writeFileSync(OUT, JSON.stringify(RESULT, null, 2));
console.log('RESULT ' + JSON.stringify(RESULT));
process.exit(checks.isolatedSessionsPrepared ? 0 : 1);
