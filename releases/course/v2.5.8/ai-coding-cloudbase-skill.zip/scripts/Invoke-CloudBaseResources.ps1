﻿# Invoke-CloudBaseResources.ps1 — resources 任务一键执行器（代码化，对话外后台可跑）
# 作用：把 resources 任务中"逐条复述 SQL → 对话内执行"改为脚本一次执行，实测可从数分钟压缩到数十秒。
# 本脚本内不含任何内置 SQL。语句只来自项目 .ai-coding/cb/current.json → options.resourceInputs：
#   1) .sql 文件：按分号切分逐条执行（识别单引号字符串与注释；不支持 $$ 函数体）。
#      SQL 文件需幂等（IF NOT EXISTS / OR REPLACE / DROP IF EXISTS），重复执行安全。
#   2) 资源契约 JSON（schemaVersion + resources[]，如 docs/specs/cloud-resources.json）：
#      按契约声明确定性渲染为语句执行——kind=table → CREATE TABLE IF NOT EXISTS（含列/主键）；
#      kind=policy → DROP POLICY IF EXISTS + CREATE POLICY；kind=grant → GRANT。
#      契约由项目审核负责业务正确性；契约未声明的内容不生成。
# 用法（在常驻终端执行；先 -DryRun 审查渲染语句，再实际执行）：
#   powershell -File Invoke-CloudBaseResources.ps1 -Root <B> [-StateFile ...] [-Out ...] [-DryRun]
# 证据接入：
#   输出 JSON 作为 resources 任务的 evidence reference（Advance 时填入 reference 字段）；
#   最终是否通过仍以 Gen-CloudBaseEvidence.ps1 -TaskId resources -Auto 的只读校验为准。
param(
  [string]$Root = (Get-Location).Path,
  [string]$StateFile,                     # 默认 <Root>\.ai-coding\cb\current.json
  [string]$Out,                           # 默认 <Root>\.ai-coding\cb\resources-exec-last.json
  [switch]$DryRun                         # 只解析/渲染并打印语句，不执行
)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path -LiteralPath $Root).Path
if (-not $StateFile) { $StateFile = Join-Path $Root '.ai-coding\cb\current.json' }
if (-not $Out)       { $Out       = Join-Path $Root '.ai-coding\cb\resources-exec-last.json' }
if (-not (Test-Path -LiteralPath $StateFile)) { throw ('STATE_FILE_MISSING:' + $StateFile) }

function Read-CourseJson([string]$Path) {
  $text = [System.IO.File]::ReadAllText($Path, (New-Object System.Text.UTF8Encoding($true)))
  $text | ConvertFrom-Json
}

$state = Read-CourseJson $StateFile
$envId = $state.envId
if (-not $envId) { throw 'ENVID_MISSING_IN_STATE' }
$cli = if ($state.cliPath) { $state.cliPath } else { 'tcb' }
$inputs = @($state.options.resourceInputs) | Where-Object { $_ }
if (-not $inputs.Count) { throw 'RESOURCE_INPUTS_EMPTY' }

# 标识符白名单：契约中的 schema/表/策略/角色/列名只允许常规标识符，防止注入式内容。
function ConvertTo-Identifier([string]$Name, [string]$Field) {
  if ($Name -notmatch '^[A-Za-z_][A-Za-z0-9_]*$') { throw ('CONTRACT_BAD_IDENTIFIER:' + $Field + ':' + $Name) }
  return $Name
}
# 数据类型仅接受常规词型或词型(数字[,数字])，如 text/integer/varchar(255)。
function Test-SqlDataType([string]$Type) {
  return $Type -match '^[A-Za-z_][A-Za-z0-9_ ]*(\(\s*\d+(\s*,\s*\d+)?\s*\))?$'
}

# 语句切分：识别单引号字符串（含 '' 转义）、-- 行注释、/* */ 块注释；
# 分号仅在字符串外切分。不处理 $$ 哑元引号（不支持函数体）。
function Split-SqlStatements([string]$Text) {
  $stmts = @(); $cur = New-Object System.Text.StringBuilder; $inString = $false
  $chars = $Text.ToCharArray()
  for ($i = 0; $i -lt $chars.Length; $i++) {
    $c = $chars[$i]
    if ($inString) {
      [void]$cur.Append($c)
      if ($c -eq "'") {
        if ($i + 1 -lt $chars.Length -and $chars[$i + 1] -eq "'") { [void]$cur.Append("'"); $i++ }
        else { $inString = $false }
      }
      continue
    }
    if ($c -eq "'") { $inString = $true; [void]$cur.Append($c); continue }
    if ($c -eq '-' -and $i + 1 -lt $chars.Length -and $chars[$i + 1] -eq '-') {
      while ($i -lt $chars.Length -and $chars[$i] -ne "`n") { $i++ }
      [void]$cur.Append("`n"); continue
    }
    if ($c -eq '/' -and $i + 1 -lt $chars.Length -and $chars[$i + 1] -eq '*') {
      $i += 2
      while ($i + 1 -lt $chars.Length -and -not ($chars[$i] -eq '*' -and $chars[$i + 1] -eq '/')) { $i++ }
      $i++; continue
    }
    if ($c -eq ';') { $s = $cur.ToString().Trim(); if ($s) { $stmts += $s }; [void]$cur.Clear(); continue }
    [void]$cur.Append($c)
  }
  $tail = $cur.ToString().Trim()
  if ($tail) { $stmts += $tail }
  return ,@($stmts)
}

# 契约 → 语句（确定性渲染，未声明的内容不生成）
function Get-ContractStatements([pscustomobject]$Contract) {
  $out = @()
  if (-not $Contract.resources) { return ,@() }
  foreach ($r in @($Contract.resources)) {
    $idParts = @([string]$r.id -split '/') | Where-Object { $_ }
    if ($r.kind -eq 'table') {
      if ($idParts.Count -lt 1) { throw ('CONTRACT_BAD_ID:' + $r.kind) }
      $schema = if ($idParts.Count -ge 2) { ConvertTo-Identifier $idParts[0] 'schema' } else { 'public' }
      $table = ConvertTo-Identifier $idParts[-1] 'table'
      $cols = @()
      $pk = $null
      if ($r.properties.primaryKey) { $pk = ConvertTo-Identifier ([string]$r.properties.primaryKey) 'primaryKey' }
      foreach ($c in @($r.properties.columns)) {
        $cn = ConvertTo-Identifier ([string]$c.name) 'column'
        $ct = [string]$c.dataType
        if (-not (Test-SqlDataType $ct)) { throw ('CONTRACT_BAD_DATATYPE:' + $cn + ':' + $ct) }
        $nulls = if ($c.nullable -eq $false) { ' NOT NULL' } else { '' }
        $cols += ('  "' + $cn + '" ' + $ct + $nulls)
      }
      if ($pk) { $cols += ('  PRIMARY KEY ("' + $pk + '")') }
      if (-not $cols.Count) { throw ('CONTRACT_TABLE_EMPTY:' + $table) }
      $out += ('CREATE TABLE IF NOT EXISTS ' + $schema + '."' + $table + '" (' + "`n" + ($cols -join ",`n") + "`n" + ')')
      $out += ('ALTER TABLE '+$schema+'."'+$table+'" ENABLE ROW LEVEL SECURITY')
      if($r.properties.forceRls -eq $true){$out += ('ALTER TABLE '+$schema+'."'+$table+'" FORCE ROW LEVEL SECURITY')}
    }
    elseif ($r.kind -eq 'policy') {
      if ($idParts.Count -lt 3) { throw ('CONTRACT_BAD_ID:' + $r.kind + ':' + $r.id) }
      $schema = ConvertTo-Identifier $idParts[0] 'schema'
      $table = ConvertTo-Identifier $idParts[1] 'table'
      $policy = ConvertTo-Identifier $idParts[2] 'policy'
      $cmd = [string]$r.properties.command
      if ($cmd -notmatch '^(ALL|SELECT|INSERT|UPDATE|DELETE)$') { throw ('CONTRACT_BAD_COMMAND:' + $cmd) }
      $roles = (@($r.properties.roles) | ForEach-Object { ConvertTo-Identifier ([string]$_) 'role' }) -join ', '
      $out += ('DROP POLICY IF EXISTS "' + $policy + '" ON ' + $schema + '."' + $table + '"')
      $stmt = 'CREATE POLICY "' + $policy + '" ON ' + $schema + '."' + $table + '" AS PERMISSIVE FOR ' + $cmd + ' TO ' + $roles
      if ($r.properties.using)     { $stmt += ' USING (' + [string]$r.properties.using + ')' }
      if ($r.properties.withCheck) { $stmt += ' WITH CHECK (' + [string]$r.properties.withCheck + ')' }
      $out += $stmt
    }
    elseif ($r.kind -eq 'grant') {
      if ($idParts.Count -lt 2) { throw ('CONTRACT_BAD_ID:' + $r.kind + ':' + $r.id) }
      $schema = ConvertTo-Identifier $idParts[0] 'schema'
      $table = ConvertTo-Identifier $idParts[1] 'table'
      $grantee = ConvertTo-Identifier ([string]$r.properties.grantee) 'grantee'
      $privs = (@($r.properties.privileges) | ForEach-Object {
        $p = [string]$_
        if ($p -notmatch '^(SELECT|INSERT|UPDATE|DELETE|TRUNCATE|REFERENCES|TRIGGER)$') { throw ('CONTRACT_BAD_PRIVILEGE:' + $p) }
        $p }) -join ', '
      $out += ('GRANT ' + $privs + ' ON ' + $schema + '."' + $table + '" TO ' + $grantee)
    }
    else { throw ('CONTRACT_UNKNOWN_KIND:' + $r.kind) }
  }
  return ,@($out)
}

# 输入文件 → 语句数组（.sql 或契约 JSON；其余形态报错，不猜测）
function Get-InputStatements([string]$Path) {
  $text = [System.IO.File]::ReadAllText($Path, (New-Object System.Text.UTF8Encoding($true)))
  if ($Path -match '\.json$') {
    $contract = $text | ConvertFrom-Json
    if ($contract.envId -and $contract.envId -ne $envId) {
      Write-Warning ('CONTRACT_ENVID_MISMATCH:contract=' + $contract.envId + ' state=' + $envId)
    }
    if (-not $contract.resources) { throw ('CONTRACT_RESOURCES_MISSING:' + ($Path -replace '\\', '/')) }
    return Get-ContractStatements $contract
  }
  if ($Path -match '\.sql$') { return Split-SqlStatements $text }
  throw ('RESOURCE_INPUT_UNSUPPORTED:' + ($Path -replace '\\', '/') + '（仅支持 .sql 或资源契约 .json）')
}

function Invoke-Statement([string]$Sql) {
  $raw = & $cli db execute -e $envId --sql $Sql --json 2>&1
  $text = ((@($raw) | ForEach-Object { $_ -as [string] }) -join "`n").Trim()
  [pscustomobject]@{ exitCode = $LASTEXITCODE; raw = ($text -replace '\s+', ' '); ok = ($LASTEXITCODE -eq 0) }
}

$files = @(); $total = 0; $okCount = 0; $started = Get-Date
foreach ($relative in $inputs) {
  $inputPath = Join-Path $Root $relative
  if (-not (Test-Path -LiteralPath $inputPath)) { throw ('RESOURCE_INPUT_MISSING:' + ($relative -replace '\\', '/')) }
  $stmts = Get-InputStatements $inputPath
  $records = @()
  for ($i = 0; $i -lt $stmts.Count; $i++) {
    $preview = ($stmts[$i] -replace '\s+', ' ')
    if ($preview.Length -gt 200) { $preview = $preview.Substring(0, 200) + '…' }
    if ($DryRun) {
      Write-Host ('[' + $relative + '] #' + ($i + 1) + ' ' + $preview)
      $records += [pscustomobject]@{ n = ($i + 1); sql = $preview; ok = $null; raw = 'dry-run' }
      continue
    }
    $r = Invoke-Statement $stmts[$i]
    $total++
    if ($r.ok) { $okCount++ }
    Write-Host ('[' + $relative + '] #' + ($i + 1) + ' exit=' + $r.exitCode + ' ' + $preview)
    if (-not $r.ok) { Write-Warning ('RAW:' + $r.raw) }
    $records += [pscustomobject]@{ n = ($i + 1); sql = $preview; ok = $r.ok; raw = $r.raw }
  }
  $files += [pscustomobject]@{ path = ($relative -replace '\\', '/'); statements = $records }
}

$checks = [ordered]@{
  resourcesExecuted = ($DryRun -or $total -gt 0)
  allSucceeded      = ($DryRun -or ($total -gt 0 -and $okCount -eq $total))
}
$result = [pscustomobject]@{
  envId = $envId; dryRun = [bool]$DryRun; root = ($Root -replace '\\', '/')
  files = $files; statementsTotal = $total; statementsOk = $okCount
  elapsedSeconds = [math]::Round(((Get-Date) - $started).TotalSeconds, 1)
  checks = $checks; createdAt = (Get-Date).ToString('o')
}
$dir = Split-Path -Parent $Out
if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
[System.IO.File]::WriteAllText($Out, ($result | ConvertTo-Json -Depth 6), (New-Object System.Text.UTF8Encoding($false)))
Write-Host ('RESULT ' + ($result | ConvertTo-Json -Depth 3 -Compress))
if (-not $DryRun) { if ($okCount -ne $total -or $total -eq 0) { exit 1 } }
