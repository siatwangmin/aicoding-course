﻿#Requires -Version 5.1
# Whole assistant task clock, separate from the deployment workflow window.
function Get-CBTaskClockPath($Context){return Join-Path $Context.Root '.ai-coding/cb/task.json'}
function Start-CBTaskClock($Context,[string]$TaskSessionId,[string]$TaskStartedAt){
 if(-not $TaskSessionId){$TaskSessionId=[guid]::NewGuid().ToString('N')}
 if($TaskSessionId -notmatch '^[a-f0-9]{32}$'){throw 'INVALID_TASK_SESSION_ID'}
 $now=[datetimeoffset]::UtcNow
 $start=if($TaskStartedAt){ConvertTo-CBTime $TaskStartedAt}else{$now}
 if(($now-$start).TotalSeconds -lt -5 -or ($now-$start).TotalHours -gt 24){throw 'TASK_START_TIME_OUT_OF_RANGE'}
 $path=Get-CBTaskClockPath $Context;$lease=Enter-CBFileLock ($path+'.lock') -WaitMs 5000
 try{
  if(Test-Path -LiteralPath $path){
   $prior=Read-CBState $path
   if($prior.taskSessionId -eq $TaskSessionId){return $prior}
   Write-CourseJson (Join-Path $Context.Root ('.ai-coding/cb/task-'+$prior.taskSessionId+'.json')) $prior
  }
  $clock=[pscustomobject]@{schemaVersion=1;taskSessionId=$TaskSessionId;projectDirectory=$Context.Root;envId=$Context.EnvId;startedAt=$start.ToString('o');startSource=$(if($TaskStartedAt){'caller-observed-prompt-submission'}else{'first-skill-command'});status='running';runId=$null;deploymentStartedAt=$null;deploymentFinishedAt=$null;finishedAt=$null;totalSeconds=$null;phases=@();workflowMeasurement=$null}
  Write-CourseJson $path $clock;return $clock
 }finally{$lease.Dispose()}
}
function Update-CBTaskClock($Context,[string]$Phase,[string]$RunId,[string]$Status='running',[string]$Measurement){
 $path=Get-CBTaskClockPath $Context
 if(-not(Test-Path -LiteralPath $path)){return}
 $lease=Enter-CBFileLock ($path+'.lock') -WaitMs 5000
 try{
  $clock=Read-CBState $path
  if($clock.runId -and $RunId -and $clock.runId -ne $RunId){throw 'TASK_CLOCK_RUN_CHANGED'}
  if($clock.status -ne 'running'){return $clock}
  $now=[datetimeoffset]::UtcNow
  if($RunId){$clock.runId=$RunId}
  if($Measurement){$clock.workflowMeasurement=$Measurement}
  if($Phase -eq 'deployment-start' -and -not $clock.deploymentStartedAt){$clock.deploymentStartedAt=$now.ToString('o')}
  if($Phase -eq 'deployment-end' -and $Status -in @('verified','deployment-verified-sync-pending-manual') -and -not $clock.deploymentFinishedAt){$clock.deploymentFinishedAt=$now.ToString('o')}
  if($Phase -eq 'finish'){
   if(-not $clock.deploymentFinishedAt -or $Status -notin @('verified','deployment-verified-sync-pending-manual')){throw 'VERIFIED_DEPLOYMENT_REQUIRED_BEFORE_TASK_FINISH'}
   $clock.finishedAt=$now.ToString('o');$clock.totalSeconds=[math]::Round(($now-(ConvertTo-CBTime $clock.startedAt)).TotalSeconds,3);$clock.status=$Status
   $clock.phases=@(
    @{id='intake-and-adaptation';seconds=[math]::Round(((ConvertTo-CBTime $clock.deploymentStartedAt)-(ConvertTo-CBTime $clock.startedAt)).TotalSeconds,3)},
    @{id='deployment-including-recovery';seconds=[math]::Round(((ConvertTo-CBTime $clock.deploymentFinishedAt)-(ConvertTo-CBTime $clock.deploymentStartedAt)).TotalSeconds,3)},
    @{id='finalization';seconds=[math]::Round(($now-(ConvertTo-CBTime $clock.deploymentFinishedAt)).TotalSeconds,3)})
  }
  Write-CourseJson $path $clock
  Write-CourseJson (Join-Path $Context.Root ('.ai-coding/cb/task-'+$clock.taskSessionId+'.json')) $clock
  return $clock
 }finally{$lease.Dispose()}
}
