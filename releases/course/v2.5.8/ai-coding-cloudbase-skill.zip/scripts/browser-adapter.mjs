import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

export async function loadBrowserAdapter(args) {
  const index = args.indexOf('--adapter');
  if (index < 0 || !args[index + 1]) throw new Error('PROJECT_BROWSER_ADAPTER_REQUIRED: pass --adapter <project module>');
  const file = path.resolve(args[index + 1]);
  let cursor = file;
  for (;;) {
    if (fs.lstatSync(cursor).isSymbolicLink()) throw new Error('BROWSER_ADAPTER_LINK_REFUSED');
    const parent = path.dirname(cursor); if (parent === cursor) break; cursor = parent;
  }
  const adapter = await import(pathToFileURL(file).href);
  if (!adapter.SITE || !adapter.SEL || typeof adapter.fillAndSubmit !== 'function') throw new Error('BROWSER_ADAPTER_EXPORTS_REQUIRED');
  return adapter;
}
