﻿#Requires -Version 5.1
# Gen-CloudBaseEvidence.ps1 - Build a Record-ready evidence JSON for one workflow task.
# Read-only: inspects the current workflow state, applies the same identity/stamp/check
# rules as Record, and writes the evidence file. It never touches workflow state.
# Usage:
#   Gen-CloudBaseEvidence.ps1 -ProjectDirectory <root> -TaskId deploy            # recovery after worker death
#   Gen-CloudBaseEvidence.ps1 ... -TaskId browser -SmokeFile <verify-smoke.json> # wrap browser smoke output
#   Gen-CloudBaseEvidence.ps1 ... -TaskId learner -ChecksJson '{"x":true}'       # explicit checks
#   Gen-CloudBaseEvidence.ps1 ... -TaskId adapter -Auto                          # derive checks via source grep
#   Gen-CloudBaseEvidence.ps1 ... -TaskId resources -Auto                        # read-only tcb query-back
#   Gen-CloudBaseEvidence.ps1 ... -TaskId credentials -Auto                      # env-file + tcb user list
#   Gen-CloudBaseEvidence.ps1 ... -TaskId probe -SmokeFile <probe-smoke.json>    # wrap probe smoke output
#   ... add -Record to invoke Record immediately after writing the evidence file.
# Then: Invoke-CloudBaseWorkflow.ps1 -ProjectDirectory <root> -Action Record -EvidenceFile <out>
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,
 [Parameter(Mandatory=$true)][string]$TaskId,
 [string]$SmokeFile,[string]$ChecksJson,[string]$Reference,[string]$OutFile,
 [ValidateSet('tool','command','browser','learner')][string]$Kind,
 [ValidateSet('verified','failed')][string]$Status='verified',
 [switch]$Auto,[string]$CredentialEnvFile,[switch]$Record)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $executionRoot 'scripts/Course-Context.ps1')
. (Join-Path $PSScriptRoot 'Course-CloudBaseWorkflow.ps1')
. (Join-Path $PSScriptRoot 'Course-CloudBaseTelemetry.ps1')
$context=Get-CBProject $ProjectDirectory
$folder=Join-Path $context.Root '.ai-coding/cb'
$statePath=Join-Path $folder 'current.json'
Assert-CoursePlainPath $folder
if(-not(Test-Path -LiteralPath $statePath)){throw 'WORKFLOW_NOT_STARTED'}
$state=Read-CBState $statePath
if($state.runId -notmatch '^[a-f0-9]{32}$'){throw 'INVALID_WORKFLOW_RUN_ID'}
# Merge attempt results in memory only (same view the coordinator sees).
$state=Get-CBWorkflowStatus $context $state (Join-Path $folder $state.runId.Substring(0,12))
$found=@($state.tasks|Where-Object id -eq $TaskId)
if($found.Count -ne 1){throw 'UNKNOWN_WORKFLOW_TASK'}
$task=$found[0]
$recovering=($task.executor -eq 'local' -and $task.status -eq 'outcome-unknown')
$taskChecks=@($task.checks)|Where-Object {$null -ne $_}

# Heartbeat liveness mirrors Record's original-operation check.
$attemptFolder=$null
if($task.attempt){$attemptFolder=Join-Path $folder ($state.runId.Substring(0,12)+'/'+$task.id+'/'+$task.attempt.Substring(0,12))}
$workerAlive=$false
if($attemptFolder){
 $heartbeat=Join-Path $attemptFolder 'heartbeat.json'
 if(Test-Path -LiteralPath $heartbeat){
  $beat=Read-CBState $heartbeat
  if(Test-CBProcess $beat.childId $beat.childStartedAt){$workerAlive=$true}
 }
}

# Task-state gates: local terminal states are already recorded by the worker's
# result.json merge, so Record (and this generator) must not run for them again.
if($task.executor -eq 'local'){
 if($task.status -in @('verified','failed')){throw 'LOCAL_TASK_ALREADY_TERMINAL_NO_RECORD_NEEDED'}
 if($task.status -eq 'running'){
  if($workerAlive){throw 'ORIGINAL_OPERATION_STILL_RUNNING'}
  throw 'LOCAL_TASK_RUNNING_RUN_STATUS_TO_INFER_THEN_REGENERATE'
 }
 if($task.status -eq 'pending'){throw 'LOCAL_TASK_NOT_STARTED_USE_ADVANCE'}
}else{
 if($task.status -eq 'verified'){throw 'EXTERNAL_TASK_ALREADY_VERIFIED'}
 if($task.status -notin @('running','failed')){throw 'BEGIN_EXTERNAL_TASK_BEFORE_RECORD'}
}
if($recovering -and $workerAlive){throw 'ORIGINAL_OPERATION_STILL_RUNNING'}
if($task.id -eq 'deploy' -and -not $state.allowPublish){throw 'DEPLOYMENT_AUTHORIZATION_REQUIRED'}

# Input stamp: recovery reuses the frozen stamp; a fresh record requires the current one.
$stamp=if($recovering){$task.inputStamp}else{
 $current=Get-CBTaskStamp $context $state $task
 if($current -eq 'artifact-not-ready'){throw 'ARTIFACT_INPUT_STAMP_NOT_READY'}
 $current
}

# Dependency pre-check mirrors Record (skipped on the recovery path).
if(-not $recovering){
 $blocked=@($task.dependsOn|Where-Object {$id=$_;@($state.tasks|Where-Object {$_.id -eq $id -and $_.status -eq 'verified'}).Count -ne 1})
 if($blocked.Count){throw ('DEPENDENCIES_PENDING:'+($blocked -join ','))}
}

# Build id is required wherever Record enforces it (deploy/assets/browser/learner
# always; build when recovered after an unknown outcome).
$buildId=$null
if($task.id -in @('deploy','assets','browser','learner') -or ($recovering -and $task.id -eq 'build')){
 $buildPath=Join-Path $context.Root '.ai-coding/cloudbase-build.json'
 if(-not(Test-Path -LiteralPath $buildPath)){throw 'ARTIFACT_BUILD_RECORD_MISSING'}
 $build=Read-CourseJson $buildPath
 if(-not $build.buildId){throw 'ARTIFACT_BUILD_ID_MISSING'}
 $buildId=$build.buildId
}

# Source checks from the strongest available signal per task family.
 $checks=@{}
 # Auto mode: derive checks and reference by read-only inspection (source grep +
# tcb queries). Never performs platform writes; unmet cloud state yields failed
# checks so the session can repair and regenerate.
$autoReference=$null
if($Auto){
 if($task.executor -ne 'external'){throw 'AUTO_EXTERNAL_TASKS_ONLY'}
 function Invoke-CBTcbScalar([string]$Sql){
  $cli=if($state.cliPath){$state.cliPath}else{'tcb'}
  $out=& $cli db execute -e $context.EnvId --sql $Sql --json 2>&1
  if($LASTEXITCODE -ne 0){throw ('TCB_QUERY_FAILED:'+((@($out)|ForEach-Object {$_ -as [string]})|Select-Object -First 2) -join ' | ')}
  $text=((@($out)|ForEach-Object {$_ -as [string]})|Where-Object {$_ -notmatch '^\s*```'}) -join "`n"
  try{
   $j=$text|ConvertFrom-Json
   if($j.PSObject.Properties.Name -contains 'data' -and $j.data -and $j.data.PSObject.Properties.Name -contains 'Rows'){$j=$j.data}
   $rowsRaw=@($j.Rows)
   if(-not $rowsRaw.Count){
    Write-Warning ('TCB_UNEXPECTED_SHAPE:'+((($text|Out-String).Substring(0,[Math]::Min(300,$text.Length))) -replace '\s+',' '))
    return -1
   }
   $first=$rowsRaw[0]
   try{$parsed=$first|ConvertFrom-Json;if($parsed -is [array]){$first=@($parsed)[0]}else{$first=$parsed}}catch{}
   if($null -eq $first){return -1}
   if($first -isnot [pscustomobject]){return [int]$first}
   foreach($p in @('n','count','cnt')){if($first.PSObject.Properties.Name -contains $p){return [int]$first.$p}}
   $props=@($first.PSObject.Properties)
   if(-not $props.Count){return [int]$first}
   return [int]($props[0].Value)
  }catch{return -1}
 }
 $options=$state.options
 if($task.id -eq 'adapter'){
  $patterns=@([ordered]@{name='js-sdk-init';pattern='@cloudbase/js-sdk'})
  if($options.login){$patterns+=[ordered]@{name='signInWithPassword';pattern='signInWithPassword'}}
  if($options.images){$patterns+=[ordered]@{name='storage-upload';pattern='storage\.from\('},[ordered]@{name='getPublicUrl';pattern='getPublicUrl'}}
  if($options.data){$patterns+=[ordered]@{name='data-mode';pattern='VITE_DATA_MODE|cloudbase'}}
  $hits=@();$ok=$true
  foreach($p in $patterns){
   $hit=$null
   foreach($relative in @($options.adapterInputs)){
    $path=Join-Path $context.Source $relative
    if(-not(Test-Path -LiteralPath $path -PathType Leaf)){throw ('ADAPTER_SOURCE_MISSING:'+($relative -replace '\\','/'))}
    $text=Get-Content -LiteralPath $path -Raw
    if($text -match $p.pattern){
     $line=1;foreach($chunk in ($text -split "`n")){if($chunk -match $p.pattern){break};$line++}
     $hit=($relative -replace '\\','/')+':'+$line+':'+$p.name;break
    }
   }
   if($hit){$hits+=$hit}else{$ok=$false;$hits+=('missing:'+ $p.name)}
  }
  $checks['adapterReady']=$ok
  $autoReference='auto-adapter;'+($hits -join ';')
 }elseif($task.id -eq 'resources'){
  if($state.options.route -cne 'CLI'){throw 'AUTO_RESOURCES_REQUIRES_CLI_ROUTE'}
  $checks['targetAccess']=((Invoke-CBTcbScalar 'SELECT 1') -eq 1)
  $tables=@()
  $forceTables=@{}
  foreach($relative in @($options.resourceInputs)){
   $sqlPath=Join-Path $context.Root $relative
   if(-not(Test-Path -LiteralPath $sqlPath)){throw ('RESOURCE_SQL_MISSING:'+($relative -replace '\\','/'))}
   $sql=Get-Content -LiteralPath $sqlPath -Raw
   foreach($match in [regex]::Matches($sql,'(?i)ALTER\s+TABLE\s+(?:[\w"]+\.)?"?(\w+)"?\s+FORCE\s+ROW\s+LEVEL\s+SECURITY')){$forceTables[$match.Groups[1].Value]=$true}
   $tables+=[regex]::Matches($sql,'(?i)CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(?:[\w"]+\.)?"?(\w+)"?')|ForEach-Object {$_.Groups[1].Value}
   # JSON resource contracts declare tables as resources[].id ("schema/name"); extract them so Auto probes real cloud state.
   if($relative -match '\.json$'){
    try{
     $contract=$sql|ConvertFrom-Json
     if($contract.resources){
      $tables+=@($contract.resources)|Where-Object {$_.kind -eq 'table' -and $_.id}|ForEach-Object {([string]$_.id -split '/')[-1]}
      foreach($r in @($contract.resources)|Where-Object {$_.kind -eq 'table' -and $_.properties.forceRls -eq $true}){$forceTables[([string]$r.id -split '/')[-1]]=$true}
     }
    }catch{}
   }
  }
  $tables=@($tables|Select-Object -Unique)
  $bucketNames=@()
  if($options.images){
   $all=foreach($relative in @($options.adapterInputs)){Get-Content -LiteralPath (Join-Path $context.Source $relative) -Raw}
   $all=$all -join "`n"
   $bucketNames+=[regex]::Matches($all,"storage\.from\(\s*'([^']+)'")|ForEach-Object {$_.Groups[1].Value}
   foreach($m in [regex]::Matches($all,"storage\.from\(\s*([A-Za-z_$][A-Za-z0-9_$]*)\s*\)")){
    $id=[regex]::Escape($m.Groups[1].Value)
    $cm=[regex]::Match($all,"(?i)(?:const|let|var)\s+"+$id+"\s*=\s*'([^']+)'")
    if($cm.Success){$bucketNames+=$cm.Groups[1].Value}
   }
  }
  $bucketNames=@($bucketNames|Select-Object -Unique)
  $notes=@();$tablesOk=$true;$permOk=$true
  # GRANT role follows the project login option: authenticated for login projects, anon for anonymous ones.
  $grantRole=if($options.login){'authenticated'}else{'anon'}
  foreach($name in $tables){
   $mask=Invoke-CBTcbScalar (Get-CBResourceProbeSql $name $grantRole ($forceTables.ContainsKey($name)))
   $notes+=($name+':probeMask='+$mask+':forceRequired='+$forceTables.ContainsKey($name))
   if($mask -lt 0 -or ($mask -band 1) -ne 1){$tablesOk=$false}
   if($mask -lt 0 -or ($mask -band 14) -ne 14){$permOk=$false}
  }
  foreach($bucket in $bucketNames){
   $b=Invoke-CBTcbScalar ("SELECT count(*)::int AS n FROM storage.buckets WHERE name='"+$bucket+"'")
   $bq=$bucket.Replace("'","''")
   $bu=$bq.Replace('-','_')
   $pol=Invoke-CBTcbScalar ("SELECT count(*)::int AS n FROM pg_policies WHERE schemaname='storage' AND tablename='objects' AND (policyname LIKE '%"+$bq+"%' OR policyname LIKE '%"+$bu+"%' OR qual LIKE '%"+$bq+"%' OR with_check LIKE '%"+$bq+"%')")
   $notes+=('bucket='+$bucket+':'+$b+':imagePolicies='+$pol)
   if($b -le 0 -or $pol -le 0){$tablesOk=$false}
  }
  $checks['resourcesReady']=$tablesOk
  $checks['permissionsChecked']=$permOk
  $autoReference='auto-resources;'+(($notes|Select-Object -Unique) -join ';')
 }elseif($task.id -eq 'credentials'){
  $loginOk=$false
  foreach($relative in @($options.adapterInputs)){
   $text=Get-Content -LiteralPath (Join-Path $context.Source $relative) -Raw
   if($text -match 'signInWithPassword'){$loginOk=$true;break}
  }
  $checks['loginMethodReady']=$loginOk
  if(-not $CredentialEnvFile){
   $svc=Join-Path $context.Root '.ai-coding/services.json'
   if(Test-Path -LiteralPath $svc){
    $m=[regex]::Match((Get-Content -LiteralPath $svc -Raw),'[A-Za-z]:\\[^"\r\n]*connection\.env')
    if($m.Success){$CredentialEnvFile=$m.Value}
   }
  }
  if(-not $CredentialEnvFile -or -not(Test-Path -LiteralPath $CredentialEnvFile)){throw 'CREDENTIAL_ENV_FILE_REQUIRED'}
  $pairs=@{}
  foreach($line in (Get-Content -LiteralPath $CredentialEnvFile)){
   if($line -match '^\s*([A-Za-z0-9_]+)\s*=\s*(.+?)\s*$'){$pairs[$Matches[1]]=$Matches[2]}
  }
  $userKey=@($pairs.Keys|Where-Object {$_ -match 'TEST_USER'})|Select-Object -First 1
  $passKey=@($pairs.Keys|Where-Object {$_ -match 'TEST_PASSWORD'})|Select-Object -First 1
  $checks['credentialDeliveryReady']=([bool]$userKey -and [bool]$passKey -and [bool]$pairs[$userKey] -and [bool]$pairs[$passKey])
  $accountOk=$false;$accountNote='not-checked'
  if($checks['credentialDeliveryReady']){
   $cli=if($state.cliPath){$state.cliPath}else{'tcb'}
   $out=& $cli user list -e $context.EnvId --name $pairs[$userKey] 2>&1
   $text=(@($out)|ForEach-Object {$_ -as [string]}) -join "`n"
   if($LASTEXITCODE -eq 0 -and $text -match [regex]::Escape($pairs[$userKey])){$accountOk=$true;$accountNote='found'}
  }
  $checks['accountAvailable']=$accountOk
  $autoReference='auto-credentials;env-file='+($CredentialEnvFile -replace '\\','/')+';env-keys=2;user-list='+$accountNote
 }
}

if($task.id -in @('build','deploy','assets')){
 foreach($name in $taskChecks){$checks[$name]=($Status -eq 'verified')}
}elseif($task.id -in @('browser','probe')){
 if(-not $SmokeFile -or -not(Test-Path -LiteralPath $SmokeFile)){throw 'BROWSER_SMOKE_FILE_REQUIRED'}
 $smoke=Read-CourseJson $SmokeFile
 if(-not $smoke.checks){throw 'SMOKE_CHECKS_MISSING'}
 foreach($name in $taskChecks){
  if($smoke.checks.PSObject.Properties.Name -notcontains $name -or $smoke.checks.$name -ne $true){throw ('SMOKE_CHECK_PENDING:'+ $name)}
  $checks[$name]=$true
 }
}elseif($ChecksJson){
 $parsed=if(Test-Path -LiteralPath $ChecksJson){Read-CourseJson $ChecksJson}else{$ChecksJson|ConvertFrom-Json}
 $source=if($parsed.PSObject.Properties.Name -contains 'checks'){$parsed.checks}else{$parsed}
 foreach($name in $taskChecks){
  if($source.PSObject.Properties.Name -contains $name){$checks[$name]=[bool]$source.$name}
 }
}
$missing=@($taskChecks|Where-Object {$name=$_;-not $checks.ContainsKey($name)})
if($missing.Count){throw ('CHECKS_SOURCE_MISSING:'+($missing -join ','))}
# Auto failures downgrade to failed evidence instead of blocking regeneration.
if($Auto){
 $falseChecks=@($checks.Keys|Where-Object {$checks[$_] -ne $true})
 if($falseChecks.Count){
  $Status='failed'
  Write-Warning ('AUTO_CHECK_NOT_SATISFIED:'+($falseChecks -join ','))
 }
}
if($Status -eq 'verified'){
 $falseChecks=@($checks.Keys|Where-Object {$checks[$_] -ne $true})
 if($falseChecks.Count){throw ('CHECK_NOT_SATISFIED:'+($falseChecks -join ','))}
}

# Identity fields; reference must survive Record's self-inverse sanitization check.
$kind=if($Kind){$Kind}else{switch($task.id){'browser'{'browser'}'probe'{'browser'}'learner'{'learner'}default{'tool'}}}
$reference=if($Reference){$Reference}else{
 if($autoReference){$autoReference}
 elseif($task.id -in @('browser','probe') -and $SmokeFile){$SmokeFile}else{'manual-verify/'+$task.id+'/'+[datetimeoffset]::UtcNow.ToString('yyyyMMddHHmmss')}
}
if($reference -ne (Protect-CBDetail $reference)){throw 'REFERENCE_UNSAFE_FOR_EVIDENCE'}

$evidence=[ordered]@{runId=$state.runId;envId=$context.EnvId;taskId=$task.id;status=$Status;kind=$kind;reference=$reference;observedAt=[datetimeoffset]::UtcNow.ToString('o');checks=$checks;inputStamp=$stamp}
if($buildId){$evidence.buildId=$buildId}
if($recovering){
 # Recovery channel prerequisites enforced by Record for local tasks.
 $evidence.readOnlyConfirmed=$true
 $evidence.originalTaskEnded=$true
}
if(-not $OutFile){$OutFile=Join-Path $folder ($task.id+'-evidence.json')}
Assert-CoursePlainPath $OutFile
Write-CourseJson $OutFile $evidence
$evidence|ConvertTo-Json -Depth 8
if(-not $Record){Write-Warning ('NEXT: Invoke-CloudBaseWorkflow.ps1 -ProjectDirectory '+$context.Root+' -Action Record -EvidenceFile '+$OutFile)}
if($Record){
 & (Join-Path $PSScriptRoot 'Invoke-CloudBaseWorkflow.ps1') -ProjectDirectory $context.Root -Action Record -EvidenceFile $OutFile
}
