#!/usr/bin/env node
// verify-probe.mjs — CloudBase probe 任务冒烟模板（无登录项目，dev server 单会话）
// 与登录版 verify-smoke.mjs 同构：五段通用骨架 + 【项目定制区】。
// checks 与工作流 probe 任务白名单一致：
//   appSession             = 页面加载进入应用态（无登录门）
//   dataOrStorageReadWrite = 云库业务写入 → 列表可见 → 刷新后仍可见（云端读回）
// 已内置：CloudBase 默认域名风险中间页循环处理、React 受控输入兼容（typeExpr）、
//         状态轮询、Chrome 进程与临时 profile 自动清理。实测约 6 秒。
//
// 用法:
//   node verify-probe.mjs --base <URL> [--port 9225] [--out <结果json>]
// 结果 JSON 的 checks 与 Gen-CloudBaseEvidence.ps1 -TaskId probe -SmokeFile 直接兼容。
//
// 换项目时只改下方【项目定制区】：
//   1. SITE 按钮文本；2. SEL 各步骤元素查找器；3. fillAndSubmit() 业务填写顺序。

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';

import { loadBrowserAdapter } from './browser-adapter.mjs';
const { SITE, SEL, fillAndSubmit } = await loadBrowserAdapter(process.argv.slice(2));


const args = process.argv.slice(2);
const arg = (n, d) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : d; };
const BASE = arg('--base');
const PORT = Number(arg('--port', '9225'));
const CHROME = arg('--chrome', 'C:/Program Files/Google/Chrome/Application/chrome.exe');
const OUT = arg('--out', 'verify-probe-last.json');
const PROFILE = `${process.env.TEMP}\\cb-probe-${Date.now()}`;
if (!BASE) { console.error('USAGE: node verify-probe.mjs --base <URL> [--port 9225] [--out <json>]'); process.exit(1); }

const t0 = Date.now();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const chrome = spawn(CHROME, ['--headless=new', `--user-data-dir=${PROFILE}`,
  `--remote-debugging-port=${PORT}`, '--no-first-run', '--no-default-browser-check',
  '--window-size=1280,900', 'about:blank'], { detached: true, stdio: 'ignore' });
chrome.unref();
process.once('exit', () => { for(const child of [chrome]) if(child?.pid) { try { spawn('taskkill', ['/pid',String(child.pid),'/T','/F'], {stdio:'ignore'}).unref(); } catch {} } });
const runnerDeadline=setTimeout(() => { console.error('BROWSER_RUNNER_TIMEOUT'); process.exit(1); }, 180000); runnerDeadline.unref();

async function waitCdp() {
  for (let i = 0; i < 40; i++) { try { if ((await fetch(`http://127.0.0.1:${PORT}/json/version`, { signal: AbortSignal.timeout(2000) })).ok) return true; } catch {} await sleep(500); }
  return false;
}
if (!(await waitCdp())) { console.error('CDP_TIMEOUT'); process.exit(1); }

const list = await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json();
const ws = new WebSocket(list.find((x) => x.type === 'page').webSocketDebuggerUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
let mid = 0; const pend = new Map();
ws.onmessage = (e) => { const m = JSON.parse(e.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (me, pa = {}) => new Promise((r) => { const i = ++mid; const timeout = setTimeout(() => { console.error('CDP_COMMAND_TIMEOUT:'+me); process.exit(1); }, 15000); pend.set(i, (value) => { clearTimeout(timeout); r(value); }); ws.send(JSON.stringify({ id: i, method: me, params: pa })); });
const evalJs = async (ex) => {
  const r = await send('Runtime.evaluate', { expression: ex, awaitPromise: true, returnByValue: true });
  if (r.result?.exceptionDetails) return 'EVAL_ERR';
  return r.result?.result?.value;
};
await send('Page.enable');

// React 受控组件兼容输入（无 id 控件用查找器表达式）：原生 setter 清空 + input 事件 + focus + 真实键入
const typeExpr = async (finder, text) => {
  await evalJs(`(()=>{const el=${finder};if(!el)return;const p=(el.tagName==='TEXTAREA'?HTMLTextAreaElement:HTMLInputElement).prototype;Object.getOwnPropertyDescriptor(p,'value').set.call(el,'');el.dispatchEvent(new Event('input',{bubbles:true}));el.focus();})()`);
  await send('Input.insertText', { text });
};

// 状态机：风险中间页(enabled/disabled 循环) → app
async function settle(timeoutMs = 30000) {
  const t = Date.now();
  while (Date.now() - t < timeoutMs) {
    const st = await evalJs(`(()=>{
      const rb=[...document.querySelectorAll('button')].find(x=>(x.textContent||'').includes('${SITE.riskButtonText}'));
      if(rb) return rb.disabled?'risk_wait':'risk_click';
      if([...document.querySelectorAll('button')].some(x=>x.textContent.includes('${SITE.appButtonText}'))) return 'app';
      return 'loading';
    })()`);
    if (st === 'app') return st;
    if (st === 'risk_click') { await evalJs(`[...document.querySelectorAll('button')].find(x=>(x.textContent||'').includes('${SITE.riskButtonText}')).click()`); await sleep(2500); }
    else await sleep(1200);
  }
  return 'timeout';
}
const goto = async (url) => {
  await evalJs('window.__cbOldDocument = true');
      await send('Page.navigate', { url });
      for(let i=0;i<40;i++){ if(await evalJs('window.__cbOldDocument === true') === false) break; await sleep(100); }
  for(let i=0;i<40;i++){ if(await evalJs('document.readyState') === 'complete') break; await sleep(100); }
  return settle();
};

const checks = {}; const steps = [];
const step = (n, d) => { steps.push({ step: n, ...d }); console.log('STEP ' + n + ' ' + JSON.stringify(d)); };

// 1) appSession
let st = await goto(BASE);
checks.appSession = st === 'app';
step('appSession', { state: st });

// 2) dataOrStorageReadWrite（云库业务写入 → 列表可见 → 刷新读回）
const marker = 'SMOKE-' + Date.now();
if (checks.appSession) {
  const w = await fillAndSubmit({ evalJs, typeExpr, sleep, step, marker, SEL });
  let still = false;
  if (w.saved) {
    st = await goto(BASE);
    const t3 = Date.now();
    while (Date.now() - t3 < SITE.reloadVisibleTimeoutMs) {
      if ((await evalJs(`document.body.textContent.includes('${marker}')`)) === true) { still = true; break; }
      await sleep(500);
    }
  }
  checks.dataOrStorageReadWrite = !!(w.saved && w.seen) && st === 'app' && still;
  step('dataOrStorageReadWrite', { ...w, reloadState: st, still });
}

const RESULT = { checks, elapsedMs: Date.now() - t0, marker, base: BASE };
console.log('RESULT ' + JSON.stringify(RESULT));
fs.writeFileSync(OUT, JSON.stringify(RESULT, null, 2));

try { spawn('taskkill', ['/pid', String(chrome.pid), '/T', '/F'], { stdio: 'ignore' }); } catch {}
ws.close();
setTimeout(() => { try { fs.rmSync(PROFILE, { recursive: true, force: true }); } catch {} process.exit(Object.values(checks).length >= 2 && Object.values(checks).every(Boolean) ? 0 : 1); }, 1500);
