﻿#Requires -Version 5.1
# Begin is adjacent to the real action; keep runtime startup, smoke and Record alive together.
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,
 [Parameter(Mandatory=$true)][ValidateSet('resources','adapter','credentials','frontend','probe','sessions','browser')][string]$TaskId,
 [string]$SmokeScript,[string]$BrowserAdapter,[ValidateSet('sync','single')][string]$SmokeMode='sync',[string]$CredentialEnvFile,[switch]$NoRecord,[switch]$Orchestrated)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $executionRoot 'scripts/Course-Context.ps1')
. (Join-Path $PSScriptRoot 'Course-CloudBaseWorkflow.ps1')
. (Join-Path $PSScriptRoot 'Course-CloudBaseHealth.ps1')
$context=Get-CBProject $ProjectDirectory
$wf=Join-Path $PSScriptRoot 'Invoke-CloudBaseWorkflow.ps1'
$gen=Join-Path $PSScriptRoot 'Gen-CloudBaseEvidence.ps1'
function Invoke-TaskControl([string]$ControlAction,[hashtable]$Extra=@{}){
 $timerLock=[Diagnostics.Stopwatch]::StartNew()
 do{try{return (& $wf -ProjectDirectory $context.Root -Action $ControlAction @Extra)}catch{if($_.Exception.Message -ne 'CLOUDBASE_OPERATION_ALREADY_RUNNING' -or $timerLock.Elapsed.TotalSeconds -ge 30){throw};Start-Sleep -Milliseconds 150}}while($true)
}
$state=(& $wf -ProjectDirectory $context.Root -Action Status|Out-String)|ConvertFrom-Json
if(-not $state.runId){throw 'START_WORKFLOW_BEFORE_TASK'}
$task=@($state.tasks|Where-Object id -eq $TaskId)
if($task.Count -ne 1 -or $task[0].executor -ne 'external'){throw 'EXTERNAL_TASK_NOT_IN_PLAN'}
if($task[0].status -eq 'verified'){[pscustomobject]@{taskId=$TaskId;status='already-verified'}|ConvertTo-Json;return}
if($task[0].status -notin @('pending','stale')){throw 'TASK_ALREADY_STARTED_RESOLVE_ORIGINAL_OPERATION'}
if($TaskId -notin @($state.ready)){throw 'TASK_DEPENDENCIES_NOT_READY'}
if($TaskId -in @('probe','browser')){
 if(-not $SmokeScript){throw 'PROJECT_SMOKE_ADAPTER_REQUIRED'}
 $SmokeScript=[IO.Path]::GetFullPath($SmokeScript);Assert-CoursePlainPath $SmokeScript
 if(-not(Test-Path -LiteralPath $SmokeScript -PathType Leaf)){throw 'SMOKE_SCRIPT_MISSING'}
}
$runDir=Join-Path $context.Root ('.ai-coding/cb/'+$state.runId.Substring(0,12))
$smoke=Join-Path $runDir ($TaskId+'-actual.json')
$runtimeLease=$null
if($TaskId -in @('frontend','probe')){
 # These tasks share one local engine/helper. Do not observe its API mid-startup
 # or end its owning parent while another task still needs the local endpoint.
 $queuedAt=[datetimeoffset]::UtcNow
 $runtimeLease=Enter-CBFileLock (Join-Path $context.Root '.ai-coding/cb/runtime-session.lock') -WaitMs 240000
 $queueSeconds=([datetimeoffset]::UtcNow-$queuedAt).TotalSeconds
 if($queueSeconds -gt 0.1){$null=Write-CBTiming $context ([ordered]@{runId=$state.runId;taskId=$TaskId;name='runtime-session-queue';kind='wait';status='completed';startedAt=$queuedAt.ToString('o');finishedAt=[datetimeoffset]::UtcNow.ToString('o');durationSeconds=$queueSeconds})}
}
$timingStarted=[datetimeoffset]::UtcNow;$timer=[Diagnostics.Stopwatch]::StartNew()
$oldRun=$env:AI_CODING_CB_RUN;$oldTask=$env:AI_CODING_CB_TASK
$env:AI_CODING_CB_RUN=$state.runId;$env:AI_CODING_CB_TASK=$TaskId
$status='failed';$detail=$null;$taskBegan=$false
try{
 $null=Invoke-TaskControl 'Begin' @{TaskId=$TaskId}
 $taskBegan=$true
 if($TaskId -in @('frontend','probe')){
  $health=Get-CBRuntimeHealth $context $executionRoot
  Write-CourseJson (Join-Path $runDir ($TaskId+'-runtime-before.json')) $health
  if($health.reason -eq 'selected-api-unavailable-machine-running'){throw 'SELECTED_API_UNAVAILABLE_MACHINE_RUNNING: inspect original connection/helper; do not restart the machine or infer sleep.'}
  # The recorded runtime owns machine selection and image verification; no replacement machine or host npm.
  if(-not $health.engineAvailable -or -not $health.pageAvailable){
   $runtimeResult=Invoke-CBMeasured $context 'ensure-runtime-for-task' {& (Join-Path $executionRoot 'scripts/Invoke-CourseProject.ps1') -ProjectDirectory $context.Root -Action Start -TimeoutSeconds 240} 'Restore only the recorded runtime; keep this parent alive.'
   $cmd=Read-CourseJson (Join-Path $context.Root '.ai-coding/command.json')
   if($cmd.status -ne 'verified'){throw 'RUNTIME_START_NOT_VERIFIED'}
  }
  $runtime=Read-CourseJson (Join-Path $context.Root '.ai-coding/runtime-check.json')
  if(-not $runtime.url){throw 'LIVE_RUNTIME_URL_REQUIRED'}
  $response=Invoke-WebRequest -UseBasicParsing -Uri $runtime.url -TimeoutSec 10
  if($response.StatusCode -ne 200){throw 'LOCAL_PAGE_NOT_READY'}
  $base=$runtime.url
 }else{$base=$context.Url}
 $params=@{ProjectDirectory=$context.Root;TaskId=$TaskId;OutFile=(Join-Path $runDir ($TaskId+'-evidence.json'))}
 if(-not $NoRecord -and -not $Orchestrated){$params.Record=$true}
 if($CredentialEnvFile){$params.CredentialEnvFile=$CredentialEnvFile}
 switch($TaskId){
  {$_ -in @('resources','adapter','credentials')} {$params.Auto=$true}
  'frontend' {$params.ChecksJson='{"pageReady":true}';$params.Reference=('Live HTTP 200 after recorded Start; '+$base)}
  'sessions' {
   & node (Join-Path $PSScriptRoot 'prepare-sessions.mjs') --root (Join-Path $runDir 'profiles') --out $smoke
   if($LASTEXITCODE -ne 0){throw 'SESSION_PREPARATION_FAILED'}
   $params.ChecksJson=$smoke;$params.Reference=$smoke
  }
  {$_ -in @('probe','browser')} {
   $nodeArgs=@($SmokeScript,'--base',$base,'--out',$smoke)
   if($SmokeMode -eq 'single'){$nodeArgs+='--single'}
   if($BrowserAdapter){
    $fullAdapter=[IO.Path]::GetFullPath($BrowserAdapter);Assert-CoursePlainPath $fullAdapter
    if(-not $fullAdapter.StartsWith($context.Root.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase) -or -not(Test-Path -LiteralPath $fullAdapter -PathType Leaf)){throw 'PROJECT_BROWSER_ADAPTER_REQUIRED'}
    $nodeArgs+=@('--adapter',$fullAdapter)
   }
   if($TaskId -eq 'browser' -and $state.options.multiSession){
    $prepared=Read-CourseJson (Join-Path $runDir 'sessions-actual.json')
    $nodeArgs+=@('--profileA',$prepared.profiles[0].dir,'--profileB',$prepared.profiles[1].dir)
   }
   & node @nodeArgs
   if($LASTEXITCODE -ne 0){throw 'APPLICATION_SMOKE_FAILED_SEE_TASK_RESULT'}
   $params.SmokeFile=$smoke
  }
 }
 $null=& $gen @params
 $saved=Read-CourseJson $params.OutFile
 if($Orchestrated -and -not $NoRecord){$null=Invoke-TaskControl 'Record' @{EvidenceFile=$params.OutFile;NoWait=$true}}
 if($saved.status -ne 'verified'){throw 'TASK_CHECKS_FAILED_SEE_EVIDENCE'}
 $status='completed'
 [pscustomobject]@{taskId=$TaskId;status='verified';durationSeconds=[math]::Round($timer.Elapsed.TotalSeconds,3);evidence=$params.OutFile;smokeFile=$(if(Test-Path -LiteralPath $smoke){$smoke}else{$null})}|ConvertTo-Json
}catch{
 $detail=$_.Exception.Message
 if($taskBegan -and -not $NoRecord){
  try{$null=Invoke-TaskControl 'Fail' @{TaskId=$TaskId;RunId=$state.runId;Diagnostic=$detail}}
  catch{Write-Warning ('FAILURE_STATE_RECORDING_REQUIRES_QUERY: '+$_.Exception.Message)}
 }
 # Record the terminated verification failure, never invent successful checks.
 throw
}finally{
 if($runtimeLease){$runtimeLease.Dispose()}
 $null=Write-CBTiming $context ([ordered]@{runId=$state.runId;taskId=$TaskId;name='external-executor';kind='work';status=$status;startedAt=$timingStarted.ToString('o');finishedAt=[datetimeoffset]::UtcNow.ToString('o');durationSeconds=$timer.Elapsed.TotalSeconds;detail=$detail})
 $env:AI_CODING_CB_RUN=$oldRun;$env:AI_CODING_CB_TASK=$oldTask
}
