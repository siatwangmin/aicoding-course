﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,
 [ValidateSet('Measure','Plan','Start','Status','Watch','Resume','Begin','Record','Fail','Retry','Run','Drive','Advance')][string]$Action='Plan',
 [string]$PlanFile,[string]$CliPath,[switch]$AllowPublish,[switch]$NewRun,
 [string]$EvidenceFile,[string]$RetryTask,[string]$RunId,[string]$TaskId,[string]$Attempt,[string]$Diagnostic,
 [ValidateRange(1,30)][int]$WaitSeconds=20,[switch]$NoAutoAdvance,
 [ValidateRange(5,3600)][int]$WorkerWaitSeconds=240,[switch]$NoWait)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $executionRoot 'scripts/Course-Context.ps1')
. (Join-Path $PSScriptRoot 'Course-CloudBaseWorkflow.ps1')
. (Join-Path $PSScriptRoot 'Course-CloudBaseReport.ps1')
. (Join-Path $PSScriptRoot 'Course-CloudBaseHealth.ps1')
$context=Get-CBProject $ProjectDirectory
$folder=Join-Path $context.Root '.ai-coding/cb'
$statePath=Join-Path $folder 'current.json'
Assert-CoursePlainPath $folder
function Read-CurrentWorkflow{
 if(-not(Test-Path -LiteralPath $statePath)){return $null}
 $state=Read-CBState $statePath
 if($state.runId -notmatch '^[a-f0-9]{32}$'){throw 'INVALID_WORKFLOW_RUN_ID'}
 $plan=New-CBWorkflowPlan $context $state.planFile $state.cliPath
 if(($state.binding -cne $plan.binding -or $state.projectDirectory -ne $context.Root) -and -not ($Action -in @('Start','Measure') -and $NewRun)){throw 'WORKFLOW_BINDING_CHANGED_CREATE_NEW_RUN'}
 return Get-CBWorkflowStatus $context $state (Join-Path $folder $state.runId.Substring(0,12))
}
function Save-CurrentWorkflow($State){
 $before=if(Test-Path -LiteralPath $statePath){Read-CBState $statePath}else{$null}
 Write-CBTransitionEvents $context $State $before
 Write-CourseJson (Join-Path $folder ($State.runId.Substring(0,12)+'/state.json')) $State
 Write-CourseJson $statePath $State
 $null=Export-CBWorkflowReport $context $State
}
function Start-CBDriver($State){
 if(-not $State.autoAdvance){return}
 $locals=@($State.tasks|Where-Object {$_.executor -eq 'local' -and $_.status -eq 'running'})
 $ready=@(Get-CBReadyTasks $State|Where-Object {$_.executor -eq 'local' -and ($_.id -ne 'deploy' -or $State.allowPublish)})
 if(-not $locals.Count -and -not $ready.Count){return}
 $runFolder=Join-Path $folder $State.runId.Substring(0,12);$identity=Join-Path $runFolder 'drive.json'
 if(Test-Path -LiteralPath $identity){$prior=Read-CBState $identity;if(Test-CBProcess $prior.processId $prior.processStartedAt){return}}
 $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',$PSCommandPath,'-ProjectDirectory',$context.Root,'-Action','Drive','-RunId',$State.runId)
 $tag=[guid]::NewGuid().ToString('N').Substring(0,8)
 $process=Start-Process -FilePath (Get-CBPowerShell) -ArgumentList (($arguments|ForEach-Object {ConvertTo-CBArgument ([string]$_)}) -join ' ') -WorkingDirectory $context.Root -WindowStyle Hidden -RedirectStandardOutput (Join-Path $runFolder ('drive-'+$tag+'.log')) -RedirectStandardError (Join-Path $runFolder ('drive-'+$tag+'.error.log')) -PassThru
 Write-CourseJson $identity @{runId=$State.runId;processId=$process.Id;processStartedAt=$process.StartTime.ToUniversalTime().ToString('o')}
}
function Get-ResultPath($State,$Task){return Join-Path $folder ($State.runId.Substring(0,12)+'/'+$Task.id+'/'+$Task.attempt.Substring(0,12))}
function Write-TaskHeartbeat($State,$Task,$Child){
 $value=@{runId=$State.runId;taskId=$Task.id;attempt=$Task.attempt;workerId=$PID;workerStartedAt=(Get-Process -Id $PID).StartTime.ToUniversalTime().ToString('o');heartbeatAt=[datetimeoffset]::UtcNow.ToString('o');childId=$Child.Id;childStartedAt=$Child.StartTime.ToUniversalTime().ToString('o')}
 Write-CourseJson (Join-Path (Get-ResultPath $State $Task) 'heartbeat.json') $value
}
if($Action -eq 'Measure'){
 $lease=Enter-CBFileLock (Join-Path $folder 'control.lock') -WaitMs 5000
 try{
  $current=Read-CurrentWorkflow
  if($current -and @($current.tasks|Where-Object status -in @('running','outcome-unknown')).Count){throw 'ACTIVE_WORKFLOW_MEASUREMENT_PRESERVED'}
  $path=Join-Path $folder 'measurement-start.json'
  $m=if(Test-Path -LiteralPath $path){Read-CBState $path}else{$null}
  if(-not $m -or $NewRun -or $m.consumed){$m=@{runId=[guid]::NewGuid().ToString('N');envId=$context.EnvId;projectDirectory=$context.Root;startedAt=[datetimeoffset]::UtcNow.ToString('o');consumed=$false};Write-CourseJson $path $m}
  $m|ConvertTo-Json
 }finally{$lease.Dispose()};return
}
if($Action -eq 'Plan'){
 if(-not $PlanFile){$PlanFile=Join-Path $context.Root '.ai-coding/cloudbase-plan.json'}
 $plan=New-CBWorkflowPlan $context $PlanFile $CliPath
 foreach($task in $plan.tasks){try{$stamp=Get-CBTaskStamp $context $plan $task}catch{$stamp=$null};$task|Add-Member NoteProperty expectedInputStamp $stamp -Force}
 $plan|Add-Member NoteProperty ready @((Get-CBReadyTasks $plan)|ForEach-Object {$_.id})
 $plan|ConvertTo-Json -Depth 14;return
}
if($Action -in @('Status','Watch')){
 $state=Read-CurrentWorkflow
 if(-not $state){[pscustomobject]@{status='not-started';actionRequired=$true;nextAction='Plan the current scope, then Start.'}|ConvertTo-Json;return}
 if($Action -eq 'Watch'){
  $signature=($state.tasks|Select-Object id,status|ConvertTo-Json -Compress)
  $watch=[Diagnostics.Stopwatch]::StartNew()
  while(-not $state.actionRequired -and $watch.Elapsed.TotalSeconds -lt $WaitSeconds){
   Start-Sleep -Milliseconds 1000;$state=Read-CurrentWorkflow
   if(($state.tasks|Select-Object id,status|ConvertTo-Json -Compress) -ne $signature){break}
  }
 }
 $state|ConvertTo-Json -Depth 14;return
}
if($Action -eq 'Drive'){
 if($RunId -notmatch '^[a-f0-9]{32}$'){throw 'INVALID_COORDINATOR_RUN_ID'}
 try{$lease=Enter-CBFileLock (Join-Path $folder ($RunId.Substring(0,12)+'/drive.lock'))}catch{if($_.Exception.Message -eq 'CLOUDBASE_OPERATION_ALREADY_RUNNING'){return};throw}
 try{
  while($true){
   try{$view=& $PSCommandPath -ProjectDirectory $context.Root -Action Advance -RunId $RunId|ConvertFrom-Json}catch{if($_.Exception.Message -eq 'CLOUDBASE_OPERATION_ALREADY_RUNNING'){Start-Sleep -Milliseconds 200;continue};throw}
   $active=@($view.tasks|Where-Object {$_.executor -eq 'local' -and $_.status -eq 'running'})
   $readyLocal=@(Get-CBReadyTasks $view|Where-Object {$_.executor -eq 'local' -and ($_.id -ne 'deploy' -or $view.allowPublish)})
   if(-not $active.Count -and -not $readyLocal.Count){
    # Publish the idle decision under the same short lock used by Begin/Record.
    # A new local task can then either keep this coordinator alive or start a successor.
    $control=Enter-CBFileLock (Join-Path $folder 'control.lock') -WaitMs 5000
    $stop=$false
    try{
     $latest=Read-CurrentWorkflow
     if($latest.runId -ne $RunId){$stop=$true}else{
      $stillActive=@($latest.tasks|Where-Object {$_.executor -eq 'local' -and $_.status -eq 'running'})
      $stillReady=@(Get-CBReadyTasks $latest|Where-Object {$_.executor -eq 'local' -and ($_.id -ne 'deploy' -or $latest.allowPublish)})
      if(-not $stillActive.Count -and -not $stillReady.Count){
       Write-CourseJson (Join-Path $folder ($RunId.Substring(0,12)+'/drive.json')) @{runId=$RunId;processId=$null;processStartedAt=$null;status='idle'}
       $stop=$true
      }
     }
    }finally{$control.Dispose()}
    if($stop){break}
   }
   Start-Sleep -Milliseconds 1000
  }
 }finally{$lease.Dispose()};return
}
if($Action -eq 'Run'){
 if($RunId -notmatch '^[a-f0-9]{32}$' -or $Attempt -notmatch '^[a-f0-9]{32}$' -or $TaskId -notin @('build','deploy','assets')){throw 'INVALID_WORKFLOW_WORKER_BINDING'}
 $saved=Read-CBState $statePath
 $fresh=New-CBWorkflowPlan $context $saved.planFile $saved.cliPath
 if($fresh.binding -ne $saved.binding){throw 'WORKFLOW_WORKER_BINDING_CHANGED'}
 $task=@($saved.tasks|Where-Object {$_.id -eq $TaskId -and $_.attempt -eq $Attempt})
 if($saved.runId -ne $RunId -or $task.Count -ne 1 -or $task[0].executor -ne 'local'){throw 'WORKFLOW_WORKER_BINDING_CHANGED'}
 $task=$task[0];$attemptFolder=Get-ResultPath $saved $task
 $lease=Enter-CBFileLock (Join-Path $attemptFolder 'worker.lock')
 try{
  if(Test-Path -LiteralPath (Join-Path $attemptFolder 'result.json')){return}
  if((Get-CBTaskStamp $context $saved $task) -ne $task.inputStamp){throw 'WORKFLOW_WORKER_INPUT_CHANGED'}
  if($TaskId -eq 'deploy' -and -not $saved.allowPublish){throw 'DEPLOYMENT_AUTHORIZATION_REQUIRED'}
  $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $PSScriptRoot 'Publish-CloudBase.ps1'),'-ProjectDirectory',$context.Root,'-Action',$(switch($TaskId){build{'Build'}deploy{'Deploy'}assets{'Verify'}}))
  if($saved.cliPath){$arguments+=@('-CliPath',$saved.cliPath)}
  if($saved.options.platformPolicyFile){$arguments+=@('-PlatformPolicyFile',(Join-Path $context.Root $saved.options.platformPolicyFile))}
  $quoted=@($arguments|ForEach-Object {ConvertTo-CBArgument ([string]$_)})
  $powershell=Get-CBPowerShell
  $started=[datetimeoffset]::UtcNow;$exitCode=$null;$outcome='outcome-unknown';$errorCode=$null;$child=$null
  try{
   $env:AI_CODING_CB_RUN=$RunId;$env:AI_CODING_CB_TASK=$TaskId;$env:AI_CODING_CB_ATTEMPT=$Attempt
   if($TaskId -in @('build','assets')){
    Ensure-CBWorkerRuntime $context $executionRoot (Join-Path $attemptFolder 'runtime-before.json')
   }
   $child=Start-Process -FilePath $powershell -ArgumentList ($quoted -join ' ') -WorkingDirectory $context.Root -WindowStyle Hidden -RedirectStandardOutput (Join-Path $attemptFolder 'operation.log') -RedirectStandardError (Join-Path $attemptFolder 'operation.error.log') -PassThru
   $null=$child.Handle;Write-TaskHeartbeat $saved $task $child
   while(-not $child.WaitForExit(5000)){Write-TaskHeartbeat $saved $task $child}
   $child.Refresh();$exitCode=$child.ExitCode
   if($exitCode -eq 0){$outcome='verified'}else{
    $publication=if(Test-Path (Join-Path $context.Root 'docs/progress/cloudbase-publish.json')){Read-CourseJson (Join-Path $context.Root 'docs/progress/cloudbase-publish.json')}else{$null}
    $operationError=Get-Content -LiteralPath (Join-Path $attemptFolder 'operation.error.log') -Raw -ErrorAction SilentlyContinue
    $outcome=if(($TaskId -eq 'deploy' -and $publication.status -eq 'deployment-unknown') -or $operationError -match 'BUILD_OUTCOME_UNKNOWN_QUERY_CONTAINER'){'outcome-unknown'}else{'failed'}
    $errorCode='OPERATION_EXIT_'+$exitCode
   }
  }catch{
   $errorCode='WORKER_PROCESS_ERROR'
   if(-not $child){$outcome='failed'}
   [IO.File]::WriteAllText((Join-Path $attemptFolder 'operation.error.log'),(Protect-CBDetail $_.Exception.Message),[Text.UTF8Encoding]::new($false))
  }
  finally{
   $finished=[datetimeoffset]::UtcNow
   $detailPath=Join-Path $attemptFolder 'operation.error.log'
   $diagnostic=if(Test-Path -LiteralPath $detailPath){Protect-CBDetail ([IO.File]::ReadAllText($detailPath))}else{$null}
   Write-CourseJson (Join-Path $attemptFolder 'result.json') @{runId=$RunId;taskId=$TaskId;attempt=$Attempt;inputStamp=$task.inputStamp;status=$outcome;exitCode=$exitCode;error=$errorCode;diagnostic=$diagnostic;startedAt=$started.ToString('o');finishedAt=$finished.ToString('o');durationSeconds=($finished-$started).TotalSeconds}
   foreach($log in @('operation.log','operation.error.log')){$logPath=Join-Path $attemptFolder $log;if(Test-Path -LiteralPath $logPath){[IO.File]::WriteAllText($logPath,(Protect-CBDetail ([IO.File]::ReadAllText($logPath))),[Text.UTF8Encoding]::new($false))}}
  }
 }finally{$lease.Dispose()}
 return
}
$lock=Enter-CBFileLock (Join-Path $folder 'control.lock') -WaitMs 5000
try{
 $state=Read-CurrentWorkflow
 if($Action -eq 'Advance' -and (-not $state -or ($RunId -and $state.runId -cne $RunId))){throw 'COORDINATOR_RUN_CHANGED'}
 if($Action -eq 'Advance' -and -not $RunId){$RunId=$state.runId}
 if($Action -eq 'Start'){
  if($state -and -not $NewRun){$Action='Resume'}else{
   if($state -and @($state.tasks|Where-Object status -in @('running','outcome-unknown')).Count){throw 'FINISH_OR_RESOLVE_ORIGINAL_TASKS_BEFORE_NEW_RUN'}
   if(-not $PlanFile){$PlanFile=Join-Path $context.Root '.ai-coding/cloudbase-plan.json'}
   if(-not $CliPath){
    $startOptions=Read-CourseJson $PlanFile
    if($startOptions.route -eq 'CLI'){
     $registeredCli=Join-Path $env:APPDATA 'npm/tcb.ps1'
     if(-not(Test-Path -LiteralPath $registeredCli -PathType Leaf)){throw 'OFFICIAL_CLI_PATH_REQUIRED_BEFORE_START: pass -CliPath from preflight.'}
     Assert-CoursePlainPath $registeredCli
     $CliPath=$registeredCli
    }
   }
   $state=New-CBWorkflowPlan $context $PlanFile $CliPath
   if(-not $context.Url){throw 'QUERY_AND_BIND_ACTUAL_HOSTING_URL_BEFORE_START'}
   $state|Add-Member NoteProperty runId ([guid]::NewGuid().ToString('N'))
   $state|Add-Member NoteProperty startedAt ([datetimeoffset]::UtcNow.ToString('o'))
   $state|Add-Member NoteProperty allowPublish ([bool]$AllowPublish)
   $state|Add-Member NoteProperty autoAdvance (-not [bool]$NoAutoAdvance)
   $measurement=Join-Path $folder 'measurement-start.json'
   if(Test-Path -LiteralPath $measurement){
    $m=Read-CBState $measurement
    $age=([datetimeoffset]::UtcNow-(ConvertTo-CBTime $m.startedAt)).TotalSeconds
    if(-not $m.consumed -and $m.envId -eq $context.EnvId -and $m.projectDirectory -eq $context.Root -and $age -ge 0 -and $age -lt 86400){
     $state.runId=$m.runId;$state.startedAt=$m.startedAt;$m.consumed=$true;Write-CourseJson $measurement $m
     $null=Write-CBTiming $context ([ordered]@{runId=$state.runId;taskId='preflight';name='preflight';kind='work';status='completed';startedAt=$m.startedAt;finishedAt=[datetimeoffset]::UtcNow.ToString('o');durationSeconds=$age})
    }
   }
  }
 }
 if(-not $state){throw 'WORKFLOW_NOT_STARTED'}
 if($Action -eq 'Retry'){
  if($state.runId -cne $RunId){throw 'RETRY_RUN_CHANGED'}
  $retry=@($state.tasks|Where-Object id -eq $TaskId)
  if($retry.Count -ne 1){throw 'UNKNOWN_WORKFLOW_TASK'}
  Reset-CBFailedTask $retry[0]
  Save-CurrentWorkflow $state
  $state|ConvertTo-Json -Depth 14;return
 }
 if($Action -eq 'Fail'){
  if($state.runId -cne $RunId){throw 'FAILURE_RUN_CHANGED'}
  $failedTask=@($state.tasks|Where-Object id -eq $TaskId)
  if($failedTask.Count -ne 1 -or $failedTask[0].executor -ne 'external'){throw 'EXTERNAL_TASK_REQUIRED'}
  if($failedTask[0].status -eq 'failed'){$state|ConvertTo-Json -Depth 14;return}
  Set-CBExternalFailure $failedTask[0] $Diagnostic
  Save-CurrentWorkflow $state
  $state|ConvertTo-Json -Depth 14;return
 }
 if($AllowPublish){$state.allowPublish=$true}
 if($Action -eq 'Begin'){
  $ids=@($TaskId -split ','|ForEach-Object {$_.Trim()}|Where-Object {$_})
  if(-not $ids.Count){throw 'READY_EXTERNAL_TASK_REQUIRED'}
  foreach($id in $ids){
   $t=@($state.tasks|Where-Object id -eq $id)
   if($t.Count -ne 1 -or $t[0].executor -ne 'external'){throw 'READY_EXTERNAL_TASK_REQUIRED'}
   $t=$t[0]
   if($t.status -ne 'running'){
    if($id -notin @(Get-CBReadyTasks $state|ForEach-Object {$_.id})){throw 'TASK_DEPENDENCIES_PENDING'}
    $t.status='running';$t.startedAt=[datetimeoffset]::UtcNow.ToString('o');$t.finishedAt=$null;$t.inputStamp=Get-CBTaskStamp $context $state $t
   }
  }
 }
 if($Action -eq 'Record'){
  if(-not $EvidenceFile){throw 'ACTUAL_TASK_EVIDENCE_REQUIRED'}
  Assert-CoursePlainPath $EvidenceFile
  if((Get-Item -LiteralPath $EvidenceFile).Length -gt 524288){throw 'EVIDENCE_TOO_LARGE'}
  $e=Read-CourseJson $EvidenceFile
  if($e.runId -ne $state.runId -or $e.envId -ne $context.EnvId -or $e.status -notin @('running','verified','failed','outcome-unknown') -or $e.kind -notin @('tool','command','browser','learner') -or -not $e.reference -or $e.reference -ne (Protect-CBDetail $e.reference)){throw 'TASK_EVIDENCE_IDENTITY_OR_SOURCE_INVALID'}
  $task=@($state.tasks|Where-Object id -eq $e.taskId)
  if($task.Count -ne 1){throw 'UNKNOWN_WORKFLOW_TASK'};$task=$task[0]
  $recovering=$task.executor -eq 'local' -and $task.status -eq 'outcome-unknown'
  $stamp=if($recovering){$task.inputStamp}else{Get-CBTaskStamp $context $state $task}
  if($e.inputStamp -ne $stamp){throw 'TASK_EVIDENCE_INPUT_CHANGED'}
  $age=([datetimeoffset]::UtcNow-(ConvertTo-CBTime $e.observedAt)).TotalSeconds
  if($age -lt -120 -or $age -gt 86400){throw 'TASK_EVIDENCE_TIME_INVALID'}
  $dependencies=@($task.dependsOn|Where-Object {$id=$_;@($state.tasks|Where-Object {$_.id -eq $id -and $_.status -eq 'verified'}).Count -ne 1})
  if($dependencies.Count -and -not $recovering){throw 'TASK_DEPENDENCIES_PENDING'}
  if($task.executor -eq 'local' -and -not ($task.status -eq 'outcome-unknown' -and $e.readOnlyConfirmed -eq $true -and $e.originalTaskEnded -eq $true)){throw 'LOCAL_TASK_REQUIRES_WORKER_RESULT_OR_CONFIRMED_RECOVERY'}
  if($task.executor -eq 'local'){
   $heartbeat=Join-Path (Get-ResultPath $state $task) 'heartbeat.json'
   if(Test-Path -LiteralPath $heartbeat){$beat=Read-CBState $heartbeat;if(Test-CBProcess $beat.childId $beat.childStartedAt){throw 'ORIGINAL_OPERATION_STILL_RUNNING'}}
  }
  if($task.id -eq 'learner' -and $e.kind -ne 'learner'){throw 'LEARNER_FEEDBACK_REQUIRED'}
  if($task.id -eq 'browser' -and $e.kind -ne 'browser'){throw 'ACTUAL_BROWSER_EVIDENCE_REQUIRED'}
  foreach($name in $e.checks.PSObject.Properties.Name){if($name -notin $task.checks -or $e.checks.$name -isnot [bool]){throw 'TASK_CHECK_FIELDS_INVALID'}}
  if($e.status -eq 'verified'){
   if($task.executor -eq 'external' -and $state.workflowProtocol -ge 2 -and -not $task.startedAt){throw 'BEGIN_EXTERNAL_TASK_BEFORE_EXECUTION'}
   if($task.id -eq 'adapter'){foreach($relative in $state.options.adapterInputs){if(-not(Test-Path -LiteralPath (Join-Path $context.Source $relative) -PathType Leaf)){throw 'ADAPTER_SOURCE_NOT_READY'}}}
   foreach($name in $task.checks){if($e.checks.$name -ne $true){throw ('TASK_CHECK_PENDING:'+ $name)}}
   if($task.id -in @('deploy','browser','assets','learner')){
    $build=Read-CourseJson (Join-Path $context.Root '.ai-coding/cloudbase-build.json')
    if($e.buildId -ne $build.buildId){throw 'TASK_BUILD_ID_CHANGED'}
   }
   if($recovering -and $task.id -eq 'build'){
    $original=Read-CourseJson (Join-Path $context.Root '.ai-coding/cloudbase-build.json')
    $null=Assert-CBArtifact $context $original -AllowLegacy
    if($e.buildId -ne $original.buildId){throw 'TASK_BUILD_ID_CHANGED'}
   }
  }
  if($task.id -eq 'deploy' -and -not $state.allowPublish){throw 'DEPLOYMENT_AUTHORIZATION_REQUIRED'}
  if($task.id -eq 'deploy' -and $e.status -eq 'verified'){
   $build=Read-CourseJson (Join-Path $context.Root '.ai-coding/cloudbase-build.json')
   $null=Assert-CBArtifact $context $build -AllowLegacy:$recovering
   $build.status='deployed';$build.url=$context.Url
   Write-CourseJson (Join-Path $context.Root 'docs/progress/cloudbase-publish.json') $build
  }
  if($task.id -eq 'deploy' -and $recovering -and $e.status -eq 'failed'){
   $original=Read-CourseJson (Join-Path $context.Root 'docs/progress/cloudbase-publish.json')
   if($original -and $original.envId -eq $context.EnvId){$original.status='confirmed-failed';Write-CourseJson (Join-Path $context.Root 'docs/progress/cloudbase-publish.json') $original}
  }
  $task.inputStamp=$stamp;$task.status=$e.status
  if($e.status -eq 'running' -and -not $task.startedAt){$task.startedAt=[datetimeoffset]::UtcNow.ToString('o')}
  if($e.status -in @('verified','failed')){$task.finishedAt=[datetimeoffset]::UtcNow.ToString('o')}
  if($e.platformTaskId){if([string]$e.platformTaskId -notmatch '^[a-zA-Z0-9_.:/-]{1,180}$'){throw 'PLATFORM_TASK_ID_INVALID'};$task.platformTaskId=$e.platformTaskId}
  $proof=Join-Path $folder ($state.runId.Substring(0,12)+'/evidence/'+$task.id+'-'+[guid]::NewGuid().ToString('N').Substring(0,12)+'.json')
  # Store only the evidence allowlist, never arbitrary MCP responses or credentials.
  Write-CourseJson $proof @{runId=$e.runId;taskId=$task.id;envId=$e.envId;inputStamp=$stamp;status=$e.status;kind=$e.kind;reference=$e.reference;observedAt=$e.observedAt;checks=$e.checks;buildId=$e.buildId;platformTaskId=$task.platformTaskId}
  $task.evidence=$proof
  $task.evidenceSha256=(Get-FileHash -LiteralPath $proof).Hash.ToLowerInvariant()
 }
 if($RetryTask){
  $task=@($state.tasks|Where-Object id -eq $RetryTask)
  if($task.Count -ne 1){throw 'UNKNOWN_WORKFLOW_TASK'}
  Reset-CBFailedTask $task[0]
 }
 # Persist control-plane changes (Start/Begin/Record) immediately; the spawn loop
 # below only covers local tasks and never runs in external-only phases.
 if($Action -in @('Start','Begin','Record')){Save-CurrentWorkflow $state}
 $workerWait=if($NoWait){[TimeSpan]::Zero}else{[TimeSpan]::FromSeconds([math]::Max(5,$WorkerWaitSeconds))}
 while($true){
  $state=Get-CBWorkflowStatus $context $state (Join-Path $folder $state.runId.Substring(0,12))
  $spawned=0
  foreach($task in @(Get-CBReadyTasks $state|Where-Object executor -eq 'local')){
   if($task.id -eq 'deploy' -and -not $state.allowPublish){continue}
   $task.inputStamp=Get-CBTaskStamp $context $state $task;$task.attempt=[guid]::NewGuid().ToString('N');$task.status='running';$task.startedAt=[datetimeoffset]::UtcNow.ToString('o');$task.error=$null
   $attemptFolder=Get-ResultPath $state $task;[void](New-Item -ItemType Directory -Path $attemptFolder -Force)
   Save-CurrentWorkflow $state
   $workerArguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',$PSCommandPath,'-ProjectDirectory',$context.Root,'-Action','Run','-RunId',$state.runId,'-TaskId',$task.id,'-Attempt',$task.attempt)
   $quoted=@($workerArguments|ForEach-Object {ConvertTo-CBArgument ([string]$_)})
   try{
    $process=Start-Process -FilePath (Get-CBPowerShell) -ArgumentList ($quoted -join ' ') -WorkingDirectory $context.Root -WindowStyle Hidden -RedirectStandardOutput (Join-Path $attemptFolder 'worker.log') -RedirectStandardError (Join-Path $attemptFolder 'worker.error.log') -PassThru
    $task.processId=$process.Id;$task.processStartedAt=$process.StartTime.ToUniversalTime().ToString('o')
   }catch{$task.status='failed';$task.error='WORKER_LAUNCH_FAILED'}
   Save-CurrentWorkflow $state
   $spawned++
   if($task.status -eq 'running' -and $workerWait -gt [TimeSpan]::Zero){
    # Keep the parent alive, but release the control lock while waiting. Other
    # external tasks must be able to Begin/Record during a local build.
    $lock.Dispose();$lock=$null
    try{
     $deadline=[datetime]::UtcNow.Add($workerWait)
     while([datetime]::UtcNow -lt $deadline){
      if(Test-Path -LiteralPath (Join-Path $attemptFolder 'result.json')){break}
      if(-not (Test-CBProcess $task.processId $task.processStartedAt)){break}
      Start-Sleep -Milliseconds 1000
     }
    }finally{$lock=Enter-CBFileLock (Join-Path $folder 'control.lock') -WaitMs 15000}
    $state=Read-CurrentWorkflow
    Save-CurrentWorkflow $state
   }
  }
  if($spawned -eq 0){break}
 }
 # Persist the final derived status/durations even when no local task was spawned.
 # Otherwise the final external Record leaves all checks verified but the disk report running.
 Save-CurrentWorkflow $state
 if($Action -ne 'Advance'){
  $localsLeft=@($state.tasks|Where-Object {$_.executor -eq 'local' -and $_.status -in @('running','outcome-unknown')}).Count
  if($localsLeft -or $NoWait){Start-CBDriver $state}
 }
 $state|ConvertTo-Json -Depth 14
}finally{if($lock){$lock.Dispose()}}
