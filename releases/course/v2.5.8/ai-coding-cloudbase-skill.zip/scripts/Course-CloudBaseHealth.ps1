﻿#Requires -Version 5.1
# Read-only separation of machine state, selected API and application port.
function Get-CBRuntimeHealth($Context,[string]$ExecutionRoot){
 . (Join-Path $ExecutionRoot 'scripts/Course-Native.ps1')
 $facts=[ordered]@{checkedAt=[datetimeoffset]::UtcNow.ToString('o');runtime=$Context.Project.containerRuntime;machineState='not-observed';engineAvailable=$false;pageAvailable=$false;url=('http://127.0.0.1:'+$Context.Project.port+'/');reason='not-checked'}
 if($Context.Project.containerRuntime -eq 'podman'){
  $tools=Read-CourseJson (Join-Path (Get-CourseUserRoot) 'tool-paths.json')
  $cli=$tools.podman.cli;$connection=$Context.Project.connection
  if(-not $cli -or -not(Test-Path -LiteralPath $cli) -or $connection -notmatch '^podman-machine-[a-zA-Z0-9_-]+$'){throw 'RECORDED_PODMAN_BINDING_REQUIRED'}
  $machine=$connection -replace '-root$',''
  $inspection=Invoke-SetupNative $cli @('machine','inspect',$machine) 12
  if($inspection.ExitCode -ne 0){$facts.reason='machine-inspect-failed';return [pscustomobject]$facts}
  $m=@((ConvertFrom-Json $(if($inspection.Stdout){$inspection.Stdout}else{$inspection.Output})))[0]
  $facts.machineState=$m.State
  if($m.State -ne 'running'){$facts.reason='machine-not-running';return [pscustomobject]$facts}
  $engine=Invoke-SetupNative $cli @('--connection',$connection,'info','--format','json') 12
  $facts.engineAvailable=$engine.ExitCode -eq 0
  if(-not $facts.engineAvailable){$facts.reason='selected-api-unavailable-machine-running';return [pscustomobject]$facts}
 }else{$facts.reason='use-recorded-runtime-verifier';return [pscustomobject]$facts}
 try{$r=Invoke-WebRequest -UseBasicParsing -Uri $facts.url -TimeoutSec 3;$facts.pageAvailable=$r.StatusCode -eq 200}catch{$facts.pageAvailable=$false}
 $facts.reason=if($facts.pageAvailable){'ready'}else{'application-port-unavailable'}
 return [pscustomobject]$facts
}

function Ensure-CBWorkerRuntime($Context,[string]$ExecutionRoot,[string]$ObservationFile){
 $liveHealth=Get-CBRuntimeHealth $Context $ExecutionRoot
 Write-CourseJson $ObservationFile $liveHealth
 if(-not $liveHealth.engineAvailable){
  if($liveHealth.reason -eq 'selected-api-unavailable-machine-running'){throw 'SELECTED_API_UNAVAILABLE_MACHINE_RUNNING: inspect original helper/connection; do not restart workloads.'}
  $null=Invoke-CBMeasured $Context 'ensure-runtime-for-worker' {& (Join-Path $ExecutionRoot 'scripts/Invoke-CourseProject.ps1') -ProjectDirectory $Context.Root -Action Start -TimeoutSeconds 240} 'Restore only the recorded environment and keep this worker alive until verification ends.'
  $runtimeCommand=Read-CourseJson (Join-Path $Context.Root '.ai-coding/command.json')
  if($runtimeCommand.status -ne 'verified'){throw 'WORKER_RUNTIME_START_NOT_VERIFIED'}
 }
}
