#!/usr/bin/env node
// verify-smoke.mjs — CloudBase 部署后单会话冒烟验收模板（browser 任务默认路线，实测约 13 秒）
// 用一条真实浏览器会话替代双会话+多标签验收：登录失败→正确登录→写入→刷新仍在→登出回登录门，
// 五项 checks 与工作流 browser 任务白名单一致：
//   pageUsable / wrongPasswordRejected / correctLogin / dataPersisted / accessDenied
// multiSession=true 的独立会话同步验收不在此脚本内，仍按 web-verification.md 人工编排。
//
// 用法:
//   node verify-smoke.mjs --base <站点URL> [--env <凭据env文件>] [--port 9225] [--out <结果json>]
// 凭据零回显：仅从 env 文件读 <PREFIX>_TEST_USER / <PREFIX>_TEST_PASSWORD，输出不含凭据与 token。
// 已内置：CloudBase 默认域名风险中间页（“确定访问”）循环处理、React 受控输入兼容、状态轮询、
//         Chrome 进程与含登录态 profile 的自动清理。
//
// 换项目时只改下方【项目定制区】：
//   1. SITE 选择器与按钮文本；2. credentialEnv 前缀；3. writeAndVerify() 里的业务写入步骤。

import fs from 'node:fs';
import { spawn } from 'node:child_process';

// ============================ 项目定制区（know-star 示例） ============================
const SITE = {
  // 状态识别：风险中间页按钮文本、登录页标志、应用页标志
  riskButtonText: '确定访问',
  loginSelector: '#loginUsername',
  appSelector: '#inputQuestion',
  appButtonText: '怪兽',
  // 登录表单
  userSelector: '#loginUsername',
  passSelector: '#loginPassword',
  userIsTextarea: false,
  passIsTextarea: false,
  submitSelector: 'form button[type=submit]',
  wrongPasswordHint: '已保留你的输入',
  // 登出按钮（按 title 或文本匹配）
  logoutTitle: '退出登录',
  logoutText: '退出',
  // 刷新持久化等待
  reloadVisibleTimeoutMs: 15000,
};
// 业务写入步骤：返回 {saved, seen}。saved=提交成功（modal 关闭等可观察结果），seen=数据在页面可见。
// 示例为 know-star「召唤怪兽」：打开 modal→填题干/答案→选错因→提交→等 modal 关→等列表出现 marker。
async function writeAndVerify(ctx) {
  const { evalJs, type, sleep, step, marker } = ctx;
  await evalJs(`[...document.querySelectorAll('button')].find(x=>x.textContent.includes('召唤怪兽')).click()`);
  let modal = false; const t = Date.now();
  while (Date.now() - t < 10000) { if (await evalJs(`!!document.querySelector('#inputQuestion')`)) { modal = true; break; } await sleep(400); }
  if (!modal) { return { saved: false, seen: false, modal: false }; }
  await sleep(500); // modal 入场/挂载完成，避免毫秒级连续操作丢事件
  await type('#inputQuestion', marker, true);
  await type('#inputAnswer', 'smoke-验证数据', true);
  // radio 点击后必须断言 checked；提交被必填校验拦截会导致 modal 不关
  const radioOk = await evalJs(`(()=>{
    const r=document.querySelector('input[name=mistakeReason][value=CARELESS]');
    if(!r) return 'NORADIO';
    if(!r.checked){ if(r.closest('label')) r.closest('label').click(); else r.click(); }
    return r.checked;
  })()`);
  if (radioOk !== true) await sleep(300);
  await evalJs(`document.querySelector('form button[type=submit]').click()`);
  // 先等提交成功（modal 关闭），未关时 dump 校验信息并重试（最多 2 次）
  let saved = false, retries = 0; const t2 = Date.now();
  while (Date.now() - t2 < 25000) {
    if ((await evalJs(`!document.querySelector('#inputQuestion')`)) === true) { saved = true; break; }
    if (Date.now() - t2 > 8000 * (retries + 1) && retries < 2) {
      retries++;
      const vmsg = await evalJs(`(()=>{const q=document.querySelector('#inputQuestion');return q?q.validationMessage:'no-q';})()`);
      await evalJs(`document.querySelector('form button[type=submit]').click()`);
      step('submitRetry', { retry: retries, validation: String(vmsg).slice(0, 60) });
    }
    await sleep(500);
  }
  // 提交成功后才认 seen：marker 必须出现在列表（排除未提交时输入框残留文本的假阳性）
  let seen = false; const t5 = Date.now();
  while (Date.now() - t5 < 10000) {
    if ((await evalJs(`document.body.textContent.includes('${marker}')`)) === true) { seen = true; break; }
    await sleep(500);
  }
  return { saved, seen };
}
const credentialEnv = (env) => ({ user: env.KNOWSTAR_TEST_USER, pass: env.KNOWSTAR_TEST_PASSWORD });
// ============================ 以下为通用骨架，通常不需改 ============================

const args = process.argv.slice(2);
const arg = (n, d) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : d; };

const BASE = arg('--base');
const ENV_PATH = arg('--env', 'D:/ENV/.cloudbase-setup/connection.env');
const PORT = Number(arg('--port', '9225'));
const CHROME = arg('--chrome', 'C:/Program Files/Google/Chrome/Application/chrome.exe');
const OUT = arg('--out', 'verify-smoke-last.json');
const PROFILE = `${process.env.TEMP}\\cb-smoke-${Date.now()}`;
if (!BASE) { console.error('USAGE: node verify-smoke.mjs --base <URL> [--env <env>] [--port 9225] [--out <json>]'); process.exit(1); }

// ---- 凭据（零回显） ----
const env = Object.fromEntries(fs.readFileSync(ENV_PATH, 'utf8').split(/\r?\n/)
  .filter((l) => l.includes('=') && !l.trim().startsWith('#'))
  .map((l) => { const i = l.indexOf('='); return [l.slice(0, i).trim(), l.slice(i + 1).trim()]; }));
const { user: USER, pass: PASS } = credentialEnv(env);
if (!USER || !PASS) { console.error('MISSING_CREDENTIALS'); process.exit(1); }

const t0 = Date.now();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---- 启动单实例 headless Chrome（脚本内管理生命周期） ----
const chrome = spawn(CHROME, ['--headless=new', `--user-data-dir=${PROFILE}`,
  `--remote-debugging-port=${PORT}`, '--no-first-run', '--no-default-browser-check',
  '--window-size=1280,900', 'about:blank'], { detached: true, stdio: 'ignore' });
chrome.unref();

async function waitCdp() {
  for (let i = 0; i < 40; i++) { try { if ((await fetch(`http://127.0.0.1:${PORT}/json/version`)).ok) return true; } catch {} await sleep(500); }
  return false;
}
if (!(await waitCdp())) { console.error('CDP_TIMEOUT'); process.exit(1); }

const list = await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json();
const ws = new WebSocket(list.find((x) => x.type === 'page').webSocketDebuggerUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
let mid = 0; const pend = new Map();
ws.onmessage = (e) => { const m = JSON.parse(e.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (me, pa = {}) => new Promise((r) => { const i = ++mid; pend.set(i, r); ws.send(JSON.stringify({ id: i, method: me, params: pa })); });
const evalJs = async (ex) => {
  const r = await send('Runtime.evaluate', { expression: ex, awaitPromise: true, returnByValue: true });
  if (r.result?.exceptionDetails) return 'EVAL_ERR';
  return r.result?.result?.value;
};
await send('Page.enable');

// React 受控组件兼容输入：原生 setter 清空 + focus + 真实键入
async function type(sel, text, textarea) {
  await evalJs(`(()=>{const el=document.querySelector('${sel}');if(!el)return;const p=${textarea ? 'HTMLTextAreaElement' : 'HTMLInputElement'}.prototype;Object.getOwnPropertyDescriptor(p,'value').set.call(el,'');el.dispatchEvent(new Event('input',{bubbles:true}));el.focus();})()`);
  await send('Input.insertText', { text });
}

// 状态机：风险中间页(enabled/disabled 循环) → login / app
async function settle(timeoutMs = 30000) {
  const t = Date.now();
  while (Date.now() - t < timeoutMs) {
    const st = await evalJs(`(()=>{
      const rb=[...document.querySelectorAll('button')].find(x=>(x.textContent||'').includes('${SITE.riskButtonText}'));
      if(rb) return rb.disabled?'risk_wait':'risk_click';
      if(document.querySelector('${SITE.loginSelector}')) return 'login';
      if(document.querySelector('${SITE.appSelector}')!==null||[...document.querySelectorAll('button')].some(x=>x.textContent.includes('${SITE.appButtonText}'))) return 'app';
      return 'loading';
    })()`);
    if (st === 'login' || st === 'app') return st;
    if (st === 'risk_click') { await evalJs(`[...document.querySelectorAll('button')].find(x=>(x.textContent||'').includes('${SITE.riskButtonText}')).click()`); await sleep(2500); }
    else await sleep(1200);
  }
  return 'timeout';
}
const goto = async (url) => {
  await send('Page.navigate', { url });
  // 换页确认：等新文档出现（performance.now 重新计数 <5s）再进入状态轮询，避免读到旧 DOM
  for (let i = 0; i < 40; i++) {
    const nw = await evalJs(`performance.now()`);
    if (typeof nw === 'number' && nw < 5000) break;
    await sleep(300);
  }
  return settle();
};

const checks = {}; const steps = [];
const step = (n, d) => { steps.push({ step: n, ...d }); console.log('STEP ' + n + ' ' + JSON.stringify(d)); };

// 1) pageUsable
let st = await goto(BASE);
checks.pageUsable = st === 'login';
step('pageUsable', { state: st });

// 2) wrongPasswordRejected（错误密码被拒 + 输入保留）
if (checks.pageUsable) {
  await type(SITE.userSelector, USER, SITE.userIsTextarea);
  await type(SITE.passSelector, PASS + 'x', SITE.passIsTextarea);
  await evalJs(`document.querySelector('${SITE.submitSelector}').click()`);
  let err = false; const t = Date.now();
  while (Date.now() - t < 15000) {
    if (await evalJs(`[...document.querySelectorAll('div')].some(x=>x.textContent.includes('${SITE.wrongPasswordHint}'))`)) { err = true; break; }
    await sleep(500);
  }
  checks.wrongPasswordRejected = err;
  step('wrongPasswordRejected', { ok: err });
}

// 3) correctLogin（提交后等待"离开登录页"而非瞬间判定，避免竞态误判）
if (checks.wrongPasswordRejected) {
  await sleep(1000);
  await type(SITE.userSelector, USER, SITE.userIsTextarea);
  await type(SITE.passSelector, PASS, SITE.passIsTextarea);
  await evalJs(`document.querySelector('${SITE.submitSelector}').click()`);
  let ok = false; const t = Date.now();
  while (Date.now() - t < 30000) {
    const s = await evalJs(`(()=>{
      if(document.querySelector('${SITE.loginSelector}')) return 'login';
      if(document.querySelector('${SITE.appSelector}')!==null||[...document.querySelectorAll('button')].some(x=>x.textContent.includes('${SITE.appButtonText}'))) return 'app';
      return 'loading';
    })()`);
    if (s === 'app') { ok = true; break; }
    if (s === 'login' && Date.now() - t > 3000) break; // 提交 3s 后仍停登录页 = 未跳转
    await sleep(500);
  }
  checks.correctLogin = ok;
  step('correctLogin', { state: ok ? 'app' : 'stuck-login' });
}

// 4) dataPersisted（业务写入定制步骤 → 列表可见 → 刷新仍在 = 上云 + 持久化）
const marker = 'SMOKE-' + Date.now();
if (checks.correctLogin) {
  const w = await writeAndVerify({ evalJs, type, sleep, step, marker });
  let still = false;
  if (w.saved) {
    st = await goto(BASE); // 刷新仍在 = 数据在云端（轮询等云端列表渲染）
    const t3 = Date.now();
    while (Date.now() - t3 < SITE.reloadVisibleTimeoutMs) {
      if ((await evalJs(`document.body.textContent.includes('${marker}')`)) === true) { still = true; break; }
      await sleep(500);
    }
  }
  checks.dataPersisted = !!(w.saved && w.seen) && st === 'app' && still;
  step('dataPersisted', { ...w, reloadState: st, still });
}

// 5) accessDenied（登出 → 登录门回归，轮询等 React 状态更新）
if (checks.correctLogin) {
  await evalJs(`(()=>{const b=[...document.querySelectorAll('button')].find(x=>(x.title||'').includes('${SITE.logoutTitle}')||x.textContent.includes('${SITE.logoutText}'));if(b)b.click();})()`);
  let gate = false; const t4 = Date.now();
  while (Date.now() - t4 < 10000) {
    if ((await evalJs(`!!document.querySelector('${SITE.loginSelector}')`)) === true) { gate = true; break; }
    await sleep(500);
  }
  checks.accessDenied = gate;
  step('accessDenied', { gate });
}

const RESULT = { checks, elapsedMs: Date.now() - t0, marker, base: BASE };
console.log('RESULT ' + JSON.stringify(RESULT));
fs.writeFileSync(OUT, JSON.stringify(RESULT, null, 2));

// 清理：杀 Chrome 树 + 删含登录态的 profile
try { spawn('taskkill', ['/pid', String(chrome.pid), '/T', '/F'], { stdio: 'ignore' }); } catch {}
ws.close();
setTimeout(() => { try { fs.rmSync(PROFILE, { recursive: true, force: true }); } catch {} process.exit(Object.values(checks).length >= 5 && Object.values(checks).every(Boolean) ? 0 : 1); }, 1500);
