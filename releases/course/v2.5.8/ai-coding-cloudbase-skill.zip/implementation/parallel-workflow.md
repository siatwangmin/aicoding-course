# 整轮快路径（本地修订 20261025.3）

已有接线项目只读 references/controller-template.md 即可运行，不必通读本文件。BeginTask→Run→CompleteTask 覆盖全部助手工作；普通数据同步 localProbe=false 可省重复本地浏览器读写，线上双会话仍保留。资源终态和 Resume -RetryTask 已由执行器处理，不按历史说明重新 Start。

以下历史事故和专门能力说明按当前故障按需读取。

# 并行、后台与增量执行

用于当前项目云端接入和部署；账号/环境准备继续原准备入口。入口为 `scripts/Invoke-CloudBaseWorkflow.ps1`。它执行本地确定性任务并管理依赖；页面、SDK 适配和官方 MCP 操作由助手按 [提示词模板](../references/workflow-prompts.md) 完成后登记实际证据。

## 计划与预检

先运行 Measure，再选 assets/examples/first-deploy-plan.json、restore-plan.json、frontend-update-plan.json，按当前需求保存到 B/.ai-coding/cloudbase-plan.json。scope=connect 表示需要本轮云端检查；scope=static-update 明确只改前端，data/images/backend/sync 均为 false。login 表示本轮需核可用账号、安全交付和正确登录，learnerReview 仅在已要求本人试用时启用；multiSession 默认 false——browser 走单会话冒烟（scripts/verify-smoke.mjs 五项，约 1 分钟），仅明确要求独立会话同步验收时设 true（创建 sessions 任务并追加双会话检查）。模板中的路径、能力和目标均需按项目填写。

adapterInputs 为相对 app 源码目录的 SDK/Repository 文件；resourceInputs/backendInputs 为相对 B 的迁移、后端实现或配置文件，路径与当前项目一致。保持已选架构，不因模板默认示例切数据库、改账号或启用额外能力。Plan 会读取本地事实、固定目标和所需检查，不访问凭证内容、不启动引擎或变更云资源。preflight 中的授权与资源状态只是待查项，须取得当前官方结果才能通过 resources。

先通过既有官方路线查询真实 hostingUrl 并写入当前 services 绑定，再 Start 固定目标。项目目标、工具入口或计划本身改变时，新建一轮；原有运行中/结果未知的任务须先查证。

资源差异可用 `scripts/Compare-CloudBaseResources.ps1 -ProjectDirectory <B> -DesiredFile <项目资源契约.json> -ObservedFile <本轮官方查询摘要.json>` 自动比较。desired-resources.json 为形状样例，资源键和属性由当前 schema 填入；observed 同样包含 schemaVersion=1、envId、resources，另带 kind=tool|command、reference、observedAt。先按官方工具实际返回归一化所需元数据；比较仅生成 create/review-update/reuse 清单，保留未声明的现有资源，不执行 SQL 或删除，不用计划状态代替查回证据。

```powershell
& '<技能>/scripts/Invoke-CloudBaseWorkflow.ps1' -ProjectDirectory '<B>' -Action Measure
& '<技能>/scripts/Invoke-CloudBaseWorkflow.ps1' -ProjectDirectory '<B>' -Action Plan
& '<技能>/scripts/Invoke-CloudBaseWorkflow.ps1' -ProjectDirectory '<B>' -Action Start
# 当前任务已经授权实际发布时，Start 或 Resume 加 -AllowPublish。
& '<技能>/scripts/Invoke-CloudBaseWorkflow.ps1' -ProjectDirectory '<B>' -Action Resume -AllowPublish
```

CLI 路线在首次 Start/Plan 加 `-CliPath '<已登记官方 .ps1/.exe>'`。MCP 路线不为了后台化改成 CLI；官方任务支持异步时记录 platformTaskId，不支持时沿原调用返回结果。计划中不接受任意 shell 命令或凭证。

## 固定依赖图

- resources、adapter、sessions（仅 multiSession）可并行；resources 内的迁移/权限写入按资源串行，backend 等资源就绪再部署。
- adapter 后接 frontend；页面输入稳定即可后台 build，不等云资源准备。probe 只等 resources、adapter 和本轮必要 backend，适配文件稳定时可与剩余页面接线/构建重叠。
- deploy 等 build、必要资源与 probe；依赖后端时由 probe 确认后端调用。assets 和 browser 在 deploy 后并行；browser 默认单会话冒烟（scripts/verify-smoke.mjs：登录页/错误密码/正确登录/写入→刷新仍在/登出回登录门，单实例 headless Chrome 约 1 分钟），仅 multiSession=true 时创建 sessions 并在其完成后做独立会话同步验收。
- Start/Resume/Record 默认启动单一协调进程，后台结果到达后自动推进已授权本地节点，无需逐步 Resume。协调进程在本地任务结束且需外部输入时退出，Record/Resume 可接续；不运行永久轮询服务。Status/Watch 只查询，不启动任何任务。-NoAutoAdvance 仅用于需要手工逐步观察的隔离调试。后台进程沿当前 PowerShell 版本运行。

## 调度节奏与后台纪律（首轮部署实测校准）

一次首轮部署实测：总挂钟约 35 分钟，其中真实机器工作仅约 6 分钟（resources 等待 130s、build 45s、deploy 16s、冒烟 25s），其余为对话串行与两次事故返工。按以下节奏可将同类首轮部署压到 6–8 分钟：

1. 预热先行：Measure/Plan 的同时在常驻终端串联项目执行包 `Invoke-CourseProject.ps1 -Action Start` 预热引擎与依赖。运行环境不可用时分别查询实际 machine State、选定API及本地端口；exit125或LAST UP不能证明虚机休眠。
2. Start 后立即三线并行：
   - resources：后台终端运行 `scripts/Invoke-CloudBaseResources.ps1 -Root '<B>'`（读 current.json 的 cliPath/envId/resourceInputs 逐条执行迁移 SQL，输出 resources-exec-last.json 作 reference），完成后再 `Gen-CloudBaseEvidence.ps1 -TaskId resources -Auto -Record` 只读闭环；不在对话中逐条复述 SQL。
   - adapter：与 resources 同期改写 adapterInputs（两任务无依赖）。
   - sessions（multiSession 时）：`node scripts/prepare-sessions.mjs --root '<B>\.ai-coding\cb\sessions' --count 2`，秒级完成，输出 checks.isolatedSessionsPrepared 与 profiles[].dir/port。
3. frontend/probe 前移：页面接线期间即可跑 probe 冒烟——无登录项目 `node scripts/verify-probe.mjs --base <hostingUrl>`（checks=appSession/dataOrStorageReadWrite），登录项目沿用 verify-smoke.mjs；不必等 build。
4. deploy 后 assets 与 browser 并行；multiSession 的 browser 用 `node scripts/verify-sync.mjs --base <hostingUrl> --profileA <profiles[0].dir> --profileB <profiles[1].dir>`（五项 checks 与白名单同名），profile 目录直接取 prepare-sessions 的输出。
5. 同一时刻至少保持一个后台动作在跑；Begin 支持逗号分隔批量，不要逐任务串行等待。

后台纪律：

- local worker（build/deploy/assets）必须由常驻终端的 Resume 主进程拉起；在临时终端用 `-NoWait` 会在主命令退出时连 worker 一起被杀——实测进程日志为空、任务停在 outcome-unknown。
- 长等待用 Watch -WaitSeconds 或终端查询轮询；不在对话里逐条阻塞式调用 CLI。
- 一次 Begin 一份 inputStamp：补录证据复用 Status 返回的 expectedInputStamp；inputStamp 变化会把同一任务登记成第二条记录（实测 adapter 被记两次，多耗约 130s）。

容器引擎存活（二次部署实测补充）：

- 使用 preflight -CheckRuntime 只读区分 machine-not-running、selected-api-unavailable-machine-running 和 application-port-unavailable。只在记录的机器确实停止时由原项目 Start 恢复；机器running但API不通时保留连接/辅助进程诊断，不能重启机器绕过或称为休眠。
- frontend/probe 用 Invoke-CloudBaseTask.ps1：即时Begin，查运行环境，调用原执行包Start，核真实HTTP，再冒烟与Record。整个父命令保持到子任务结束；在Trae以可轮询的长任务运行，不能用-NoWait后结束父命令。该措施防止短命终端导致依赖进程丢失；并非声称所有Start退出都会杀虚机。

## 事故恢复预案

- assets 首试 `LOCAL_ENGINE_UNAVAILABLE_NO_HOST_FALLBACK`：常驻终端串联 `Invoke-CourseProject.ps1 -Action Start` 预热引擎，runtime-check 通过后 `Resume -RetryTask assets`（-RetryTask 仅限明确 failed 的 local 任务）。
- 任务 outcome-unknown（worker 被杀/心跳丢失）：先只读查证记录的进程、子进程与原平台任务是否已结束；结束后 `Gen-CloudBaseEvidence.ps1 -TaskId <任务>` 自动走恢复通道（附加 readOnlyConfirmed/originalTaskEnded、复用冻结 inputStamp、跳过依赖检查），产出 verified 或明确 failed 证据；未知任务不自动重发。
- 同任务双记录：保留后一条为准，核对前一条 attempt 的诊断与耗时，不删除任务目录。
- deploy 失败或超时：先查原平台任务，再沿 Publish-CloudBase -Action Recover；不为重试覆盖未知部署的构建记录。
- assets `PUBLIC_HTML_HEADERS_INVALID`：先运行 `node <技能>/scripts/observe-policy.mjs --project <B> --cli <登记tcb入口>` 自动取得精确EnvId/StaticDomain及HTTP响应头，策略证据写入当前项目；不把网关Enable冒充enableSafeDomain。随后仅对明确failed的assets使用 `-Action Advance -RetryTask assets` 重验，不重建或重传。CLI JSON由Node argv传递，不套用固定PowerShell转义字符串。

## 证据接续

Start/Status 返回 runId、envId、ready 和每个任务的 expectedInputStamp/checks。外部 ready 任务开始前执行 Begin（-TaskId 支持逗号分隔批量一次标记多个），再调用对应官方工具或处理页面。resources/credentials/adapter/probe 优先用 scripts/Gen-CloudBaseEvidence.ps1 -Auto 只读生成证据（加 -Record 一条命令闭环），Auto 检查不满足时自动生成 failed 证据，修复后重跑即可；frontend/sessions/backend 等其余外部动作完成后保存实际 JSON 并 Record，新轮次禁止缺开始时间直接报 verified。不得把样例检查项直接全部填 true。未通过记 failed，未知记 outcome-unknown。

```json
{
  "runId": "本轮实际runId",
  "taskId": "resources",
  "envId": "当前实际环境",
  "inputStamp": "Status返回的本任务expectedInputStamp",
  "status": "verified",
  "kind": "tool",
  "reference": "实际官方工具结果或项目内脱敏证据位置",
  "observedAt": "实际观察时间ISO8601",
  "checks": {"targetAccess": true, "resourcesReady": true, "permissionsChecked": true}
}
```

```powershell
& '<技能>/scripts/Invoke-CloudBaseWorkflow.ps1' -ProjectDirectory '<B>' -Action Begin -TaskId resources,credentials,adapter
# resources/credentials/adapter/probe：一条命令只读生成证据并 Record（probe 另加 -SmokeFile）。
& '<技能>/scripts/Gen-CloudBaseEvidence.ps1' -ProjectDirectory '<B>' -TaskId resources -Auto -Record
# frontend/浏览器等其余外部动作：先执行实际官方查询/操作，然后按实际结果提交证据。
& '<技能>/scripts/Invoke-CloudBaseWorkflow.ps1' -ProjectDirectory '<B>' -Action Record -EvidenceFile '<本轮实际证据.json>'
& '<技能>/scripts/Invoke-CloudBaseWorkflow.ps1' -ProjectDirectory '<B>' -Action Status
& '<技能>/scripts/Invoke-CloudBaseWorkflow.ps1' -ProjectDirectory '<B>' -Action Watch -WaitSeconds 20
```

deploy/browser/assets/learner 证据另绑定本轮 buildId；learner 必须 kind=learner。browser 默认先跑 `node '<技能>/scripts/verify-smoke.mjs' --base <hostingUrl> --out <结果json>`（结果 checks 与任务白名单同名），再把它包装为 evidence（kind=browser、补 runId/envId/inputStamp/buildId/reference/observedAt）Record；换项目时按脚本头部【项目定制区】改选择器与业务写入步骤。CLI 的本地结果由 worker 登记；MCP 的 deploy 证据确认原 TaskId 终态及本轮产物，Record 后再做 assets。应用检查与静态文件通过分开记录。

项目状态与历史在 `.ai-coding/cb/<runId前12位>`；任务各有独立 attempt、进程身份、心跳、日志与结果，主入口持短锁汇总 current.json。任务心跳不证明下载字节进度。不得在运行中修改原脚本或清理任务目录；已有项目仍固定原执行包，新包安装/升级后再使用本入口。

目录仅缩短标识以兼容 Windows PowerShell 路径限制，JSON 内始终核完整 runId/attempt。Status 输出外部任务的原 platformTaskId；助手用官方工具查询原任务并 Record 更新实际观察，Status 本身不会调用会话 MCP。资源/SDK/probe 按本轮证据校验并保存摘要；证据丢失、内容变化或外部观察过期时相应任务失效。appSession 沿当前已确认身份策略核应用访问，不因此新增注册或登录界面。

## 复用、失败与恢复

默认域名按 references/preflight-queries.md 取得本轮官方网关事实后，将 assets/examples/platform-policy.json 填写为 B/.ai-coding/cloudbase-policy.json；其他路径可在开始前设置platformPolicyFile。它绑定环境、完整URL、域名、默认域事实、安全提示开关和观察时间；示例不能直接当通过证据。仅明确匹配受支持策略时允许程序请求的已知attachment头，仍全量核buildId、HTTP、HTML类型和SHA256；真实浏览器始终独立验收。未知/过期策略、跨目标重定向、摘要不符仍失败，不伪造请求头/Cookie。

若原验证缺少策略证据，补齐默认路径的真实观察后，只对assets显式RetryTask，并重验失效的浏览器证据。策略内容摘要只影响验证节点，不使已完成的构建和部署失效；不为修复验证问题重新上传。改变目标、能力范围或计划路径仍需新轮次。

Build 对源码、依赖锁、构建配置、镜像和环境计算指纹，构建前后比对，随后生成完整资源摘要。Deploy 只读取已核产物；部署或浏览器检查前再次核原 dist。输入/产物变化使相应任务 stale，依赖任务一并失效；资源和明确适配文件未变时，对应证据可在本轮保留。新一轮按 scope 选择增量范围，不自动刷新旧观察时间。

完整运行环境通过后可短时复用；复用前实时核引擎、容器、镜像、挂载和依赖探针，连接/配置/锁文件/执行包变化或探针失败回到原完整检查。CLI版本/help按入口与实际包摘要短时复用，当前目标授权每轮仍查。各原生命令的阶段、退出码、脱敏错误、耗时和下一动作保存在 .ai-coding/cb-events，worker diagnostic 直接返回首个实际错误。

## 自动计时与交付

Measure覆盖预检开始至最终报告；未调用时起点为Start，之前时间明确未测。本地命令细分 runtime-check/compile/assets-manifest/cli-help/target-access/upload/assets-verify；外部任务由Begin/Record在实际调用前后计时，脚本不会冒充MCP执行器。等待或排障可用 Write-CloudBaseEvent -Action Begin -TaskId <实际任务> -Name <简短标识> -Kind wait|diagnosis，返回eventId；结束用同脚本 -Action End -EventId <原标识>。异常也应在finally收尾。

本轮 .ai-coding/cb/<runId前12位>/measurement.json 和 report.md 自动更新；可用Export-CloudBaseReport再次汇总。报告给总墙钟、任务重叠、已记录等待/诊断和命令事件，缺失字段不伪造。deployment/artifact/browser/application/learner分别判定。交付需要登录时只通过授权安全渠道提供已有/本轮创建账号信息，普通报告仅引用安全来源；没有凭据时提前说明并继续独立工作，不改密码绕过。

后台 worker 丢失时，不能凭 PID 缺失断定容器内命令已结束，保留 outcome-unknown。先查记录的进程、子进程和原容器/平台任务。实际只读查证结束后，用同一任务证据补 `readOnlyConfirmed=true`、`originalTaskEnded=true`，记录 verified 或明确 failed；仍活着的已知子进程会拒绝恢复。确认失败的本地任务用 Resume -RetryTask build|deploy|assets 重试；未知任务不自动重发。

部署失败或超时先查询原平台任务，再沿 Publish-CloudBase -Action Recover 或原 -Recover 验证原产物。不得为了重试覆盖未知部署的构建记录。日志与证据仅保存脱敏摘要，不粘贴完整 MCP 响应、Key、Cookie、设备码或会话 token。

旧调用 `Publish-CloudBase -Publish/-Recover` 保留；新分段动作是 Build/Deploy/Verify/Recover。修改后的脚本与模板由统一构建打入工具箱及独立技能包。约 15 分钟为常规首次接入的目标预算，真实平台/本人等待和排障计入总耗时，离线测试不证明实际部署或时长达标。

## 确定步骤的直接入口

先Measure。部署前执行 `node <技能>/scripts/observe-policy.mjs --project <B> --cli <登记tcb.ps1>`；它只查询精确环境和URL，保留旧策略.previous，不改平台配置、不关闭安全提示。预检缺策略会返回PLATFORM_POLICY_OBSERVATION_REQUIRED和可执行命令；过期证据需重新观测，不能改时间冒充新证据。

Start建立本轮后，对ready任务调用 `Invoke-CloudBaseTask.ps1 -ProjectDirectory <B> -TaskId <任务>`。resources只查回，不自动应用SQL；首次缺资源先按已审核迁移创建，再执行该任务。adapter仍是静态预检，不能代替真实probe。probe/browser加 `-SmokeScript <本项目已适配验证脚本>`；sessions输出在本轮profiles下，browser自动传隔离profile。脚本不从其他项目复制固定账号/控件；无登录共享项目保持当前权限合同。

独立任务可用工具托管的后台命令同时启动，保留各自父进程；同一资源写入串行。开始时间紧邻实际动作，external-executor事件记录真实工作区间，排队/排障另留证；任务窗口包含的真实等待不叫虚假时间。超时/结果未知查原任务，不自动重复提交。已有验证失败保留并仅重验受影响节点。

frontend/probe共享同一运行环境，Invoke-CloudBaseTask在Begin前取得项目级runtime-session.lock；等待单列事件，锁覆盖Start、HTTP、冒烟与Record。不要并发启动这两个运行环境任务，以免把另一个任务正在启动的API误判故障。资源/适配/会话准备仍可并行，跨项目不共用此锁。

build/assets worker也即时检查自己的运行环境；确认原机器停止时在worker父命令内沿原执行包Start恢复，再执行构建/校验并等待子命令结束。机器running但API不通时保留诊断，不重启工作负载。校验失败只重试assets，不重传网页。
# 统一执行入口（本地修订 20261025.2）

已登记 CLI 且项目接线就绪时，优先执行 Invoke-CloudBaseDeploy.ps1，具体参数见 ../references/controller-template.md。该入口保持唯一父进程并行调度；不要再由对话逐个 Begin/Record。默认公共脚本读取项目适配文件，旧文中脚本单独调用时也必须传 --adapter。原节点恢复和 MCP 路线继续沿用下文，禁止把 CLI 控制器套用于未授权通道。只有真实双独立会话通过才报告同步通过，人工模式明确待确认。

