---
name: ai-coding-cloudbase
description: 在当前目录准备或恢复 CloudBase 账号与授权；在已选择云端能力的作品中实现数据、权限、存储、函数、托管和受保护的 AI 后端。
---

# 当前项目的 CloudBase 能力

本技能为用户级，按当前项目绑定操作；保留用户指定环境、授权、镜像、业务与数据。准备模式读取 [账号与环境准备](references/account-preparation.md)，不创建业务或要求模型账号。

## 已有 Web 项目的部署快路径

目标是压缩整条 Trae 任务，不只缩短上传。第一条命令执行 `scripts/Invoke-CloudBaseDeploy.ps1 -ProjectDirectory <B> -Action BeginTask`；调用方给出了真实指令提交时间时加 -TaskStartedAt，不推算 Trae 的内部时间。此后只读根 AGENTS 要求的 project/services、工程入口与当前进度，以及当前部署计划和验证配置；先确认现有页面、数据适配和绑定，不默认通读原型、历史案例、所有官方子技能或执行器源码。

已有接线与验收适配器直接复用，只读 [统一执行模板](references/controller-template.md)，调用统一入口 Run。资源缺项、SDK 变更或新增功能时才按 [官方技能路由](references/official-routing.md) 读取对应子技能和 [云端实施](implementation/cloudbase.md)。若只有占位页，明确缺少的业务实现，不把部署自动扩成完整产品开发，也不以另写一个演示页代替原项目迁移。

使用工具管理的可轮询长任务，保持一个父进程到所有子任务结束。资源核验、适配检查、前端就绪、隔离会话准备按依赖并行；发布后产物校验和线上双会话并行。助手等待原命令，按需查询状态；不要逐个对话 Begin/Record、重复 Start、读脚本猜参数或重跑全链。当前项目已就绪的容器只查健康，源码适配改变后在原容器尽早做类型检查，再构建一次；同一资源写操作串行。

普通无登录数据同步可在计划设 localProbe=false，省掉重复本地浏览器写读；线上页面可用、持久化、敏感路径、双独立会话双向同步仍必须实测。登录、图片、后端等专门能力保留对应检查。SDK 初始化、Repository、迁移契约和浏览器适配按现有模板修改少量项目参数，不重写通用执行器，不自动添加账号、AI、Android、图片、云函数或实时推送。

resources 只读查当前表、RLS、策略和权限；FORCE RLS 只在项目契约明确要求时检查，JSON 表模板与检查器保持一致。不通过就给出精确缺项，沿已确认迁移预览并只补必要变更，不自动重放全部 SQL、不降低权限。执行器失败即时记录 failed，原始错误与全部尝试留存；修复后 `Resume -RetryTask <原失败节点>`，成功节点复用。未知云端结果先查原操作，不能当明确失败自动重试。

开始→准备/适配→部署及恢复→收尾使用同一个 task.json；Run 不重置整轮时钟，Resume 不重置起点。更新项目已有 Spec/进度的简短结果后，最后一条工具命令 CompleteTask，输出整轮 totalSeconds、阶段耗时、workflowMeasurement。部署 measurement.json 是子流程，不称为整条任务总耗时；失败重跑保留 attempts。15分钟是已有业务工程的整轮优化目标，不靠换起点、删必要验收或省略等待排障来达成。只给网址、同步结论和短表，不另写长报告。

## 其他场景按需读取

- 新接入和数据迁移：[云端实施](implementation/cloudbase.md)、[Web PG 范例](references/web-pg-example.md)。保留既有身份与数据归属，静态托管负责页面、数据库与存储负责共享数据。
- MCP 项目保留既有通道，CLI 控制器不代替当前会话 MCP；官方工具接入与版本适配见 [官方路由](references/official-routing.md)、references/management-operations.md。工具授权不等于应用权限通过。
- 登录和 Web 改造：[通用检查](references/web-verification.md)；先核真实返回结构、账号交付与所需权限。只使用当前项目的安全凭证来源，不输出密码或 Key。
- AI：implementation/ai-service-setup.md、model-settings.md、ai.md 和 ai-settings-access.md，仅在明确需要时读取；沿现有受保护后端配置，秘密不进入前端、Git、APK、镜像或日志，不自动换供应商或充值。
- 故障的进一步说明：implementation/parallel-workflow.md、efficient-execution.md。只在当前错误需要时读取对应段落，保留原资源、环境和镜像。

每次交付给出本轮真实完整 https 网址；独立会话、物理手机和本人产品试用分别记录，缺证据不报告通过。纯静态展示发布到 GitHub.io 时调用 ai-coding-github。
