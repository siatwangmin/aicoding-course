---
name: ai-coding-project
description: 在任意目录初始化作品，原样复制标准 app 并绑定已准备环境、容器构建运行；提供独立恢复、验证、升级和连接入口。
---

# 项目初始化

本技能与 GitHub、CloudBase、Android 技能均为用户级，各项目按当前任务调用。先读取已有 AGENTS、manifest、服务绑定、设计和进度。运行工具由 scripts/Course-Execution.ps1 解析已记录的公共执行包，不依赖全局 env。

新建调用 scripts/Initialize-Project.ps1 -ProjectDirectory <B>：只读规划与完整冲突检查 → 原样复制 assets/app 和最少根文件 → 绑定已准备环境 → 容器内构建运行 → 验证网页与热更新并交付网址。任何生成目标文件重名即终止，即使内容相同；无冲突材料原位保留，冲突时 B 零写入、不操作引擎。

模板身份及摘要在 assets/app-template.json；初始化不改包名、锁文件、入口或样式。项目身份、端口及运行绑定单独记录。宿主已验证的管理 Node 只做规划与文件复制，项目运行、依赖及 Web/APK 编译始终使用准备镜像。

宿主端口默认 5187；被其他程序占用时自动尝试 5188—5197。容器内部固定 5187，不改 app 配置或重新构建来切换宿主端口。核当前容器身份、实际映射和 HTTP 后，直接给使用者完整可点击网址及实际端口。SSH、镜像、依赖和挂载错误按原错误恢复。

工程已存在时 Initialize 报告已存在，不自动 Upgrade。复制中断用 scripts/Resume-Project.ps1；构建或运行失败保留工程，Resume 仅接续运行；scripts/Verify-Project.ps1 检查当前状态；scripts/Upgrade-Project.ps1 只在明确要求时升级受管规则，保留自定义冲突和稳定标识，明确需要公共脚本修复时加 -UpdateExecutionPackage 切到已校验的新执行包；scripts/Connect-Project.ps1 连接明确准备环境或服务。

返回 pending 后同一任务继续实际网页、热更新和 Trae 规则/技能加载检查，按 implementation/initialization-evidence.md 留证。未观察项分别报告，不把 HTTP 200 当作整体完成。

初始化不询问三项平台选择，不安装平台或案例技能。用户本轮已要求发布、同步、AI 或安卓时，在本地初始化后直接调用对应用户级技能，沿 implementation/capability-activation.md 登记必要项目绑定并继续完成需求。GitHub 源码与 Pages 目标独立；CloudBase 环境、Android appId、授权均按 B 保存，不能复用另一作品目标。Android 配置、AI 默认配置在首次实际需要时生成。

通用开发方法保存在 B/AGENTS.md、docs/engineering、Spec 和进度；后续按这些规则直接实现。knowstar 案例退出默认链；历史案例工程保留，只有明确要求案例时才使用 Install-ProjectCase.ps1。普通已有源码或静态 HTML 先按自身结构处理，不为发布强制生成 app。缺准备工具时回到 A 的 env 流程。
