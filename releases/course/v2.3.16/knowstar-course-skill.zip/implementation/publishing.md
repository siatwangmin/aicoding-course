# V2-PAGES：把静态 HTML 发布到 github.io

这是 V2 必做教学案例，位于接收设计文件之后、复查 CloudBase 之前。目标只有一个：把学员已确认的 HTML 页面发布到 GitHub Pages，得到能实际打开的 github.io 链接。它不依赖腾讯云环境，不实现登录、注册、数据库、云端保存、跨设备同步或 AI 调用；后续 V2-04—V2-06 再完成 CloudBase 能力。不得把 CloudBase 授权或数据读写作为本项前置条件。

学员只发送短提示、处理必要的本人 GitHub 登录授权、点击结果链接看页面。文件整理、Git 操作、Pages 设置、发布与检查由助手连续完成，不要求学员理解分支、命令、Actions 或构建配置。课前 ai-coding-github 仍只准备账号；进入本项自动调用该技能的 references/pages-cli.md，以 Git/GitHub CLI 完成仓库、Pages 设置、推送和部署查询，development 提供静态副本与产物验收。BrowserUse 只用于必要本人授权及最终页面体验，不点击仓库设置，也不更改学员提示词。

## 页面与发布文件

1. 从本轮已确认的设计记录定位完整 Canvas HTML，复制为独立发布目录的 `index.html`，保留原文件、视觉和交互。默认使用现成 HTML，不构建 React 工程、不重新开发业务、不为上线接入服务。模拟效果保留模拟标识，不把原型当作真实业务实现。
2. 仅整理该页面所需的公开 CSS、JS、图片、字体等静态资源，使用适合仓库子路径的相对地址；外部资源要实际可访问。缺资源时补齐现有资源，不重画页面。发布页面不能实际调用账号、CloudBase 或模型服务；若 HTML 存在真实服务接线，只在发布副本移除接线并保留原设计与工程。
3. 在本作品独立暂存目录（例如 `.course-publish/github-pages/`）整理文件，先核对已有内容，不覆盖无关文件。输出只含 `index.html`、必要公开静态资源与空 `.nojekyll`。检查实际提交清单及 HTML/JS 中的秘密；不能上传源码工程、PRD、个人题目、账号准备记录、`.env*`、`.ai-setup`、令牌、密钥、APK、node_modules 或课程软件包。
4. 复用现有静态预览工具打开发布副本，检查页面、关键交互及资源请求；不新装工具链。本地正常只是准备证据，仍须完成公网验收。

## GitHub 与 Pages

- 从课前 `.github-setup/github-setup.md`、当前 GitHub 会话和项目进度复用本人账号。登录授权由本人处理，不索取个人密码或令牌，不在聊天保存凭据。账号归属不明时先确认，不推送到课程资料仓库或其他人的仓库。
- 复用项目已记录的专用静态仓库；首次发布可按技术标识生成 `<project-slug>-pages`，说明实际目标，不要求学员填写技术名称。免费个人路线使用本人公开仓库。已有仓库内容冲突时不覆盖、清空或强推，不修改现有工程 remote；发布与作品的关联写入进度，不重新初始化作品。
- 仅提交并推送检查过的静态文件。按 [GitHub 官方发布源说明](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)，通过 `gh api` 配置与 **Deploy from a branch → 实际发布分支 → /(root)** 对应的 `build_type=legacy`、`source.branch`、`source.path=/`，根部有 `index.html` 与 `.nojekyll`。无需上传源码、运行 npm 或新增 Actions 构建流程。
- 已有正确的静态 Actions 路线可以复用，不同时配置两套源。[静态工作流样例](../templates/pages.yml)只上传静态仓库文件，没有 Node/Vite 构建、CloudBase 变量或账号逻辑，不能套用历史的整工程构建流程。
- push 成功不等于 Pages 成功。读取实际部署状态和返回 URL，核对仓库归属、分支和提交；项目站一般为 `https://<本人用户名>.github.io/<仓库名>/`，不能把 github.com 仓库地址当作品网址。按 [GitHub 说明](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site)记录发布等待，不重复推相同文件或循环建仓库。

## 完成证据

1. 推送提交与 Pages 实际发布成功分别有证据。
2. 浏览器打开实际 github.io 地址，看到本轮页面；检查样式、图片、脚本和一项关键交互，没有资源 404、登录跳转或连接云服务才能显示的阻塞。文件存在、HTTP 200、部署成功字样或本地预览不能代替页面验收。
3. 带学员点击同一链接确认页面；本人未试时记“助手已验证，学员待试”，不能代为勾选。
4. 在实际项目 `docs/progress/V2.md` 记录 HTML 来源、发布文件清单、仓库/分支/提交、部署状态、URL、页面与资源检查、本人反馈及等待时间，不保存秘密或个人题目。与后续 CloudBase URL、验收结果分别记录。

本项只交付静态展示，不要求测试数据保存、账号或同步。失败按页面资源、仓库、授权、部署、网络定位具体阶段，保留结果。可继续独立可做的 CloudBase 工作，但静态案例仍记未完成，CloudBase 通过不能自动使整轮 V2 全部通过。

后续 CloudBase 正式发布、演示账号和双会话数据验收按 [v2.md](v2.md) 与 [course-demo-auth.md](course-demo-auth.md)。github.io 保留为静态展示，不自动改成另一套云服务入口。
