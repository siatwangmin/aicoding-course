﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,
 [ValidateSet('Plan','Start','Status','Watch','Resume','Record','Run')][string]$Action='Plan',
 [string]$PlanFile,[string]$CliPath,[switch]$AllowPublish,[switch]$NewRun,
 [string]$EvidenceFile,[string]$RetryTask,[string]$RunId,[string]$TaskId,[string]$Attempt,
 [ValidateRange(1,30)][int]$WaitSeconds=20)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $executionRoot 'scripts/Course-Context.ps1')
. (Join-Path $PSScriptRoot 'Course-CloudBaseWorkflow.ps1')
$context=Get-CBProject $ProjectDirectory
$folder=Join-Path $context.Root '.ai-coding/cb'
$statePath=Join-Path $folder 'current.json'
Assert-CoursePlainPath $folder
function Read-CurrentWorkflow{
 if(-not(Test-Path -LiteralPath $statePath)){return $null}
 $state=Read-CBState $statePath
 if($state.runId -notmatch '^[a-f0-9]{32}$'){throw 'INVALID_WORKFLOW_RUN_ID'}
 $plan=New-CBWorkflowPlan $context $state.planFile $state.cliPath
 if(($state.binding -cne $plan.binding -or $state.projectDirectory -ne $context.Root) -and -not ($Action -eq 'Start' -and $NewRun)){throw 'WORKFLOW_BINDING_CHANGED_CREATE_NEW_RUN'}
 return Get-CBWorkflowStatus $context $state (Join-Path $folder $state.runId.Substring(0,12))
}
function Save-CurrentWorkflow($State){
 Write-CourseJson (Join-Path $folder ($State.runId.Substring(0,12)+'/state.json')) $State
 Write-CourseJson $statePath $State
}
function Get-ResultPath($State,$Task){return Join-Path $folder ($State.runId.Substring(0,12)+'/'+$Task.id+'/'+$Task.attempt.Substring(0,12))}
function Write-TaskHeartbeat($State,$Task,$Child){
 $value=@{runId=$State.runId;taskId=$Task.id;attempt=$Task.attempt;workerId=$PID;workerStartedAt=(Get-Process -Id $PID).StartTime.ToUniversalTime().ToString('o');heartbeatAt=[datetimeoffset]::UtcNow.ToString('o');childId=$Child.Id;childStartedAt=$Child.StartTime.ToUniversalTime().ToString('o')}
 Write-CourseJson (Join-Path (Get-ResultPath $State $Task) 'heartbeat.json') $value
}
if($Action -eq 'Plan'){
 if(-not $PlanFile){$PlanFile=Join-Path $context.Root '.ai-coding/cloudbase-plan.json'}
 $plan=New-CBWorkflowPlan $context $PlanFile $CliPath
 foreach($task in $plan.tasks){try{$stamp=Get-CBTaskStamp $context $plan $task}catch{$stamp=$null};$task|Add-Member NoteProperty expectedInputStamp $stamp -Force}
 $plan|Add-Member NoteProperty ready @((Get-CBReadyTasks $plan)|ForEach-Object {$_.id})
 $plan|ConvertTo-Json -Depth 14;return
}
if($Action -in @('Status','Watch')){
 $state=Read-CurrentWorkflow
 if(-not $state){[pscustomobject]@{status='not-started';actionRequired=$true;nextAction='Plan the current scope, then Start.'}|ConvertTo-Json;return}
 if($Action -eq 'Watch'){
  $signature=($state.tasks|Select-Object id,status|ConvertTo-Json -Compress)
  $watch=[Diagnostics.Stopwatch]::StartNew()
  while(-not $state.actionRequired -and $watch.Elapsed.TotalSeconds -lt $WaitSeconds){
   Start-Sleep -Milliseconds 1000;$state=Read-CurrentWorkflow
   if(($state.tasks|Select-Object id,status|ConvertTo-Json -Compress) -ne $signature){break}
  }
 }
 $state|ConvertTo-Json -Depth 14;return
}
if($Action -eq 'Run'){
 if($RunId -notmatch '^[a-f0-9]{32}$' -or $Attempt -notmatch '^[a-f0-9]{32}$' -or $TaskId -notin @('build','deploy','assets')){throw 'INVALID_WORKFLOW_WORKER_BINDING'}
 $saved=Read-CBState $statePath
 $fresh=New-CBWorkflowPlan $context $saved.planFile $saved.cliPath
 if($fresh.binding -ne $saved.binding){throw 'WORKFLOW_WORKER_BINDING_CHANGED'}
 $task=@($saved.tasks|Where-Object {$_.id -eq $TaskId -and $_.attempt -eq $Attempt})
 if($saved.runId -ne $RunId -or $task.Count -ne 1 -or $task[0].executor -ne 'local'){throw 'WORKFLOW_WORKER_BINDING_CHANGED'}
 $task=$task[0];$attemptFolder=Get-ResultPath $saved $task
 $lease=Enter-CBFileLock (Join-Path $attemptFolder 'worker.lock')
 try{
  if(Test-Path -LiteralPath (Join-Path $attemptFolder 'result.json')){return}
  if((Get-CBTaskStamp $context $saved $task) -ne $task.inputStamp){throw 'WORKFLOW_WORKER_INPUT_CHANGED'}
  if($TaskId -eq 'deploy' -and -not $saved.allowPublish){throw 'DEPLOYMENT_AUTHORIZATION_REQUIRED'}
  $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $PSScriptRoot 'Publish-CloudBase.ps1'),'-ProjectDirectory',$context.Root,'-Action',$(switch($TaskId){build{'Build'}deploy{'Deploy'}assets{'Verify'}}))
  if($saved.cliPath){$arguments+=@('-CliPath',$saved.cliPath)}
  $quoted=@($arguments|ForEach-Object {ConvertTo-CBArgument ([string]$_)})
  $powershell=Get-CBPowerShell
  $started=[datetimeoffset]::UtcNow;$exitCode=$null;$outcome='outcome-unknown';$errorCode=$null
  try{
   $child=Start-Process -FilePath $powershell -ArgumentList ($quoted -join ' ') -WorkingDirectory $context.Root -WindowStyle Hidden -RedirectStandardOutput (Join-Path $attemptFolder 'operation.log') -RedirectStandardError (Join-Path $attemptFolder 'operation.error.log') -PassThru
   $null=$child.Handle;Write-TaskHeartbeat $saved $task $child
   while(-not $child.WaitForExit(5000)){Write-TaskHeartbeat $saved $task $child}
   $child.Refresh();$exitCode=$child.ExitCode
   if($exitCode -eq 0){$outcome='verified'}else{
    $publication=if(Test-Path (Join-Path $context.Root 'docs/progress/cloudbase-publish.json')){Read-CourseJson (Join-Path $context.Root 'docs/progress/cloudbase-publish.json')}else{$null}
    $operationError=Get-Content -LiteralPath (Join-Path $attemptFolder 'operation.error.log') -Raw -ErrorAction SilentlyContinue
    $outcome=if(($TaskId -eq 'deploy' -and $publication.status -eq 'deployment-unknown') -or $operationError -match 'BUILD_OUTCOME_UNKNOWN_QUERY_CONTAINER'){'outcome-unknown'}else{'failed'}
    $errorCode='OPERATION_EXIT_'+$exitCode
   }
  }catch{$errorCode='WORKER_PROCESS_ERROR'}
  finally{
   $finished=[datetimeoffset]::UtcNow
   Write-CourseJson (Join-Path $attemptFolder 'result.json') @{runId=$RunId;taskId=$TaskId;attempt=$Attempt;inputStamp=$task.inputStamp;status=$outcome;exitCode=$exitCode;error=$errorCode;startedAt=$started.ToString('o');finishedAt=$finished.ToString('o');durationSeconds=($finished-$started).TotalSeconds}
  }
 }finally{$lease.Dispose()}
 return
}
$lock=Enter-CBFileLock (Join-Path $folder 'control.lock')
try{
 $state=Read-CurrentWorkflow
 if($Action -eq 'Start'){
  if($state -and -not $NewRun){$Action='Resume'}else{
   if($state -and @($state.tasks|Where-Object status -in @('running','outcome-unknown')).Count){throw 'FINISH_OR_RESOLVE_ORIGINAL_TASKS_BEFORE_NEW_RUN'}
   if(-not $PlanFile){$PlanFile=Join-Path $context.Root '.ai-coding/cloudbase-plan.json'}
   $state=New-CBWorkflowPlan $context $PlanFile $CliPath
   if(-not $context.Url){throw 'QUERY_AND_BIND_ACTUAL_HOSTING_URL_BEFORE_START'}
   $state|Add-Member NoteProperty runId ([guid]::NewGuid().ToString('N'))
   $state|Add-Member NoteProperty startedAt ([datetimeoffset]::UtcNow.ToString('o'))
   $state|Add-Member NoteProperty allowPublish ([bool]$AllowPublish)
  }
 }
 if(-not $state){throw 'WORKFLOW_NOT_STARTED'}
 if($AllowPublish){$state.allowPublish=$true}
 if($Action -eq 'Record'){
  if(-not $EvidenceFile){throw 'ACTUAL_TASK_EVIDENCE_REQUIRED'}
  Assert-CoursePlainPath $EvidenceFile
  if((Get-Item -LiteralPath $EvidenceFile).Length -gt 524288){throw 'EVIDENCE_TOO_LARGE'}
  $e=Read-CourseJson $EvidenceFile
  if($e.runId -ne $state.runId -or $e.envId -ne $context.EnvId -or $e.status -notin @('running','verified','failed','outcome-unknown') -or $e.kind -notin @('tool','command','browser','learner') -or -not $e.reference -or $e.reference -ne (Protect-CourseOutput $e.reference)){throw 'TASK_EVIDENCE_IDENTITY_OR_SOURCE_INVALID'}
  $task=@($state.tasks|Where-Object id -eq $e.taskId)
  if($task.Count -ne 1){throw 'UNKNOWN_WORKFLOW_TASK'};$task=$task[0]
  $recovering=$task.executor -eq 'local' -and $task.status -eq 'outcome-unknown'
  $stamp=if($recovering){$task.inputStamp}else{Get-CBTaskStamp $context $state $task}
  if($e.inputStamp -ne $stamp){throw 'TASK_EVIDENCE_INPUT_CHANGED'}
  $age=([datetimeoffset]::UtcNow-(ConvertTo-CBTime $e.observedAt)).TotalSeconds
  if($age -lt -120 -or $age -gt 86400){throw 'TASK_EVIDENCE_TIME_INVALID'}
  $dependencies=@($task.dependsOn|Where-Object {$id=$_;@($state.tasks|Where-Object {$_.id -eq $id -and $_.status -eq 'verified'}).Count -ne 1})
  if($dependencies.Count -and -not $recovering){throw 'TASK_DEPENDENCIES_PENDING'}
  if($task.executor -eq 'local' -and -not ($task.status -eq 'outcome-unknown' -and $e.readOnlyConfirmed -eq $true -and $e.originalTaskEnded -eq $true)){throw 'LOCAL_TASK_REQUIRES_WORKER_RESULT_OR_CONFIRMED_RECOVERY'}
  if($task.executor -eq 'local'){
   $heartbeat=Join-Path (Get-ResultPath $state $task) 'heartbeat.json'
   if(Test-Path -LiteralPath $heartbeat){$beat=Read-CBState $heartbeat;if(Test-CBProcess $beat.childId $beat.childStartedAt){throw 'ORIGINAL_OPERATION_STILL_RUNNING'}}
  }
  if($task.id -eq 'learner' -and $e.kind -ne 'learner'){throw 'LEARNER_FEEDBACK_REQUIRED'}
  foreach($name in $e.checks.PSObject.Properties.Name){if($name -notin $task.checks -or $e.checks.$name -isnot [bool]){throw 'TASK_CHECK_FIELDS_INVALID'}}
  if($e.status -eq 'verified'){
   if($task.id -eq 'adapter'){foreach($relative in $state.options.adapterInputs){if(-not(Test-Path -LiteralPath (Join-Path $context.Source $relative) -PathType Leaf)){throw 'ADAPTER_SOURCE_NOT_READY'}}}
   foreach($name in $task.checks){if($e.checks.$name -ne $true){throw ('TASK_CHECK_PENDING:'+ $name)}}
   if($task.id -in @('deploy','browser','assets','learner')){
    $build=Read-CourseJson (Join-Path $context.Root '.ai-coding/cloudbase-build.json')
    if($e.buildId -ne $build.buildId){throw 'TASK_BUILD_ID_CHANGED'}
   }
   if($recovering -and $task.id -eq 'build'){
    $original=Read-CourseJson (Join-Path $context.Root '.ai-coding/cloudbase-build.json')
    $null=Assert-CBArtifact $context $original -AllowLegacy
    if($e.buildId -ne $original.buildId){throw 'TASK_BUILD_ID_CHANGED'}
   }
  }
  if($task.id -eq 'deploy' -and -not $state.allowPublish){throw 'DEPLOYMENT_AUTHORIZATION_REQUIRED'}
  if($task.id -eq 'deploy' -and $e.status -eq 'verified'){
   $build=Read-CourseJson (Join-Path $context.Root '.ai-coding/cloudbase-build.json')
   $null=Assert-CBArtifact $context $build -AllowLegacy:$recovering
   $build.status='deployed';$build.url=$context.Url
   Write-CourseJson (Join-Path $context.Root 'docs/progress/cloudbase-publish.json') $build
  }
  if($task.id -eq 'deploy' -and $recovering -and $e.status -eq 'failed'){
   $original=Read-CourseJson (Join-Path $context.Root 'docs/progress/cloudbase-publish.json')
   if($original -and $original.envId -eq $context.EnvId){$original.status='confirmed-failed';Write-CourseJson (Join-Path $context.Root 'docs/progress/cloudbase-publish.json') $original}
  }
  $task.inputStamp=$stamp;$task.status=$e.status
  if($e.status -eq 'running' -and -not $task.startedAt){$task.startedAt=[datetimeoffset]::UtcNow.ToString('o')}
  if($e.status -in @('verified','failed')){$task.finishedAt=[datetimeoffset]::UtcNow.ToString('o')}
  if($e.platformTaskId){if([string]$e.platformTaskId -notmatch '^[a-zA-Z0-9_.:/-]{1,180}$'){throw 'PLATFORM_TASK_ID_INVALID'};$task.platformTaskId=$e.platformTaskId}
  $proof=Join-Path $folder ($state.runId.Substring(0,12)+'/evidence/'+$task.id+'-'+[guid]::NewGuid().ToString('N').Substring(0,12)+'.json')
  # Store only the evidence allowlist, never arbitrary MCP responses or credentials.
  Write-CourseJson $proof @{runId=$e.runId;taskId=$task.id;envId=$e.envId;inputStamp=$stamp;status=$e.status;kind=$e.kind;reference=$e.reference;observedAt=$e.observedAt;checks=$e.checks;buildId=$e.buildId;platformTaskId=$task.platformTaskId}
  $task.evidence=$proof
  $task.evidenceSha256=(Get-FileHash -LiteralPath $proof).Hash.ToLowerInvariant()
 }
 if($RetryTask){
  $task=@($state.tasks|Where-Object id -eq $RetryTask)
  if($task.Count -ne 1 -or $task[0].status -ne 'failed' -or $task[0].executor -ne 'local'){throw 'ONLY_CONFIRMED_FAILED_LOCAL_TASK_CAN_RETRY'}
  $task[0].status='pending'
 }
 $state=Get-CBWorkflowStatus $context $state (Join-Path $folder $state.runId.Substring(0,12))
 Save-CurrentWorkflow $state
 foreach($task in @(Get-CBReadyTasks $state|Where-Object executor -eq 'local')){
  if($task.id -eq 'deploy' -and -not $state.allowPublish){continue}
  $task.inputStamp=Get-CBTaskStamp $context $state $task;$task.attempt=[guid]::NewGuid().ToString('N');$task.status='running';$task.startedAt=[datetimeoffset]::UtcNow.ToString('o');$task.error=$null
  $attemptFolder=Get-ResultPath $state $task;[void](New-Item -ItemType Directory -Path $attemptFolder -Force)
  Save-CurrentWorkflow $state
  $workerArguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',$PSCommandPath,'-ProjectDirectory',$context.Root,'-Action','Run','-RunId',$state.runId,'-TaskId',$task.id,'-Attempt',$task.attempt)
  $quoted=@($workerArguments|ForEach-Object {ConvertTo-CBArgument ([string]$_)})
  try{
   $process=Start-Process -FilePath (Get-CBPowerShell) -ArgumentList ($quoted -join ' ') -WorkingDirectory $context.Root -WindowStyle Hidden -RedirectStandardOutput (Join-Path $attemptFolder 'worker.log') -RedirectStandardError (Join-Path $attemptFolder 'worker.error.log') -PassThru
   $task.processId=$process.Id;$task.processStartedAt=$process.StartTime.ToUniversalTime().ToString('o')
  }catch{$task.status='failed';$task.error='WORKER_LAUNCH_FAILED'}
  Save-CurrentWorkflow $state
 }
 $state=Get-CBWorkflowStatus $context $state (Join-Path $folder $state.runId.Substring(0,12))
 Save-CurrentWorkflow $state
 $state|ConvertTo-Json -Depth 14
}finally{$lock.Dispose()}
