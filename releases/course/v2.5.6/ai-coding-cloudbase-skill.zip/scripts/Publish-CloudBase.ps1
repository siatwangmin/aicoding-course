﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,[string]$CliPath,[switch]$Publish,[switch]$Recover,
      [ValidateSet('Legacy','Build','Deploy','Verify','Recover')][string]$Action='Legacy',
      [ValidateRange(1,8)][int]$Concurrency=4,[switch]$ForceBuild)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $executionRoot 'scripts/Course-Context.ps1')
. (Join-Path $executionRoot 'scripts/Course-Native.ps1')
. (Join-Path $PSScriptRoot 'Course-CloudBaseWorkflow.ps1')
$projectContext=Get-CBProject $ProjectDirectory
$root=$projectContext.Root
$recordPath=Join-Path $root 'docs/progress/cloudbase-publish.json'
$buildPath=Join-Path $root '.ai-coding/cloudbase-build.json'
$scripts=$PSScriptRoot
if($Recover){$Action='Recover'}
function Get-CBPublishRuntime([switch]$Start){
    . (Join-Path $executionRoot 'scripts/Course-Runtime.ps1')
    return Get-CourseProjectRuntime $root -Start:$Start
}
function Invoke-CBPublicAssets($Runtime,[string]$Operation){
    $output=$projectContext.Output
    $a=$Runtime.Prefix+@('run','--rm','--mount',("type=bind,source=$output,target=/public"),'--mount',("type=bind,source=$scripts,target=/course,readonly"),'--entrypoint','node',$Runtime.Project.image,'/course/publish-assets.mjs',$Operation)
    if($Operation -eq 'manifest'){$a+=@('--directory','/public')}else{$a+=@('--url',$projectContext.Url,'--manifest','/public/course-publish.json','--concurrency',[string]$Concurrency)}
    $r=Invoke-SetupNative $Runtime.Cli $a 180 $root
    if($r.ExitCode -ne 0){throw ('PUBLIC_ASSET_CHECK_FAILED:'+ $Operation)}
    return $(if($r.Stdout){$r.Stdout}else{$r.Output})|ConvertFrom-Json
}
function Assert-CBPublicConfiguration{
    $values=@{}
    foreach($name in @('.env','.env.local','.env.production','.env.production.local')){
        $path=Join-Path $projectContext.Source $name
        if(Test-Path -LiteralPath $path){Assert-CoursePlainPath $path;foreach($line in [IO.File]::ReadAllLines($path)){if($line -match '^\s*(VITE_DATA_MODE|VITE_CLOUDBASE_ENV_ID)\s*=\s*(.*?)\s*$'){$values[$Matches[1]]=$Matches[2].Trim('"',"'")}}}
    }
    if($values.VITE_DATA_MODE -ne 'cloudbase' -or $values.VITE_CLOUDBASE_ENV_ID -ne $projectContext.EnvId){throw 'PRODUCTION_CLOUDBASE_BINDING_MISMATCH'}
}
function Invoke-CBBuild{
    if(Test-Path -LiteralPath $recordPath){if((Read-CourseJson $recordPath).status -eq 'deployment-unknown'){throw 'QUERY_PRIOR_DEPLOYMENT_BEFORE_BUILD_OR_REDEPLOY'}}
    Assert-CBPublicConfiguration
    if(-not $ForceBuild -and (Test-Path -LiteralPath $buildPath)){
        $cached=Read-CourseJson $buildPath
        try{$null=Assert-CBArtifact $projectContext $cached;return $cached}catch{if($_.Exception.Message -notmatch '^CLOUDBASE_BUILD_'){throw}}
    }
    $runtime=Get-CBPublishRuntime -Start
    $before=Get-CBBuildFingerprint $projectContext
    $started=[datetimeoffset]::UtcNow
    $r=Invoke-SetupNative $runtime.Cli ($runtime.Prefix+@('compose','exec','-T','app','npm','run','build')) 180 $root
    if($r.TimedOut){throw 'BUILD_OUTCOME_UNKNOWN_QUERY_CONTAINER'}
    if($r.ExitCode -ne 0){throw 'CONTAINER_WEB_BUILD_FAILED'}
    if((Get-CBBuildFingerprint $projectContext) -cne $before){throw 'CLOUDBASE_BUILD_INPUT_CHANGED_DURING_BUILD'}
    $manifest=Invoke-CBPublicAssets $runtime 'manifest'
    $manifestSha256=(Get-FileHash -LiteralPath (Join-Path $projectContext.Output 'course-publish.json')).Hash.ToLowerInvariant()
    $record=@{schemaVersion=3;status='prepared';envId=$projectContext.EnvId;url=$projectContext.Url;buildId=$manifest.buildId;image=$projectContext.Project.image;inputFingerprint=$before;preparedAt=[datetimeoffset]::UtcNow.ToString('o');startedAt=$started.ToString('o');durationSeconds=([datetimeoffset]::UtcNow-$started).TotalSeconds;applicationData='pending';learnerTried='pending'}
    $record.manifestSha256=$manifestSha256
    $null=Assert-CBArtifact $projectContext ([pscustomobject]$record)
    Write-CourseJson $buildPath $record
    Write-CourseJson $recordPath $record
    return [pscustomobject]$record
}
function Invoke-CBDeploy{
    if(-not $projectContext.Url){throw 'ACTUAL_HTTPS_HOSTING_URL_REQUIRED'}
    $prior=if(Test-Path -LiteralPath $recordPath){Read-CourseJson $recordPath}else{$null}
    if($prior.status -eq 'deployment-unknown'){throw 'QUERY_PRIOR_DEPLOYMENT_BEFORE_REDEPLOY'}
    $record=Read-CourseJson $buildPath
    $null=Assert-CBArtifact $projectContext $record
    if(-not $CliPath -or -not(Test-Path -LiteralPath $CliPath -PathType Leaf)){throw 'RECORDED_OFFICIAL_CLI_REQUIRED_OR_USE_MCP_ROUTE'}
    Assert-CoursePlainPath $CliPath
    $prefix=@()
    if([IO.Path]::GetExtension($CliPath) -eq '.ps1'){$exe=Join-Path $env:SystemRoot 'System32/WindowsPowerShell/v1.0/powershell.exe';$prefix=@('-NoProfile','-File',$CliPath)}
    elseif([IO.Path]::GetExtension($CliPath) -eq '.exe'){$exe=$CliPath}else{throw 'OFFICIAL_EXE_OR_POWERSHELL_ENTRY_REQUIRED'}
    foreach($argsToCheck in @(@('--version'),@('hosting','deploy','--help'),@('hosting','list','--env-id',$projectContext.EnvId,'--json'))){
        $r=Invoke-SetupNative $exe ($prefix+$argsToCheck) 60 $root
        if($r.ExitCode -ne 0){throw 'OFFICIAL_CLI_HELP_OR_TARGET_ACCESS_FAILED'}
    }
    # The build stayed immutable while help and authorization checks ran.
    $null=Assert-CBArtifact $projectContext $record
    $record.url=$projectContext.Url;$record.status='deployment-unknown'
    Write-CourseJson $recordPath $record
    $r=Invoke-SetupNative $exe ($prefix+@('hosting','deploy',$projectContext.Output,'--env-id',$projectContext.EnvId,'--json')) 600 $root
    if($r.ExitCode -ne 0){throw 'DEPLOYMENT_OUTCOME_UNKNOWN_QUERY_ORIGINAL_TASK'}
    $null=Assert-CBArtifact $projectContext $record
    $record.status='deployed';$record|Add-Member NoteProperty deployedAt ([datetimeoffset]::UtcNow.ToString('o')) -Force
    Write-CourseJson $recordPath $record
    return $record
}
function Invoke-CBVerify([switch]$Recovery){
    if(-not $projectContext.Url){throw 'ACTUAL_HTTPS_HOSTING_URL_REQUIRED'}
    $record=Read-CourseJson $recordPath
    if(-not $record -or $record.envId -ne $projectContext.EnvId -or $record.url -ne $projectContext.Url){throw 'RECOVERY_TARGET_DIFFERS'}
    $null=Assert-CBArtifact $projectContext $record -AllowLegacy:$Recovery
    $runtime=Get-CBPublishRuntime
    $verified=Invoke-CBPublicAssets $runtime 'verify'
    $record.status='assets-verified';$record|Add-Member NoteProperty checkedAt $verified.checkedAt -Force
    Write-CourseJson $recordPath $record
    return $record
}
$lock=Enter-CBFileLock (Join-Path $root '.ai-coding/cloudbase-artifact.lock')
$targetLock=$null
try{
    if($Action -eq 'Deploy' -or ($Action -eq 'Legacy' -and $Publish)){
        $key=Get-CBHash ($projectContext.EnvId+'|'+$projectContext.Url)
        $targetLock=Enter-CBFileLock (Join-Path (Get-CourseUserRoot) ('locks/cloudbase-hosting-'+$key+'.lock'))
    }
    switch($Action){
        Build {$result=Invoke-CBBuild}
        Deploy {$result=Invoke-CBDeploy}
        Verify {$result=Invoke-CBVerify}
        Recover {$result=Invoke-CBVerify -Recovery}
        Legacy {
            $result=Invoke-CBBuild
            if($Publish){$null=Invoke-CBDeploy;$result=Invoke-CBVerify}
        }
    }
    $result|ConvertTo-Json -Depth 8
}finally{if($targetLock){$targetLock.Dispose()};$lock.Dispose()}
