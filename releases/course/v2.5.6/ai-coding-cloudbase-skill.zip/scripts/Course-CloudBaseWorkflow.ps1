﻿#Requires -Version 5.1
# Deterministic project facts. Import after the recorded Course-Context library.
function Get-CBHash([string]$Text){
    $sha=[Security.Cryptography.SHA256]::Create()
    try{return ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Text)))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
}
function Get-CBProject([string]$ProjectDirectory){
    $root=(Resolve-Path -LiteralPath $ProjectDirectory -ErrorAction Stop).Path
    Assert-CoursePlainPath $root
    $project=Read-CourseJson (Join-Path $root '.ai-coding/project.json')
    $services=Read-CourseJson (Join-Path $root '.ai-coding/services.json')
    $source=[IO.Path]::GetFullPath((Join-Path $root $project.sourceDirectory))
    if(-not $project.sourceDirectory -or -not $source.StartsWith($root.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'CLOUDBASE_SOURCE_OUTSIDE_PROJECT'}
    Assert-CoursePlainPath $source
    if(-not(Test-Path -LiteralPath $source -PathType Container)){throw 'CLOUDBASE_SOURCE_REQUIRED'}
    $envId=$services.cloudbase.envId
    if($envId -notmatch '^[a-zA-Z0-9-]+$' -or -not $project.image){throw 'CONFIRMED_CLOUDBASE_PROJECT_BINDING_REQUIRED'}
    $url=[string]$services.cloudbase.hostingUrl
    if($url){$uri=$null;if(-not [uri]::TryCreate($url,[UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -ne 'https' -or $uri.UserInfo){throw 'ACTUAL_HTTPS_HOSTING_URL_REQUIRED'}}
    return [pscustomobject]@{Root=$root;Source=$source;Project=$project;EnvId=$envId;Url=$url;Output=(Join-Path $source 'dist')}
}
function Get-CBSourceFiles([string]$Root){
    Assert-CoursePlainPath $Root
    foreach($entry in Get-ChildItem -LiteralPath $Root -Force){
        if($entry.Name -in @('node_modules','dist','.git','.local','coverage','android','ios')){continue}
        Assert-CoursePlainPath $entry.FullName
        if($entry.PSIsContainer){Get-CBSourceFiles $entry.FullName}else{$entry.FullName}
    }
}
function Get-CBBuildFingerprint($Context){
    $lines=New-Object 'Collections.Generic.List[string]'
    foreach($path in @(Get-CBSourceFiles $Context.Source|Sort-Object)){
        $relative=$path.Substring($Context.Source.Length).Replace('\','/')
        $lines.Add($relative+':'+(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant())
    }
    # These project facts affect the build; ports and progress do not.
    $lines.Add('image:'+ $Context.Project.image)
    $toolchain=if($null -eq $Context.Project.toolchain){'null'}else{$Context.Project.toolchain|ConvertTo-Json -Depth 10 -Compress}
    $lines.Add('toolchain:'+$toolchain)
    $lines.Add('environment:'+ $Context.EnvId)
    return Get-CBHash ($lines -join "`n")
}
function Get-CBAdapterFingerprint($Context,$Paths){
    $lines=@('environment:'+$Context.EnvId)
    foreach($relative in @($Paths|Where-Object {$_})+@('package.json','package-lock.json','.env','.env.local','.env.production','.env.production.local')){
        if(-not $relative -or [IO.Path]::IsPathRooted($relative)){throw 'RELATIVE_ADAPTER_INPUT_REQUIRED'}
        $path=[IO.Path]::GetFullPath((Join-Path $Context.Source $relative))
        if(-not $path.StartsWith($Context.Source.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'ADAPTER_INPUT_OUTSIDE_SOURCE'}
        Assert-CoursePlainPath $path
        $hash=if(Test-Path -LiteralPath $path -PathType Leaf){(Get-FileHash -LiteralPath $path).Hash}else{'missing'}
        $lines+=($relative+':'+$hash)
    }
    return Get-CBHash ($lines -join "`n")
}
function Assert-CBArtifact($Context,$Record,[switch]$AllowLegacy){
    if(-not $Record -or $Record.envId -ne $Context.EnvId -or $Record.image -ne $Context.Project.image -or (-not $AllowLegacy -and $Record.inputFingerprint -ne (Get-CBBuildFingerprint $Context))){throw 'CLOUDBASE_BUILD_INPUT_CHANGED'}
    Assert-CoursePlainPath $Context.Output
    $manifestPath=Join-Path $Context.Output 'course-publish.json'
    Assert-CoursePlainPath $manifestPath
    if($Record.schemaVersion -ge 3 -and (-not $Record.manifestSha256 -or (Get-FileHash -LiteralPath $manifestPath).Hash.ToLowerInvariant() -cne $Record.manifestSha256)){throw 'CLOUDBASE_BUILD_MANIFEST_CHANGED'}
    $manifest=Read-CourseJson $manifestPath
    if(-not $manifest -or $manifest.buildId -ne $Record.buildId -or -not $manifest.files.'index.html'){throw 'CLOUDBASE_BUILD_MANIFEST_CHANGED'}
    $actual=@(Get-ChildItem -LiteralPath $Context.Output -File -Recurse -Force|Where-Object Name -ne 'course-publish.json')
    if($actual.Count -ne @($manifest.files.PSObject.Properties).Count){throw 'CLOUDBASE_BUILD_FILES_CHANGED'}
    foreach($item in $manifest.files.PSObject.Properties){
        $path=[IO.Path]::GetFullPath((Join-Path $Context.Output $item.Name))
        if(-not $path.StartsWith($Context.Output.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'CLOUDBASE_BUILD_PATH_INVALID'}
        Assert-CoursePlainPath $path
        if(-not(Test-Path -LiteralPath $path -PathType Leaf) -or (Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant() -cne $item.Value){throw 'CLOUDBASE_BUILD_FILES_CHANGED'}
    }
    return $manifest
}
function Enter-CBFileLock([string]$Path){
    Assert-CoursePlainPath $Path
    [void](New-Item -ItemType Directory -Path (Split-Path $Path -Parent) -Force)
    try{return [IO.File]::Open($Path,'OpenOrCreate','ReadWrite','None')}catch [IO.IOException]{throw 'CLOUDBASE_OPERATION_ALREADY_RUNNING'}
}
function ConvertTo-CBTime($Value){
    if(-not $Value){throw 'CLOUDBASE_TIME_REQUIRED'}
    if($Value -is [datetimeoffset]){return $Value.ToUniversalTime()}
    if($Value -is [datetime]){return ([datetimeoffset]$Value).ToUniversalTime()}
    return [datetimeoffset]::Parse([string]$Value,[Globalization.CultureInfo]::InvariantCulture).ToUniversalTime()
}
function Get-CBPowerShell{
    $name=if($PSVersionTable.PSEdition -eq 'Core'){'pwsh.exe'}else{'powershell.exe'}
    $path=Join-Path $PSHOME $name
    if(-not(Test-Path -LiteralPath $path -PathType Leaf)){throw 'CURRENT_POWERSHELL_EXECUTABLE_REQUIRED'}
    return $path
}
function Test-CBProcess($ProcessId,$StartedAt){
    if(-not $ProcessId -or -not $StartedAt){return $false}
    try{return (ConvertTo-CBTime (Get-Process -Id $ProcessId -ErrorAction Stop).StartTime) -eq (ConvertTo-CBTime $StartedAt)}catch{return $false}
}
function Read-CBState([string]$Path){
    Assert-CoursePlainPath $Path
    for($i=0;$i -lt 8;$i++){
        $reader=$null;$stream=$null
        try{
            $stream=[IO.File]::Open($Path,'Open','Read',([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
            $reader=[IO.StreamReader]::new($stream,[Text.Encoding]::UTF8,$true)
            return $reader.ReadToEnd()|ConvertFrom-Json
        }catch [IO.IOException]{if($i -eq 7){throw};Start-Sleep -Milliseconds 25}
        finally{if($reader){$reader.Dispose()}elseif($stream){$stream.Dispose()}}
    }
}
function New-CBWorkflowPlan($Context,[string]$PlanFile,[string]$CliPath){
    $path=[IO.Path]::GetFullPath($PlanFile)
    if(-not $path.StartsWith($Context.Root.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'WORKFLOW_PLAN_MUST_BELONG_TO_PROJECT'}
    Assert-CoursePlainPath $path
    $o=Read-CourseJson $path
    if($o.schemaVersion -ne 1 -or $o.scope -notin @('connect','static-update') -or $o.route -notin @('MCP','CLI')){throw 'CLOUDBASE_WORKFLOW_PLAN_INVALID'}
    $allowed=@('schemaVersion','scope','route','data','images','backend','sync','learnerReview','adapterInputs','resourceInputs','backendInputs')
    foreach($name in $o.PSObject.Properties.Name){if($name -notin $allowed){throw ('WORKFLOW_PLAN_UNKNOWN_FIELD:'+ $name)}}
    foreach($name in @('data','images','backend','sync','learnerReview')){if($null -ne $o.$name -and $o.$name -isnot [bool]){throw 'WORKFLOW_BOOLEAN_REQUIRED'}}
    if(($o.data -or $o.images) -and -not @($o.adapterInputs).Count){throw 'DECLARE_EXISTING_OR_PLANNED_ADAPTER_INPUTS'}
    if($o.scope -eq 'static-update' -and ($o.data -or $o.images -or $o.backend -or $o.sync)){throw 'STATIC_UPDATE_MUST_EXCLUDE_UNCHANGED_CLOUD_CAPABILITIES'}
    # Validate all declared input paths, including planned files that do not exist yet.
    $null=Get-CBAdapterFingerprint $Context @($o.adapterInputs)
    foreach($relative in @($o.resourceInputs)+@($o.backendInputs)){
        if(-not $relative){continue}
        if([IO.Path]::IsPathRooted($relative)){throw 'RELATIVE_WORKFLOW_INPUT_REQUIRED'}
        $declaredPath=[IO.Path]::GetFullPath((Join-Path $Context.Root $relative))
        if(-not $declaredPath.StartsWith($Context.Root.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'WORKFLOW_INPUT_OUTSIDE_PROJECT'}
        Assert-CoursePlainPath $declaredPath
    }
    $cliHash=$null
    if($CliPath){Assert-CoursePlainPath $CliPath;$cliHash=(Get-FileHash -LiteralPath $CliPath).Hash.ToLowerInvariant()}
    $binding=Get-CBHash (($o|ConvertTo-Json -Depth 10 -Compress)+'|'+$Context.EnvId+'|'+$Context.Url+'|'+$Context.Project.image+'|'+$Context.Source+'|'+$cliHash)
    $tasks=New-Object 'Collections.Generic.List[object]'
    function Add-CBTask($Id,$Executor,$Depends,$Kind,$Checks){
        $tasks.Add([pscustomobject]@{id=$Id;executor=$Executor;dependsOn=@($Depends|Where-Object {$_});inputKind=$Kind;checks=@($Checks);status='pending';inputStamp=$null;attempt=$null;processId=$null;processStartedAt=$null;platformTaskId=$null;startedAt=$null;finishedAt=$null;evidence=$null;evidenceSha256=$null;error=$null})
    }
    $needsCloud=$o.scope -eq 'connect'
    $needsAdapter=$o.data -or $o.images
    if($needsCloud){Add-CBTask 'resources' 'external' @() 'resource' @('targetAccess','resourcesReady','permissionsChecked')}
    if($needsAdapter){Add-CBTask 'adapter' 'external' @() 'adapter' @('adapterReady');Add-CBTask 'frontend' 'external' @('adapter') 'source' @('pageReady')}
    if($o.backend){Add-CBTask 'backend' 'external' @('resources') 'backend' @('deploymentReady')}
    $probeDependencies=@();$probeChecks=@()
    if($needsAdapter){$probeDependencies+=@('resources','adapter');$probeChecks+=@('appSession','dataOrStorageReadWrite')}
    if($o.images){$probeChecks+='imageUploadAndRead'}
    if($o.backend){$probeDependencies+='backend';$probeChecks+='backendCall'}
    if($probeDependencies.Count){Add-CBTask 'probe' 'external' @($probeDependencies|Select-Object -Unique) 'probe' $probeChecks}
    Add-CBTask 'build' 'local' $(if($needsAdapter){@('frontend')}else{@()}) 'source' @('artifactReady')
    if($o.sync){Add-CBTask 'sessions' 'external' @() 'binding' @('isolatedSessionsPrepared')}
    $deployDependencies=@('build');if($needsCloud){$deployDependencies+='resources'};if($probeDependencies.Count){$deployDependencies+='probe'}
    Add-CBTask 'deploy' $(if($o.route -eq 'CLI'){'local'}else{'external'}) $deployDependencies 'artifact' @('deploymentReady')
    Add-CBTask 'assets' 'local' @('deploy') 'artifact' @('publicAssetsVerified')
    $browserDeps=@('deploy');$browserChecks=@('pageUsable')
    if($o.sync){$browserDeps+='sessions';$browserChecks+=@('independentSessions','dataSync')}
    if($o.data -or $o.images){$browserChecks+=@('failureRecovery','accessDenied')}
    Add-CBTask 'browser' 'external' $browserDeps 'artifact' $browserChecks
    if($o.learnerReview){Add-CBTask 'learner' 'external' @('assets','browser') 'artifact' @('learnerTried')}
    $package=Read-CourseJson (Join-Path $Context.Source 'package.json')
    return [pscustomobject]@{schemaVersion=1;projectDirectory=$Context.Root;envId=$Context.EnvId;hostingUrl=$Context.Url;planFile=$path;binding=$binding;options=$o;cliPath=$CliPath;tasks=@($tasks.ToArray());preflight=@{sdk=$package.dependencies.'@cloudbase/js-sdk';image=$Context.Project.image;runtime=$Context.Project.containerRuntime;authorization='requires-current-official-target-check';resources='requires-official-resource-evidence';engineStarted=$false;remoteWritesPerformed=$false}}
}
function Get-CBDeclaredFingerprint($Context,$Paths){
    $lines=@()
    foreach($relative in @($Paths)){
        if(-not $relative){continue}
        $p=[IO.Path]::GetFullPath((Join-Path $Context.Root $relative));Assert-CoursePlainPath $p
        $lines+=($relative+':'+$(if(Test-Path -LiteralPath $p -PathType Leaf){(Get-FileHash -LiteralPath $p).Hash}else{'missing'}))
    }
    return Get-CBHash ($lines -join "`n")
}
function Get-CBTaskStamp($Context,$State,$Task){
    $o=$State.options
    $value=$State.binding
    switch($Task.inputKind){
        resource {$value+='|'+(Get-CBDeclaredFingerprint $Context $o.resourceInputs)}
        adapter {$value+='|'+(Get-CBAdapterFingerprint $Context $o.adapterInputs)}
        backend {$value+='|'+(Get-CBDeclaredFingerprint $Context (@($o.resourceInputs)+@($o.backendInputs)))}
        probe {$value+='|'+(Get-CBAdapterFingerprint $Context $o.adapterInputs)+'|'+(Get-CBDeclaredFingerprint $Context (@($o.resourceInputs)+@($o.backendInputs)))}
        source {$value+='|'+(Get-CBBuildFingerprint $Context)}
        artifact {
            $path=Join-Path $Context.Root '.ai-coding/cloudbase-build.json'
            $build=if(Test-Path -LiteralPath $path){Read-CourseJson $path}else{$null}
            if(-not $build){return 'artifact-not-ready'}
            $null=Assert-CBArtifact $Context $build
            $value+='|'+$build.buildId+'|'+$build.inputFingerprint
        }
    }
    return Get-CBHash $value
}
function Get-CBReadyTasks($State){
    foreach($task in $State.tasks){
        if($task.status -notin @('pending','stale')){continue}
        $blocked=@($task.dependsOn|Where-Object {$id=$_;@($State.tasks|Where-Object {$_.id -eq $id -and $_.status -eq 'verified'}).Count -ne 1})
        if(-not $blocked.Count){$task}
    }
}
function Get-CBWorkflowStatus($Context,$State,[string]$RunDirectory){
    # Merge per-attempt results only in memory; Status/Watch never writes state.
    $snapshot=@{}
    foreach($task in $State.tasks){
        if($snapshot.ContainsKey($task.inputKind)){$expected=$snapshot[$task.inputKind]}else{
            try{$expected=Get-CBTaskStamp $Context $State $task}catch{$expected=$null}
            $snapshot[$task.inputKind]=$expected
        }
        $task|Add-Member NoteProperty expectedInputStamp $expected -Force
        if($task.status -eq 'running' -and $task.executor -eq 'local'){
            $heartbeat=Join-Path $RunDirectory ($task.id+'/'+$task.attempt.Substring(0,12)+'/heartbeat.json')
            if(Test-Path -LiteralPath $heartbeat){
                $beat=Read-CBState $heartbeat
                if($beat.runId -ne $State.runId -or $beat.taskId -ne $task.id -or $beat.attempt -ne $task.attempt){throw 'WORKFLOW_HEARTBEAT_BINDING_CHANGED'}
                $task|Add-Member NoteProperty heartbeatAt $beat.heartbeatAt -Force
                $task|Add-Member NoteProperty heartbeatAgeSeconds ([math]::Round(([datetimeoffset]::UtcNow-(ConvertTo-CBTime $beat.heartbeatAt)).TotalSeconds,1)) -Force
            }
            $resultPath=Join-Path $RunDirectory ($task.id+'/'+$task.attempt.Substring(0,12)+'/result.json')
            if(Test-Path -LiteralPath $resultPath){
                $result=Read-CBState $resultPath
                if($result.runId -ne $State.runId -or $result.taskId -ne $task.id -or $result.attempt -ne $task.attempt -or $result.inputStamp -ne $task.inputStamp){throw 'WORKFLOW_RESULT_BINDING_CHANGED'}
                if($result.status -notin @('verified','failed','outcome-unknown') -or ($result.status -eq 'verified' -and $result.exitCode -ne 0)){throw 'WORKFLOW_RESULT_OUTCOME_INVALID'}
                $task.status=$result.status;$task.finishedAt=$result.finishedAt;$task.error=$result.error;$task.evidence=$resultPath;$task.evidenceSha256=(Get-FileHash -LiteralPath $resultPath).Hash.ToLowerInvariant()
            }elseif(-not(Test-CBProcess $task.processId $task.processStartedAt)){
                $age=([datetimeoffset]::UtcNow-(ConvertTo-CBTime $task.startedAt)).TotalSeconds
                # A dead controller does not prove its native/container child ended.
                if($age -gt 15){$task.status='outcome-unknown'}
            }
        }
        if($task.status -eq 'verified'){
            $fresh=$expected -and $expected -eq $task.inputStamp
            if(-not $task.evidence -or -not(Test-Path -LiteralPath $task.evidence -PathType Leaf)){$fresh=$false}else{
                Assert-CoursePlainPath $task.evidence
                if((Get-FileHash -LiteralPath $task.evidence).Hash.ToLowerInvariant() -cne $task.evidenceSha256){$fresh=$false}
                if($task.executor -eq 'external'){
                    $proof=Read-CBState $task.evidence
                    try{$age=([datetimeoffset]::UtcNow-(ConvertTo-CBTime $proof.observedAt)).TotalSeconds;if($age -gt 86400 -or $age -lt -120){$fresh=$false}}catch{$fresh=$false}
                }
            }
            $deps=@($task.dependsOn|Where-Object {$id=$_;@($State.tasks|Where-Object {$_.id -eq $id -and $_.status -eq 'verified'}).Count -ne 1})
            if(-not $fresh -or $deps.Count){$task.status='stale'}
        }
        $duration=if($task.startedAt -and $task.finishedAt){[math]::Round(((ConvertTo-CBTime $task.finishedAt)-(ConvertTo-CBTime $task.startedAt)).TotalSeconds,3)}else{$null}
        $task|Add-Member NoteProperty durationSeconds $duration -Force
    }
    $ready=@(Get-CBReadyTasks $State)
    $unfinished=@($State.tasks|Where-Object status -ne 'verified')
    $status=if(-not $unfinished.Count){'verified'}elseif(@($State.tasks|Where-Object status -eq 'outcome-unknown').Count){'outcome-unknown'}elseif(@($State.tasks|Where-Object status -in @('failed','interrupted')).Count){'attention'}elseif(@($State.tasks|Where-Object status -eq 'running').Count){'running'}else{'waiting'}
    $State|Add-Member NoteProperty status $status -Force
    $finished=$null
    if($status -eq 'verified'){
        foreach($task in $State.tasks){if($task.finishedAt -and (-not $finished -or (ConvertTo-CBTime $task.finishedAt) -gt $finished)){$finished=ConvertTo-CBTime $task.finishedAt}}
    }
    $State|Add-Member NoteProperty finishedAt $(if($finished){$finished.ToString('o')}else{$null}) -Force
    $end=if($finished){$finished}else{[datetimeoffset]::UtcNow}
    $State|Add-Member NoteProperty elapsedSeconds ([math]::Round(($end-(ConvertTo-CBTime $State.startedAt)).TotalSeconds,3)) -Force
    $State|Add-Member NoteProperty ready @($ready|ForEach-Object {$_.id}) -Force
    $State|Add-Member NoteProperty actionRequired ([bool]($status -ne 'running' -or @($ready|Where-Object executor -eq 'external').Count -or @($State.tasks|Where-Object {$_.status -eq 'running' -and $_.heartbeatAgeSeconds -gt 20}).Count)) -Force
    return $State
}

function ConvertTo-CBArgument {
    param([string]$Value)
    if ($Value -ne '' -and $Value -notmatch '[\s"]') { return $Value }
    return '"' + ([regex]::Replace($Value, '(\\*)"', '$1$1\"') -replace '(\\+)$', '$1$1') + '"'
}

