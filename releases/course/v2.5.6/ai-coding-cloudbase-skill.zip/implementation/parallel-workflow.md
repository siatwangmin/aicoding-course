# 并行、后台与增量执行

用于当前项目云端接入和部署；账号/环境准备继续原准备入口。入口为 `scripts/Invoke-CloudBaseWorkflow.ps1`。它执行本地确定性任务并管理依赖；页面、SDK 适配和官方 MCP 操作由助手按 [提示词模板](../references/workflow-prompts.md) 完成后登记实际证据。

## 计划与预检

将 assets/examples/cloudbase-plan.json 按本轮需求保存为 B/.ai-coding/cloudbase-plan.json。scope=connect 表示需要本轮云端检查；scope=static-update 明确只改前端，data/images/backend/sync 均为 false，已有云端结果按 Spec 复用。能力字段描述本轮受影响范围；learnerReview 只在已确认要求本人试用时启用。

adapterInputs 为相对 app 源码目录的 SDK/Repository 文件；resourceInputs/backendInputs 为相对 B 的迁移、后端实现或配置文件，路径与当前项目一致。保持已选架构，不因模板默认示例切数据库、改账号或启用额外能力。Plan 会读取本地事实、固定目标和所需检查，不访问凭证内容、不启动引擎或变更云资源。preflight 中的授权与资源状态只是待查项，须取得当前官方结果才能通过 resources。

先通过既有官方路线查询真实 hostingUrl 并写入当前 services 绑定，再 Start 固定目标。项目目标、工具入口或计划本身改变时，新建一轮；原有运行中/结果未知的任务须先查证。

资源差异可用 `scripts/Compare-CloudBaseResources.ps1 -ProjectDirectory <B> -DesiredFile <项目资源契约.json> -ObservedFile <本轮官方查询摘要.json>` 自动比较。desired-resources.json 为形状样例，资源键和属性由当前 schema 填入；observed 同样包含 schemaVersion=1、envId、resources，另带 kind=tool|command、reference、observedAt。先按官方工具实际返回归一化所需元数据；比较仅生成 create/review-update/reuse 清单，保留未声明的现有资源，不执行 SQL 或删除，不用计划状态代替查回证据。

```powershell
& '<技能>/scripts/Invoke-CloudBaseWorkflow.ps1' -ProjectDirectory '<B>' -Action Plan
& '<技能>/scripts/Invoke-CloudBaseWorkflow.ps1' -ProjectDirectory '<B>' -Action Start
# 当前任务已经授权实际发布时，Start 或 Resume 加 -AllowPublish。
& '<技能>/scripts/Invoke-CloudBaseWorkflow.ps1' -ProjectDirectory '<B>' -Action Resume -AllowPublish
```

CLI 路线在首次 Start/Plan 加 `-CliPath '<已登记官方 .ps1/.exe>'`。MCP 路线不为了后台化改成 CLI；官方任务支持异步时记录 platformTaskId，不支持时沿原调用返回结果。计划中不接受任意 shell 命令或凭证。

## 固定依赖图

- resources、adapter、sessions（需要时）可并行；resources 内的迁移/权限写入按资源串行，backend 等资源就绪再部署。
- adapter 后接 frontend；页面输入稳定即可后台 build，不等云资源准备。probe 只等 resources、adapter 和本轮必要 backend，适配文件稳定时可与剩余页面接线/构建重叠。
- deploy 等 build、必要资源与 probe；依赖后端时由 probe 确认后端调用。assets 和 browser 在 deploy 后并行；sessions 准备完成才进行独立会话同步验收。
- Record、Resume、Start 会启动已就绪的本地节点；Status/Watch 只查询，不自动续发写操作。助手在前台动作结束后 Resume 推进；没有独立工作时用 Watch（1—30 秒）等状态变化。后台进程沿当前 PowerShell 版本运行，避免混用模块环境。

## 证据接续

Start/Status 返回 runId、envId、ready 和每个任务的 expectedInputStamp/checks。实际执行某个外部 ready 任务后保存 JSON，再调用 Record。不得把模板检查项直接全部填 true；只填写实际观察结果。检查不通过时记录 failed 或 outcome-unknown。

```json
{
  "runId": "本轮实际runId",
  "taskId": "resources",
  "envId": "当前实际环境",
  "inputStamp": "Status返回的本任务expectedInputStamp",
  "status": "verified",
  "kind": "tool",
  "reference": "实际官方工具结果或项目内脱敏证据位置",
  "observedAt": "实际观察时间ISO8601",
  "checks": {"targetAccess": true, "resourcesReady": true, "permissionsChecked": true}
}
```

```powershell
& '<技能>/scripts/Invoke-CloudBaseWorkflow.ps1' -ProjectDirectory '<B>' -Action Record -EvidenceFile '<本轮实际证据.json>'
& '<技能>/scripts/Invoke-CloudBaseWorkflow.ps1' -ProjectDirectory '<B>' -Action Status
& '<技能>/scripts/Invoke-CloudBaseWorkflow.ps1' -ProjectDirectory '<B>' -Action Watch -WaitSeconds 20
```

deploy/browser/assets/learner 证据另绑定本轮 buildId；learner 必须 kind=learner。CLI 的本地结果由 worker 登记；MCP 的 deploy 证据确认原 TaskId 终态及本轮产物，Record 后再做 assets。应用检查与静态文件通过分开记录。

项目状态与历史在 `.ai-coding/cb/<runId前12位>`；任务各有独立 attempt、进程身份、心跳、日志与结果，主入口持短锁汇总 current.json。任务心跳不证明下载字节进度。不得在运行中修改原脚本或清理任务目录；已有项目仍固定原执行包，新包安装/升级后再使用本入口。

目录仅缩短标识以兼容 Windows PowerShell 路径限制，JSON 内始终核完整 runId/attempt。Status 输出外部任务的原 platformTaskId；助手用官方工具查询原任务并 Record 更新实际观察，Status 本身不会调用会话 MCP。资源/SDK/probe 按本轮证据校验并保存摘要；证据丢失、内容变化或外部观察过期时相应任务失效。appSession 沿当前已确认身份策略核应用访问，不因此新增注册或登录界面。

## 复用、失败与恢复

Build 对源码、依赖锁、构建配置、镜像和环境计算指纹，构建前后比对，随后生成完整资源摘要。Deploy 只读取已核产物；部署或浏览器检查前再次核原 dist。输入/产物变化使相应任务 stale，依赖任务一并失效；资源和明确适配文件未变时，对应证据可在本轮保留。新一轮按 scope 选择增量范围，不自动刷新旧观察时间。

后台 worker 丢失时，不能凭 PID 缺失断定容器内命令已结束，保留 outcome-unknown。先查记录的进程、子进程和原容器/平台任务。实际只读查证结束后，用同一任务证据补 `readOnlyConfirmed=true`、`originalTaskEnded=true`，记录 verified 或明确 failed；仍活着的已知子进程会拒绝恢复。确认失败的本地任务用 Resume -RetryTask build|deploy|assets 重试；未知任务不自动重发。

部署失败或超时先查询原平台任务，再沿 Publish-CloudBase -Action Recover 或原 -Recover 验证原产物。不得为了重试覆盖未知部署的构建记录。日志与证据仅保存脱敏摘要，不粘贴完整 MCP 响应、Key、Cookie、设备码或会话 token。

旧调用 `Publish-CloudBase -Publish/-Recover` 保留；新分段动作是 Build/Deploy/Verify/Recover。修改后的脚本与模板由统一构建打入工具箱及独立技能包。约 15 分钟为常规首次接入的目标预算，真实平台/本人等待和排障计入总耗时，离线测试不证明实际部署或时长达标。
