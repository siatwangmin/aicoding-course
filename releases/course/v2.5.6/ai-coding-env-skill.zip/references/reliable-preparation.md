# 准备状态与故障接续

完整准备由 env 编排，按已有范围接续工具、GitHub、CloudBase 与汇总；已有明确授权不重复询问。后台工具安装保持依赖顺序，前台可继续账号工作，不并行打开多轮交互授权或重复安装。

## 后台检查

每次前台工具动作结束、转入本人操作或等待前，调用 `scripts/Start-CourseToolPreparation.ps1 -WorkingDirectory <A> -Action Status`。Git/gh 就绪可接 GitHub，所需 Node 就绪可接本地 CloudBase 工具，不必等镜像全部完成；不能因工具就绪而跳过已要求的平台准备。

无其他可执行动作时用同入口 `-Action Watch -WaitSeconds 20`，等待值为 1—30 秒。状态/阶段变化、失败、需要授权/重启或工具完成会返回，随后由助手处理。Status/Watch 只读已有状态，不创建任务或修复环境；Watch 不是推送服务，也不能保证前台阻塞或会话暂停时仍及时响应。

Failed 按 failureClass 与本轮日志定位；Interrupted/ChildRunning 先核记录的进程身份，不重复启动仍活着的安装器；RestartRequired 保留账号结果，由本人决定重启；Verified 立即接真实工具验收、服务登记和剩余平台/汇总。不要把已退出的任务当成慢下载，也不以 lock 文件存在或大小为零判断死锁。

每轮工具状态保存在 `.course-setup/tools-background.json`；`tool-runs/<taskId>/state.json` 保留各轮，`events.jsonl` 保留转换，各阶段 `*-timing.json` 保存起止、退出码及未知结果。旧记录没有新字段时不伪造历史。约 10 秒心跳表示控制进程仍在检查子进程，不证明下载有字节增长；阶段耗时含启动、下载、校验和安装，不能当作带宽或纯下载时间。

失败分类是诊断提示：证书信任、代理认证、DNS、网络超时、摘要不匹配分别处理；未知错误保持 NeedsDiagnosis。分类不证明根因，也不授权换镜像、跳校验、清代理或放宽权限。下载缓存与已完成账号结果保留，修具体缺项后沿原目录恢复。

## 证书与授权

Windows 浏览器、宿主 Node 与容器虚拟机的信任来源可能不同；核本次失败进程和真实证书链，不能由浏览器可访问推断其他执行端也可用。仅使用组织提供或已核实来源、指纹、有效期的必要 CA，不批量导入根证书、不复制私钥、不使用过期 CA，不禁用 TLS。此流程没有自动导入证书的步骤。

Node 的进程环境配置需要在启动相应进程时生效；进程级 `NODE_EXTRA_CA_CERTS` 不会自动成为其他新会话的持久配置。记录所选文件与恢复方式，重开后复核。修改 machine 或系统信任库是持久变更，先核共享范围与已有授权；必要 CA 不明确时只向本人请求取得组织认可 CA 或选择已允许网络，不试错导入。

需要本人批准时一次给当前官方页面、一个动作与预期结果；保留该轮官方授权进程，不为了查看后台而杀掉授权轮询。凭证、设备码、Cookie 和授权页面正文不写进通用日志；诊断记录仅保留阶段、时间和脱敏错误。

## 准确汇总

Trae 加载沿 [实际加载验收](trae-load-verification.md)：当前 A 新会话发现四个用户级技能、A 本地 env 和两份规则，来源为真实会话工具或本人明确确认；保留作用域/路径/摘要等现有检查，不用网页打开替代。

`currentResultsReviewed` 通过必须来自本人实际确认，kind=learner；助手读报告不能代替。已有明确反馈按原时间留证，不反复询问。老汇总没有本人来源或真实加载证据时保持待验收，不改历史或自动补成通过。

服务登记的 `authorizationStatus=pending` 与 `authorizationMeaning=not-checked-by-registration` 表示登记未实时核授权。实际平台结果取自对应 evidence 与检查时间；恢复时只读复查当前身份和目标，不能仅凭 pending 重新注册、反复授权或手改 verified。

资料入口可在现有 `Get-CourseMaterials.ps1 -WorkingDirectory <A> -CheckOnly` 做无网络、无写入、无安装预检；它只核明确目录与路径保护，不证明资料完整、平台授权或环境可用。
