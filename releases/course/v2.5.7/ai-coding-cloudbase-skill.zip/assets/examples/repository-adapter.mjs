// Adapt callbacks to the project's existing schema and access layer.
// The unique request key must have a verified database constraint.
export function createSaveIntentAdapter({lookup,writeAndRead,upload,uniqueConstraintVerified}) {
  if(!uniqueConstraintVerified||typeof lookup!=='function'||typeof writeAndRead!=='function')throw new Error('VERIFIED_SAVE_CONTRACT_REQUIRED');
  const inFlight=new Map();
  async function run(intent) {
    if(!intent?.requestId)throw new Error('STABLE_REQUEST_ID_REQUIRED');
    const existing=await lookup(intent.requestId);
    if(existing)return existing;
    // Keep the same intent and object key on an unresolved retry. Query first.
    if(intent.file&&!intent.uploadedObject){
      if(!intent.objectKey||typeof upload!=='function')throw new Error('STABLE_IMAGE_CONTRACT_REQUIRED');
      intent.uploadedObject=await upload(intent.objectKey,intent.file);
    }
    // The project callback maps row/owner fields, checks errors and reads back.
    // Unknown writes are reconciled by lookup on the next explicit retry.
    return await writeAndRead(intent.requestId,intent.row,intent.uploadedObject);
  }
  return {
    save(intent){
      if(!intent?.requestId)return Promise.reject(new Error('STABLE_REQUEST_ID_REQUIRED'));
      if(inFlight.has(intent.requestId))return inFlight.get(intent.requestId);
      const pending=run(intent).finally(()=>inFlight.delete(intent.requestId));
      inFlight.set(intent.requestId,pending);return pending;
    }
  };
}
