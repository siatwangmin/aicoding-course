﻿#Requires -Version 5.1
# Short-lived reuse of a fully verified runtime, with live identity and dependency checks.
function Get-CBRuntimeBinding($Context,[string]$ExecutionRoot,[string]$Cli){
    $parts=@($Context.Root,$Context.EnvId)
    foreach($relative in @('.ai-coding/project.json','.ai-coding/local.json','compose.yaml','compose.yml','.env')){
        $path=Join-Path $Context.Root $relative;Assert-CoursePlainPath $path
        if(Test-Path -LiteralPath $path -PathType Leaf){$parts+=($relative+':'+(Get-FileHash -LiteralPath $path).Hash)}
    }
    foreach($name in @('package.json','package-lock.json')){$path=Join-Path $Context.Source $name;Assert-CoursePlainPath $path;if(Test-Path -LiteralPath $path){$parts+=($name+':'+(Get-FileHash -LiteralPath $path).Hash)}}
    foreach($path in @($Cli,$Context.Project.compose.path,(Join-Path $ExecutionRoot 'execution-manifest.json'))){if($path -and (Test-Path -LiteralPath $path -PathType Leaf)){Assert-CoursePlainPath $path;$parts+=($path+':'+(Get-FileHash -LiteralPath $path).Hash)}}
    return Get-CBHash ($parts -join '|')
}
function Get-CBLiveRuntime($Context,$Runtime,[switch]$Dependencies){
    $info=Invoke-SetupNative $Runtime.Cli ($Runtime.Prefix+@('info','--format','json')) 20 $Context.Root
    Assert-CBNativeResult $info 'CACHED_ENGINE_UNAVAILABLE'
    $engine=$(if($info.Stdout){$info.Stdout}else{$info.Output})|ConvertFrom-Json
    $engineId=if($engine.ID){$engine.ID}else{$engine.host.id}
    if(-not $engineId){throw 'ENGINE_IDENTITY_UNAVAILABLE'}
    $inspect=Invoke-SetupNative $Runtime.Cli ($Runtime.Prefix+@('inspect',$Runtime.ContainerId)) 20 $Context.Root
    Assert-CBNativeResult $inspect 'CACHED_CONTAINER_UNAVAILABLE'
    $container=@($(if($inspect.Stdout){$inspect.Stdout}else{$inspect.Output})|ConvertFrom-Json)[0]
    $image=if($container.Image){$container.Image}else{$container.ImageId}
    if(-not $container.State.Running -or $container.Id -ne $Runtime.ContainerId -or ($image -replace '^sha256:','') -ne ($Runtime.ImageId -replace '^sha256:','')){throw 'CACHED_CONTAINER_IDENTITY_CHANGED'}
    $mounts=@($container.Mounts|Select-Object Type,Name,Source,Destination,RW|Sort-Object Destination)
    $snapshot=Get-CBHash (([ordered]@{image=$image;mounts=$mounts;labels=$container.Config.Labels;network=$container.HostConfig.NetworkMode}|ConvertTo-Json -Depth 10 -Compress))
    if($Dependencies){
        $probe='const fs=require("fs"),crypto=require("crypto"),{createRequire}=require("module");const lock=fs.readFileSync("/workspace/package-lock.json"),p=JSON.parse(lock),r=createRequire("/workspace/package.json");for(const n of ["typescript","vite","rollup","@ionic/react","@capacitor/android"]){if(JSON.parse(fs.readFileSync("/workspace/node_modules/"+n+"/package.json")).version!==p.packages["node_modules/"+n]?.version)throw Error("LOCKFILE_DEPENDENCY_VERSION_MISMATCH")}for(const n of ["typescript","vite","rollup"])r(n);if(process.platform!=="linux"||process.arch!=="x64")throw Error("RUNTIME_PLATFORM_CHANGED");console.log(JSON.stringify({node:process.versions.node,lock:crypto.createHash("sha256").update(lock).digest("hex")}))'
        $r=Invoke-SetupNative $Runtime.Cli ($Runtime.Prefix+@('compose','exec','-T','app','node','-e',$probe)) 30 $Context.Root
        Assert-CBNativeResult $r 'CACHED_DEPENDENCIES_CHANGED'
        $deps=$(if($r.Stdout){$r.Stdout}else{$r.Output})|ConvertFrom-Json
        $expected=(Get-FileHash -LiteralPath (Join-Path $Context.Source 'package-lock.json')).Hash.ToLowerInvariant()
        if($deps.lock -cne $expected -or ($Context.Project.toolchain.capabilities.node -and $deps.node -ne $Context.Project.toolchain.capabilities.node)){throw 'CACHED_DEPENDENCIES_CHANGED'}
    }
    return [pscustomobject]@{engineId=$engineId;snapshot=$snapshot}
}
function Get-CBVerifiedRuntime($Context,[string]$ExecutionRoot,[switch]$Start){
    . (Join-Path $ExecutionRoot 'scripts/Course-Runtime.ps1')
    $path=Join-Path $Context.Root '.ai-coding/cloudbase-runtime.json'
    $cached=if(Test-Path -LiteralPath $path){Read-CBState $path}else{$null}
    if($cached){
        try{
            $age=([datetimeoffset]::UtcNow-(ConvertTo-CBTime $cached.checkedAt)).TotalSeconds
            $binding=Get-CBRuntimeBinding $Context $ExecutionRoot $cached.runtime.Cli
            $sameTarget=$cached.runtime.Root -eq $Context.Root -and $cached.runtime.Source -eq $Context.Source -and $cached.runtime.Project.image -eq $Context.Project.image
            if($Context.Project.connection -and ($cached.runtime.Prefix -join '|') -notlike ('*--connection|'+$Context.Project.connection+'*')){$sameTarget=$false}
            if($sameTarget -and $cached.binding -ceq $binding -and $age -ge 0 -and $age -lt 120){
                if($Context.Project.compose.path){Assert-CoursePlainPath $Context.Project.compose.path;if($Context.Project.containerRuntime -eq 'podman'){$env:PODMAN_COMPOSE_PROVIDER=$Context.Project.compose.path}}
                $live=Get-CBLiveRuntime $Context $cached.runtime -Dependencies
                if($live.engineId -ceq $cached.engineId -and $live.snapshot -ceq $cached.snapshot){
                    $null=Write-CBTiming $Context ([ordered]@{runId=$env:AI_CODING_CB_RUN;taskId=$env:AI_CODING_CB_TASK;name='runtime-reuse';kind='work';status='completed';detail='Same input, live engine/container/mount identity and locked dependency probe verified.'})
                    return $cached.runtime
                }
            }
        }catch{
            # Re-run the complete original verifier; never proceed with an unverified cache.
            $null=Write-CBTiming $Context ([ordered]@{runId=$env:AI_CODING_CB_RUN;taskId=$env:AI_CODING_CB_TASK;name='runtime-cache-invalid';kind='diagnosis';status='completed';detail=$_.Exception.Message})
        }
    }
    $runtime=Get-CourseProjectRuntime $Context.Root -Start:$Start
    if($runtime.ContainerId -and $runtime.ImageId){
        try{
            $live=Get-CBLiveRuntime $Context $runtime
            Write-CourseJson $path @{binding=(Get-CBRuntimeBinding $Context $ExecutionRoot $runtime.Cli);runtime=$runtime;engineId=$live.engineId;snapshot=$live.snapshot;checkedAt=[datetimeoffset]::UtcNow.ToString('o')}
        }catch{
            $null=Write-CBTiming $Context ([ordered]@{runId=$env:AI_CODING_CB_RUN;taskId=$env:AI_CODING_CB_TASK;name='runtime-cache-unavailable';kind='work';status='completed';detail=$_.Exception.Message})
        }
    }
    return $runtime
}
