﻿#Requires -Version 5.1
# Requires the recorded Context library. No side effects on import.
function Protect-CBDetail([string]$Value){
    $text=Protect-CourseOutput $Value
    $text=[regex]::Replace($text,'(?i)(Bearer\s+)[^\s,;]+','$1[REDACTED]')
    return $text.Substring(0,[math]::Min(6000,$text.Length))
}
function Write-CBTiming($Context,$Event){
    $folder=Join-Path $Context.Root '.ai-coding/cb-events'
    $id=[guid]::NewGuid().ToString('N')
    $value=[ordered]@{eventId=$id;recordedAt=[datetimeoffset]::UtcNow.ToString('o');envId=$Context.EnvId;projectDirectory=$Context.Root;startedAt=$null;finishedAt=$null;durationSeconds=$null}
    foreach($key in @('runId','taskId','attempt','operationId','name','kind','status','startedAt','finishedAt','durationSeconds','exitCode','timedOut','detail','nextAction')){if($Event.Contains($key)){$value[$key]=$Event[$key]}}
    if($value.detail){$value.detail=Protect-CBDetail $value.detail}
    $path=Join-Path $folder ($id+'.json');Write-CourseJson $path $value
    return $path
}
function Invoke-CBMeasured($Context,[string]$Name,[scriptblock]$Operation,[string]$NextAction){
    $cbTimingStarted=[datetimeoffset]::UtcNow;$cbTimer=[Diagnostics.Stopwatch]::StartNew();$cbTimedResult=$null;$cbFailure=$null
    try{$cbTimedResult=& $Operation;return $cbTimedResult}catch{$cbFailure=$_.Exception.Message;throw}
    finally{
        $native=$cbTimedResult -and $null -ne $cbTimedResult.ExitCode
        $failed=$cbFailure -or ($native -and $cbTimedResult.ExitCode -ne 0)
        $detail=if($cbFailure){$cbFailure}elseif($failed){if($cbTimedResult.Stderr){$cbTimedResult.Stderr}else{$cbTimedResult.Output}}else{$null}
        $event=[ordered]@{runId=$env:AI_CODING_CB_RUN;taskId=$env:AI_CODING_CB_TASK;attempt=$env:AI_CODING_CB_ATTEMPT;name=$Name;kind='work';status=$(if($failed){'failed'}else{'completed'});startedAt=$cbTimingStarted.ToString('o');finishedAt=[datetimeoffset]::UtcNow.ToString('o');durationSeconds=$cbTimer.Elapsed.TotalSeconds;detail=$detail;nextAction=$NextAction}
        if($native){$event.exitCode=$cbTimedResult.ExitCode;$event.timedOut=[bool]$cbTimedResult.TimedOut}
        $script:CBLastEvent=Write-CBTiming $Context $event
    }
}
function Assert-CBNativeResult($Result,[string]$Code){
    if($Result.ExitCode -ne 0){
        $detail=if($Result.Stderr){$Result.Stderr}else{$Result.Output}
        throw ($Code+': '+(Protect-CBDetail $detail)+'; evidence='+$script:CBLastEvent)
    }
}
