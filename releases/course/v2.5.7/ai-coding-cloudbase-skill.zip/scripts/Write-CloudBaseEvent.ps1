﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,
 [Parameter(Mandatory=$true)][ValidateSet('Begin','End')][string]$Action,
 [string]$TaskId,[string]$Name,[ValidateSet('work','wait','diagnosis')][string]$Kind='work',
 [string]$EventId,[ValidateSet('completed','failed')][string]$Status='completed',[string]$Detail)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$execution=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $execution 'scripts/Course-Context.ps1')
. (Join-Path $PSScriptRoot 'Course-CloudBaseWorkflow.ps1')
$ctx=Get-CBProject $ProjectDirectory;$state=Read-CBState (Join-Path $ctx.Root '.ai-coding/cb/current.json')
if($state.envId -ne $ctx.EnvId -or $state.projectDirectory -ne $ctx.Root){throw 'EVENT_TARGET_MISMATCH'}
if($Action -eq 'Begin'){
 if(-not @($state.tasks|Where-Object id -eq $TaskId).Count -or $Name -notmatch '^[a-z][a-z0-9-]{0,63}$'){throw 'EVENT_TASK_OR_NAME_INVALID'}
 $path=Write-CBTiming $ctx ([ordered]@{runId=$state.runId;taskId=$TaskId;name=$Name;kind=$Kind;status='running';startedAt=[datetimeoffset]::UtcNow.ToString('o');detail=$Detail})
 [pscustomobject]@{eventId=[IO.Path]::GetFileNameWithoutExtension($path)}|ConvertTo-Json
}else{
 if($EventId -notmatch '^[a-f0-9]{32}$'){throw 'EVENT_ID_INVALID'}
 $path=Join-Path $ctx.Root ('.ai-coding/cb-events/'+$EventId+'.json');$lease=Enter-CBFileLock ($path+'.lock')
 try{$event=Read-CBState $path;if($event.runId -ne $state.runId -or $event.envId -ne $ctx.EnvId -or $event.status -ne 'running'){throw 'EVENT_BINDING_OR_STATE_INVALID'};$event.status=$Status;$event.finishedAt=[datetimeoffset]::UtcNow.ToString('o');$event.durationSeconds=([datetimeoffset]::UtcNow-(ConvertTo-CBTime $event.startedAt)).TotalSeconds;$event.detail=Protect-CBDetail $Detail;Write-CourseJson $path $event;[pscustomobject]@{eventId=$EventId;status=$Status;durationSeconds=$event.durationSeconds}|ConvertTo-Json}finally{$lease.Dispose()}
}
