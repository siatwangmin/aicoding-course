﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,
      [Parameter(Mandatory=$true)][string]$DesiredFile,[Parameter(Mandatory=$true)][string]$ObservedFile)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $executionRoot 'scripts/Course-Context.ps1')
. (Join-Path $PSScriptRoot 'Course-CloudBaseWorkflow.ps1')
$context=Get-CBProject $ProjectDirectory
foreach($path in @($DesiredFile,$ObservedFile)){Assert-CoursePlainPath $path}
$desired=Read-CourseJson $DesiredFile;$observed=Read-CourseJson $ObservedFile
if($desired.schemaVersion -ne 1 -or $observed.schemaVersion -ne 1 -or $desired.envId -ne $context.EnvId -or $observed.envId -ne $context.EnvId){throw 'RESOURCE_SNAPSHOT_TARGET_MISMATCH'}
if($observed.kind -notin @('tool','command') -or -not $observed.reference -or $observed.reference -ne (Protect-CourseOutput $observed.reference)){throw 'OFFICIAL_RESOURCE_OBSERVATION_REQUIRED'}
$age=([datetimeoffset]::UtcNow-(ConvertTo-CBTime $observed.observedAt)).TotalSeconds
if($age -lt -120 -or $age -gt 86400){throw 'RESOURCE_SNAPSHOT_TIME_INVALID'}
function Assert-ResourceList($Items){
 $seen=@{}
 foreach($item in @($Items)){
  if($item.kind -notin @('table','column','constraint','policy','bucket','function','hosting','auth') -or [string]$item.id -notmatch '^[a-zA-Z0-9_.:/-]{1,180}$'){throw 'RESOURCE_KEY_INVALID'}
  $key=$item.kind+'|'+$item.id;if($seen.ContainsKey($key)){throw 'DUPLICATE_RESOURCE_KEY'};$seen[$key]=$true
  if($item.properties -isnot [pscustomobject]){throw 'RESOURCE_PROPERTIES_OBJECT_REQUIRED'}
 }
}
function Compare-ResourceProperties($Expected,$Actual,[string]$Path){
 if($Expected -is [pscustomobject]){
  foreach($property in $Expected.PSObject.Properties){
   $name=$property.Name;$nested=if($Path){$Path+'.'+$name}else{$name}
   $found=@($Actual.PSObject.Properties|Where-Object Name -CEQ $name)
   if($found.Count -ne 1){$nested}else{Compare-ResourceProperties $property.Value $found[0].Value $nested}
  }
 }else{
  if((ConvertTo-Json -InputObject $Expected -Depth 15 -Compress) -cne (ConvertTo-Json -InputObject $Actual -Depth 15 -Compress)){$Path}
 }
}
Assert-ResourceList $desired.resources;Assert-ResourceList $observed.resources
$diff=@()
foreach($item in @($desired.resources)){
 $matches=@($observed.resources|Where-Object {$_.kind -ceq $item.kind -and $_.id -ceq $item.id})
 if(-not $matches.Count){$action='create';$properties=@()}else{
  $properties=@(Compare-ResourceProperties $item.properties $matches[0].properties '')
  $action=if($properties.Count){'review-update'}else{'reuse'}
 }
 $diff+=@{kind=$item.kind;id=$item.id;action=$action;differentProperties=$properties}
}
# Read-only plan: no schema writes and no destructive/delete suggestions.
[pscustomobject]@{schemaVersion=1;envId=$context.EnvId;status='diff-planned';desiredSha256=(Get-FileHash $DesiredFile).Hash.ToLowerInvariant();observedSha256=(Get-FileHash $ObservedFile).Hash.ToLowerInvariant();remoteWritesPerformed=$false;resources=$diff;nextAction='Review actual differences, apply the authorized increment through the existing official route, then query back and record resources evidence.'}|ConvertTo-Json -Depth 15
