﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,[string]$CliPath,[switch]$Publish,[switch]$Recover,
      [ValidateSet('Legacy','Build','Deploy','Verify','Recover')][string]$Action='Legacy',
      [ValidateRange(1,8)][int]$Concurrency=4,[switch]$ForceBuild,[string]$PlatformPolicyFile)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $executionRoot 'scripts/Course-Context.ps1')
. (Join-Path $executionRoot 'scripts/Course-Native.ps1')
. (Join-Path $PSScriptRoot 'Course-CloudBaseWorkflow.ps1')
. (Join-Path $PSScriptRoot 'Course-CloudBaseRuntime.ps1')
$projectContext=Get-CBProject $ProjectDirectory
$root=$projectContext.Root
$recordPath=Join-Path $root 'docs/progress/cloudbase-publish.json'
$buildPath=Join-Path $root '.ai-coding/cloudbase-build.json'
$scripts=$PSScriptRoot
if(-not $PlatformPolicyFile -and (Test-Path -LiteralPath (Join-Path $root '.ai-coding/cloudbase-policy.json'))){$PlatformPolicyFile=Join-Path $root '.ai-coding/cloudbase-policy.json'}
$policy=Get-CBPlatformPolicy $projectContext $PlatformPolicyFile
if($Recover){$Action='Recover'}
function Get-CBPublishRuntime([switch]$Start){
    return Invoke-CBMeasured $projectContext 'runtime-check' {Get-CBVerifiedRuntime $projectContext $executionRoot -Start:$Start} 'Restore the recorded engine, image or project dependency volume; no host fallback.'
}
function Invoke-CBPublicAssets($Runtime,[string]$Operation){
    $output=$projectContext.Output
    $mounts=@('run','--rm','--mount',("type=bind,source=$output,target=/public,readonly"),'--mount',("type=bind,source=$scripts,target=/course,readonly"))
    if($Operation -eq 'manifest'){$mounts[3]=("type=bind,source=$output,target=/public")}
    if($Operation -eq 'verify' -and $policy){$mounts+=@('--mount',("type=bind,source=$PlatformPolicyFile,target=/policy/context.json,readonly"))}
    $a=$Runtime.Prefix+$mounts+@('--entrypoint','node',$Runtime.Project.image,'/course/publish-assets.mjs',$Operation)
    if($Operation -eq 'manifest'){$a+=@('--directory','/public')}else{$a+=@('--url',$projectContext.Url,'--manifest','/public/course-publish.json','--concurrency',[string]$Concurrency)}
    if($Operation -eq 'verify' -and $policy){$a+=@('--policy','/policy/context.json')}
    $r=Invoke-CBMeasured $projectContext ('assets-'+$Operation) {Invoke-SetupNative $Runtime.Cli $a 180 $root} 'Inspect the native error; confirm the target policy and compare bytes. Do not rebuild or redeploy for a verification-only failure.'
    Assert-CBNativeResult $r ('PUBLIC_ASSET_CHECK_FAILED:'+ $Operation)
    return $(if($r.Stdout){$r.Stdout}else{$r.Output})|ConvertFrom-Json
}
function Assert-CBPublicConfiguration{
    $values=@{}
    foreach($name in @('.env','.env.local','.env.production','.env.production.local')){
        $path=Join-Path $projectContext.Source $name
        if(Test-Path -LiteralPath $path){Assert-CoursePlainPath $path;foreach($line in [IO.File]::ReadAllLines($path)){if($line -match '^\s*(VITE_DATA_MODE|VITE_CLOUDBASE_ENV_ID)\s*=\s*(.*?)\s*$'){$values[$Matches[1]]=$Matches[2].Trim('"',"'")}}}
    }
    if($values.VITE_DATA_MODE -ne 'cloudbase' -or $values.VITE_CLOUDBASE_ENV_ID -ne $projectContext.EnvId){throw 'PRODUCTION_CLOUDBASE_BINDING_MISMATCH'}
}
function Invoke-CBBuild{
    if(Test-Path -LiteralPath $recordPath){if((Read-CourseJson $recordPath).status -eq 'deployment-unknown'){throw 'QUERY_PRIOR_DEPLOYMENT_BEFORE_BUILD_OR_REDEPLOY'}}
    Assert-CBPublicConfiguration
    if(-not $ForceBuild -and (Test-Path -LiteralPath $buildPath)){
        $cached=Read-CourseJson $buildPath
        try{$null=Assert-CBArtifact $projectContext $cached;return $cached}catch{if($_.Exception.Message -notmatch '^CLOUDBASE_BUILD_'){throw}}
    }
    $runtime=Get-CBPublishRuntime -Start
    $before=Get-CBBuildFingerprint $projectContext
    $started=[datetimeoffset]::UtcNow
    $r=Invoke-CBMeasured $projectContext 'compile' {Invoke-SetupNative $runtime.Cli ($runtime.Prefix+@('compose','exec','-T','app','npm','run','build')) 180 $root} 'Fix the first source or dependency error in the original image.'
    if($r.TimedOut){throw 'BUILD_OUTCOME_UNKNOWN_QUERY_CONTAINER'}
    Assert-CBNativeResult $r 'CONTAINER_WEB_BUILD_FAILED'
    if((Get-CBBuildFingerprint $projectContext) -cne $before){throw 'CLOUDBASE_BUILD_INPUT_CHANGED_DURING_BUILD'}
    $manifest=Invoke-CBPublicAssets $runtime 'manifest'
    $manifestSha256=(Get-FileHash -LiteralPath (Join-Path $projectContext.Output 'course-publish.json')).Hash.ToLowerInvariant()
    $record=@{schemaVersion=3;status='prepared';envId=$projectContext.EnvId;url=$projectContext.Url;buildId=$manifest.buildId;image=$projectContext.Project.image;inputFingerprint=$before;preparedAt=[datetimeoffset]::UtcNow.ToString('o');startedAt=$started.ToString('o');durationSeconds=([datetimeoffset]::UtcNow-$started).TotalSeconds;applicationData='pending';learnerTried='pending'}
    $record.manifestSha256=$manifestSha256
    $null=Assert-CBArtifact $projectContext ([pscustomobject]$record)
    Write-CourseJson $buildPath $record
    Write-CourseJson $recordPath $record
    return [pscustomobject]$record
}
function Invoke-CBDeploy{
    if(-not $projectContext.Url){throw 'ACTUAL_HTTPS_HOSTING_URL_REQUIRED'}
    $prior=if(Test-Path -LiteralPath $recordPath){Read-CourseJson $recordPath}else{$null}
    if($prior.status -eq 'deployment-unknown'){throw 'QUERY_PRIOR_DEPLOYMENT_BEFORE_REDEPLOY'}
    $record=Read-CourseJson $buildPath
    $null=Assert-CBArtifact $projectContext $record
    if(-not $CliPath -or -not(Test-Path -LiteralPath $CliPath -PathType Leaf)){throw 'RECORDED_OFFICIAL_CLI_REQUIRED_OR_USE_MCP_ROUTE'}
    Assert-CoursePlainPath $CliPath
    $prefix=@()
    if([IO.Path]::GetExtension($CliPath) -eq '.ps1'){$exe=Join-Path $env:SystemRoot 'System32/WindowsPowerShell/v1.0/powershell.exe';$prefix=@('-NoProfile','-File',$CliPath)}
    elseif([IO.Path]::GetExtension($CliPath) -eq '.exe'){$exe=$CliPath}else{throw 'OFFICIAL_EXE_OR_POWERSHELL_ENTRY_REQUIRED'}
    $identity=@((Get-FileHash -LiteralPath $CliPath).Hash)
    foreach($relative in @('node_modules/@cloudbase/cli/package.json','node_modules/@cloudbase/cli/dist/standalone/cli.js')){$f=Join-Path (Split-Path $CliPath -Parent) $relative;if(Test-Path -LiteralPath $f){Assert-CoursePlainPath $f;$identity+=(Get-FileHash -LiteralPath $f).Hash}}
    $key=Get-CBHash ($identity -join '|');$helpPath=Join-Path $root '.ai-coding/cloudbase-cli-help.json'
    $cache=if(Test-Path -LiteralPath $helpPath){Read-CBState $helpPath}else{$null}
    $reused=$cache -and $cache.identity -eq $key -and (([datetimeoffset]::UtcNow-(ConvertTo-CBTime $cache.checkedAt)).TotalSeconds -ge 0) -and (([datetimeoffset]::UtcNow-(ConvertTo-CBTime $cache.checkedAt)).TotalSeconds -lt 300)
    if(-not $reused){
        foreach($argsToCheck in @(@('--version'),@('hosting','deploy','--help'))){
            $r=Invoke-CBMeasured $projectContext 'cli-help' {Invoke-SetupNative $exe ($prefix+$argsToCheck) 60 $root} 'Use the registered official CLI and inspect its current help.'
            Assert-CBNativeResult $r 'OFFICIAL_CLI_HELP_OR_TARGET_ACCESS_FAILED'
        }
        Write-CourseJson $helpPath @{identity=$key;checkedAt=[datetimeoffset]::UtcNow.ToString('o')}
    }
    # CLI help reuse never substitutes for current target authorization.
    $r=Invoke-CBMeasured $projectContext 'target-access' {Invoke-SetupNative $exe ($prefix+@('hosting','list','--env-id',$projectContext.EnvId,'--json')) 60 $root} 'Restore current target authorization; do not switch environments.'
    Assert-CBNativeResult $r 'OFFICIAL_CLI_HELP_OR_TARGET_ACCESS_FAILED'
    # The build stayed immutable while help and authorization checks ran.
    $null=Assert-CBArtifact $projectContext $record
    $record.url=$projectContext.Url;$record.status='deployment-unknown'
    Write-CourseJson $recordPath $record
    $r=Invoke-CBMeasured $projectContext 'upload' {Invoke-SetupNative $exe ($prefix+@('hosting','deploy',$projectContext.Output,'--env-id',$projectContext.EnvId,'--json')) 600 $root} 'Query the original platform operation before any resubmission.'
    Assert-CBNativeResult $r 'DEPLOYMENT_OUTCOME_UNKNOWN_QUERY_ORIGINAL_TASK'
    $null=Assert-CBArtifact $projectContext $record
    $record.status='deployed';$record|Add-Member NoteProperty deployedAt ([datetimeoffset]::UtcNow.ToString('o')) -Force
    Write-CourseJson $recordPath $record
    return $record
}
function Invoke-CBVerify([switch]$Recovery){
    if(-not $projectContext.Url){throw 'ACTUAL_HTTPS_HOSTING_URL_REQUIRED'}
    $record=Read-CourseJson $recordPath
    if(-not $record -or $record.envId -ne $projectContext.EnvId -or $record.url -ne $projectContext.Url){throw 'RECOVERY_TARGET_DIFFERS'}
    $null=Assert-CBArtifact $projectContext $record -AllowLegacy:$Recovery
    $runtime=Get-CBPublishRuntime
    $verified=Invoke-CBPublicAssets $runtime 'verify'
    $record.status='assets-verified';$record|Add-Member NoteProperty checkedAt $verified.checkedAt -Force
    $record|Add-Member NoteProperty assetVerification $verified -Force
    Write-CourseJson $recordPath $record
    return $record
}
$lock=Enter-CBFileLock (Join-Path $root '.ai-coding/cloudbase-artifact.lock')
$targetLock=$null
try{
    if($Action -eq 'Deploy' -or ($Action -eq 'Legacy' -and $Publish)){
        $key=Get-CBHash ($projectContext.EnvId+'|'+$projectContext.Url)
        $targetLock=Enter-CBFileLock (Join-Path (Get-CourseUserRoot) ('locks/cloudbase-hosting-'+$key+'.lock'))
    }
    switch($Action){
        Build {$result=Invoke-CBBuild}
        Deploy {$result=Invoke-CBDeploy}
        Verify {$result=Invoke-CBVerify}
        Recover {$result=Invoke-CBVerify -Recovery}
        Legacy {
            $result=Invoke-CBBuild
            if($Publish){$null=Invoke-CBDeploy;$result=Invoke-CBVerify}
        }
    }
    $result|ConvertTo-Json -Depth 8
}finally{if($targetLock){$targetLock.Dispose()};$lock.Dispose()}
