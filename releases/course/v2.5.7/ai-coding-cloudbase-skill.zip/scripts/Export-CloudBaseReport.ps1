﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$execution=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $execution 'scripts/Course-Context.ps1')
. (Join-Path $PSScriptRoot 'Course-CloudBaseWorkflow.ps1')
. (Join-Path $PSScriptRoot 'Course-CloudBaseReport.ps1')
$context=Get-CBProject $ProjectDirectory
$state=Read-CBState (Join-Path $context.Root '.ai-coding/cb/current.json')
if($state.envId -ne $context.EnvId -or $state.projectDirectory -ne $context.Root -or $state.runId -notmatch '^[a-f0-9]{32}$'){throw 'REPORT_TARGET_MISMATCH'}
$lease=Enter-CBFileLock (Join-Path $context.Root '.ai-coding/cb/control.lock') -WaitMs 5000
try{$state=Read-CBState (Join-Path $context.Root '.ai-coding/cb/current.json');$state=Get-CBWorkflowStatus $context $state (Join-Path $context.Root ('.ai-coding/cb/'+$state.runId.Substring(0,12)));Export-CBWorkflowReport $context $state|ConvertTo-Json}finally{$lease.Dispose()}
