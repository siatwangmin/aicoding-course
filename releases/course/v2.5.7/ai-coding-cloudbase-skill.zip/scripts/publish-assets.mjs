import {readFile,writeFile,mkdir,readdir,copyFile,lstat} from 'node:fs/promises';
import {resolve,join,dirname,relative,isAbsolute,basename} from 'node:path';
import {createHash,randomUUID} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const sha=b=>createHash('sha256').update(b).digest('hex');
const allowed=/\.(?:html?|css|js|mjs|json|png|jpe?g|webp|svg|gif|ico|woff2?|ttf|mp3|wav|ogg|mp4)$/i;
function within(root,path){const full=resolve(root,path),rel=relative(root,full);if(rel==='..'||rel.startsWith('../')||rel.startsWith('..\\')||isAbsolute(rel))throw new Error('PUBLIC_RESOURCE_ESCAPES_ROOT');return full;}
function publicName(name){if(/[\x00-\x1f\x7f]/.test(name)||name.includes('\\')||name.split('/').some(p=>p.startsWith('.')&&p!=='.nojekyll')||(!allowed.test(name)&&name!=='.nojekyll'))throw new Error('NON_PUBLIC_OR_INVALID_FILE:'+name);}
function noSecret(text){if(/(?:SILICONFLOW_API_KEY|TENCENTCLOUD_SECRET_KEY|CLOUDBASE_SECRET_KEY)\s*[=:]\s*['"]?[^\s'"<>]{12,}|\bsk-[A-Za-z0-9_-]{20,}/.test(text))throw new Error('POTENTIAL_SERVER_SECRET_IN_PUBLIC_CONTENT');}
export async function directoryManifest(dir){
 let cursor=resolve(dir);for(;;){if((await lstat(cursor)).isSymbolicLink())throw new Error('PUBLIC_LINK_REFUSED');if(cursor===dirname(cursor))break;cursor=dirname(cursor);}
 const files={};
 async function walk(path){for(const e of await readdir(path,{withFileTypes:true})){const full=join(path,e.name),rel=relative(dir,full).replaceAll('\\','/');if(e.isSymbolicLink())throw new Error('PUBLIC_LINK_REFUSED');if(e.isDirectory()){if(e.name.startsWith('.'))throw new Error('PRIVATE_PUBLIC_DIRECTORY');await walk(full);}else if(rel!=='course-publish.json'){publicName(rel);const bytes=await readFile(full);if(/\.(?:html?|css|js|mjs|json|svg)$/i.test(rel))noSecret(bytes.toString());files[rel]=sha(bytes);}}}
 await walk(dir);if(!files['index.html'])throw new Error('PUBLIC_INDEX_REQUIRED');
 return {schemaVersion:2,buildId:randomUUID(),files:Object.fromEntries(Object.entries(files).sort(([a],[b])=>a.localeCompare(b)))};
}
export async function prepareStatic({html,root,out}){
 root=resolve(root);html=within(root,html);out=resolve(out);await mkdir(out,{recursive:true});if((await readdir(out)).length)throw new Error('PUBLIC_OUTPUT_MUST_BE_EMPTY');
 const seen=new Set();
 async function copy(input,output){
  input=within(root,input);output=within(out,output);const rel=relative(out,output).replaceAll('\\','/');publicName(rel);
  if(seen.has(input))return;seen.add(input);
  // Check every ancestor for symlinks, including a linked parent outside the design folder.
  let cursor=input;for(;;){if((await lstat(cursor)).isSymbolicLink())throw new Error('PUBLIC_LINK_REFUSED');if(cursor===dirname(cursor))break;cursor=dirname(cursor);}
  const bytes=await readFile(input);await mkdir(dirname(output),{recursive:true});await copyFile(input,output);
  if(!/\.(?:html?|css|js|mjs)$/i.test(input))return;
  const text=bytes.toString();noSecret(text);
  const refs=[...text.matchAll(/(?:src|href|poster)\s*=\s*["']([^"']+)["']|url\(\s*["']?([^)'"\s]+)|(?:from\s*|import\s*\()\s*["'](\.[^"']+)["']/gi)].map(m=>m[1]||m[2]||m[3]);
  for(const m of text.matchAll(/srcset\s*=\s*["']([^"']+)["']/gi))refs.push(...m[1].split(',').map(x=>x.trim().split(/\s+/)[0]));
  for(let ref of refs){
   if(/^(?:https:|data:|blob:|#|mailto:|tel:)/i.test(ref))continue;
   if(ref.startsWith('//'))continue;
   ref=decodeURIComponent(ref.split(/[?#]/)[0]);if(!ref)continue;
   if(ref.startsWith('/')||/^[a-z]+:/i.test(ref))throw new Error('ROOT_OR_NON_HTTPS_RESOURCE_REQUIRES_REVIEW');
   const dep=within(root,resolve(dirname(input),ref));if(dep===html)continue;
   const destination=within(out,resolve(dirname(output),ref));await copy(dep,destination);
  }
 }
 await copy(html,join(out,'index.html'));await writeFile(join(out,'.nojekyll'),'');
 const manifest=await directoryManifest(out);await writeFile(join(out,'course-publish.json'),JSON.stringify(manifest,null,2)+'\n');return manifest;
}
export function validatePlatformPolicy(policy,base){
 if(!policy)return false;
 const age=Date.now()-Date.parse(policy.observedAt);
 const host=new URL(base).hostname;
 const facts=policy.facts;
 if(policy.schemaVersion!==1||policy.kind!=='cloudbase-default-domain'||!policy.envId||new URL(policy.url).href!==new URL(base).href||!Number.isFinite(age)||age< -120000||age>86400000||!['tool','command'].includes(policy.source?.kind)||!policy.source?.reference||facts?.domain!==host||facts.isDefault!==true||facts.enableSafeDomain!==true||!['STATIC_STORE','APP'].includes(facts.domainType)||!host.endsWith('.tcloudbaseapp.com')&&!host.endsWith('.app.tcloudbase.com'))throw new Error('PLATFORM_POLICY_EVIDENCE_INVALID');
 return true;
}
export async function verifyUrl(url,manifest,fetcher=fetch,{concurrency=4,platformPolicy}={}){
 if(!Number.isInteger(concurrency)||concurrency<1||concurrency>8)throw new Error('PUBLIC_CONCURRENCY_RANGE');
 const base=new URL(url.endsWith('/')?url:url+'/');if(base.protocol!=='https:'&&!(base.protocol==='http:'&&['127.0.0.1','localhost'].includes(base.hostname)))throw new Error('HTTPS_PUBLIC_URL_REQUIRED');
 if(base.username||base.password)throw new Error('PUBLIC_URL_CREDENTIALS_REFUSED');
 const knownPolicy=validatePlatformPolicy(platformPolicy,base);let htmlHeaders;
 const entries=Object.entries(manifest.files);if(!entries.length||!manifest.files['index.html'])throw new Error('PUBLIC_INDEX_REQUIRED');
 for(const [path,hash] of entries){publicName(path);if(!/^[a-f0-9]{64}$/.test(hash))throw new Error('PUBLIC_HASH_INVALID');}
 const get=async path=>{const r=await fetcher(new URL(path,base),{cache:'no-store',signal:AbortSignal.timeout(15000)});if(!r.ok)throw new Error('PUBLIC_HTTP_'+r.status);if(r.url&&(new URL(r.url).origin!==base.origin))throw new Error('PUBLIC_REDIRECT_TARGET_CHANGED');return r;};
 let remote;try{remote=await(await get('course-publish.json')).json();}catch(e){if(e instanceof SyntaxError)throw new Error('PUBLIC_MANIFEST_NOT_JSON');throw e;}if(remote.buildId!==manifest.buildId)throw new Error('REMOTE_BUILD_ID_MISMATCH');
 let cursor=0,checked=0,failure;
 async function worker(){
  while(!failure){
   const next=cursor++;if(next>=entries.length)return;
   const [path,hash]=entries[next];
   try{
    const r=await get(path.split('/').map(encodeURIComponent).join('/'));
    if(path==='index.html'){
     const contentType=r.headers.get('content-type')||'',contentDisposition=r.headers.get('content-disposition')||'';
     const attachment=/attachment/i.test(contentDisposition);
     if(!/text\/html/i.test(contentType)||attachment&&!knownPolicy)throw new Error('PUBLIC_HTML_HEADERS_INVALID');
     htmlHeaders={status:attachment?'documented-platform-policy':'verified',contentType,contentDisposition};
    }
    if(sha(Buffer.from(await r.arrayBuffer()))!==hash)throw new Error('REMOTE_CONTENT_MISMATCH:'+path);
    checked++;
   }catch(error){failure??=error;}
  }
 }
 await Promise.all(Array.from({length:Math.min(concurrency,entries.length)},worker));
 if(failure)throw failure;
 if(checked!==entries.length)throw new Error('PUBLIC_CHECK_INCOMPLETE');
 return {status:'assets-verified',buildId:manifest.buildId,url:base.href,checkedResources:checked,concurrency,htmlHeaders,browserRequired:true,browser:'pending',checkedAt:new Date().toISOString()};
}

if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const [action,...args]=process.argv.slice(2);const option=k=>args[args.indexOf(k)+1];
 try{
  let result;
  if(action==='static')result=await prepareStatic({html:option('--html'),root:option('--root'),out:option('--out')});
  else if(action==='manifest'){const dir=resolve(option('--directory'));result=await directoryManifest(dir);await writeFile(join(dir,'course-publish.json'),JSON.stringify(result,null,2)+'\n');}
  else if(action==='verify')result=await verifyUrl(option('--url'),JSON.parse(await readFile(option('--manifest'),'utf8')),fetch,{concurrency:args.includes('--concurrency')?Number(option('--concurrency')):4,platformPolicy:args.includes('--policy')?JSON.parse(await readFile(option('--policy'),'utf8')):undefined});
  else throw new Error('UNKNOWN_PUBLICATION_ACTION');
  console.log(JSON.stringify(result));
 }catch(e){console.error(e.message);process.exitCode=1;}
}
