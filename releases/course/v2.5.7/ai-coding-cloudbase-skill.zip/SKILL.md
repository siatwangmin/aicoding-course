---
name: ai-coding-cloudbase
description: 在当前目录准备或恢复 CloudBase 账号与授权；在已选择云端能力的作品中实现数据、权限、存储、函数、托管和受保护的 AI 后端。
---

# 当前项目的 CloudBase 能力

本技能为用户级，准备与各项目按当前任务调用。先读当前根 AGENTS、manifest/services 与进度，核模式和精确目标。MCP/CLI可能共享登录，但每次云操作必须核当前作品的环境、身份和授权范围，不使用其他作品绑定。

准备模式读取 [账号与环境准备](references/account-preparation.md)，复用本人账号、实名、官方接入及可用PG环境，保存公开连接值并返回 env 汇总。此模式不创建业务表/函数、不部署作品，不要求模型供应商账号或调用。

项目模式：直接调用本用户级技能，必要时用 Enable-ProjectCapability 登记当前项目绑定；先按 [官方技能路由](references/official-routing.md) 读取当前需要的本地域技能，再按 [云端实施](implementation/cloudbase.md) 连续完成复查、补缺、最小链路、页面接线、构建发布与独立会话验收。复用已安装的官方技能及已登记 MCP/CLI，不重复安装或搬动作用域，不把 SDK 存在当工具授权通过。

项目接入/部署先读 [并行与后台工作流](implementation/parallel-workflow.md)。先执行 scripts/Invoke-CloudBaseWorkflow.ps1 -Action Measure 记录本轮起点，再按首次接入、恢复、前端更新选择计划样例；Plan/Status 只读，Start/Resume 后台自动推进已授权本地节点。外部任务先 Begin，再按 [提示词模板](references/workflow-prompts.md) 完成实际 MCP/页面/浏览器动作并 Record；资源、接口契约准备、会话准备按依赖并行，同一资源写操作串行。缺项和原始错误直接看 nextActions/diagnostic，结果未知先查询原任务。

预检只读所需元数据，使用 [查询与差异模板](references/preflight-queries.md) 和现有资源比较脚本，不从头试接口。首次前端发布按当前官方入口发现目标，更新保留既有目标。默认域名响应头按本轮官方查询证据显式适配，文件摘要与真实浏览器分开验证；不关闭平台安全提示。需要登录的作品在计划启用 login，提前核可用账号及安全交付来源，正确登录后再交付，不把密码写入普通日志。

工作流自动生成本轮 measurement.json/report.md；等待和排障使用 scripts/Write-CloudBaseEvent.ps1，必要时 scripts/Export-CloudBaseReport.ps1 重新汇总。报告区分部署、文件、浏览器、业务和本人试用，重叠不重复计时，缺测不推算；后台心跳和任务受理不代表完成。当前本地工作流能力见 assets/workflow-contract.json。

Web 的 PG 数据与图片接入可参考 [最小接入范例](references/web-pg-example.md)，使用实际锁定版本与现有表/桶；业务数据优先 app.rdb()，PG 图片使用 app.storage.from(bucket)，不因需要同步就自动增加云函数。AI 或其他确需服务端能力的任务继续走下述后端路线。执行开始与接续读取 [阶段记录](implementation/efficient-execution.md)，保留实际耗时和下一动作。

页面接线、构建排障和浏览器验收读取 [通用 Web 检查](references/web-verification.md)：检查异步返回契约，定位首个源码错误，使用真实目标与有效控件，区分模拟失败、实际请求失败和独立会话证据。只验证当前要求，缺证据不报全部通过。

需要 AI 时才读 [AI服务设置](implementation/ai-service-setup.md)、[模型设置](implementation/model-settings.md) 与 [AI实施](implementation/ai.md)。本人在已实现的受保护设置中输入供应商Key，服务端受限保存；账号与调用仅属于当前AI需求，不是环境或纯本地初始化门槛。默认配置见 assets/default-models.json，保留已有供应商和有效模型，不自动换平台或充值。

Web/APK callFunction→CloudBase函数→项目已配置模型服务，秘密不进入前端/Git/APK/镜像/日志。AI私有配置先按 [服务身份](implementation/ai-settings-access.md) 验证后端PG访问与指定配置用户授权，不因管理工具可用就放宽应用权限。

网页发布使用 scripts/Publish-CloudBase.ps1 与已确认官方路线，核本轮产物和真实访问地址。CloudBase 静态托管承载前端，数据库与存储承担共享数据；只发布网页不等于同步已实现。纯静态展示发布到 GitHub.io 调用 ai-coding-github，已有托管目标按项目绑定保留。每次首次、更新或恢复部署后，在完成回复给出完整https网址和可点击链接，说明状态；控制台或旧网址不能代替本轮作品入口。访问、真实读写/同步、模型结果及本人试用分别验证。

授权失效或访问异常只补当前缺项；权限分管理授权、应用会话、GRANT/RLS与归属，不放开匿名写、关闭RLS/TLS或重建环境。实际SDK/CLI版本适配读取 references/management-operations.md。更新项目Spec、证据与进度，再接续原任务。
