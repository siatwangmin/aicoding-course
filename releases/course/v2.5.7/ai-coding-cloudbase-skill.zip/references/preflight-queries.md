# 统一预检与查询模板

输入：当前B的服务绑定、实际源码契约、所需能力、已登记官方工具。输出：可复用项、真实缺项、任务依赖、下一动作。查询不变更资源，不把SDK已安装当管理授权。

按所需能力选择，独立只读查询可并行；同一资源的迁移、权限和上传写入串行。表名、字段、桶名由当前源码与Spec提供，不枚举无关业务数据。

| 检查 | 当前官方工具形状 | 完成依据 |
| --- | --- | --- |
| 管理身份/目标 | auth(status)，核服务envId；必要时auth(set_env) | 当前环境/地域与项目一致，授权实际可用。 |
| 数据模式 | queryEnv(info,envId=实际ID) | 真实RuntimeBackends；不将PG切到NoSQL/MySQL。 |
| 表与字段 | queryPgDatabase(schema,objectName=实际schema.table) | 精确字段、约束、索引与RLS；只读权限查询可用information_schema.table_privileges，避免将INSERT等词拼进不必要的字符串表达式。 |
| 归属策略 | queryPgDatabase(sql, SELECT policyname,roles,cmd,qual,with_check FROM pg_policies WHERE schemaname=实际schema AND tablename=实际表) | 当前策略、角色与归属符合本项目；管理查询不替代应用会话实测。 |
| PG图片桶 | queryPgStorage(buckets)或官方PG元数据查询 | 实际pgstore桶；不以旧COS桶代替。 |
| 登录 | queryAppAuth(getLoginConfig)，已有账号通过实际CLI/官方账号管理查询 | 方式可用、账号存在、有授权安全凭据来源；没有则按已授权范围补齐，不删除别人账号或改密码。 |
| 已有托管 | queryHosting(status/websiteConfig) | 当前目标、首页/路由配置；findFiles必须传实际非空前缀，列全部用listFiles。 |
| 默认域名策略 | queryGateway(getRoute,domain=实际域名,path=实际路径) | 返回的domainType/isDefault/enableSafeDomain归一化为platform-policy.json事实，填实际观察时间与来源。 |
| 首次前端目标 | 当前官方技能的manageApps/部署计划入口 | 官方实际支持的目标与真实URL；已有托管更新保持原路线。 |

CLI路线先核实际help，用明确envId做等价查询；不为并行改用另一套工具。官方接口版本变化以当前schema/help为准。

将所需事实归一化为 assets/examples/observed-resources.json 的形状，资源契约沿 desired-resources.json；执行Compare-CloudBaseResources输出reuse/create/review-update，只补已确认差异并查回。迁移与权限使用当前官方技能，不盲目套通用建表SQL。

每个外部阶段先Begin，真实操作后Record。若平台返回TaskId，用同一任务记录running和后续终态；结果未知先查询。资源、SDK接口契约准备和会话准备可并行，实际字段及权限就绪后完成接线和最小链路。
