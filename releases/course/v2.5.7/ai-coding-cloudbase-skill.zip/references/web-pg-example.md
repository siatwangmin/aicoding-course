# Web PG 最小接入范例

用途：给已有 Web 工程接云端数据与图片时复用，按 [云端实施](../implementation/cloudbase.md) 先查现有资源与登录方式。此范例不创建账号、表或桶，不部署，不自动加入新项目；仅在启用 PG 业务能力时按现有 Repository 适配。

方法来自已有工程使用的 Web SDK v3 路线；当前标准 app 锁定 `@cloudbase/js-sdk 3.10.0`。对应 API 的依据见 [官方技能路由](official-routing.md)，不同版本先核实际方法与返回结构，普通修复不临时升级依赖。示例代码见 [web-pg-client.mjs](../assets/examples/web-pg-client.mjs)，不替换项目现有客户端或会话封装。

## 集中适配一次

从当前项目配置向 `createWebPgAccess({ envId, publishableKey })` 传入公开连接值，在一个模块创建并复用客户端；例如由现有 Vite 环境变量 `VITE_CLOUDBASE_ENV_ID` / `VITE_CLOUDBASE_PUBLISHABLE_KEY` 提供。管理/API Key 和用户密码不放构建配置、示例或日志，本地数据模式不启动云登录。

示例按已选择的用户名密码模式提供：

| 方法 | 用途及前提 |
| --- | --- |
| `restoreSession()` | 读 `auth.getSession()`；返回有效非匿名会话或 null，检查 `error`。用户归属按实际 session.user.id 与现有策略核对 |
| `signIn(username, password)` | 用官方 SDK 登录，检查响应错误及真实会话；只在应用明确选择的登录流程调用，不尝试一批 HTTP 地址 |
| `readPage(table, from, to)` | 用 app.rdb().from(table).select('*').range(from, to) 读取当前会话可见行；实际列表补稳定排序/分页 |
| `insertAndRead(table, row, keyColumn, keyValue)` | 示例先写再按已核唯一键回读，避免依赖某版本 insert().select() 的返回行为；表须已有对应唯一约束和 SELECT/INSERT 权限 |
| `uploadPrivateImage(bucket, key, file)` | 向实际 PG 桶上传，再生成临时签名链接；示例沿已验证的 `data.fullSignedURL` 读取，不猜字段 |

物理表名、字段与行到业务对象的映射来自当前 schema，不从 UI 名称推断。若 owner 列已有 `DEFAULT auth.uid()`，插入时沿已有默认；不要由浏览器任意指定别人的 UID。更新/删除沿官方 PG 子技能的 `.update(...).eq(...)` / `.delete().eq(...)`，检查每次 error 和实际影响结果；已有适配可直接复用，不为套范例重写。

图片 key 是桶内路径，不重复桶名。现有策略若按首段 UID 限制，使用当前真实 session.user.id 加项目既定对象标识；重新打开或跨会话读取时按保存的 bucket/key 重新签名，不把过期签名 URL 当唯一持久数据。公开图片沿项目现有公开策略，不能把私有桶改公开来套示例。

## 失败和最小验证

提交前保留同一个请求标识、唯一业务键、所选文件和对象路径。上传成功但写表失败时先查实际行/对象；写入超时也可能已成功，重试前按唯一键查询确认。示例不会自动重试或删除对象：由 Repository 按项目确定的幂等/补偿方式接续，不直接连续再调用 insert。共享资源只清理本轮有明确 ID 的测试对象。

先通过真实页面登录，再保存并回读一条虚构记录、上传并重新打开一张小图；相关权限失败按会话→表/桶→GRANT/RLS→归属定位。UI 仅在实际成功后按设计处理输入，失败不清空；日志只保留阶段与脱敏错误，不打印 SDK 原始响应、密码或 token。

这些是可复用调用形态，代码语法或打包校验不能证明当前云环境已通过。项目实施仍须取得真实应用会话、读写、图片、独立窗口同步及相应拒绝访问证据，再报告联网完成。

页面异步保存可参考 [repository-adapter.mjs](../assets/examples/repository-adapter.mjs)：同一次提交持有稳定 requestId、对象路径和 intent，重复点击共享 Promise；结果未知后由下一次明确重试先查询已有记录，复用已确认上传的对象。lookup/writeAndRead/upload 回调按实际 Repository 实现，唯一请求键须有已核数据库约束；upload 回调还须按同一对象路径查证上传结果未知的情况。此模板不自动重试、清理共享对象、创建表或替换业务组件。
