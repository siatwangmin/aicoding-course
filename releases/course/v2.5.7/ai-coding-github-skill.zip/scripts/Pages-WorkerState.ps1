﻿#Requires -Version 5.1
# Dependency-free startup evidence, loaded before the execution package.
function Get-PagesWorkerStatePath([string]$Root,[string]$PublicationId) {
    if($PublicationId -cnotmatch '^[a-f0-9]{32}$'){throw 'PAGES_WORKER_PUBLICATION_INVALID'}
    $rootPath=[IO.Path]::GetFullPath($Root).TrimEnd('\')
    $path=Join-Path $rootPath ('.local/pages-jobs/'+$PublicationId+'/worker-state.json')
    $cursor=Split-Path $path -Parent
    while($cursor){
        if((Test-Path -LiteralPath $cursor) -and ([IO.File]::GetAttributes($cursor) -band [IO.FileAttributes]::ReparsePoint)){throw 'PAGES_WORKER_LINK_REFUSED'}
        $cursor=Split-Path $cursor -Parent
    }
    return $path
}
function Write-PagesWorkerState([string]$Root,[string]$PublicationId,[string]$Phase,[string]$Code='') {
    $path=Get-PagesWorkerStatePath $Root $PublicationId
    [void](New-Item -ItemType Directory -Path (Split-Path $path -Parent) -Force)
    $process=Get-Process -Id $PID
    $state=@{publicationId=$PublicationId;processId=$PID;startTicks=$process.StartTime.ToUniversalTime().Ticks.ToString();phase=$Phase;at=[DateTimeOffset]::UtcNow.ToString('o');errorCode=$Code}
    $temp=$path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
    [IO.File]::WriteAllText($temp,($state|ConvertTo-Json -Compress),[Text.UTF8Encoding]::new($false))
    $backup=$temp+'.backup'
    try {if(Test-Path -LiteralPath $path){[IO.File]::Replace($temp,$path,$backup)}else{[IO.File]::Move($temp,$path)}}
    finally {foreach($file in @($temp,$backup)){if(Test-Path -LiteralPath $file){[IO.File]::Delete($file)}}}
}
function Read-PagesWorkerState([string]$Root,[string]$PublicationId) {
    $path=Get-PagesWorkerStatePath $Root $PublicationId
    if(-not(Test-Path -LiteralPath $path)){return $null}
    if([IO.File]::GetAttributes($path) -band [IO.FileAttributes]::ReparsePoint){throw 'PAGES_WORKER_LINK_REFUSED'}
    $stream=$null;$reader=$null
    try {
        $stream=[IO.File]::Open($path,[IO.FileMode]::Open,[IO.FileAccess]::Read,([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
        $reader=[IO.StreamReader]::new($stream,[Text.Encoding]::UTF8,$true)
        return $reader.ReadToEnd()|ConvertFrom-Json
    } finally {if($reader){$reader.Dispose()}elseif($stream){$stream.Dispose()}}
}
function Update-PagesWorkerHeartbeat([string]$Phase) {
    if($global:AiCodingPagesWorkerContext){Write-PagesWorkerState $global:AiCodingPagesWorkerContext.root $global:AiCodingPagesWorkerContext.publicationId $Phase}
}
