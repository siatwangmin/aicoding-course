﻿#Requires -Version 5.1
# Pure helpers. The caller imports the recorded execution package, never a new toolchain.
. (Join-Path $PSScriptRoot 'Pages-WorkerState.ps1')
function Start-PagesTiming([string]$Stage) {
    if(-not $env:AI_CODING_PAGES_TIMING_DIRECTORY){return $null}
    return @{id=[guid]::NewGuid().ToString('N');stage=$Stage;startedAt=[DateTimeOffset]::UtcNow.ToString('o');watch=[Diagnostics.Stopwatch]::StartNew()}
}
function Stop-PagesTiming($Span,[string]$Status='completed') {
    if(-not $Span){return}
    $directory=$env:AI_CODING_PAGES_TIMING_DIRECTORY;Assert-CoursePlainPath $directory
    [void](New-Item -ItemType Directory -Path $directory -Force)
    $event=@{id=$Span.id;stage=$Span.stage;startedAt=$Span.startedAt;endedAt=[DateTimeOffset]::UtcNow.ToString('o');elapsedSeconds=[math]::Round($Span.watch.Elapsed.TotalSeconds,3);status=$Status;processId=$PID}
    Write-CourseJson (Join-Path $directory ($Span.id+'.json')) $event
}
function Invoke-PagesNative($Exe,[string[]]$Arguments,[int]$Timeout=30,[string]$Root) {
    $operation=if($Arguments[0] -eq '-C'){$Arguments[2]}else{$Arguments[0]}
    $span=Start-PagesTiming ('native.'+[IO.Path]::GetFileNameWithoutExtension($Exe)+'.'+$operation)
    $outcome='failed'
    try {
        $r=Invoke-SetupNative $Exe $Arguments $Timeout $Root
        if($r.ExitCode -ne 0){throw 'PAGES_COMMAND_FAILED: inspect identity, permissions or network; no automatic repeated mutation.'}
        $outcome='completed';return $(if($r.Stdout){$r.Stdout}else{$r.Output})
    } finally {Stop-PagesTiming $span $outcome}
}

function Get-PagesTarget([string]$Gh,[string]$Repository,[string]$Root,[string]$Branch) {
    [void](Invoke-PagesNative $Gh @('auth','status') 30 $Root)
    $identity=(Invoke-PagesNative $Gh @('api','user','--jq','.login') 30 $Root).Trim()
    if($identity -ine $Repository.Split('/')[0]){throw 'PAGES_IDENTITY_MISMATCH'}
    $target=(Invoke-PagesNative $Gh @('api',('repos/'+$Repository)) 30 $Root)|ConvertFrom-Json
    if(-not $Branch){$Branch=$target.default_branch}
    if($target.full_name -ine $Repository -or $Branch -notmatch '^[a-zA-Z0-9/_-]+$'){throw 'PAGES_TARGET_MISMATCH'}
    if(-not $target.permissions.push -and -not $target.permissions.admin){throw 'PAGES_PUSH_PERMISSION_REQUIRED'}
    [void](Get-CoursePagesConfiguration $Gh $Repository $Branch $Root)
    return [pscustomobject]@{identity=$identity;branch=$Branch}
}

function Get-PagesReadIdentity([string]$Gh,[string]$Repository,[string]$Root,[string]$ExpectedIdentity) {
    # A read-only worker needs a current identity, not another push-permission preflight.
    $identity=(Invoke-PagesNative $Gh @('api','user','--jq','.login') 30 $Root).Trim()
    if($identity -ine $Repository.Split('/')[0] -or ($ExpectedIdentity -and $identity -ine $ExpectedIdentity)){throw 'PAGES_IDENTITY_MISMATCH'}
    return $identity
}

function Start-PagesPreflight([string]$ExecutionRoot,[string]$Scripts,[string]$Gh,[string]$Repository,[string]$Root,[string]$Branch) {
    $runner=[PowerShell]::Create()
    try {
        [void]$runner.AddScript({
            param($execution,$scripts,$gh,$repository,$root,$branch)
            $ErrorActionPreference='Stop'
            . (Join-Path $execution 'scripts/Course-Native.ps1')
            . (Join-Path $scripts 'GitHub-Pages.ps1')
            . (Join-Path $scripts 'Pages-Publication.ps1')
            $span=Start-PagesTiming 'remote-preflight'
            $outcome='failed'
            try {$result=Get-PagesTarget $gh $repository $root $branch;$outcome='completed';return $result}
            finally {Stop-PagesTiming $span $outcome}
        }).AddArgument($ExecutionRoot).AddArgument($Scripts).AddArgument($Gh).AddArgument($Repository).AddArgument($Root).AddArgument($Branch)
        return @{runner=$runner;handle=$runner.BeginInvoke()}
    } catch {$runner.Dispose();throw}
}

function Complete-PagesPreflight($Task) {
    try {
        $result=@($Task.runner.EndInvoke($Task.handle))
        if($Task.runner.HadErrors -or $result.Count -ne 1){throw 'PAGES_PREFLIGHT_FAILED: inspect the current account, repository permissions and Pages source.'}
        return $result[0]
    } finally {$Task.runner.Dispose()}
}

function Enter-PagesLease([string]$Root,[int]$WaitSeconds=0) {
    $path=Join-Path $Root 'docs/progress/pages-publish.lock';Assert-CoursePlainPath $path
    [void](New-Item -ItemType Directory -Path (Split-Path $path -Parent) -Force)
    $clock=[Diagnostics.Stopwatch]::StartNew()
    do {
        try{return [IO.File]::Open($path,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}
        catch [IO.IOException] {if($clock.Elapsed.TotalSeconds -ge $WaitSeconds){throw 'PAGES_PUBLICATION_BUSY: query -Status; do not start another writer.'};Start-Sleep -Milliseconds 200}
    } while($true)
}

function Read-PagesRecord([string]$Root) {
    $path=Join-Path $Root 'docs/progress/pages-publish.json';Assert-CoursePlainPath (Split-Path $path -Parent)
    # Windows readers must allow replacement while the sole writer atomically updates the snapshot.
    for($attempt=0;$attempt -lt 5;$attempt++){
        $stream=$null;$reader=$null
        try {
            # FileInfo can cache Attributes=-1 if replacement removes its old leaf.
            # Query the leaf directly instead of interpreting that value as a link.
            $attributes=[IO.File]::GetAttributes($path)
            if([int]$attributes -eq -1){throw [IO.IOException]::new('Snapshot temporarily unavailable.')}
            if($attributes -band [IO.FileAttributes]::ReparsePoint){throw 'PAGES_SNAPSHOT_LINK_REFUSED'}
            $stream=[IO.File]::Open($path,[IO.FileMode]::Open,[IO.FileAccess]::Read,([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
            $reader=[IO.StreamReader]::new($stream,[Text.Encoding]::UTF8,$true)
            $text=$reader.ReadToEnd()
            return $text|ConvertFrom-Json
        } catch {
            # A Windows replacement/scan may briefly hide the leaf. Never retry corrupt JSON.
            if($attempt -eq 4 -or $_.Exception.GetBaseException() -isnot [IO.IOException]){throw}
            Start-Sleep -Milliseconds (20*($attempt+1))
        } finally {if($reader){$reader.Dispose()}elseif($stream){$stream.Dispose()}}
    }
}

function Save-PagesRecord([string]$Root,$Record) {
    if($Record.publicationId -and $Record.publicationId -cnotmatch '^[a-f0-9]{32}$'){throw 'PAGES_PUBLICATION_ID_INVALID'}
    $Record|Add-Member NoteProperty checkedAt ([DateTimeOffset]::UtcNow.ToString('o')) -Force
    if($Record.startedAt){$Record|Add-Member NoteProperty elapsedSeconds ([math]::Round(([DateTimeOffset]::UtcNow-[DateTimeOffset]::Parse($Record.startedAt)).TotalSeconds,1)) -Force}
    $transitions=@($Record.transitions)
    if(-not $transitions.Count -or $transitions[-1].status -cne $Record.status){
        $transitions=@($transitions|Where-Object {$_})+@(@{status=$Record.status;at=$Record.checkedAt})
        $Record|Add-Member NoteProperty transitions @($transitions|Select-Object -Last 128) -Force
    }
    if($Record.status -eq 'assets-verified' -and $Record.checks.deployment -eq 'passed' -and $Record.checks.assets -eq 'passed' -and -not $Record.technicalCompletedAt){
        $Record|Add-Member NoteProperty technicalCompletedAt $Record.checkedAt -Force
        $Record|Add-Member NoteProperty technicalElapsedSeconds $Record.elapsedSeconds -Force
    }
    # Per-publication snapshots preserve earlier runs. Both files use atomic JSON replacement.
    if($Record.publicationId){Write-CourseJson (Join-Path $Root ('docs/progress/pages-runs/'+$Record.publicationId+'.json')) $Record}
    Write-CourseJson (Join-Path $Root 'docs/progress/pages-publish.json') $Record
}

function Write-PagesResult([string]$Root,$Record,[switch]$FullRecord) {
    if($FullRecord){$Record|ConvertTo-Json -Depth 20;return}
    [pscustomobject][ordered]@{
        status=$Record.status;url=$Record.url;elapsedSeconds=$Record.elapsedSeconds;technicalElapsedSeconds=$Record.technicalElapsedSeconds
        publicationId=$Record.publicationId;repository=$Record.repository;commit=$Record.commit;checks=$Record.checks
        workerActive=(Test-PagesWorker $Record);worker=$Record.worker;workerHealth=(Get-PagesWorkerHealth $Root $Record)
        diagnosticPath=$Record.diagnosticPath;workerFallback=$Record.workerFallback
        runtimeContextReused=$Record.runtimeContextReused;timingDirectory=$Record.timingDirectory
        recordPath=(Join-Path $Root 'docs/progress/pages-publish.json');errorCode=$Record.errorCode
    }|ConvertTo-Json -Depth 8
}

function Test-PagesWorker($Record) {
    if(-not $Record.worker -or -not $Record.worker.processId){return $false}
    $process=Get-Process -Id $Record.worker.processId -ErrorAction SilentlyContinue
    return [bool]($process -and $process.StartTime.ToUniversalTime().Ticks.ToString() -eq $Record.worker.startTicks)
}

function Get-PagesWorkerHealth([string]$Root,$Record) {
    if(-not $Record.worker){return 'not-started'}
    $state=Read-PagesWorkerState $Root $Record.publicationId
    $matches=$state -and $state.publicationId -ceq $Record.publicationId -and $state.processId -eq $Record.worker.processId -and $state.startTicks -ceq $Record.worker.startTicks
    if(-not(Test-PagesWorker $Record)){
        if($matches -and $state.phase -eq 'stopped'){return 'stopped'}
        return 'exited'
    }
    if(-not $matches){return 'starting'}
    if($state.phase -eq 'failed'){return 'failed'}
    $age=([DateTimeOffset]::UtcNow-[DateTimeOffset]::Parse($state.at)).TotalSeconds
    if($age -gt 45 -and $state.phase -ne 'verifying-assets'){return 'heartbeat-delayed'}
    return $state.phase
}

function Assert-PagesRecord([string]$Root,[string]$Repository,$Record) {
    if($Record.repository -ine $Repository -or $Record.commit -cnotmatch '^[a-f0-9]{40,64}$' -or $Record.branch -notmatch '^[a-zA-Z0-9/_-]+$'){throw 'PAGES_RECOVERY_IDENTITY_INVALID'}
    $out=[IO.Path]::GetFullPath($Record.stagingDirectory);Assert-CoursePlainPath $out
    if(-not $out.StartsWith((Join-Path $Root '.local/pages-stage/'),[StringComparison]::OrdinalIgnoreCase)){throw 'PAGES_STAGING_PATH_INVALID'}
    $path=Join-Path $out 'course-publish.json';$manifest=Read-CourseJson $path
    if($manifest.buildId -cne $Record.buildId -or ($Record.manifestSha256 -and (Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant() -cne $Record.manifestSha256)){throw 'PAGES_MANIFEST_CHANGED'}
}

function Assert-PagesRemoteCommit([string]$Gh,$Record,[string]$Root) {
    $head=(Invoke-PagesNative $Gh @('api',('repos/'+$Record.repository+'/git/ref/heads/'+$Record.branch),'--jq','.object.sha') 30 $Root).Trim()
    if($head -cne $Record.commit){throw 'PAGES_REMOTE_HEAD_CHANGED: preserve the original publication; no new push performed.'}
}

function Test-PagesAssets($Context,$Record,[int]$Timeout=180) {
    if($Context.ImageId -cnotmatch '^(sha256:)?[a-f0-9]{64}$'){throw 'PAGES_VERIFIED_IMAGE_REQUIRED'}
    $arguments=$Context.Prefix+@('run','--rm','--pull=never','--mount',("type=bind,source="+$Record.stagingDirectory+",target=/public,readonly"),'--mount',("type=bind,source="+$PSScriptRoot+",target=/course,readonly"),'--entrypoint','node',$Context.ImageId,'/course/publish-assets.mjs','verify','--url',$Record.url,'--manifest','/public/course-publish.json')
    $span=Start-PagesTiming 'online-assets-verification'
    $outcome='failed'
    try {$result=Invoke-SetupNative $Context.Cli $arguments $Timeout $Context.Root;if($result.ExitCode -eq 0){$outcome='completed'};return $result}
    finally {Stop-PagesTiming $span $outcome}
}

function Invoke-PagesMonitor($Context,[string]$Gh,$Record,[int]$WaitSeconds=600,[int]$PollSeconds=10) {
    $root=$Context.Root;$watch=[Diagnostics.Stopwatch]::StartNew();$networkFailures=0
    $waitSpan=Start-PagesTiming 'pages-platform-wait'
    Update-PagesWorkerHeartbeat 'checking'
    Assert-PagesRemoteCommit $Gh $Record $root
    if(-not(Get-CoursePagesConfiguration $Gh $Record.repository $Record.branch $root)){throw 'PAGES_SITE_CONFIGURATION_MISSING'}
    $Record.status='deployment-pending';Save-PagesRecord $root $Record
    do {
        Update-PagesWorkerHeartbeat 'waiting-build'
        $last=Invoke-SetupNative $Gh @('api',('repos/'+$Record.repository+'/pages/builds/latest')) 30 $root
        if($last.ExitCode -eq 0){
            $networkFailures=0;$build=$(if($last.Stdout){$last.Stdout}else{$last.Output})|ConvertFrom-Json
            if($build.commit -ceq $Record.commit -and $build.status -eq 'errored'){
                Stop-PagesTiming $waitSpan 'failed';$waitSpan=$null
                $Record.checks.deployment='failed';$Record.status='deployment-failed';$Record.errorCode='PAGES_BUILD_FAILED';Save-PagesRecord $root $Record;return $Record
            }
            if($build.commit -ceq $Record.commit -and $build.status -eq 'built'){
                Stop-PagesTiming $waitSpan;$waitSpan=$null
                Assert-PagesRemoteCommit $Gh $Record $root
                $Record.checks.deployment='passed';$Record.status='verifying-assets';Save-PagesRecord $root $Record
                Update-PagesWorkerHeartbeat 'verifying-assets'
                $verified=Test-PagesAssets $Context $Record ([math]::Max(1,[math]::Min(180,$WaitSeconds-[int]$watch.Elapsed.TotalSeconds)))
                if($verified.ExitCode -eq 0){
                    # A successful process alone is insufficient: require the expected result identity.
                    $proof=$(if($verified.Stdout){$verified.Stdout}else{$verified.Output})|ConvertFrom-Json
                    if($proof.status -cne 'assets-verified' -or $proof.buildId -cne $Record.buildId -or $proof.url -cne $Record.url){throw 'PAGES_ASSET_PROOF_MISMATCH'}
                    Assert-PagesRemoteCommit $Gh $Record $root
                    $Record.checks.assets='passed';$Record.status='assets-verified';$Record.errorCode=$null
                    Save-PagesRecord $root $Record;return $Record
                }
                # CDN propagation can lag the build. Retry only verification, never push or enablement.
                $Record.checks.assets='pending';$Record.errorCode='PAGES_ASSETS_NOT_YET_VERIFIED';Save-PagesRecord $root $Record
            }
        } else {
            $networkFailures++
            if(($last.Output+' '+$last.Stderr) -match 'HTTP (401|403)'){throw 'PAGES_QUERY_AUTHORIZATION_FAILED'}
            if($networkFailures -ge 3){$Record.errorCode='PAGES_QUERY_UNAVAILABLE';break}
        }
        $remaining=$WaitSeconds-$watch.Elapsed.TotalSeconds
        if($remaining -le 0){break}
        Start-Sleep -Milliseconds ([int]([math]::Min($PollSeconds,$remaining)*1000))
    } while($watch.Elapsed.TotalSeconds -lt $WaitSeconds)
    $Record.status=if($Record.checks.deployment -eq 'passed'){'assets-pending'}else{'deployment-pending'}
    Stop-PagesTiming $waitSpan 'pending'
    Save-PagesRecord $root $Record;return $Record
}

function Start-PagesMonitor([string]$Root,[string]$Entry,$Record,[int]$WaitSeconds,[int]$StartupSeconds=5) {
    $directory=Join-Path $Root ('.local/pages-jobs/'+$Record.publicationId);Assert-CoursePlainPath $directory
    [void](New-Item -ItemType Directory -Path $directory -Force)
    $shell=Join-Path $PSHOME 'powershell.exe';if(-not(Test-Path -LiteralPath $shell)){$shell=Join-Path $PSHOME 'pwsh.exe'}
    $watcher=Join-Path (Split-Path $Entry -Parent) 'Watch-Pages.ps1'
    $log=Join-Path $directory ('worker-'+[guid]::NewGuid().ToString('N')+'.log')
    $span=Start-PagesTiming 'background-startup'
    # Redirect inside the detached child, before Watch-Pages parameter binding/imports.
    # EncodedCommand preserves spaces/quotes and avoids inherited caller pipes.
    $bootstrap="& { `$ErrorActionPreference='Stop'; try { & '"+$watcher.Replace("'","''")+"' -ProjectDirectory '"+$Root.Replace("'","''")+"' -ExpectedPublicationId '"+$Record.publicationId+"' -WaitSeconds "+$WaitSeconds+" } catch { `$code=(`$_.Exception.Message -split ':')[0]; if(`$code -cnotmatch '^[A-Z][A-Z_]+$'){`$code='PAGES_WORKER_BOOTSTRAP_FAILED'}; Write-Output `$code; exit 1 } } *> '"+$log.Replace("'","''")+"'"
    $encoded=[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($bootstrap))
    $process=Start-Process -FilePath $shell -ArgumentList @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-EncodedCommand',$encoded) -WorkingDirectory $Root -Verb Open -WindowStyle Hidden -PassThru
    $Record|Add-Member NoteProperty worker @{processId=$process.Id;startTicks=$process.StartTime.ToUniversalTime().Ticks.ToString();log=$log;launchStatus='starting'} -Force
    Save-PagesRecord $Root $Record
    $clock=[Diagnostics.Stopwatch]::StartNew()
    do {
        $state=Read-PagesWorkerState $Root $Record.publicationId
        if($state -and $state.processId -eq $process.Id -and $state.startTicks -ceq $Record.worker.startTicks -and $state.phase -eq 'ready'){
            $Record.worker.launchStatus='ready';Save-PagesRecord $Root $Record;Stop-PagesTiming $span;return $true
        }
        if(-not(Test-PagesWorker $Record)){
            $Record.worker.launchStatus='exited';Save-PagesRecord $Root $Record;Stop-PagesTiming $span 'exited';return $false
        }
        Start-Sleep -Milliseconds 50
    } while($clock.Elapsed.TotalSeconds -lt $StartupSeconds)
    # An alive but slow startup remains observable; never launch a second live worker.
    $Record.worker.launchStatus='starting';Save-PagesRecord $Root $Record
    Stop-PagesTiming $span 'starting';return $true
}
