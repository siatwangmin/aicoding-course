﻿#Requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$ProjectDirectory,
    [ValidateRange(1,60)][int]$WaitSeconds=30,
    [switch]$AutoRecover
)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $executionRoot 'scripts/Course-ProjectRoot.ps1')
. (Join-Path $PSScriptRoot 'Pages-Publication.ps1')
$root=Resolve-CourseProjectRoot $ProjectDirectory
$first=Read-PagesRecord $root;$identity=$first.publicationId;$commit=$first.commit
$clock=[Diagnostics.Stopwatch]::StartNew()
do {
    $record=Read-PagesRecord $root
    if($record.publicationId -cne $identity -or $record.commit -cne $commit){throw 'PAGES_WAIT_PUBLICATION_CHANGED'}
    if($record.status -in @('assets-verified','removed','deployment-failed','check-failed','preparation-failed')){break}
    $health=Get-PagesWorkerHealth $root $record
    if($AutoRecover -and $record.commit -and $record.worker -and $health -eq 'exited'){
        $claim=Join-Path $root ('.local/pages-jobs/'+$identity+'/automatic-recovery.json')
        $lease=Enter-PagesLease $root
        try {
            $current=Read-PagesRecord $root
            if($current.publicationId -cne $identity -or $current.commit -cne $commit){throw 'PAGES_WAIT_PUBLICATION_CHANGED'}
            $recover=-not(Test-PagesWorker $current) -and -not(Test-Path -LiteralPath $claim)
            if($recover){Write-CourseJson $claim @{publicationId=$identity;commit=$commit;attempts=1;at=[DateTimeOffset]::UtcNow.ToString('o')}}
        } finally {$lease.Dispose()}
        if($recover){$ignored=& (Join-Path $PSScriptRoot 'Publish-Pages.ps1') -ProjectDirectory $root -Recover -Background -ExpectedPublicationId $identity}
        else {break}
    } elseif($health -in @('exited','stopped','not-started')){break}
    if($clock.Elapsed.TotalSeconds -ge $WaitSeconds){break}
    Start-Sleep -Milliseconds 250
} while($true)
Write-PagesResult $root (Read-PagesRecord $root)
