﻿#Requires -Version 5.1
# The launch bootstrap captures output before this file's parameter binding or imports.
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$ProjectDirectory,
    [Parameter(Mandatory=$true)][ValidatePattern('^[a-f0-9]{32}$')][string]$ExpectedPublicationId,
    [ValidateRange(1,900)][int]$WaitSeconds=600
)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Pages-WorkerState.ps1')
$global:AiCodingPagesWorkerContext=@{root=$ProjectDirectory;publicationId=$ExpectedPublicationId}
try {
    Write-PagesWorkerState $ProjectDirectory $ExpectedPublicationId 'starting'
    . (Join-Path $PSScriptRoot 'Course-Execution.ps1')
    $executionRoot=Resolve-CourseExecutionRoot $ProjectDirectory
    . (Join-Path $executionRoot 'scripts/Course-ProjectRoot.ps1')
    $root=Resolve-CourseProjectRoot $ProjectDirectory
    $current=Read-CourseJson (Join-Path $root 'docs/progress/pages-publish.json')
    if($current.publicationId -cne $ExpectedPublicationId){throw 'PAGES_WORKER_PUBLICATION_CHANGED'}
    Write-PagesWorkerState $root $ExpectedPublicationId 'ready'
    & (Join-Path $PSScriptRoot 'Publish-Pages.ps1') -ProjectDirectory $root -Recover -MonitorWorker -FullRecord -ExpectedPublicationId $ExpectedPublicationId -WaitSeconds $WaitSeconds
    Write-PagesWorkerState $root $ExpectedPublicationId 'stopped'
} catch {
    $code=($_.Exception.Message -split ':')[0]
    if($code -cnotmatch '^[A-Z][A-Z_]+$'){$code='PAGES_WORKER_START_OR_RUN_FAILED'}
    Write-PagesWorkerState $ProjectDirectory $ExpectedPublicationId 'failed' $code
    throw
}
