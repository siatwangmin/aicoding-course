﻿#Requires -Version 5.1
# Byte-preserving rules apply only to the disposable, dedicated static checkout.
function Initialize-PagesCheckout([string]$Checkout) {
    $info=Join-Path $Checkout '.git/info';Assert-CoursePlainPath $info
    [void](New-Item -ItemType Directory -Path $info -Force)
    [IO.File]::WriteAllText((Join-Path $info 'attributes'),"* -text -filter -ident !working-tree-encoding`n",[Text.UTF8Encoding]::new($false))
}
function Save-PagesGitDiagnostic([string]$Root,$Record,[string]$File,[string]$Code,[string]$Expected,[string]$Actual) {
    $path=Join-Path $Root ('.local/pages-jobs/'+$Record.publicationId+'/git-diagnostic.json')
    Write-CourseJson $path @{code=$Code;file=$File;expected=$Expected;actual=$Actual;publicationId=$Record.publicationId;at=[DateTimeOffset]::UtcNow.ToString('o');action='Preserve source and remote content. Use the byte-preserving checkout; reconcile real content conflicts.'}
    $Record|Add-Member NoteProperty diagnosticPath $path -Force
    throw ($Code+': '+$File+'; diagnostic: '+$path)
}
function Assert-PagesManagedFile([string]$Root,$Record,[string]$Path,[string]$Name,[string]$Expected) {
    $actual=(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
    if($actual -ceq $Expected){return}
    $code='PAGES_MANAGED_CONTENT_CHANGED'
    # Diagnose only: keep the original bytes and retain the content-conflict guard.
    if([IO.Path]::GetExtension($Name) -in @('.html','.htm','.css','.js','.mjs','.json','.svg','.txt','.md','.xml','.csv')){
        $bytes=[IO.File]::ReadAllBytes($Path);$stream=[IO.MemoryStream]::new();$sha=[Security.Cryptography.SHA256]::Create()
        try {
            for($i=0;$i -lt $bytes.Length;$i++){
                if($bytes[$i] -eq 13 -and $i+1 -lt $bytes.Length -and $bytes[$i+1] -eq 10){continue}
                $stream.WriteByte($bytes[$i])
            }
            $normalized=([BitConverter]::ToString($sha.ComputeHash($stream.ToArray()))).Replace('-','').ToLowerInvariant()
            if($normalized -ceq $Expected){$code='PAGES_LINE_ENDING_MISMATCH'}
        } finally {$stream.Dispose();$sha.Dispose()}
    }
    Save-PagesGitDiagnostic $Root $Record $Name $code $Expected $actual
}
function Assert-PagesStagedFiles([string]$Git,[string]$Checkout,[string[]]$Files,[string]$Root,$Record) {
    # Two Git processes per bounded batch, not two processes for every resource.
    for($offset=0;$offset -lt $Files.Count;$offset+=64){
        $batch=@($Files|Select-Object -Skip $offset -First 64)
        $paths=@($batch|ForEach-Object {Join-Path $Checkout $_})
        $rawText=Invoke-PagesNative $Git (@('-C',$Checkout,'hash-object','--no-filters','--')+$paths) 30 $Root
        $rawHashes=@([regex]::Split($rawText.Trim(),'\r?\n'))
        $indexText=Invoke-PagesNative $Git (@('-C',$Checkout,'ls-files','--stage','-z','--')+$batch) 30 $Root
        $index=@{}
        foreach($entry in $indexText.Split([char[]]@([char]0),[StringSplitOptions]::RemoveEmptyEntries)){
            if($entry -cmatch '^[0-7]{6} ([a-f0-9]{40}|[a-f0-9]{64}) 0\t(.+)$'){$index[$Matches[2]]=$Matches[1]}
        }
        if($rawHashes.Count -ne $batch.Count){throw 'PAGES_GIT_INDEX_PROOF_INVALID'}
        for($i=0;$i -lt $batch.Count;$i++){
            $name=$batch[$i];$raw=$rawHashes[$i]
            if($raw -cnotmatch '^([a-f0-9]{40}|[a-f0-9]{64})$' -or $raw -cne $index[$name]){
                Save-PagesGitDiagnostic $Root $Record $name 'PAGES_GIT_INDEX_TRANSFORMED' $raw $index[$name]
            }
        }
    }
}
