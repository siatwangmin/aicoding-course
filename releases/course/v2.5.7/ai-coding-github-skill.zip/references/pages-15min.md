# 静态发布标准流程（复用场景 3–5 分钟预算）

前提：网页与公开范围已确认，Git/gh、既有镜像和本人授权可复用，专用目标已在 B 的 `services.githubPages` 绑定。未绑定时先按 pages-cli.md 准备目标；首次安装、注册、授权、页面修改与额外平台排队据实计时。3–5 分钟是待持续实测的复用预算，不能跳过验收来满足时限；本文件路径保留兼容。

| 预算 | 执行内容 | 编排方式 |
| --- | --- | --- |
| 0–30 秒 | gh 身份、权限与 Pages 来源检查；同时核必要引擎/连接/镜像、准备静态副本和摘要 | 两条线路并行，远端预检只读 |
| 30–60 秒 | 汇合检查 → 明确文件清单 → commit → 先保存状态再 push → 查询或开通 Pages | 同一目标顺序写入，项目级独占锁 |
| 1–3 分钟 | 平台部署、状态查询；前台准备浏览器验收 | 独立隐藏进程查询，前台可响应 |
| 3–4 分钟 | 核本次 commit、首页响应与全部资源摘要；浏览器检查样式、资源和关键交互 | 资源最多 4 路并发；浏览器可与技术核验并行，但须确认展示本轮内容 |
| 4–5 分钟 | 直接交付实际网址、状态和耗时，请本人打开确认 | 自动留证；本人未反馈时保留 pending |

```mermaid
flowchart TD
  A[确认网页与目标] --> B[远端只读预检]
  A --> C[本地运行时与静态模板]
  B --> D[汇合检查并提交推送]
  C --> D
  D --> E[查询或开通 Pages]
  E --> F[后台查询同一 commit]
  E --> G[前台准备验收]
  F --> H{本轮构建成功}
  H -->|否| R[保留 pending 或失败并按原记录接续]
  H -->|是| I[并发核首页及资源摘要]
  H -->|是| J
  G --> J[浏览器实际体验]
  I --> K[汇总本轮验收并交付实际网址]
  J --> K
```

## 标准入口

以下由助手调用，使用者无需填写命令。路径取当前 Skill 与 B 的实际绝对路径。

```powershell
# 已明确要求发布时：准备并推送，启动后台部署查询和资源核验。
& <Skill>/scripts/Publish-Pages.ps1 -ProjectDirectory <B> -HtmlPath <确认HTML> -Publish -Background

# 换窗口查询，不启动运行时，不触发网络或写操作。
& <Skill>/scripts/Publish-Pages.ps1 -ProjectDirectory <B> -Status

# 有界等待本地进展；完成即返回，后台意外退出最多自动接续一次。
& <Skill>/scripts/Wait-PagesPublication.ps1 -ProjectDirectory <B> -WaitSeconds 30 -AutoRecover

# 后台已结束或中断时按原 commit 接续，不新建 commit、不重复 push。
& <Skill>/scripts/Publish-Pages.ps1 -ProjectDirectory <B> -Recover -Background
```

后台采用有界查询窗口（默认 600 秒）。平台排队保留 `deployment-pending`，资源未一致保留 `assets-pending`，构建失败为 `deployment-failed`，检查失败为 `check-failed`。启动应答到达即返回，最多等待 5 秒；超时但进程仍存活时记 starting，避免启动第二个工作进程。确认启动进程退出时在原上下文内接续。启动器在加载脚本前捕获日志；workerHealth 结合 PID、启动时间与本地状态显示健康情况。心跳随既有构建轮询写入，资源核验期间标明 verifying-assets，不增加平台 API。Wait 入口对意外退出最多恢复一次，不因心跳延迟强杀活进程，不自动重复构建失败/明确检查失败/正常查询窗口结束的任务。恢复消耗的真实时间单列，WaitSeconds 仅限制本地等待段。后台受理及进程退出码均不能单独证明部署通过。不要为平台等待再次运行 `-Publish`。

每轮的 publicationId、repository、branch、commit、buildId、manifestSha256、URL、起止检查时间和四项验收共同保存。当前状态为 `docs/progress/pages-publish.json`，每轮快照为 `docs/progress/pages-runs/<publicationId>.json`，后台日志为 `.local/pages-jobs/<publicationId>/`。对同一项目的提交、恢复和验收登记串行执行；文件锁在进程退出时自动释放。

## 快速执行与自动留痕

- `assets/pages-workflow.json` 是步骤、并行组、后台阶段、预算和短交付语的模板；入口读取默认参数。`-FullRecord` 返回完整机器记录，默认输出精简摘要；两种输出都不写长报告。
- 普通调用自动将阶段事件保存至 `.local/pages-jobs/<publicationId>/timing/`。可显式设置项目内的 `AI_CODING_PAGES_TIMING_DIRECTORY` 汇集事件；默认设置在调用结束后恢复。状态变化追加到 transitions，technicalCompletedAt/technicalElapsedSeconds 保留技术完成口径，后续本人试用登记不改变该时间。
- StaticPublish 只核所选本地引擎、连接身份/角色、平台和既有镜像；不运行 Compose、不检查开发端口/依赖、不启动开发服务器。静态打包实际读写宿主副本，在线核验只读挂载该副本。
- 同轮上下文只含非秘密摘要与已验证镜像 ID。后台仍查询当前引擎和本地连接，确认项目/执行包/CLI/连接一致后复用镜像检查；跨轮、超过 900 秒、字段或引擎变化均重验。实际执行使用不可变镜像 ID 与 `--pull=never`，镜像删除时失败，不隐式拉取或替换镜像。
- 后台仍核当前 GitHub 身份、Pages 来源和本轮远端 HEAD，省去另一遍推送权限预检。缺记录时走完整静态检查；兼容旧执行包，不原地改写旧包。
- 完成回复采用短模板：实际可点击 URL → 打开此地址查看作品 → 验收状态与技术耗时 → 当前缺项。报告与表格按需导出；并行区间及父/子操作不能相加当作总墙钟。

## 模板与验收

`assets/pages-acceptance.json` 提供浏览器清单、四项 pending 状态与交付语；时间目标由 pages-workflow.json 统一维护。静态打包脚本统一生成 `index.html`、`.nojekyll` 与公开摘要清单，不上传整个工作区。模板只定义结构，实际仓库、commit、URL 和结果来自本轮运行。

代码只自动填写 deployment、assets；browser、learner 必须有实际观察。浏览器证据保存为 B 内 JSON，以下是字段示意，身份值取本轮记录，观察内容由助手实际检查后填写：

默认浏览器验收采用 `assets/pages-browser-smoke.json` 的 core-smoke 范围：主内容与基本样式可见、关键可见资源正常、一项符合当前产品的非破坏性交互能进入/退出预期可见状态。先从当前页面快照取定位，工具支持时批量执行，定位失败最多重新取一次快照；用可见性判断，不把 DOM 中存在字段或样式表数量当作通过。逐资源摘要已由技术工作进程验证，不在浏览器重复遍历所有资源。30 秒是目标而非跳过检查的截止时间；浏览器工具或定位持续失败时标明 browser pending，先交付技术核验结果。CRUD、登录、多设备、视觉手感等产品验收由本人试用或另行明确测试范围，本人未反馈保持 learner pending。

```json
{
  "publicationId": "本轮 publicationId",
  "commit": "本轮 commit",
  "buildId": "本轮 buildId",
  "url": "本轮实际 https 地址",
  "kind": "browser",
  "scope": "core-smoke",
  "status": "passed",
  "observation": "实际检查的页面、样式、资源与关键交互结果",
  "checks": {"styles": true, "resources": true, "interaction": true}
}
```

用 `Save-PagesAcceptance.ps1 -ProjectDirectory <B> -Kind browser -EvidencePath <B内证据JSON>` 登记。本人反馈使用相同四项身份与 `kind=learner`、`source=user`、实际 `observation`、`status=passed|failed`，再以 `-Kind learner` 登记。脚本要求技术核验已通过，拒绝其他轮次、其他网址、B 外证据和缺失观察；记录证据路径及摘要，不能代替真实浏览器检查或本人反馈。

前台在后台部署期间继续准备验收，并在终态后读取记录、完成实际检查。最终回复始终给出本轮实际可点击网址及“打开此地址查看作品”；部署、浏览器或本人体验未通过时逐项说明，不把旧页面或后台启动当成完成。
