---
name: ai-coding-github
description: 准备或恢复 GitHub 本人账号与授权，按当前需求接入代码仓库，并默认使用 Git/GitHub CLI 发布和验证 GitHub Pages。账号注册与必要本人授权使用浏览器；准备账号不自动发布作品。
---

# GitHub 账号、仓库与 Pages

本技能为用户级，准备与各项目按当前任务调用。准备时只处理账号与工具授权；项目时核当前 services.github/services.githubPages，不能使用其他作品目标或因源码仓库存在自动开启Pages。

网页已确认、工具与授权已准备时，复用场景按 3–5 分钟预算，沿 [静态发布标准流程](references/pages-15min.md) 编排。身份/目标只读预检与本地静态准备并行；默认沿 `Publish-Pages.ps1 -Publish -Background` 将部署查询与资源核验交给独立隐藏进程，前台用 `-Status` 接续并准备验收。采用 StaticPublish 模式检查必要引擎/连接/镜像，后台复用同轮记录；不启动开发应用或检查其端口和依赖。后台受理不等于上线成功，必须继续同轮验收；首次准备、排障与平台额外排队据实计时，不承诺固定完成时间。

标准编排、目标预算与简短交付模板维护于 `assets/pages-workflow.json`。阶段计时、状态变化和失败原因自动保存在本轮本地记录；默认只交付实际网址、验收状态与技术耗时，长报告及 CSV 仅按需生成。保持并行准备、代码执行、独立后台与模板复用，不因提速省略当前身份、目标、commit、线上资源和真实浏览器验收。

复用发布先读项目要求的入口、当前绑定与发布记录，再直接执行标准入口；工具定位、格式处理和同轮检查交给脚本，异常时按错误码及诊断文件读取对应实现。专用静态副本保留产物字节，Git 暂存内容与产物一致才提交。后台有启动应答与本地心跳；用 `Wait-PagesPublication.ps1 -AutoRecover` 等待进展并对意外退出做一次同提交恢复，不固定盲等。浏览器默认按 `assets/pages-browser-smoke.json` 做核心冒烟检查，业务全流程、视觉手感与设备体验留给本人，交付分别说明技术、核心检查及本人试用状态。

## 网页部署交付规则

每次网页部署完成（包括 V2 项目上云后的 GitHub Pages 首次发布、更新发布和恢复发布），必须在面向使用者的完成回复中给出本次实际网页地址：使用完整的 `https://` URL 和可点击链接，并说明“打开此地址查看作品”。地址从当前平台部署结果或站点查询取得，保留实际域名与项目子路径；仓库、Actions、控制台地址或本地预览不能代替作品地址，也不能只把地址留在工具输出或进度文件中。按 [Pages CLI 默认流程](references/pages-cli.md) 核验本轮部署后再报告成功；仍在发布或验证未通过时，给出已取得的地址并标明当前状态，不把旧页面当作本轮已上线。尚未取得地址时继续查询，确有阻塞则说明原因，不猜地址或仅回复“部署成功”。

先判模式：E-07准备账号/邮箱及 GitHub CLI 持久授权，读取 [CLI 授权准备](references/cli-auth.md)；源码备份只接入代码仓库；本轮要求发布 github.io/GitHub Pages 时，直接按 [Pages CLI 默认流程](references/pages-cli.md) 连续完成身份、仓库、Pages 配置、发布与验证，不先走下文的浏览器账号准备助手。P-01仅在当前需求明确需要时接入，不自动创建未来资源。本技能同时负责静态副本、产物检查、Git/GitHub CLI 路线与 Pages 设置，实施读取 references/publishing.md；标准脚本 scripts/Publish-Pages.ps1。恢复读原记录与B绑定，已有账号直接用。浏览器已登录不等于Git/API可推送，分别核验；授权中断/过期从当前官方流程恢复，不新建账号或让本人抄token。代理407先核实际网络/项目配置，保留单位全局设置，不关闭TLS或强推改remote绕过。

下文账号注册/邮箱验证模式使用 Trae BrowserUse 主动打开、读取和导航页面；Pages 部署不使用 BrowserUse 点击仓库设置。账号模式每次只给一个本人动作：在哪里、做什么、完成后看到什么。完成目标是本人 GitHub 账号能登录、邮箱已验证、gh 可用且 CLI 持久安全授权和 Git 凭证配置已核验；不要求使用者配置 Git、SSH、PAT 或理解仓库原理。

## 账号准备模式：先检查已有状态

读取当前工作区 `.github-setup/github-setup.md`，再用 BrowserUse 打开 [GitHub](https://github.com/) 检查当前会话。已有本人账号直接复用，不重注册。若当前会话属于其他人，先明确要使用谁的账号，不替使用者继续另一个人的设置，也不擅自退出其会话。已登录不等于邮箱已验证，分别检查。

按当前 [GitHub 官方注册说明](https://docs.github.com/en/account-and-profile/how-tos/account-management/creating-an-account-on-github) 和实际页面推进，入口为 [注册](https://github.com/signup) 或 [登录](https://github.com/login)。采用免费个人账号；不启动 Pro、Copilot 付费试用或购买。使用者自己的 GitHub 账号与作品演示账号是不同用途，不能用项目演示密码注册 GitHub。

## 一次一个动作

1. 尚未登录时先引导已有账号登录；只有没有账号才进入注册。BrowserUse 观察当前页面再定位按钮，不依赖固定按钮顺序或过时截图。
2. 引导本人在官网填写自己的邮箱、用户名和密码，处理验证码、身份验证及条款，助手不代设密码、不接收或回显密码、验证码、邮箱验证链接。用户名已占用时依据页面提示请本人调整，不自动创建第二个账号。
3. 注册或登录完成后读取真实成功状态。需要验证邮箱时，指引本人打开自己的邮箱，按 GitHub 邮件完成验证；不索取邮箱密码或验证码，也不替其发送邮件。本人完成后重新读取 GitHub 状态。
4. 使用 [官方邮箱验证说明](https://docs.github.com/en/account-and-profile/how-tos/email-preferences/verifying-your-email-address)，从账号 Settings → Emails 或当前验证提示确认“已验证”。已有验证状态直接通过。密码和邮箱页面不主动截图归档。
5. 网络不可达、收不到邮件、验证过期或账号受限时，只处理当前阻塞；需要重新发送验证邮件时先说明目的，按本人决定继续，不循环注册。平台要求 2FA 时按页面引导本人完成；不为准备账号添加付费服务或个人访问令牌；仅按 references/cli-auth.md 完成当前需要的官方 GitHub CLI 授权，不增加无关第三方授权。

BrowserUse 未启用时依据 [Trae 官方说明](https://docs.trae.cn/work_browser-use) 一步引导开启。工具确实不可用才给一个官方入口和当前动作，记录“本人反馈”，不能冒充工具已看到页面。账号注册、验证与法律条款由本人操作，助手负责导航和检查。

## 记录与完成

准备进度写入当前工作区 `.github-setup/github-setup.md`，目录加入 Git 忽略。记录用户名或个人主页、登录与邮箱验证状态、检查时间、证据来源及待办；不保存密码、验证码、完整邮箱地址、验证链接、令牌或恢复码。中断后从记录继续。

BrowserUse 实际确认本人已登录、邮箱已验证后，继续 references/cli-auth.md 的 CLI 检查；账号/邮箱与 cliAvailable、cliAuthVerified、gitCredentialConfigured 五项都有真实证据才报告“GitHub 已准备好”。只收到本人反馈时明确标记相应证据待复核；不能凭注册页提交、头像可见或操作步骤勾选宣布全部通过。完成后回到环境准备下一项；暂不创建仓库、推送代码或开启 Pages，这些留给后续实际作品任务。

面向使用者的完成说明只需：“GitHub 已准备好，账号、邮箱和命令行授权已检查，后续发布可复用。我会继续处理环境准备中的未完成项。”

如果由完整环境准备或项目按需能力助手调用，完成后直接返回编排并继续下一阶段；不要求本人回页面重发下一条提示。仅独立账号请求按上述方式交付。

## 项目按需接入模式

由按需能力入口在本轮明确需要GitHub时调用，不在P-01自动调用。通过用户级 preparation-index 找 A，读取明确准备来源和 B/.ai-coding/services.json/local.json；已有账号、环境和有效授权直接用。检查当前官方工具实际可用与本人资源归属，完成 B 的绑定，记录检查时间、证据与待办。配置存在不等于授权有效；仅在缺项时引导本人一个登录动作，不要求使用者填技术参数。

不提前创建业务表、产品 AI 函数或发布未确认设计。后续阶段只复查失效项。账号准备、项目绑定、真实客户端和产品验收分别记录；检查记录写.ai-coding/capabilities/<所选服务>.json，保持本地initializationStatus独立，不凭网页勾选通过。

准备/服务检查结束后调用项目绑定公共执行包的 scripts/Register-CourseServices.ps1 -WorkingDirectory <A>，将允许的非秘密连接值与脱敏服务证据登记到用户级服务记录；GitHub 再传官方当前身份 -GithubLogin。它不保存登录令牌，也不把登记当作授权通过。B 优先读自己的绑定与用户级登记，原始历史可追溯到 A。

## 估时与等待

CLI 三项使用 scripts/Test-GitHubCli.ps1 的实际脱敏结果逐项登记 command 证据；脚本不自动代填账号或邮箱观察。旧准备仅有账号/邮箱时先补 CLI，不创建仓库验证准备。

环境准备阶段完成后，按环境Skill的references/preparation-workflow.md通过Save-PreparationEvidence记录实际观察；时间、证据位置和阶段登记交给脚本，不手写通过记录或把浏览器头像当推送授权。

读取本技能 assets/course-timing.json，按当前阶段/步骤说明首次或复用的预计时间。长下载、编译、部署说明真实等待原因及本人是否需要操作；超过预计上限说明已完成部分、阻塞和处理，有依据才更新剩余时间。时间估算不代替实际证据，不展示虚假百分比；实际等待计入墙钟。

## 项目按需接入

仅本轮明确需要代码备份/协作或github.io发布时调用项目Skill Enable-ProjectCapability：github记录services.github源码仓库，github-pages记录services.githubPages静态目标。两者独立核验，不因创建代码仓库自动启用Pages，不覆盖其他remote。按当前目标复用或准备仓库，完成后接续原任务；初始化和离线APK不要求GitHub。
