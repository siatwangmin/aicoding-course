# 按当前需求接入能力

先读当前项目规则、需求和进度，未确认时只问功能问题。公开静态网址→github-pages；代码备份/协作→github；云端保存/同步/服务端→cloudbase；安卓安装包→android；AI→ai（必要的 CloudBase 后端）。需求未明确先建立 local。

调用 scripts/Enable-ProjectCapability.ps1 -ProjectDirectory <B> -Capability <值> -Reason <目标>。入口增量登记能力、物化必要公开配置，登记必要项目绑定并返回 pending/nextSkills（不安装技能）。它不创建远程资源、调用模型或生成 APK；助手必须在同一任务继续接入与实施。

GitHub 使用用户级 ai-coding-github；云端及 AI 使用用户级 ai-coding-cloudbase；Android 使用用户级 ai-coding-android。平台管理登录可复用，但操作目标必须核 B/services.json。AI 不自动启用业务同步/托管，Android 不自动接云账号。

保留旧绑定，冲突不覆盖。默认只给当前项目增加服务绑定，不复制或删除平台技能。仅安装文件、配置存在、本地初始化通过均不证明服务通过；按 Scope Capability 保存实际证据。未选择项不作为缺项；当前请求尚未完成的能力继续报告待办。

CloudBase 的准备账号与项目环境分开。没有 B 的明确 envId 时保持待绑定，不自动采用 A 的示例环境或其他 B 的环境；确定当前需求的目标后可用 Connect-Project -Services cloudbase -CloudBaseEnvironmentId <当前目标> 连接。已有不同绑定保持原样，先解决资源归属。
