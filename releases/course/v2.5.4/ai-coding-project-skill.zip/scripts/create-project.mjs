#!/usr/bin/env node
// Run with the prepared toolchain container; no host npm install is needed.
import { access, cp, mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID, createHash } from 'node:crypto';
import { within, plainPath } from './project-context.mjs';
import { beginGeneration, commitGeneration, inventory, planGeneration } from './generation.mjs';

const args = process.argv.slice(2);
const option = (key, fallback) => {
  const index = args.indexOf(key);
  if (index < 0) return fallback;
  if (!args[index + 1] || args[index + 1].startsWith('--')) throw new Error(`Missing value: ${key}`);
  return args[index + 1];
};
const requestedTarget = resolve(option('--target', '/project'));
let target = requestedTarget;
const resources = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const template = resolve(option('--template', join(resources, 'assets/app')));
const templateManifest = JSON.parse(await readFile(join(resources, 'assets/app-template.json'), 'utf8'));
const templateFiles = [];
for (const [relative, expected] of Object.entries(templateManifest.files)) {
  const source = await plainPath(within(template, relative));
  const bytes = await readFile(source);
  if (createHash('sha256').update(bytes).digest('hex') !== expected) throw new Error('APP_TEMPLATE_FILE_MISMATCH: ' + relative);
  templateFiles.push({relative, bytes});
}
const rootFiles=['.ai-coding/project.json','.ai-coding/services.json','.env','.gitignore','.dockerignore','.containerignore','compose.yaml','AGENTS.md','.trae/rules/course-entry.md','docs/specs/_template.md','docs/progress/current.md','README.md'];
const engineeringFiles=(await inventory(join(resources,'assets/engineering'))).map(i=>'docs/engineering/'+i.path);
const plannedFiles=[...templateFiles.map(i=>'app/'+i.relative),...rootFiles,...engineeringFiles];
// Binding/runtime files are also initialization outputs, even though later phases write them.
plannedFiles.push('.ai-coding/local.json','.ai-coding/preparation.json','.ai-coding/command.json','.ai-coding/web-build.json','.ai-coding/runtime-check.json','.ai-coding/dependencies.json','.ai-coding/initialization-plan.json','.local/course-execution.jsonl','.local/course-command.log');
const plannedDirectories=['docs/design','app/docs/design','app/docs/progress'];
if(args.includes('--plan')){
 const plan=await planGeneration(requestedTarget,plannedFiles,plannedDirectories);
 console.log(JSON.stringify({...plan,status:plan.conflicts.length?'conflict':'planned'}));process.exit(plan.conflicts.length?2:0);
}
let name = option('--name', '我的作品');
let nameSource = args.includes('--name') ? 'user' : 'placeholder';
let slug = option('--slug', `aicoding-${randomUUID().slice(0, 8)}`);
const image = option('--image', '');
const preparationPath = option('--preparation', '');
let preparation = null;
if (preparationPath) {
  preparation = JSON.parse((await readFile(resolve(preparationPath), 'utf8')).replace(/^\uFEFF/, ''));
  if (preparation.schemaVersion !== 2 || !preparation.verifiedAt || preparation.image !== image) throw new Error('Preparation image mismatch or unverified');
}
const containerRuntime = option('--runtime', preparation?.containerRuntime || 'podman');
if (!['docker', 'podman'].includes(containerRuntime)) throw new Error('Invalid container runtime');
const networkMode = option('--network-mode', 'pasta');
if (!['pasta', 'bridge'].includes(networkMode)) throw new Error('Invalid network mode');
const port = Number(option('--port', '5187'));
if (!/^[a-z][a-z0-9-]{1,47}$/.test(slug)) throw new Error('Invalid project slug');
if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('Invalid port');
if (!image) throw new Error('The prepared image reference is required');
// Management Node performs file copying only; all project compilation stays in the prepared image.
if (preparation && preparation.containerRuntime !== containerRuntime) throw new Error('Preparation runtime conflict');
await access(join(template, 'package-lock.json'));
const generation = await beginGeneration(requestedTarget,{image,runtime:containerRuntime,slug,port,name,nameSource},{files:plannedFiles,directories:plannedDirectories,resume:args.includes('--resume'),stateRoot:option('--state-root',undefined)});
if(generation.resume){await commitGeneration(generation);console.log(JSON.stringify({status:'resumed',next:'Continue project connection and verification'}));process.exit(0);}
try {
slug=generation.state.slug;target=generation.stage;
name=generation.state.name;nameSource=generation.state.nameSource;
const app = join(target, 'app');
await mkdir(app,{recursive:true});
for (const {relative, bytes} of templateFiles) {
  const destination = within(app, relative);
  await mkdir(dirname(destination), {recursive: true});
  await writeFile(destination, bytes, {flag: 'wx'});
}
const appId = `com.aicoding.${slug.replaceAll('-', '')}`;
await mkdir(join(app, 'docs/design'), { recursive: true });
await mkdir(join(app, 'docs/progress'), { recursive: true });
await mkdir(join(target, '.ai-coding'), { recursive: true });
const project = { schemaVersion: 2, appTemplate: {id: templateManifest.templateId, version: templateManifest.templateVersion, contentId: templateManifest.contentId}, baselineVersion: '2.5.0', preparationId: preparation?.preparationId || null, initializationStatus: 'pending', toolchain: preparation ? { capabilities: preparation.capabilities || null, imageDigest: preparation.imageDigest, verificationMethod: preparation.verificationMethod || 'registry-digest', imageId: preparation.imageId || null, archiveSha256: preparation.archiveSha256 || null, verifiedAt: preparation.verifiedAt } : null, connection: preparation?.connection || null, compose: containerRuntime === 'podman' ? (preparation?.compose || {provider:'docker-compose',verificationStatus:'pending'}) : null, name, nameSource, purpose: null, identityStatus: 'pending-design', storageRoot: preparation?.storageRoot || null, slug, appId, sourceDirectory: 'app', designDirectory: generation.designDirectory, specDirectory: 'docs/specs', progressDirectory: 'docs/progress', image, port, containerRuntime, networkMode: containerRuntime === 'podman' ? networkMode : 'bridge', capabilityMode: 'on-demand', capabilities: ['local'], android: { webDir: 'dist', iconReviewRequired: false }, businessProfile: null };
await writeFile(join(target, '.ai-coding/project.json'), JSON.stringify(project, null, 2) + '\n');
await writeFile(join(target, '.env'), `AI_CODING_IMAGE=${image}\nAI_CODING_PORT=${port}\nAI_CODING_RUNTIME=${containerRuntime}\nAI_CODING_NETWORK_MODE=${networkMode}\nCOMPOSE_PROJECT_NAME=${slug}-${randomUUID().slice(0, 8)}\n`);
await writeFile(join(target, '.gitignore'), '.env\n.local/\n.cloudbase-setup/\n.github-setup/\n.ai-setup/\n.course-setup/\n.docker-setup/\n.podman-setup/\ntoolchain-verification.json\nenvironment-checklist.md\napp/node_modules/\napp/dist/\napp/android/\n*.apk\n');
await cp(join(resources, containerRuntime === 'podman' ? 'assets/compose.podman.yaml' : 'assets/compose.yaml'), join(target, 'compose.yaml'));
await cp(join(resources, 'assets/AGENTS.project.md'), join(target, 'AGENTS.md'));
await mkdir(join(target, '.trae/rules'), { recursive: true });
await cp(join(resources, 'assets/trae-entry.md'), join(target, '.trae/rules/course-entry.md'));
await cp(join(resources, 'assets/engineering'), join(target, 'docs/engineering'), { recursive: true });
await mkdir(join(target, 'docs/design'), { recursive: true });
await mkdir(join(target, 'docs/specs'), { recursive: true });
await cp(join(resources, 'assets/spec-template.md'), join(target, 'docs/specs/_template.md'));
await mkdir(join(target, 'docs/progress'), { recursive: true });
await writeFile(join(target, 'docs/progress/current.md'), '# 当前进度\n\n工程已生成；本地构建、起始网页、热更新与规则加载待检查。外部能力按需求在对应阶段接入。\n');
await writeFile(join(target, 'README.md'), '# 我的作品\n\n助手从 AGENTS.md 恢复。源码在 app/，需求设计放 docs/design，工程基线在 docs/engineering。运行与构建使用准备阶段镜像。本人只确认需求、授权与亲自试用。\n');
await writeFile(join(target, '.ai-coding/services.json'), JSON.stringify({ schemaVersion: 2 }, null, 2) + '\n');
const exclusions = '.ai-coding/port-transition.json\n.ai-coding/command.json\n.ai-coding/web-build.json\n.ai-coding/guidance-upgrade.json\n.ai-coding/diagnostics.json\n.ai-coding/progress.json\n.ai-coding/dependencies.json\n.ai-coding/initialization-plan.json\n.ai-coding/runtime-check.json\n.ai-coding/local.json\n.ai-coding/preparation.json\n.ai-coding/initialization.json\n.ai-coding/evidence/\n.ai-setup/\n.cloudbase-setup/\n.github-setup/\n.course-setup/\n.local/\n**/.env\n**/.env.*\n!**/.env.example\n*.apk\n*.aab\n*.jks\n*.keystore\n';
await writeFile(join(target, '.gitignore'), (await readFile(join(target, '.gitignore'), 'utf8')) + exclusions);
await writeFile(join(target, '.dockerignore'), exclusions);
await writeFile(join(target, '.containerignore'), exclusions);
} catch(error) { await generation.release(); throw error; }
await commitGeneration(generation);
const projectResult=JSON.parse(await readFile(join(requestedTarget,'.ai-coding/project.json'),'utf8'));
console.log(JSON.stringify({ status: 'created', project:projectResult, next: 'Start the project container and verify the blank page' }));
