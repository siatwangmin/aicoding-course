﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,[string]$PreparationDirectory,[string]$Name,[int]$Port=5187,
      [string]$ManagementNode,
      [ValidateSet('Initialize','Resume','Verify')][string]$Action='Initialize',
      [string[]]$Capabilities,[string]$CapabilityReason,[string]$CaseSkill,[string]$CasePackageRoot)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$root=[IO.Path]::GetFullPath($ProjectDirectory)
$manifest=Join-Path $root '.ai-coding/project.json'
if($Action -eq 'Initialize' -and (Test-Path -LiteralPath $manifest)){throw 'PROJECT_ALREADY_EXISTS: use Resume, Verify or explicit Upgrade; Initialize does not upgrade.'}
if($Capabilities.Count -or $CaseSkill){throw 'LOCAL_INITIALIZATION_ONLY: invoke the user-level platform skill or explicit case entry after local initialization.'}
$executionRoot=if($Action -eq 'Initialize'){Resolve-CourseExecutionRoot ''}else{Resolve-CourseExecutionRoot $root}
. (Join-Path $executionRoot 'scripts/Course-Runtime.ps1')
. (Join-Path $executionRoot 'scripts/Course-NodeJs.ps1')
Assert-CoursePlainPath $root
$projectMutex=[Threading.Mutex]::new($false,('Local\course-initialize-'+(Get-CourseLifecycleHash $root.ToLowerInvariant())))
try{$projectEntered=$projectMutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{$projectEntered=$true}
if(-not $projectEntered){$projectMutex.Dispose();throw 'PROJECT_INITIALIZATION_BUSY'}
try{
$generator=Join-Path $PSScriptRoot 'create-project.mjs'
# No project writes, preparation recovery or engine operations before this full path plan.
if($Action -eq 'Initialize'){
    $node=Resolve-CourseManagementNode $ManagementNode
    $plan=Invoke-SetupNative $node @($generator,'--target',$root,'--plan') 30
    if($plan.ExitCode -ne 0){throw ('PROJECT_PREFLIGHT_FAILED: '+(Protect-CourseOutput $plan.Output))}
}
if($Action -eq 'Verify'){
    $ctx=Get-CourseProjectRuntime $root
    [pscustomobject]@{status='verified';scope='runtime';projectDirectory=$root;url=$ctx.Url;port=$ctx.Project.port;evidence='.ai-coding/runtime-check.json'}|ConvertTo-Json
    return
}
$node=Resolve-CourseManagementNode $ManagementNode
$timer=[Diagnostics.Stopwatch]::StartNew();$started=(Get-Date).ToUniversalTime().ToString('o');$phase='PreparationBinding';$outcome='failed';$lease=$null
try{
    $prepared=Find-CourseProjectPreparation $root $PreparationDirectory;$p=$prepared.record
    $lease=Enter-CourseOperation $prepared.workspace 'InitializeProject'
    if(-not(Test-Path -LiteralPath $manifest)){
        $phase='TemplateCopy'
        $temporary=Join-Path (Get-CourseUserRoot) 'temporary';$null=Protect-CourseDirectory $temporary
        $transactions=Join-Path (Get-CourseUserRoot) 'project-transactions';$null=Protect-CourseDirectory $transactions
        $snapshot=Join-Path $temporary ([guid]::NewGuid().ToString('N')+'.json')
        try{
            & (Join-Path $executionRoot 'scripts/Export-CoursePreparation.ps1') -PreparationDirectory $prepared.workspace -Destination $snapshot|Out-Host
            $arguments=@($generator,'--target',$root,'--image',$p.image,'--preparation',$snapshot,'--runtime',$p.containerRuntime,'--port',[string]$Port,'--state-root',$transactions)
            if($p.containerRuntime -eq 'podman'){$arguments+=@('--network-mode',$p.networkMode)}
            if($Name){$arguments+=@('--name',$Name)}
            if($Action -eq 'Resume'){$arguments+='--resume'}
            $created=Invoke-SetupNative $node $arguments 90
            if($created.ExitCode -ne 0){throw ('PROJECT_COPY_FAILED: '+(Protect-CourseOutput $created.Output))}
        }finally{if(Test-Path -LiteralPath $snapshot){Remove-Item -LiteralPath $snapshot}}
    }
    $phase='ConnectRuntime'
    & (Join-Path $PSScriptRoot 'Connect-Project.ps1') -ProjectDirectory $root -PreparationDirectory $prepared.workspace|Out-Host
    $phase='ContainerBuildAndStart'
    # One runtime Start/mount/dependency verification inside the common command entry.
    $build=& (Join-Path $executionRoot 'scripts/Invoke-CourseProject.ps1') -ProjectDirectory $root -Action RunScript -Script build -ReuseBuild|ConvertFrom-Json
    $runtime=Read-CourseJson (Join-Path $root '.ai-coding/runtime-check.json')
    if($runtime.mountRoundtripAndHostHttp -ne 'verified' -or -not $runtime.url){throw 'VERIFIED_RUNTIME_URL_REQUIRED'}
    $project=Read-CourseJson $manifest
    $progress=Join-Path $root '.ai-coding/initialization-plan.json'
    Write-CourseJson $progress @{schemaVersion=2;checkedAt=(Get-Date).ToString('o');status='pending';localBuild='verified';scope='local-initialization';url=$runtime.url;hostPort=$runtime.hostPort;requestedCapabilities=@();capabilityStatus='not-requested';nextSkills=@();remaining=@('browser and mounted hot reload','Trae rule/skill load observation','initialization evidence gate')}
    $outcome='pending'
    [pscustomobject]@{status='pending';projectDirectory=$root;url=$runtime.url;port=$runtime.hostPort;designDirectory=$project.designDirectory;continuation=$progress}|ConvertTo-Json
    Write-Host ('本地网页：'+$runtime.url+' （端口 '+$runtime.hostPort+'）')
}catch{
    $diagnostic=Get-CourseErrorDiagnostic $_ $phase $executionRoot
    $folder=Join-Path (Get-CourseUserRoot) 'diagnostics';$null=Protect-CourseDirectory $folder
    $file=Join-Path $folder ('initialize-'+[guid]::NewGuid().ToString('N')+'.json');Write-CourseJson $file $diagnostic
    throw ('PROJECT_INITIALIZATION_FAILED: phase='+$phase+'; '+$diagnostic.message+'; diagnostics='+$file)
}finally{
    if($lease){Exit-CourseOperation $lease}
    if(Test-Path -LiteralPath $manifest){Write-CourseEvent $root @{stage='P-01';action=$Action;status=$outcome;startedAt=$started;finishedAt=(Get-Date).ToUniversalTime().ToString('o');durationMs=$timer.ElapsedMilliseconds;evidence='.ai-coding/initialization-plan.json'}}
}

}finally{$projectMutex.ReleaseMutex();$projectMutex.Dispose()}
