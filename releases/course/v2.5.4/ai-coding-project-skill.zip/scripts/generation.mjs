// File operations only: this module never starts an engine or installs dependencies.
import {mkdir,readdir,readFile,writeFile,lstat,copyFile,unlink,rmdir,open,rename} from 'node:fs/promises';
import {constants} from 'node:fs';
import {join,dirname,resolve} from 'node:path';
import {homedir} from 'node:os';
import {createHash,randomUUID} from 'node:crypto';
import {plainPath,within,atomicJson} from './project-context.mjs';
const hash=b=>createHash('sha256').update(b).digest('hex');
async function exists(path){try{return await lstat(path);}catch(e){if(e.code==='ENOENT')return null;throw e;}}
export async function inventory(root,rel=''){
 const result=[];
 for(const entry of await readdir(join(root,rel),{withFileTypes:true})){
  const path=rel?`${rel}/${entry.name}`:entry.name;await plainPath(join(root,path));
  if(entry.isDirectory())result.push(...await inventory(root,path));
  else if(entry.isFile())result.push({path,sha256:hash(await readFile(join(root,path)))});
  else throw Error('GENERATION_LINK_REFUSED');
 }
 return result;
}
export async function planGeneration(root,files,directories=[]){
 root=resolve(root);await plainPath(root);
 const conflicts=[],seen=new Set();
 for(const [path,directory] of [...files.map(p=>[p,false]),...directories.map(p=>[p,true])]){
  within(root,path);
  if(!path||path.includes('\\')||path.split('/').some(p=>!p||p==='.'||p==='..'))throw Error('UNSAFE_GENERATION_PATH');
  const key=path.toLowerCase();if(seen.has(key))throw Error('DUPLICATE_GENERATION_PATH: '+path);seen.add(key);
  let current=root;
  for(const [index,part] of path.split('/').entries()){
   const parent=await exists(current);if(!parent)break;
   if(!parent.isDirectory()||parent.isSymbolicLink()){conflicts.push({path,at:current,reason:'parent-type-or-link'});break;}
   const matches=(await readdir(current)).filter(n=>n.toLowerCase()===part.toLowerCase());
   if(!matches.length)break;
   const matched=matches[0],dest=join(current,matched),stat=await exists(dest),last=index===path.split('/').length-1;
   if(matches.length!==1||matched!==part||stat.isSymbolicLink()||(!last&&!stat.isDirectory())||(last&&(!directory||!stat.isDirectory()))){conflicts.push({path,at:dest,reason:matched!==part?'case-equivalent':last?'target-exists':'parent-type-or-link'});break;}
   current=dest;
  }
 }
 return {root,files,directories,conflicts};
}
function assertPlan(plan){if(plan.conflicts.length)throw Error('GENERATION_COLLISION_PRESERVED: '+JSON.stringify(plan.conflicts));}
export async function beginGeneration(root,binding,options={}){
 root=resolve(root);await plainPath(root);
 if(await exists(join(root,'.ai-coding/project.json')))throw Error('PROJECT_ALREADY_EXISTS: use Verify, Resume or explicit Upgrade');
 const folder=resolve(options.stateRoot||join(homedir(),'.ai-coding/project-transactions'));
 const transaction=join(folder,hash(root.toLowerCase())),journal=join(transaction,'state.json');let stage=join(transaction,'staging');
 const prior=await exists(journal);
 if(prior&&!options.resume)throw Error('GENERATION_RESUME_REQUIRED: '+journal);
 if(!prior&&options.resume)throw Error('GENERATION_TRANSACTION_NOT_FOUND');
 if(!options.resume)assertPlan(await planGeneration(root,options.files||[],options.directories||[]));
 await plainPath(transaction);await mkdir(transaction,{recursive:true});
 const lockPath=join(transaction,'lock.json');let lock;
 // The public PowerShell entry also holds an OS mutex across planning/copy/runtime.
 // Recover an interrupted generator only when its recorded process has exited.
 if(options.resume&&await exists(lockPath)){
  const owner=JSON.parse(await readFile(lockPath,'utf8'));let dead=false;
  if(!Number.isInteger(owner.pid)||owner.pid<1)throw Error('GENERATION_LOCK_OWNER_INVALID');
  try{process.kill(owner.pid,0);}catch(e){if(e.code==='ESRCH')dead=true;else throw e;}
  if(dead)await rename(lockPath,join(transaction,'interrupted-lock-'+randomUUID()+'.json'));
 }
 try{lock=await open(lockPath,'wx');await lock.writeFile(JSON.stringify({pid:process.pid,at:new Date().toISOString()}));}
 catch(e){if(e.code==='EEXIST')throw Error('GENERATION_BUSY_OR_INTERRUPTED_LOCK: '+lockPath);throw e;}
 const release=async()=>{await lock.close();await unlink(lockPath);};
 try{
  let state;
  if(prior){
   state=JSON.parse(await readFile(journal,'utf8'));
   if(state.root!==root||state.image!==binding.image||state.runtime!==binding.runtime||state.port!==binding.port)throw Error('GENERATION_BINDING_CONFLICT');
   if(!['ready','copying','rolledback','preparing'].includes(state.status))throw Error('GENERATION_STATE_REQUIRES_INSPECTION');
   if(state.status==='preparing'){
    if(state.created.length)throw Error('GENERATION_INCOMPLETE_STAGE_REQUIRES_INSPECTION');
    // Preserve the old partial stage for diagnosis; rebuild into a new private stage.
    state.stageName='staging-'+randomUUID();stage=within(transaction,state.stageName);await mkdir(stage);
    await atomicJson(journal,state);
   }else{stage=within(transaction,state.stageName||'staging');}
  }else{
   const rootRequirements=(await Promise.all(['需求说明文档.md','PRD.md','需求说明.md'].map(n=>exists(join(root,n))))).some(Boolean);
   const designDirectory=await exists(join(root,'design'))?'design':rootRequirements?'.':'docs/design';
   await mkdir(stage,{recursive:true});
   state={schemaVersion:3,...binding,root,designDirectory,status:'preparing',created:[],directories:[],plannedFiles:options.files||[],plannedDirectories:options.directories||[]};
   await atomicJson(journal,state);
  }
  return {root,stage,journal,state,resume:!!prior&&state.status!=='preparing',designDirectory:state.designDirectory,release};
 }catch(e){await release();throw e;}
}
async function makeDirectories(path,g){
 if(await exists(path))return;
 const parent=dirname(path);if(parent!==path)await makeDirectories(parent,g);
 try{await mkdir(path);g.state.directories.push(path);await atomicJson(g.journal,g.state);}catch(e){if(e.code!=='EEXIST')throw e;}
}
export async function commitGeneration(g,options={}){
 const {root,stage,journal}=g;
 try{
  if(!g.resume){g.state={...g.state,status:'ready',files:await inventory(stage)};await atomicJson(journal,g.state);}
  const state=g.state,created=new Set(state.created.map(i=>i.path));
  for(const item of state.files){if(hash(await readFile(within(stage,item.path)))!==item.sha256)throw Error('GENERATION_STAGE_CHANGED');}
  const allPaths=[...new Set([...(state.plannedFiles||[]),...state.files.map(i=>i.path)])];
  assertPlan(await planGeneration(root,allPaths.filter(path=>!created.has(path)),state.plannedDirectories||[]));
  for(const item of state.created){const dest=within(root,item.path);await plainPath(dest);if((await exists(dest))&&hash(await readFile(dest))!==item.sha256)throw Error('GENERATION_CREATED_FILE_CHANGED: '+item.path);}
  state.status='copying';await atomicJson(journal,state);
  for(const directory of state.plannedDirectories||[])await makeDirectories(within(root,directory),g);
  const ordered=[...state.files].sort((a,b)=>(a.path==='.ai-coding/project.json')-(b.path==='.ai-coding/project.json'));
  for(const item of ordered){
   const dest=within(root,item.path);await plainPath(dest);
   if(created.has(item.path)&&await exists(dest))continue;
   await makeDirectories(dirname(dest),g);await options.beforeCopy?.(item,g);
   await copyFile(within(stage,item.path),dest,constants.COPYFILE_EXCL);
   if(!created.has(item.path)){state.created.push(item);created.add(item.path);}
   await atomicJson(journal,state);await options.afterCopy?.(item,g);
  }
  state.status='committed';state.finishedAt=new Date().toISOString();await atomicJson(journal,state);
 }catch(e){
  const state=g.state;state.rollbackPreserved=[];
  for(const item of [...state.created].reverse()){
   const dest=within(root,item.path);await plainPath(dest);
   if(!await exists(dest))continue;
   if(hash(await readFile(dest))===item.sha256)await unlink(dest);else state.rollbackPreserved.push(item.path);
  }
  state.created=state.created.filter(i=>state.rollbackPreserved.includes(i.path));
  for(const directory of [...state.directories].reverse()){try{await rmdir(directory);}catch(err){if(!['ENOTEMPTY','ENOENT','EEXIST'].includes(err.code))throw err;}}
  state.directories=[];state.status='rolledback';await atomicJson(journal,state);throw e;
 }finally{await g.release();}
}
