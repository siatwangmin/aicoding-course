﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,[string]$PreparationDirectory)
& (Join-Path $PSScriptRoot 'Initialize-Project.ps1') -ProjectDirectory $ProjectDirectory -PreparationDirectory $PreparationDirectory -Action Verify
