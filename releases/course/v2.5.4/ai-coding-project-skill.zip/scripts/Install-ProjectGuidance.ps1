﻿#Requires -Version 5.1
# Upgrade only exact known course text / managed blocks; preserve project customizations.
function Install-ProjectGuidance([string]$Root,[string]$BackupDirectory) {
    $assets=Join-Path $PSScriptRoot '..\assets'
    $legacy=Read-CourseJson (Join-Path $assets 'guidance-legacy.json')
    $previous=Read-CourseJson (Join-Path $assets 'guidance-legacy-2.2.json')
    $lastCourse=Read-CourseJson (Join-Path $assets 'guidance-legacy-2.2.1.json')
    $lastManaged=Read-CourseJson (Join-Path $assets 'guidance-legacy-2.3.13.json')
    $lastPages=Read-CourseJson (Join-Path $assets 'guidance-legacy-2.3.14.json')
    $lastScoped=Read-CourseJson (Join-Path $assets 'guidance-legacy-2.3.16.json')
    $priorGlobal=Read-CourseJson (Join-Path $assets 'guidance-legacy-2.4.json')
    $conflicts=New-Object Collections.Generic.List[string]
    function Update-ManagedGuidance([string]$Target,[string]$Asset,[string]$Key) {
        Assert-CoursePlainPath $Target
        $fresh=[IO.File]::ReadAllText($Asset).Replace("`r`n","`n")
        $old=if(Test-Path -LiteralPath $Target){[IO.File]::ReadAllText($Target).Replace("`r`n","`n")}else{''}
        if($old -eq $fresh){return}
        if($BackupDirectory -and $old){$name=($Key -replace '[/\\]','_');[IO.File]::WriteAllText((Join-Path $BackupDirectory $name),$old,[Text.UTF8Encoding]::new($false))}
        $start='<!-- ai-coding:guidance:'+ $Key +':start -->';$end='<!-- ai-coding:guidance:'+ $Key +':end -->'
        $block=$start+"`n"+$fresh.TrimEnd()+"`n"+$end
        if(-not $old){$updated=$block+"`n"}
        elseif($old.Contains($start) -and $old.Contains($end)){$updated=[regex]::Replace($old,('(?s)'+[regex]::Escape($start)+'.*?'+[regex]::Escape($end)),[Text.RegularExpressions.MatchEvaluator]{param($m)$block})}
        elseif($priorGlobal.$Key -and $old.StartsWith([string]$priorGlobal.$Key,[StringComparison]::Ordinal)){$updated=$block+$old.Substring(([string]$priorGlobal.$Key).Length)}
        elseif($lastScoped.$Key -and $old.StartsWith([string]$lastScoped.$Key,[StringComparison]::Ordinal)){$updated=$block+$old.Substring(([string]$lastScoped.$Key).Length)}
        elseif($lastPages.$Key -and $old.StartsWith([string]$lastPages.$Key,[StringComparison]::Ordinal)){$updated=$block+$old.Substring(([string]$lastPages.$Key).Length)}
        elseif($lastManaged.$Key -and $old.StartsWith([string]$lastManaged.$Key,[StringComparison]::Ordinal)){$updated=$block+$old.Substring(([string]$lastManaged.$Key).Length)}
        elseif($lastCourse.$Key -and $old.StartsWith([string]$lastCourse.$Key,[StringComparison]::Ordinal)){$updated=$block+$old.Substring(([string]$lastCourse.$Key).Length)}
        elseif($previous.$Key -and $old.StartsWith([string]$previous.$Key,[StringComparison]::Ordinal)){$updated=$block+$old.Substring(([string]$previous.$Key).Length)}
        elseif($legacy.$Key -and $old.StartsWith([string]$legacy.$Key,[StringComparison]::Ordinal)){$updated=$block+$old.Substring(([string]$legacy.$Key).Length)}
        elseif($old.StartsWith($fresh,[StringComparison]::Ordinal)){$updated=$block+$old.Substring($fresh.Length)}
        elseif($Key -eq 'AGENTS.project.md'){$conflicts.Add($Key);$updated=$old+"`n`n"+$block+"`n"}
        else{$conflicts.Add($Key);return}
        [void](New-Item -ItemType Directory -Path (Split-Path $Target -Parent) -Force)
        [IO.File]::WriteAllText($Target,$updated,[Text.UTF8Encoding]::new($false))
    }
    Update-ManagedGuidance (Join-Path $Root 'AGENTS.md') (Join-Path $assets 'AGENTS.project.md') 'AGENTS.project.md'
    foreach($pair in @(@('trae-entry.md','.trae/rules/course-entry.md'),@('spec-template.md','docs/specs/_template.md'))){Update-ManagedGuidance (Join-Path $Root $pair[1]) (Join-Path $assets $pair[0]) $pair[0]}
    foreach($file in Get-ChildItem -LiteralPath (Join-Path $assets 'engineering') -File -Filter *.md){Update-ManagedGuidance (Join-Path $Root ('docs/engineering/'+$file.Name)) $file.FullName ('engineering/'+$file.Name)}
    foreach($file in Get-ChildItem -LiteralPath (Join-Path $assets 'engineering') -File -Filter *.json){
        $target=Join-Path $Root ('docs/engineering/'+$file.Name);Assert-CoursePlainPath $target
        if(-not(Test-Path -LiteralPath $target)){Copy-Item -LiteralPath $file.FullName -Destination $target}
    }
    $defaults=Join-Path $Root 'config/ai-models.defaults.json'
    $serviceFile=Join-Path $Root '.ai-coding/services.json'
    if((Test-Path -LiteralPath $serviceFile) -and (Read-CourseJson $serviceFile).ai -and -not(Test-Path -LiteralPath $defaults)){[void](New-Item -ItemType Directory -Path (Split-Path $defaults -Parent) -Force);Copy-Item -LiteralPath (Join-Path $assets 'default-models.json') -Destination $defaults}
    $manifest=Read-CourseJson (Join-Path $Root '.ai-coding/project.json')
    $source=[IO.Path]::GetFullPath((Join-Path $Root $manifest.sourceDirectory));Assert-CoursePlainPath $source
    if(-not $source.StartsWith($Root.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase) -and $source -ne $Root){throw 'SOURCE_ESCAPES_PROJECT'}
    $pkgPath=Join-Path $source 'package.json'
    if(Test-Path -LiteralPath $pkgPath){
        $pkg=Read-CourseJson $pkgPath
        if(-not $pkg.scripts){$pkg|Add-Member NoteProperty scripts ([pscustomobject]@{})}
        if($BackupDirectory){Copy-Item -LiteralPath $pkgPath -Destination (Join-Path $BackupDirectory 'package-before-guard.json')}
        $guard=Join-Path $source 'scripts/course-runtime-guard.cjs';Assert-CoursePlainPath $guard
        if(Test-Path -LiteralPath $guard){if([IO.File]::ReadAllText($guard) -ne [IO.File]::ReadAllText((Join-Path $assets 'course-runtime-guard.cjs'))){$conflicts.Add('runtime-guard');$guard=$null}}
        if($guard){
            [void](New-Item -ItemType Directory -Path (Split-Path $guard -Parent) -Force);Copy-Item -LiteralPath (Join-Path $assets 'course-runtime-guard.cjs') -Destination $guard -Force
            foreach($hook in @('preinstall','prebuild','pretypecheck','pretest')){
                $value=[string]$pkg.scripts.$hook
                if($value -notmatch 'scripts/course-runtime-guard.cjs'){$pkg.scripts|Add-Member -MemberType NoteProperty -Name $hook -Value ('node scripts/course-runtime-guard.cjs'+$(if($value){' && '+$value}else{''})) -Force}
            }
            Write-CourseJson $pkgPath $pkg
        }
    }
    # Upgrade only the exact prior managed Podman template. Custom health checks stay project decisions.
    $composeFile=Join-Path $Root 'compose.yaml'
    if($manifest.containerRuntime -eq 'podman' -and (Test-Path -LiteralPath $composeFile)){
        Assert-CoursePlainPath $composeFile
        $freshCompose=[IO.File]::ReadAllText((Join-Path $assets 'compose.podman.yaml')).Replace("`r`n","`n")
        $oldCompose=[IO.File]::ReadAllText($composeFile).Replace("`r`n","`n")
        if($oldCompose -eq $freshCompose.Replace('timeout: ${AI_CODING_HEALTH_TIMEOUT:-10s}','timeout: 3s')){
            if($BackupDirectory){Copy-Item -LiteralPath $composeFile -Destination (Join-Path $BackupDirectory 'compose-before-health.yaml')}
            [IO.File]::WriteAllText($composeFile,$freshCompose,[Text.UTF8Encoding]::new($false))
        }
    }
    Write-CourseJson (Join-Path $Root '.ai-coding/guidance-upgrade.json') @{schemaVersion=2;version='2.4.0';status=$(if($conflicts.Count){'pending-custom-guidance-merge'}else{'updated'});conflicts=@($conflicts.ToArray());checkedAt=(Get-Date).ToUniversalTime().ToString('o')}
    if($conflicts.Count){Write-Warning ('Custom guidance preserved; agent must merge current rules: '+($conflicts -join ', '))}
}
