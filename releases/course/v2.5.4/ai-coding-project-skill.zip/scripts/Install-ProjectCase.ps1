﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,[Parameter(Mandatory=$true)][ValidatePattern('^[a-z][a-z0-9-]{0,63}$')][string]$CaseSkill,[string]$PackageRoot)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $executionRoot 'scripts/Course-Context.ps1')
. (Join-Path $executionRoot 'scripts/Course-ProjectRoot.ps1')
. (Join-Path $executionRoot 'scripts/Course-SkillScopes.ps1')
$root=Resolve-CourseProjectRoot $ProjectDirectory
$manifest=Join-Path $root '.ai-coding/project.json';$project=Read-CourseJson $manifest
if(-not $PackageRoot){$PackageRoot=Join-Path $executionRoot 'packages'}
$bundle=Assert-CourseBundle $PackageRoot
if(-not $bundle.skills.$CaseSkill -or $bundle.skills.$CaseSkill.kind -ne 'case'){throw 'EXPLICIT_CASE_PACKAGE_REQUIRED: obtain and verify the selected case package; do not infer a case from cached files.'}
$profile=Read-CourseJson (Join-Path $PackageRoot 'case-profile.json')
if($profile.caseSkillName -cne $CaseSkill){throw 'EXPLICIT_CASE_PROFILE_MISMATCH'}
$caseId=if($profile.caseId){$profile.caseId}else{$CaseSkill}
if($project.businessProfile -and $project.businessProfile -ne $caseId){throw 'EXISTING_BUSINESS_PROFILE_PRESERVED'}
$null=Install-CourseScopedSkills -Workspace $root -PackageRoot $PackageRoot -Scope Project -Names @($CaseSkill)
$project|Add-Member NoteProperty businessProfile $caseId -Force
Write-CourseJson $manifest $project
$agents=Join-Path $root 'AGENTS.md';Assert-CoursePlainPath $agents
$text=if(Test-Path -LiteralPath $agents){[IO.File]::ReadAllText($agents)}else{''}
$start='<!-- ai-coding:case:start -->';$end='<!-- ai-coding:case:end -->'
$block=$start+"`n明确选择的案例：$($profile.caseName)。读取当前项目 .trae/skills/$CaseSkill/SKILL.md，保留已确认设计与原项目规则。`n"+$end
if($text.Contains($start)-and $text.Contains($end)){$text=[regex]::Replace($text,('(?s)'+[regex]::Escape($start)+'.*?'+[regex]::Escape($end)),[Text.RegularExpressions.MatchEvaluator]{param($m)$block})}else{$text+="`n`n"+$block+"`n"}
[IO.File]::WriteAllText($agents,$text,[Text.UTF8Encoding]::new($false))
[pscustomobject]@{status='installed';caseSkill=$CaseSkill;scope='Project';nextAction='Read the selected local case skill; case installation does not enable future platform capabilities.'}|ConvertTo-Json
