﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,[string]$PreparationDirectory,[switch]$UpdateExecutionPackage)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=if($UpdateExecutionPackage){Resolve-CourseExecutionRoot ''}else{Resolve-CourseExecutionRoot $ProjectDirectory}
$helper=Join-Path $executionRoot 'scripts/Course-Context.ps1'
if(-not(Test-Path -LiteralPath $helper)){throw 'Restore the recorded execution package in the preparation workspace.'};. $helper
. (Join-Path (Split-Path $helper -Parent) 'Course-ProjectRoot.ps1')
$root=Resolve-CourseProjectRoot $ProjectDirectory
$manifest=Join-Path $root '.ai-coding\project.json'
if(-not(Test-Path -LiteralPath $manifest)){throw 'Agent must inspect this existing project and record its real sourceDirectory/runtime/image/appId before adoption. Do not run the empty-project generator.'}
$project=Read-CourseJson $manifest;$prepared=Find-CourseProjectPreparation $root $PreparationDirectory
if($project.image -ne $prepared.record.image -or $project.containerRuntime -ne $prepared.record.containerRuntime){throw 'Existing toolchain differs; preserve project and resolve compatibility before upgrade.'}
if($UpdateExecutionPackage){
    $compatibility=Read-CourseJson (Join-Path $executionRoot 'packages/course-contract/compatibility.json')
    if($compatibility.supportedProjectSchemas -notcontains $project.schemaVersion -or $compatibility.imageDigest -ne $prepared.record.imageDigest){throw 'EXECUTION_UPGRADE_PROJECT_INCOMPATIBLE'}
}
$source=[IO.Path]::GetFullPath((Join-Path $root $project.sourceDirectory));Assert-CoursePlainPath $source
if(($source -ne $root -and -not $source.StartsWith($root.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)) -or -not(Test-Path -LiteralPath $source -PathType Container) -or -not $project.appId){throw 'Existing source/appId not confirmed.'}
$backup=Join-Path $root ('.local\course-upgrades\'+[guid]::NewGuid().ToString('N'))
Assert-CoursePlainPath $backup;[void](New-Item -ItemType Directory -Path $backup -Force)
Copy-Item -LiteralPath $manifest -Destination (Join-Path $backup 'project.json')
$rootAgents=Join-Path $root 'AGENTS.md';Assert-CoursePlainPath $rootAgents
if(Test-Path -LiteralPath $rootAgents){Copy-Item -LiteralPath $rootAgents -Destination (Join-Path $backup 'AGENTS.root.md')}
$legacyDesign=Join-Path $source 'docs\design'
$designDirectory=if($project.designDirectory){$project.designDirectory}elseif(Test-Path -LiteralPath $legacyDesign){($project.sourceDirectory.TrimEnd('/','\')+'/docs/design')}else{'docs/design'}
$initStatus=if($project.schemaVersion -eq 2 -and $project.initializationStatus){$project.initializationStatus}else{'pending'}
foreach($item in @(@('schemaVersion',2),@('baselineVersion','2.5.0'),@('initializationStatus',$initStatus),@('capabilityMode','on-demand'),@('designDirectory',$designDirectory))){$project|Add-Member -MemberType NoteProperty -Name $item[0] -Value $item[1] -Force}
if(-not $project.storageRoot){$project|Add-Member -MemberType NoteProperty -Name storageRoot -Value $prepared.record.storageRoot -Force}
$project|Add-Member -MemberType NoteProperty -Name preparationId -Value $prepared.record.preparationId -Force
$toolchain=@{imageDigest=$prepared.record.imageDigest;verificationMethod=$prepared.record.verificationMethod;imageId=$prepared.record.imageId;archiveSha256=$prepared.record.archiveSha256;verifiedAt=$prepared.record.verifiedAt}
$project|Add-Member -MemberType NoteProperty -Name toolchain -Value $toolchain -Force
if(-not $project.connection -and $prepared.record.connection){$project|Add-Member -MemberType NoteProperty -Name connection -Value $prepared.record.connection -Force}
$assets=Join-Path $PSScriptRoot '..\assets'
. (Join-Path $PSScriptRoot 'Install-ProjectGuidance.ps1')
if(-not(Test-Path -LiteralPath (Join-Path $root '.ai-coding/services.json'))){Write-CourseJson (Join-Path $root '.ai-coding/services.json') @{schemaVersion=2}}
Install-ProjectGuidance $root $backup
$servicesPath=Join-Path $root '.ai-coding\services.json'
if(-not(Test-Path -LiteralPath $servicesPath)){
    Write-CourseJson $servicesPath @{schemaVersion=2}
}
$progress=Join-Path $root 'docs\progress\current.md';Assert-CoursePlainPath $progress
if(-not(Test-Path -LiteralPath $progress)){
    [void](New-Item -ItemType Directory -Path (Split-Path $progress -Parent) -Force)
    [IO.File]::WriteAllText($progress,"# 工程接续`n`n旧作品增量接入 2.0，原需求和进度保持原位。服务当前授权与初始化门槛待检查，不代表功能重新完成。`n",[Text.UTF8Encoding]::new($false))
}
foreach($ignoreName in @('.gitignore','.dockerignore','.containerignore')){
    $ignore=Join-Path $root $ignoreName;Assert-CoursePlainPath $ignore
    $ignored=if(Test-Path -LiteralPath $ignore){[IO.File]::ReadAllText($ignore)}else{''}
    foreach($rule in @('.ai-coding/port-transition.json','.local/','.ai-coding/command.json','.ai-coding/web-build.json','.ai-coding/progress.json','.ai-coding/guidance-upgrade.json','.ai-coding/dependencies.json','.ai-coding/initialization-plan.json','.ai-coding/runtime-check.json','.ai-coding/local.json','.ai-coding/preparation.json','.ai-coding/initialization.json','.ai-coding/evidence/','.ai-setup/','.cloudbase-setup/','.github-setup/','.course-setup/','**/.env','**/.env.*','!**/.env.example')){if(@($ignored -split '\r?\n') -notcontains $rule){$ignored+="`n$rule`n"}}
    [IO.File]::WriteAllText($ignore,$ignored,[Text.UTF8Encoding]::new($false))
}
Write-CourseJson $manifest $project
if($UpdateExecutionPackage){
    $localPath=Join-Path $root '.ai-coding/local.json'
    $local=if(Test-Path -LiteralPath $localPath){Copy-Item -LiteralPath $localPath -Destination (Join-Path $backup 'local.json');Read-CourseJson $localPath}else{[pscustomobject]@{schemaVersion=2}}
    $identity=Read-CourseJson (Join-Path $executionRoot 'execution-manifest.json')
    $local|Add-Member NoteProperty executionRoot $executionRoot -Force
    $local|Add-Member NoteProperty executionId $identity.contentId -Force
    Write-CourseJson $localPath $local
}
Write-Output 'Existing project adopted. Source, identity, runtime and product rules preserved; run Connect-Project and actual initialization checks next.'
