﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,[switch]$Start)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $executionRoot 'scripts/Course-Runtime.ps1')
$runtime=Get-CourseProjectRuntime $ProjectDirectory -Start:$Start
[pscustomobject]@{status='verified';projectDirectory=$runtime.Root;url=$runtime.Url;port=$runtime.Project.port;evidence='.ai-coding/runtime-check.json'}|ConvertTo-Json
Write-Output 'Runtime verified. This does not verify cloud services, product behavior or phone installation.'
