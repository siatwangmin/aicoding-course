import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { context, json, atomicJson, verifyImage, within } from './project-context.mjs';

const required = {
  github: ['identityVerified','authorizationVerified','targetVerified'],
  githubPages: ['identityVerified','authorizationVerified','targetVerified'],
  cloudbase: ['envIdVerified','managementAccessVerified','clientConfigVerified'],
  ai: ['credentialDecrypted','serviceEvidenceVerified','feesScopeKnown'],
  android: ['configVerified','toolchainVerified'],
  rules: ['projectEntryObserved','skillsObserved'],
  browser: ['pageSeen','hotReloadVerified']
};
function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === 'object') return Object.fromEntries(Object.keys(value).sort().map(key => [key,canonical(value[key])]));
  return value;
}
function validEvidence(value, name, binding) {
  const fields=name==='ai'&&binding?.setupMode==='application-settings'?['defaultModelsVerified','configurationRouteRecorded']:required[name];
  return value.status === 'verified' && value.checkedAt && Number.isFinite(Date.parse(value.checkedAt)) &&
    Date.parse(value.checkedAt) <= Date.now() && Date.now()-Date.parse(value.checkedAt)<=24*60*60*1000 && Array.isArray(value.evidence) && value.evidence.length > 0 &&
    fields.every(key => value.checks?.[key] === true);
}
function validBinding(name,binding,project) {
  if (!binding) return false;
  if (name === 'githubPages' || name === 'github') return typeof binding.repository === 'string' && /^(?:https:\/\/github\.com\/)?[a-zA-Z0-9-]+\/[a-zA-Z0-9._-]+$/.test(binding.repository);
  if (name === 'cloudbase') return typeof binding.envId === 'string' && binding.envId.length > 0;
  if (name === 'ai') return binding.setupMode==='application-settings'?/^[a-f0-9]{64}$/.test(binding.defaultModelsSha256):typeof binding.credentialRef === 'string' && binding.credentialRef.length > 0;
  if (name === 'android') return binding.appId === project.appId;
  return binding.image === project.image && binding.port === project.port;
}
export async function recordEvidence(root, name, evidencePath) {
  if (!Object.hasOwn(required,name)) throw new Error('UNKNOWN_SERVICE');
  const ctx = await context(root), evidence = await json(evidencePath);
  const services = await json(join(ctx.root,'.ai-coding/services.json'));
  const binding = await initializationBinding(ctx,services,name);
  if (!validEvidence(evidence,name,binding)) throw new Error('INCOMPLETE_EVIDENCE');
  if (!validBinding(name,binding,ctx.project)) throw new Error('MISSING_BINDING');
  await atomicJson(join(ctx.root,'.ai-coding/evidence',name+'.json'), { ...evidence,binding,toolchainImage:ctx.project.image });
}
async function initializationBinding(ctx, services, name) {
  if(name==='rules'){
    const files=['AGENTS.md','.trae/rules/course-entry.md','docs/engineering/workflow.md'];
    const h=createHash('sha256');for(const file of files)h.update(await readFile(join(ctx.root,file)));
    return {image:ctx.project.image,port:ctx.project.port,guidanceSha256:h.digest('hex')};
  }
  if(name==='browser')return {image:ctx.project.image,port:ctx.project.port};
  if(name==='ai'&&services.ai?.setupMode==='application-settings'){
    const bytes=await readFile(join(ctx.root,'config/ai-models.defaults.json'));
    const models=JSON.parse(bytes);
    if(!models.textModel||!models.visionModel)throw new Error('DEFAULT_MODELS_REQUIRED');
    return {setupMode:'application-settings',defaultModelsSha256:createHash('sha256').update(bytes).digest('hex')};
  }
  return services[name];
}

export async function checkCapability(root,name){
  if(!['github','githubPages','cloudbase','ai','android'].includes(name))throw new Error('UNKNOWN_CAPABILITY');
  const ctx=await context(root),services=await json(join(ctx.root,'.ai-coding/services.json'));
  let status='pending';
  try{const binding=await initializationBinding(ctx,services,name),e=await json(join(ctx.root,'.ai-coding/evidence',name+'.json'));
    if(validBinding(name,binding,ctx.project)&&validEvidence(e,name,binding)&&e.toolchainImage===ctx.project.image&&JSON.stringify(canonical(e.binding))===JSON.stringify(canonical(binding)))status='verified';
  }catch{}
  const result={schemaVersion:2,scope:'capability',service:name,status,checkedAt:new Date().toISOString()};
  await atomicJson(join(ctx.root,'.ai-coding/capabilities',name+'.json'),result);return result;
}

export async function checkInitialization(root, run, fetcher = fetch) {
  const ctx = await context(root);
  const result = { schemaVersion: 2, checkedAt: new Date().toISOString(), status: 'pending', checks: {}, missing: [] };
  try{const upgrade=await json(join(ctx.root,'.ai-coding/guidance-upgrade.json'));if(upgrade.status!=='updated')result.missing.push('CUSTOM_GUIDANCE_MERGE_REQUIRED');}catch(e){if(e.code!=='ENOENT')throw e;}
  try { result.checks.toolchain = verifyImage(ctx, run); } catch (error) { result.missing.push(error.message); }
  try {
    const storage=await json(join(ctx.root,'.course-setup/storage.json'));
    const age=Date.now()-Date.parse(storage.checkedAt);
    if(storage.status!=='verified'||storage.runtime!==ctx.project.containerRuntime||!storage.desiredRoot||storage.desiredRoot!==(ctx.project.storageRoot||storage.desiredRoot)||!Number.isFinite(age)||age<0||age>24*60*60*1000)throw new Error('STORAGE_REQUIRED');
    result.checks.storage='verified';
  }catch{result.missing.push('ACTUAL_STORAGE_LOCATION_CHECK_REQUIRED');}
  if (!Number.isInteger(ctx.project.port) || ctx.project.port < 1024 || ctx.project.port > 65535) throw new Error('INVALID_PROJECT_PORT');
  try {
    const page = await fetcher('http://127.0.0.1:' + ctx.project.port, { signal: AbortSignal.timeout(5000), redirect: 'error' });
    result.checks.localPage = page.ok ? 'reachable' : 'failed';
    if (!page.ok) result.missing.push('LOCAL_PAGE_FAILED');
  } catch { result.missing.push('LOCAL_PAGE_UNREACHABLE'); }
  const services = await json(join(ctx.root, '.ai-coding/services.json'));
  // A reachable page is not proof of browser interaction or actual mounted hot reload.
  try {
    const browser = await json(join(ctx.root, '.ai-coding/evidence/browser.json'));
    if (!validEvidence(browser,'browser') || browser.binding?.image !== ctx.project.image || browser.binding?.port !== ctx.project.port) throw new Error('BROWSER_REQUIRED');
    result.checks.browser = 'verified';
  } catch { result.missing.push('BROWSER_AND_HOT_RELOAD_CHECK_REQUIRED'); }
  { // Current rules observation is required independently of external services.
    try{const rules=await json(join(ctx.root,'.ai-coding/evidence/rules.json'));const binding=await initializationBinding(ctx,services,'rules');if(!validEvidence(rules,'rules')||rules.binding?.guidanceSha256!==binding.guidanceSha256)throw Error('RULES');result.checks.rules='verified';}catch{result.missing.push('TRAE_PROJECT_RULE_LOAD_OBSERVATION_REQUIRED');}
  }
  result.status = result.missing.length ? 'pending' : 'verified';
  await atomicJson(join(ctx.root, '.ai-coding/initialization.json'), result);
  await atomicJson(join(ctx.root, '.ai-coding/project.json'), { ...ctx.project, initializationStatus: result.status });
  const current=join(ctx.root,'docs/progress/current.md');
  try{let text=await readFile(current,'utf8');if(text.includes('工程已生成；本地构建、起始网页、热更新与规则加载待检查。')){text=text.replace('工程已生成；本地构建、起始网页、热更新与规则加载待检查。外部能力按需求在对应阶段接入。',result.status==='verified'?'初始化技术检查已通过；业务开发和本人试用分别记录。下一步按已确认设计维护本轮Spec并实施。':`初始化仍待完成：${result.missing.join('、')}。助手沿原入口补缺。`);await writeFile(current,text);}}catch(e){if(e.code!=='ENOENT')throw e;}
  return result;
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2), i = args.indexOf('--project');
  if (i < 0 || !args[i+1] || !['record','check'].includes(args[0])) throw new Error('Use: check --project <root>, or record --project <root> --service <name> --evidence <path>');
  const action = args[0] === 'record' ? recordEvidence(args[i+1],args[args.indexOf('--service')+1],args[args.indexOf('--evidence')+1]) : checkInitialization(args[i+1]);
  action.then(value => { if(value) { console.log(JSON.stringify(value)); if (value.status !== 'verified') process.exitCode=2; } })
    .catch(error => { console.error(error.message); process.exitCode=1; });
}
