# 通用默认能力｜仅供 Agent 实施

本配置适用于当前已验证工具箱的 Web/Cloud/Android/AI 路线，不是所有 AI Coding 项目的通用技术标准。用户已有工程采用其他路线时先评估兼容性，不能强行重写。

实施前遵循通用项目 Skill 的迭代顺序：本轮功能目标 → Gemini 更新 PRD → Canvas 更新 HTML → 用户试用确认 → 分步实现与测试 → 验收记录。每次增加云端、手机或 AI 能力都更新需求和原型，不只在首次开发时检查。已确认的本轮材料直接沿用；实现缺陷直接修复，不要求用户重复完成设计流程。

| 用户的功能目标 | 默认执行能力 | 必须实际验证 |
| --- | --- | --- |
| 本机网页保存 | Ionic React + TypeScript + Vite，Tailwind 3 本地编译；IndexedDB；Repository 隔离数据实现 | 保存、重开、更新、删除；原型外观对照；本机断网 |
| 分享网页、云端保存 | 静态网页发布按项目配置，可采用 GitHub Pages；CloudBase PostgreSQL 与图片存储、登录和最小权限 | 网页发布与真实跨会话 CRUD、图片分别验证；实际账号策略由本项目确认 |
| 安卓使用与同步 | Capacitor 6 复用网页；镜像内 `knowstar-android-build` 是工具历史名称，可用于任意兼容项目 | 同步最新 Web 后离线构建 APK，实测安装、触控、账号恢复和跨设备数据 |
| 增加 AI 功能 | 默认 CloudBase 服务端网关 + 硅基流动兼容接口；前端不暴露模型密钥 | 根据用户任务配置模型；真实调用、输出校验、用户确认和失败回退 |

框架和平台默认值由工具能力配置承担，不向非技术用户提出候选清单。模型 ID、函数名、表名、登录策略、页面结构和数据规则必须来自本项目配置或需求；不得默认植入某个示例。

CloudBase 开发接入在 Agent/MCP 所在环境执行；构建在项目容器中执行；部署目标是用户云端环境。按官方 Skill/MCP 路径接入并只读核验自己的 EnvId、站点和 PostgreSQL 类型；不能用容器里的 SDK 存在替代 MCP 已连接。用户本人完成授权和密码/密钥输入。

已有项目的权限修改先检查实际前端读写表、GRANT/RLS 和用户归属，以真实用户 CRUD 验证，不只看管理员查询成功。部署到其他服务或扩大权限不属于“启动项目”的自动动作，按用户实际功能请求的范围执行。

APK 构建命令：项目 Compose 根中 `docker compose run --rm app knowstar-android-build`。它先生成或同步 Capacitor 资源，再执行 Gradle `:app:assembleDebug --offline --no-daemon`。输出为 `app/android/app/build/outputs/apk/debug/app-debug.apk`。完整根任务的缓存已预热，可另外按实际需要复核；不要求学员自己运行 Gradle，也不在准备工具阶段当作某个产品交付。
