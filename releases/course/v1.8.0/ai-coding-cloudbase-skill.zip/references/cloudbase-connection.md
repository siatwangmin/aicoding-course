# Trae 中接入腾讯云官方能力



在 `SKILL.md` 第 3 阶段安装或授权前读取。依据 2026-10-09 实际读取的 [官方 setup skill](https://docs.cloudbase.net/skill.md)、[CloudBase 的 Trae 配置指南](https://docs.cloudbase.net/ai/cloudbase-ai-toolkit/ide-setup/trae)及 [Trae MCP 说明](https://docs.trae.cn/work_remote-mcp-server)编写；执行时再核对当前说明。



## 先检查当前客户端



1. 保持任务当前作品目录不变，确认这是学员的 Trae 本地任务。由当前控制台域名可知本课程为腾讯云国内站，不重复询问国内／国际站；用户实际使用国际站时改用官方对应入口，不混用账号。

2. 查看当前已安装的官方 `cloudbase` Skill、相关域 Skill 和实际可调用的 MCP 工具。已连接时先查授权，不重复安装。当前桌面客户端的可调用工具才是依据，其他客户端、容器或宿主机中存在配置不代表本会话已连接。

3. 官方文档提供 `npx plugins add` 首选，但其列出的支持目标没有 Trae。先核对 `npx plugins targets` 或当前官方支持列表；不要编造 `--target trae`，也不要让自动安装到别的 IDE 代替接入 Trae。当前不支持时使用官方的“不支持该 IDE”的原生接入分支。



## 补齐官方 Skill 与 MCP



- 优先使用 Trae 已有的 CloudBase 原生插件／市场接入，遵循当前官方说明，避免叠加重复 MCP 实例。

- 官方 Skill 缺失时，按 setup skill 的 Skills 分支使用 `npx skills add tencentcloudbase/cloudbase-skills -y`。核对安装结果确实落在 Trae 可发现的位置；只有工具不支持 Trae目标时，按其当前帮助或官方资料将下载的**官方技能目录及引用资源**放到当前用户 Trae 的 `%USERPROFILE%/.trae-cn/skills`，不复制到项目目录。不能只复制根 SKILL.md、丢失它依赖的域 Skill 和 references；不要改写官方包当成等价品。已有官方 Skill 不重复下载。

- CloudBase 的 Trae 指南展示 `.trae/mcp.json`，这是其 IDE 接入路线；Trae 的官方入口是“头像 → 设置 → MCP → 本地 → 创建 → 从市场添加／手动配置”。**不要只写 `.trae/mcp.json` 就报告 Trae 已读取**。优先用客户端实际可用的配置工具代办；只有客户端设置确实必须本人操作时，给一个页面动作，你准备配置内容。

- 原生 MCP 的 stdio 配置取自当前官方文档，不附账号密钥。2026-10-09 Trae 指南展示的配置为：



  ```json

  {

    "mcpServers": {

      "cloudbase": {

        "command": "npx",

        "args": ["@cloudbase/cloudbase-mcp@latest"],

        "env": { "INTEGRATION_IDE": "Trae" }

      }

    }

  }

  ```



  按当前客户端的包装格式适配并合并已有服务器，不覆盖其他 MCP。Skill 是操作指引，MCP 是可调用工具，写了配置只是配置阶段。

- 在**实际运行 MCP 的环境**检查 Node/npm/npx 版本与首次联网下载条件；按 setup skill 修复缺失或改用客户端市场支持的路线。不让学员执行命令，不拿 Docker 中的 Node 代替 Windows MCP 的依赖。执行命令时安全引用路径和参数。

- 能看到工具之后读取 schema，再执行一次只读的授权检查。OAuth／设备码链接来自该次官方工具结果，由 BrowserUse 打开并交本人完成批准，之后重新查状态；控制台已登录不替代管理端授权。



## 首会话 MCP 未加载时



官方 setup skill 明确允许先配好 MCP，再在本会话使用 **官方 Skill + `tcb` CLI**。执行 `tcb --version`；没有 CLI 时按官方说明安装 `@cloudbase/cli`，随后 `tcb login`、查询环境、绑定环境。读取官方 CLI 域 Skill 与当前命令帮助，不凭记忆编造创建或密钥命令，不使用笼统的 `tcb deploy`。



登录授权需要本人批准时用 BrowserUse 处理返回页面。CLI 完成环境、密钥与读取验证后如实报告当前工具路线；客户端刷新后只复查 MCP，不重做云资源创建。网络、权限或工具依赖确实阻塞时保存进度并说明具体缺口，不能把“插件已安装”“授权链接已打开”当作接入成功。



## 核对结果与边界



本任务需要的官方域能力是环境管理与 `auth-tool-cloudbase` 的 Publishable Key，不要求调用所有域 Skill。授权、绑定和 `queryEnv(info)`／CLI 等价详情读取都应有真实结果；两个值实际保存并读回后才达到课前准备完成：无作品时使用工作区 `.cloudbase-setup/connection.env`，已有作品时使用真实源码 `.env`；作品配置接入与管理授权分别记录。没有调用官方管理工具就不能写“腾讯云 Skill 已接好”。



创建环境的确认要求以实际官方工具为准。先准备具体名称、地域、资源、当前套餐和费用摘要，复用用户已对同一配置的明确决定；要求确认时只确认这一具体操作。未获同意不能为创建调用伪造确认参数。免费接口路径不可用时核对官方错误与资格，不用付费 ID 替代，不重复下单。



官方安装页可能建议创建后端或部署例子；本课程准备任务到配置检查为止。课程 E-06 完成后先回到网页 E-07 准备 GitHub，再由 E-08 的硅基流动陪练准备 AI 服务，然后建立作品并完成需求和原型；进入 V2 才依据已确认材料接入云端保存并验证同步，不自动扩展到部署、数据表或新页面。

