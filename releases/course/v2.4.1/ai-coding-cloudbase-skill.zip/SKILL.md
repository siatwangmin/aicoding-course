---
name: ai-coding-cloudbase
description: 在当前目录准备或恢复 CloudBase 账号与授权；在已选择云端能力的作品中实现数据、权限、存储、函数、托管和受保护的 AI 后端。
---

# 当前项目的 CloudBase 能力

只安装于准备目录或明确启用能力的作品 .trae/skills。先读当前根 AGENTS、manifest/services 与进度，核模式和精确目标。MCP/CLI可能共享登录，但每次云操作必须核当前作品的环境、身份和授权范围，不使用其他作品绑定。

准备模式读取 [账号与环境准备](references/account-preparation.md)，复用本人账号、实名、官方接入及可用PG环境，保存公开连接值并返回 env 汇总。此模式不创建业务表/函数、不部署作品，不要求模型供应商账号或调用。

项目模式：先经用户级 project 的 Enable-ProjectCapability 安装本技能；按 [云端实施](implementation/cloudbase.md) 实现当前需求的业务数据、身份、权限、存储和部署。全部云端管理沿腾讯云官方 CloudBase Skill 的 MCP 或官方CLI；官方技能也优先安装到当前工作区，不把 SDK 存在当工具授权通过。

需要 AI 时才读 [AI服务设置](implementation/ai-service-setup.md)、[模型设置](implementation/model-settings.md) 与 [AI实施](implementation/ai.md)。本人在已实现的受保护设置中输入供应商Key，服务端受限保存；账号与调用仅属于当前AI需求，不是环境或纯本地初始化门槛。默认配置见 assets/default-models.json，保留已有供应商和有效模型，不自动换平台或充值。

Web/APK callFunction→CloudBase函数→项目已配置模型服务，秘密不进入前端/Git/APK/镜像/日志。AI私有配置先按 [服务身份](implementation/ai-settings-access.md) 验证后端PG访问与指定配置用户授权，不因管理工具可用就放宽应用权限。

网页发布使用 scripts/Publish-CloudBase.ps1 与已确认官方路线，核本轮产物和真实访问地址。每次首次、更新或恢复部署后，在完成回复给出完整https网址和可点击链接，说明状态；控制台或旧网址不能代替本轮作品入口。访问、真实读写/同步、模型结果及本人试用分别验证。

授权失效或访问异常只补当前缺项；权限分管理授权、应用会话、GRANT/RLS与归属，不放开匿名写、关闭RLS/TLS或重建环境。实际SDK/CLI版本适配读取 references/management-operations.md。更新项目Spec、证据与进度，再接续原任务。
