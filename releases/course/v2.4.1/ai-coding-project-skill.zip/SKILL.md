---
name: ai-coding-project
description: 在任意目录创建或恢复作品，复用已准备工具；按当前需求为当前作品安装 GitHub、CloudBase、Android 或明确选择的案例技能，并接续接入。
---

# 项目初始化与能力管理

本技能是唯一用户级入口。读取已有 AGENTS、manifest、服务绑定、设计和进度；恢复已有工程不得重建。运行工具由 scripts/Course-Execution.ps1 从项目绑定或用户发现索引解析，不依赖全局 env 技能。

先读取 implementation/capability-activation.md。需求已明确直接采用；未明确时用功能语言依次确认是否需要公开静态网址、云端保存/多端同步、安卓安装包，可答暂不需要。代码备份/协作同样启用 GitHub。不要求选择技术组件，不因准备过账号或存在案例包默认启用能力。

使用 scripts/Initialize-Project.ps1 -ProjectDirectory <B>，已有当前需求传 -Capabilities 与 -CapabilityReason。本地生成、构建和检查使用已绑定镜像。返回 pending 后，同一任务继续实际网页、热更新与规则加载检查，按 implementation/initialization-evidence.md 留证。

新增能力通过 scripts/Enable-ProjectCapability.ps1，向 B/.trae/skills 安装所需技能，再立即接续返回的 nextSkills 完成真实授权与绑定。仅安装文件不代表服务已接入，初始化本地状态与所请求能力分别报告。

GitHub 源码和 Pages 独立；CloudBase 只启用所需服务；离线 APK 不要求任何平台账号。AI 需要时接项目级 CloudBase 技能的 AI 指南，不设模型供应商准备门槛。未启用项不生成待办。

生成根 AGENTS、Trae alwaysApply 引用、docs/engineering 工作流、Spec 模板与进度。之后助手按这些项目规则直接开发。本地开发指南随工程保存，平台开发及发布由当前项目技能承担。仅明确选择案例才使用 scripts/Install-ProjectCase.ps1 -ProjectDirectory <B> -CaseSkill <已选名称> -PackageRoot <已校验案例包> 安装项目级案例技能；初始化也可传 CaseSkill/CasePackageRoot。缺案例缓存先从明确发布来源取得并校验，缓存存在不代表选择。

恢复先使用 Upgrade-Project 增量更新受管规则，保留自定义冲突、稳定标识和所有有效配置。缺准备工具时定位准备目录 A 的 env 流程；不在 B 临时安装另一套环境。退出给真实入口、项目位置、当前状态和缺项。
