# 按当前需求接入能力

先读当前项目规则、需求和进度，未确认时只问功能问题。公开静态网址→github-pages；代码备份/协作→github；云端保存/同步/服务端→cloudbase；安卓安装包→android；AI→ai（必要的 CloudBase 后端）。需求未明确先建立 local。

调用 scripts/Enable-ProjectCapability.ps1 -ProjectDirectory <B> -Capability <值> -Reason <目标>。入口增量登记能力、物化必要公开配置，安装对应项目技能并返回 pending/nextSkills。它不创建远程资源、调用模型或生成 APK；助手必须在同一任务继续接入与实施。

GitHub 使用 .trae/skills/ai-coding-github；云端及 AI 使用 .trae/skills/ai-coding-cloudbase；Android 使用 .trae/skills/ai-coding-android。平台管理登录可复用，但操作目标必须核 B/services.json。AI 不自动启用业务同步/托管，Android 不自动接云账号。

保留旧绑定，冲突不覆盖。默认只给当前项目增加能力，不删除现有技能。仅安装文件、配置存在、本地初始化通过均不证明服务通过；按 Scope Capability 保存实际证据。未选择项不作为缺项；当前请求尚未完成的能力继续报告待办。
