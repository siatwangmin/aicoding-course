---
name: ai-coding-android
description: 从现有 Web/Capacitor 工程生成或恢复 Android 版本，核验 APK，指导传输安装与真实手机试用。使用环境准备的同一工具链镜像，不预设业务或自动上架。
---

# Android 版本

本技能只在当前已选择Android能力的作品 .trae/skills 生效。运行入口由 scripts/Course-Execution.ps1 解析项目绑定的公共执行包，不依赖全局env或开发技能。

读取根 AGENTS、project.json、services.json、工程基线、已确认手机 PRD/Canvas 及当前进度。按 manifest 找实际源码/Compose；保留已有 appId、依赖、运行时和工程，不能重建以绕过错误。其他既有技术路线先检查兼容性。

“生成安卓版本/安装文件/把这轮网页装到手机/更新APK”均触发；本人不必精确写Skill名。确认本轮材料后，助手在当前spec写清复用Web入口、数据/身份配置、图标/版本、build→sync→Gradle→包内容核验→安装试用的顺序，再直接实施，不要求本人选择框架或重复批准。

当前Android需求先调用项目Skill Enable-ProjectCapability -Capability android，按capability-activation.md保留稳定appId并物化必要配置，再继续原任务。离线APK不要求GitHub、CloudBase、硅基流动；只有同步需求才接云端。

默认复用同一个 Web 工程和已验证 Capacitor 工具。开发、Web 编译、cap sync 和 Gradle 均在项目绑定的准备镜像内执行；不在宿主安装 Java/Android SDK，不另拉 latest 或临时下载工具。

引擎未开先恢复原工具；缺Linux平台依赖查命名卷/lockfile并在原镜像修复。不要把宿主node_modules挂入容器，不因JDK/Gradle不匹配升级Capacitor。以实际webDir/入口为准；独立移动入口只在需求要求时实现。打印等原生功能按当前插件版本核线程/权限，不能以Web模拟冒充原生实测。

标准入口是 [Build-Android.ps1](scripts/Build-Android.ps1) `-ProjectDirectory <B>`：宿主PowerShell控制所选引擎，Web/cap sync/Gradle/Node资源核验均在准备镜像内，不要求宿主安装Node。脚本核运行/独立依赖卷，分阶段比较Web→Capacitor→APK资源，生成带版本/buildId交付副本。旧 scripts/android.mjs 保留兼容与低层测试，不作为新交付入口。manifest为旧版先由项目技能恢复准备绑定；Podman沿已登记原连接，不静默换引擎。

本轮图标已确认时将 project.android.iconReviewRequired 设true；脚本输出预览后实际对照确认设计，在 .local/android-delivery/icon-review.json 记录 status=verified、apkSha256、designSource、checkedAt，再用同入口 -Finalize。未目视核对不能写此证据；图标未确认的中性工程不凭空强制图标。实际webDir不同于dist时写project.android.webDir，不能靠重命名入口猜路径。

调用脚本前按 [交付检查](implementation/acceptance.md) 确认设计与数据策略。有云共享需求时检查当前环境、用户归属和会话恢复；本地作品不强制引入云登录。

脚本输出实际 APK 绝对路径、SHA-256、版本来源与构建记录。每次 APK 生成完成（包括首次构建、更新和恢复构建），必须在面向使用者的完成回复中给出本次实际 APK 文件的完整绝对路径和可点击文件链接，并说明这是供传输安装的文件；不能仅在脚本输出或进度文件中记录，也不能只说“APK 已生成”、只给文件名、目录或相对路径。交付前确认文件确实存在且对应本轮 hash/版本；容器内生成的包先导出到使用者可访问的宿主机目录，再给出宿主机路径。路径含空格时使用支持空格的 Markdown 链接格式。构建失败时说明阻塞，不把旧包或预期路径当成本次产物。之后仍须带本人传输、安装、启动和试用；不能以构建成功或旧 APK 代替真机结果。需要重新试用时确认安装的是本次 hash/版本。

构建失败保持failed，旧包保留备查；网页不更新沿build/sync/APK内资源定位，不能只跑Gradle、改名交旧包或让本人反复安装替助手排障。包名/版本正确不证明网页或图标正确，交付前按acceptance核实际资源，未核项不得称通过。

可用已授权 adb 时助手承担设备检查与传输；否则一次引导一个手机动作，不默认要求 USB 调试、不绕过系统安装授权。本人未试过明确待试。发布商店、正式签名及付费分发不属于生成 debug APK 的自动动作。

新 Podman 工程通过项目绑定公共执行包的 scripts/Course-Runtime.ps1 的共同入口执行，复用其受管 Docker Compose EXE、显式 connection、API 转发验证与超时，不依赖 Desktop 或默认 PATH。构建失败保留原镜像/工程/身份并按对应层恢复。旧 Docker 工程继续按原绑定。

## 估时与等待

读取本技能 assets/course-timing.json，按当前阶段/步骤说明首次或复用的预计时间。长下载、编译、部署说明真实等待原因及本人是否需要操作；超过预计上限说明已完成部分、阻塞和处理，有依据才更新剩余时间。时间估算不代替实际证据，不展示虚假百分比；实际等待计入墙钟。
