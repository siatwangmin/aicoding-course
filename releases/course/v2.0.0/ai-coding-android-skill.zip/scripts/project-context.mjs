import { readFile, writeFile, lstat, readdir, mkdir, rename } from 'node:fs/promises';
import { resolve, join, relative, isAbsolute, dirname } from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { spawnSync } from 'node:child_process';

export async function plainPath(path) {
  let cursor = resolve(path);
  for (;;) {
    try { if ((await lstat(cursor)).isSymbolicLink()) throw new Error('LINK_PATH_REFUSED'); }
    catch (error) { if (error.code !== 'ENOENT') throw error; }
    const parent = dirname(cursor); if (parent === cursor) break; cursor = parent;
  }
  return resolve(path);
}
export function within(root, path) {
  const result = resolve(root, path), rel = relative(root, result);
  if (rel === '..' || rel.startsWith('../') || rel.startsWith('..\\') || isAbsolute(rel)) throw new Error('PATH_ESCAPES_PROJECT');
  return result;
}
export async function json(path) { await plainPath(path); return JSON.parse((await readFile(path, 'utf8')).replace(/^\uFEFF/, '')); }
export async function atomicJson(path, value) {
  await plainPath(path); await mkdir(dirname(path), { recursive: true });
  const temp = path + '.' + randomUUID() + '.tmp';
  await writeFile(temp, JSON.stringify(value, null, 2) + '\n'); await rename(temp, path);
}
export async function context(root) {
  root = await plainPath(root);
  const project = await json(join(root, '.ai-coding/project.json'));
  if (!['docker', 'podman'].includes(project.containerRuntime) || !project.image || /\s/.test(project.image)) throw new Error('INVALID_PROJECT_TOOLCHAIN');
  const source = await plainPath(within(root, project.sourceDirectory));
  return { root, source, project };
}
export function command(exe, args, cwd, options = {}) {
  const result = spawnSync(exe, args, { cwd, encoding: 'utf8', shell: false, ...options });
  if (result.error || result.status !== 0) throw new Error('COMMAND_FAILED:' + exe + ':' + (result.status ?? 'unavailable'));
  return result.stdout;
}
export function engineArgs(project) {
  if (project.containerRuntime === 'docker') return ['--host', 'npipe:////./pipe/dockerDesktopLinuxEngine'];
  if (!project.connection || !/^[a-zA-Z0-9_-]+$/.test(project.connection)) throw new Error('PODMAN_CONNECTION_REQUIRED');
  return ['--connection', project.connection];
}
export function verifyImage(ctx, run = command) {
  const p = ctx.project, prefix = engineArgs(p);
  const info = JSON.parse(run(p.containerRuntime, [...prefix, 'info', '--format', 'json'], ctx.root));
  const os = info.OSType || info.host?.os, arch = info.Architecture || info.host?.arch;
  if (os !== 'linux' || !['amd64', 'x86_64'].includes(arch)) throw new Error('LOCAL_LINUX_ENGINE_REQUIRED');
  const [actual] = JSON.parse(run(p.containerRuntime, [...prefix, 'image', 'inspect', p.image], ctx.root));
  const identity = p.toolchain;
  if (!identity || !identity.imageDigest) throw new Error('PREPARATION_BINDING_REQUIRED');
  const digestMatches = actual.RepoDigests?.some(value => value.endsWith('@' + identity.imageDigest));
  const approvedOffline = identity.verificationMethod === 'archive-sha256+image-config' &&
    /^sha256:[a-f0-9]{64}$/.test(identity.imageId || '') && actual.Id === identity.imageId && /^[a-f0-9]{64}$/.test(identity.archiveSha256 || '');
  if (actual.Os !== 'linux' || actual.Architecture !== 'amd64' || (!digestMatches && !approvedOffline)) throw new Error('PREPARED_IMAGE_MISMATCH');
  const config = JSON.parse(run(p.containerRuntime, [...prefix, 'compose', 'config', '--format', 'json'], ctx.root));
  if (config.services?.app?.image !== p.image || config.services.app.build) throw new Error('COMPOSE_IMAGE_MISMATCH');
  const service=config.services.app;
  if (!service.volumes?.some(volume => volume.type === 'bind' && volume.target === '/workspace' && resolve(volume.source) === ctx.source)) throw new Error('COMPOSE_SOURCE_MISMATCH');
  if (service.volumes?.some(volume => volume.target === '/workspace/node_modules' && volume.type !== 'volume')) throw new Error('HOST_DEPENDENCY_MOUNT_REFUSED');
  if (Object.keys(service.environment || {}).some(key => /SILICONFLOW_API_KEY|TENCENTCLOUD_SECRET|CLOUDBASE_SECRET/.test(key))) throw new Error('SERVER_SECRET_IN_APP_CONTAINER');
  return { image: p.image, imageId: actual.Id, imageDigest: identity.imageDigest, verificationMethod: digestMatches ? 'registry-digest' : identity.verificationMethod };
}
export async function sourceDigest(root) {
  const hash = createHash('sha256');
  async function walk(directory) {
    for (const entry of (await readdir(directory, { withFileTypes: true })).sort((a,b) => a.name.localeCompare(b.name))) {
      if (['node_modules', 'dist', 'android', '.git', '.local'].includes(entry.name) || entry.name.startsWith('.env')) continue;
      const path = join(directory, entry.name);
      if (entry.isSymbolicLink()) throw new Error('SOURCE_LINK_REFUSED');
      if (entry.isDirectory()) await walk(path);
      else { hash.update(relative(root, path)); hash.update(await readFile(path)); }
    }
  }
  await walk(root); return hash.digest('hex');
}
