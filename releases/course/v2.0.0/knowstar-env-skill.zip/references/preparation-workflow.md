# 完整课前准备与恢复

课前短提示请求“全部准备”时，env是总编排入口，工具检查通过后连续调用当前用户cloudbase→github→siliconflow，最后汇总，不停在E-01让本人再说继续。只明确请求工具排障/复查时保持该范围，不擅自创建云资源或产生模型费用。没有作品时不创建业务工程/表/函数/APK。

1. 保存A和所选引擎，读取materials/runtime/原工具与服务记录。缺资料按setup-guide零资料入口下载/安装用户级技能，保留已有内容。
2. 按所选引擎指南安装/恢复并实际Verify，记录D盘计划和实际位置；引擎/镜像/容器检查各自完成。准备记录登记用户索引，不复制原始日志到用户目录。
3. 调ai-coding-cloudbase复用本人账号/实名/官方工具授权/环境，真实核PG能力及公开连接；无目标时才在本人已决定费用范围准备环境。
4. 调ai-coding-github核本人登录/邮箱；推送和Pages权限在B绑定时另核，不把头像当管理授权。保留官方登录缓存，不索取token。
5. 调ai-coding-siliconflow核本人账号/费用范围，先开启隐藏输入再引导粘贴；复用Key并按授权最小验证。保存加密凭证引用和脱敏结果，不创建业务函数。
6. 用 Register-CourseServices.ps1 登记允许摘要；最后E-05实际复查所选引擎/完整用户级Skill/存储/服务状态，明确每项范围和缺项。步骤勾选不代替工具结果。

每阶段记录本次结果、检查时间、实际入口、当前本人动作与下一阶段。发生本人授权/费用/条款/重启时一次引导一个动作并保存接续点；完成后继续。正常技术操作不暂停让本人重复发提示，也不自动批准其身份/费用。

用 scripts/Invoke-CoursePreparation.ps1 -WorkingDirectory <A> -Action Status 取得下一阶段/Skill；完成后 -Action Record -Stage tools|cloudbase|github|ai|summary -EvidencePath <真实证据JSON>。tools使用本次工具报告且技能/实际存储须通过；ai使用真实verification.json；cloudbase/github/summary使用脱敏checkedAt/status/checks/evidence记录。脚本不登录、不代办费用，也不把记录当实际检查；缺项时由Agent立即调用nextSkill接续，不把JSON交给本人。

cloudbase checks为identityVerified/managementAccessVerified/pgCapabilityVerified/publicConfigSaved；github为identityVerified/emailVerified；summary为skillsVerified/traeLoadObserved/currentResultsReviewed。没有观察到Trae加载不得填true。证据改动/超过24小时需当前复查后重新登记，模型调用有效旧证据仍可按授权范围复用；刷新记录不意味着重调付费模型。

恢复先查A与用户级准备索引，仅补失效项；多环境冲突保留工程并核对目标。Podman不在PATH使用实际验证的绝对路径；缺CLI/Compose按官方安装链补齐，不把Desktop安装等同Ready。引擎离线恢复所选引擎，不切另一个；TLS失败核可信CA/出口，不禁用证书。下载慢按实测恢复，不能承诺可越过客户端网络策略。

PS5.1清单必须完整写入头部、技能逐项行及未验证项；核本次退出码/时间/内容，不能只看文件存在。旧通过留历史，本次失败不得沿用。费用/模型变化先核已授权范围，普通恢复不反复要求本人批准。

给学员的结果用功能语言：“工具已准备，接下来完成云服务授权”“课前还差AI验证”等；不把技术检查变成学员作业，不承诺固定审批次数或理想耗时。完整课前通过与作品可运行/已部署/手机通过分开。
