# 知错星学员工程约束

本文件仅在用户选择知错星案例时合并到当前项目，不能写入通用环境或其他产品。工程由通用项目助手启动；兼容已有目录，不要求使用固定的 knowstar-learning 名称。学员自己与 Gemini 完成实际设计目录中的 PRD 和 Canvas HTML；新工程默认 docs/design，旧工程沿用根目录等已有位置和文件名；这是每轮设计阶段的全部必交输入。PRD 给出产品规则，HTML 是页面视觉与交互依据，技术路线由本文件和课程 Skill 给出。先明确前阶段的通过与未验证项，再推进可执行的下一阶段。

## 每轮迭代的顺序

V1、V2、V3、V4 及每项后续功能均为：功能目标 → Gemini 新建或更新 PRD.md → Canvas 新建或更新 HTML → 学员试用确认 → Trae 分步实现与实际测试 → 学员验收 → 记录进度。核对两份材料确实覆盖本轮目标；不能因为文件已存在就跳过本轮需求和设计。已经确认的本轮材料直接使用，不重复审批。V1 移植原始原型；后续仅实现本轮确认的变化，保留案例结构和已确认规则。实现偏差直接修复与复测；改变功能或规则先更新需求和原型。该流程是学员的学习目标，知错星业务只是实例。

## 固定技术路线

- V1 本地网页：Ionic React、TypeScript、Vite、Tailwind 3 本地编译、IndexedDB；业务数据通过 Repository 接口读写，后续可接云实现。保持单页 Monster Deck、Weekend Trial、Add Monster Modal；不加五 Tab 外壳。实际 Canvas HTML 是视觉与交互基准，移植其样式和状态，不只照着文字描述重做。
- V2 云端：腾讯云 CloudBase 静态托管发布正式课程网页，CloudBase PostgreSQL 保存演示题目，Storage 保存图片；GitHub Pages 是独立静态发布补充练习。先复查 E-06 课前已准备的账号、官方接入和本人环境；缺项才调用 CloudBase 陪练从记录继续，不重复开通。按项目课程 Skill 的 implementation/course-demo-auth.md 由 Agent 准备固定演示用户，自动登录后用真实会话访问云端。保持 V1 页面与规则。
- V3 安卓：Capacitor 6 打包同一 Web 工程；使用 V2 的课程演示用户登录并同步，不另建用户系统或重写页面。
- V4 AI：网页和 APK 只用 CloudBase SDK `callFunction()` 调 `vision-question`、`learning-ai`；云函数服务端通过硅基流动 API 调用默认模型 `Qwen/Qwen3.8-27B`（识题）和 `deepseek-ai/DeepSeek-V4-Flash`（错因、引导、变式、报告）。`SILICONFLOW_API_KEY` 仅在服务端；模型 ID 在各自函数环境中配置。模型不可用时报告错误，等待课程负责人确认替代。图文识别形成可编辑草稿，人工确认后保存；模型错误可手工继续；AI 不直接修改掌握等级。

## 工作与验收

每次任务先读取本工程现状、`PRD.md`、Canvas HTML 和前阶段记录；不因缺少 spec 或交接文档而阻断开发。已确认的范围连续实施，交付时集中提供试用入口；案例执行节奏优先于通用约定中每个小功能单独构建和交付的描述。实际执行必要构建/测试并报告结果。V1 先确认 Tailwind/PostCSS 已从镜像本地编译，构建 CSS 中有页面实际使用的工具类，再按相同视口和数据状态对照原型与实现截图。不要只检查构建成功，也不要用 Tailwind CDN 补样式。学员不在宿主机装 npm、Java 或 Android SDK；统一容器提供工具链。不要把公开网页地址能打开误认为云同步完成。不要把 API Key、管理密钥、个人错题图片写进 Git、`VITE_*`、APK 或输出日志。真实设备、云端同步和公网发布未执行时明确写“未验证”。

V1 IndexedDB 本地版独立保留。V2–V4 的课程网页和 APK 自动使用指定演示用户并恢复会话，不增加注册、账号切换或登录练习。该公开课堂凭据是明确允许预置的例外，具体值和准备方式只在课程 Skill 的 implementation/course-demo-auth.md 维护；本人平台密码、管理令牌与模型 Key 仍不进入前端、APK、Git 或日志。PG 与图片桶只允许已登录用户访问；V4 的两个 AI 函数只允许非匿名已登录用户调用，并限制用量。云端模式仅在线访问 PostgreSQL，不做本地双写或离线队列。只录虚构例题；原有私有表的 RLS 不得放宽。


## 与非技术学员沟通

学员学习 AI Coding 的目标表达、范围取舍、分步推进、试用反馈与验收。采用功能语言说明目标，技术命令由 Agent 执行并留在脱敏进度中。一次只问一个必要的产品问题；本人授权和试用时给一个明确动作及预期结果。不要让学员记忆技术栈、模型 ID 或复制长技术提示。识别“本机保存、云端共享、安卓同步、增加具体 AI 功能”等需求，自动读取案例内部实施要求。环境准备和项目启动不得带入本案例业务。

<!-- knowstar-course:v1-pace:2 -->
## V1 连续实施与集中验收

学员提示词保持课程网页原样，课堂时间和技术约束由 Agent 承担。材料确认且工程已启动后，从当前用户的 `%USERPROFILE%/.trae-cn/skills/knowstar-course/implementation/v1.md` 读取执行指南，按其要求 以约 15 分钟为执行目标：核对材料、连续实现、集中技术检查、一次学员试用。小成果只是内部实现顺序，不逐项等待学员批准；只在材料冲突、必要输入缺失或本人操作时暂停。复用现有实现，不重新初始化、不重复安装。检查 Windows 挂载文件变更能触发 Vite 页面更新；仅 HTTP 200、healthy 或构建成功不能宣布 V1 通过。第 10 分钟仍有阻塞时简短说明；不能为赶时间删功能、降验收或虚报完成。技术细节、耗时与未验证项写入工程记录，不向学员追加长提示或摘要作业。

<!-- knowstar-course:v2-pace:1 -->
## V2 连续实施与集中验收

学员提示词保持原样。本轮材料已确认且 V1 已验收时，读取当前用户 `%USERPROFILE%/.trae-cn/skills/knowstar-course/implementation/v2.md`，按其约 20 分钟预算完成课前状态复查、真实会话最小读写、现有界面云端接线、CloudBase 发布和集中双浏览器验收。只增量读取和实现，不重建工程、不重复开通、不在作品开发中穿插课程资料维护或 Pages 补充练习。指定演示账号与 SDK 返回结构按 course-demo-auth.md，先验证身份再访问资源；先排除旧页面/前端校验，再定位登录或 RLS，不能盲目刷新重启。第 10/15 分钟仍有阻塞时简短说明，超时不降验收、不放宽权限、不标完成。V2-06 保留学员保存、同步和失败重试；未改的 V1 功能沿用证据。Gemini/Canvas 设计、课前准备、本人等待和本轮总耗时分别如实记录。

<!-- knowstar-course:cloud-preparation:1 -->
## 课前云服务与 V2 衔接

课程 E-06 调用 ai-coding-cloudbase，在课前完成腾讯云注册/登录、实名、官方授权和 PostgreSQL 练习环境检查；E-07 调用 ai-coding-github 完成本人的 GitHub 免费账号与邮箱验证。没有作品时将两个客户端连接值保存到原 workspace 的 .cloudbase-setup/connection.env，记录准备证据，不创建产品工程、业务表或部署。作品建立后由助手自动合并到实际源码配置，V1 保持本机模式。V2-04 只复查与补缺；复用账号、环境和有效授权，不要求学员重注册、抄变量或重新走完整开通。V2 作品演示用户由 Agent 准备和检查，模型凭证在 E-08 课前准备，V4-04 仅复查补缺。本人授权、条款和费用决定按真实页面处理；未完成不标通过。

<!-- knowstar-course:ai-preparation:1 -->
## 课前 AI 服务与 V4 衔接

E-08 调用当前用户 %USERPROFILE%/.trae-cn/skills/ai-coding-siliconflow，按 knowstar-course/implementation/siliconflow-models.json 陪本人登录、核对额度/费用、创建或复用 Key，并通过隐藏输入保存到 workspace 的 .ai-setup/siliconflow.env（基础地址 https://api.siliconflow.cn/v1）。目录限制本人访问、Git/打包/镜像排除；不得回显、写入 VITE_*、前端 .env 或 APK。建立作品时安全迁移准备结果并记录来源，不重注册、不将秘密放入 app。

V4-04 只复查当前凭证和所需模型，缺项恢复陪练；不要求已有云函数、不提前编码。V4-05 读取项目 knowstar-course/implementation/v4.md，只实现当前选定任务：网页/APK 用 callFunction 调 vision-question 或 learning-ai，云函数通过 HTTPS 直接请求硅基流动，不使用 CloudBase 内置 AI。旧 provider 的 SILICONFLOW_BASE_URL 要完整 /v1/chat/completions，避免与准备文件的基础地址混淆。凭证已保存、模型服务可用、云函数接通、页面/真机验收分别记录，不能互相代替；免费环境是否支持函数运行与外网请求需要实测。

<!-- knowstar-course:v4-vision-pace:1 -->
## 选图识题的课堂节奏

当前选择“选图识题”、本轮材料已确认且 V3 已验收时，读取 当前用户 %USERPROFILE%/.trae-cn/skills/knowstar-course/implementation/v4-vision-pace.md，配合 v4.md 固定调用链，以约 15 分钟为 V4-04—V4-06 的复查、增量实现、发布与网页/真机验收目标。保持学员原提示词；复用当前授权路线、现有依赖和固定虚构题图，同一函数更新串行等待终态，配置失败只补配置，不列桶找图或新建绘图工具链。第 10/12 分钟仍有阻塞须简短说明，第 15 分钟记录实际状态；本人等待计入总墙钟，未安装/未试的新 APK 不能标通过。短记录支持接续；不降低鉴权、限额或本项验收，不提前实现其他 AI 任务。其他任务不自动套用识图预算。

<!-- knowstar-course:learner-roles:2 -->
## 学员操作与助手检查

读取 课程 Skill 的 implementation/learner-responsibilities.md（本仓库来源为 docs/teaching/knowstar-course-skill/implementation/learner-responsibilities.md）。本人只确认需求、可见结果和亲自试用；工具、配置、文件版本/备份、调用核验、失败测试与记录由助手完成，不转成学员作业。E-05 汇总四项课前准备；V2 准备独立试用窗口并自行做受控失败测试，保留新增/图片/等级/删除/重试门槛。本人登录授权、费用决定和真实手机操作仍需本人完成。助手未验证或本人未试过不得说通过，网页勾选不当真实证据；保持现有产品规则与内部时间预算。

助手的逐步检查默认读取同一课程 Skill 的 implementation/agent-step-checks.json，按当前步骤和 AI 任务取检查项与阶段门槛。学员页面不展示这些内部要求，不要求学员替助手检查或勾选助手完成状态。E-01 短提示（含原 E-04）默认完成安装和实际运行检查、保存报告且不创建作品；仅在需要本人时给一个动作。保留全部技术验收，未验证项照实记录。

<!-- knowstar-course:project-start:1 -->
## 建立作品的默认执行

本课程 P-01 的“调用ai-coding-project技能创建学生错题本项目工程。”已足够启动项目助手。当前课程案例是“知错星”学生错题本，沿用已确认名称与用途，不要求学员补充长提示。调用当前用户已安装的 ai-coding-project，带本人选择空文件夹，自动检查并提供可打开的起始网页和作品位置；仅建立工作空间，具体功能等本轮需求和 Canvas 页面设计确认后再做。把所选案例及执行约定合并到新作品 AGENTS，并记录实际路径；已有工程和修改保留，不能因这条默认约定重建或重新初始化。技术检查由助手完成。

<!-- knowstar-course:trae-bootstrap:1 -->
## Trae 先行的课前准备

当前课前顺序为 E-02 安装打开 Trae → E-01 助手连续下载课程资料与官方安装包、实际安装和工具验收（原 E-04 合并）。E-01 的在线 setup-guide 提供无需预装 Skill 的 Get-CourseMaterials.ps1 入口；小资料包从 GitHub Pages 固定版本取得，所选 Docker/Podman 与 WSL 只用清单中的官方原始地址，不下载 GitHub Release 完整包。读取 workspace 的 .course-setup/materials.json 定位实际资料根和 setup-guide，六项课程技能安装在当前用户 %USERPROFILE%/.trae-cn/skills，不要求学员下载、解压、搬文件或重新打开目录；保留已有工程、修改和有效准备记录。资料下载和安装程序就绪不能代替 E-01 的实际验收，E-05 仍最后汇总。

<!-- knowstar-course:user-skills:1 -->
## 课程技能统一使用用户级安装

六项课程技能统一安装在当前用户的 %USERPROFILE%/.trae-cn/skills，不放入项目 .trae/skills，也不随新作品复制。读取已安装 Skill 的实际根目录与其 implementation；已有同名用户副本先备份再更新，当前工作区的同名项目副本先备份再移出发现目录，保留其他技能与工程修改。资料、工具验收和服务准备记录仍保存在原 workspace，凭证不迁入全局技能目录。E-01 发送一次提示后连续完成下载、安装和真实验收；旧 E-03/E-04 进度映射到 E-01，不要求学员再发第二条提示。

<!-- knowstar-course:container-runtime:1 -->
## 容器工具选择与恢复

课前环境页可选 Docker Desktop 或 Podman Desktop；只准备本人所选的一种，不要求同时安装。读取本轮明确选择、现有作品 .ai-coding/project.json 的 containerRuntime、workspace 的 .course-setup/container-runtime.json / materials.json；既有记录冲突时保留工程并澄清，不静默切换。旧记录无选择时沿用 Docker 默认路线。准备脚本传 -ContainerRuntime docker|podman，项目生成器传 --runtime 与报告中的实际镜像引用；Podman 再传已验证 NetworkMode。

Docker 继续使用原 Prepare/Verify 与 .docker-setup。Podman 读取当前用户 ai-coding-env/references/windows-podman-setup.md，使用 Setup-PodmanDesktop.ps1、Verify-Toolchain.ps1 -ContainerRuntime podman 和 .podman-setup，核对本机 machine/connection、Linux Server、Compose、固定镜像来源与真实容器检查。选择按钮、安装完成和其他引擎旧报告不能当所选工具验收。Podman 的 rootless/pasta、WSL 与代理兼容只按实测处理，保留已有资源，不关闭隔离、不重建 machine。归档 SHA-256+镜像配置ID与在线 RepoDigest 的证据分别记录，不虚称远端摘要通过。

助手承担下载安装、配置、构建、调用核验与记录；本人只做必要授权、费用决定、条款、重启和亲自试用。环境就绪不代替网页、云端、AI 或真机验收。切换作品复用用户级技能与所选容器工具，不复制技能或重建现有工程。
