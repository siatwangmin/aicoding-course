# Trae 内部执行指南

当前学员网页主线的 V2 正式作品发布到本人 CloudBase 静态托管；本指南的 GitHub Pages 路线仅为独立补充练习，不要求先完成它才能用 CloudBase。正式发布按当前 CloudBase 官方 Skill/CLI 的真实能力执行，读取实际构建配置、来源域名和返回 URL，分别验证公开网址与登录后数据读写。以下历史 Pages 流程只在学员明确选择静态发布练习时应用。

## 开始实施前：本轮需求与原型已确认

本指南只负责技术执行。V1、V2、V3、V4 和每项新增 AI 功能都先按课程 Skill 完成本轮 PRD 与 Canvas HTML 的更新和学员试用确认，再执行下文。已有文件仍需核对本轮变化；本轮材料已确认时直接使用，不重复审批。下文历史章节里的“对 Trae 说”是 Agent 内部任务描述，不能要求学员复制。只实现本轮确认的范围；旧长提示包含多个 AI 任务时按本轮已选任务裁剪。实现偏差直接修复；改变功能先更新需求与设计。

先从项目 manifest 的 sourceDirectory 或已有 Compose 定位实际源码目录与项目根，不假设固定工程名称。新项目源码默认在 app/；旧工程保留原目录。本文中的历史路径示例必须替换成当前项目实际路径。本文保留本阶段已验证的技术要求。由 Agent 自行读取、实施和验收，下面的长提示词是执行约束，不要求学员复制或理解。面向学员时，使用课程页中的功能语言；详细命令与排查证据写入工程记录。

# 实操案例｜先上线静态网页，再启用动态数据

这一步接在 V1 过关之后、V2 开发期间。例子使用你自己的 GitHub 仓库 `knowstar-learning`；网址形如 `https://你的用户名.github.io/knowstar-learning/`。如果仓库另起名字，把下面的 `/knowstar-learning/` 换成实际仓库名。**本轮先实现发布配置；如果暂时不能测试 github.io，记录“公网未验证”并继续 CloudBase，不要卡在这里。**

## A. 先让别人能打开网页

**你对 Trae 说**：

```text
我要先把 V1 页面作为静态网页上线到 GitHub Pages。请检查当前 Vite 工程，给仓库名设置正确的 base 路径；创建 GitHub Actions 工作流，把 dist 发布到 Pages。不要把个人错题、.env.local、密钥或 node_modules 上传。先在容器里构建，确认首页和静态资源路径正确，再告诉我 GitHub 网页上需要点击的位置和预期 URL。
```

**Trae 应做**：在工程的 `vite.config.ts` 根据构建环境设置 `base`，本地开发仍用 `/`，Pages 构建用 `/${仓库名}/`。课程已提供可核对的[Vite 配置样例](../templates/vite.config.pages.ts)和[Pages 工作流样例](../templates/pages.yml)；Trae 应根据你的工程检查后放到 `.github/workflows/pages.yml`，而非盲目覆盖已有配置。GitHub Actions 在其 Ubuntu 环境用仓库锁文件执行 `npm ci`、`npm run build`，上传 `dist/` 并部署 Pages。这里下载依赖发生在 GitHub 的机器上，学员电脑仍只用统一 Docker 镜像。部署时 `VITE_DATA_MODE=local`，这只是**静态演示**：每位访问者的 IndexedDB 在各自浏览器中，数据不会跨设备同步。

**你在 GitHub 点**：新建公开仓库，上传/推送自己的工程代码；在仓库 `Settings → Pages → Build and deployment → Source` 选 `GitHub Actions`；在 `Actions` 中等发布任务成功，然后打开显示的 Pages URL。[GitHub 官方步骤](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)。

**本轮验收**：`npm run build` 在 `VITE_BASE_PATH=/knowstar-learning/` 下通过，`dist/index.html` 中资源路径带仓库名；工作流文件存在且只上传 `dist/`。公网 URL 的打开检查可后补。发布后，另一个设备看不到本地录题是**预期结果**，说明此时还没有动态数据。

## B. 再让课程演示用户的数据跨设备

CloudBase PostgreSQL 保存该演示用户的示例错题，PG Storage 保存手绘图。GitHub Pages 仍只放构建后的网页文件。

**你对 Trae 说**：

```text
现在按 V2 接入 CloudBase 动态数据：复用课前官方接入和环境，仅缺项时补齐，核对 EnvId、PG 环境与 usernamePassword 登录方式。按 course-demo-auth.md 在本人课程环境由 Agent 准备指定公开演示用户，网页自动登录并恢复会话，不要求学员设置密码。创建独立的 demo_* 表与 knowstar-demo-media 桶，仅允许有效会话读写虚构课堂数据。保留 V1 IndexedDB 本地模式，V2 云端模式只在线访问 PostgreSQL，不做双写。保持同一个 Pages URL，切换 VITE_DATA_MODE=cloudbase。报告目标环境、公开配置位置和来源域名，不回显完整 Key；个人密码、管理密钥与模型 Key 不进入前端构建或 GitHub。先在本地验证两个独立会话自动登录后的双向同步。
```

**Trae 应做**：在学员自己的 CloudBase 环境用版本化迁移建立演示资源，并配置 `authenticated` 权限与 RLS；只把 `VITE_DATA_MODE=cloudbase`、EnvId 和 Publishable Key 等公开信息打进网页。检查来源域名。网页经 CloudBase SDK 的有效登录会话读写演示表，原有私有表保持原权限。

**动态验收**：浏览器 A 和 B 各登录同一演示用户；A 新增虚构错题，B 刷新后看到；B 修改等级或删除后 A 刷新可见；手绘图跨浏览器显示。未登录与错误密码访问被拒绝。断网时写入失败有明确提示，输入保留。Pages 公网测试延后时，先在本地完成检查。

> 教学环境只使用虚构例题，不上传真实学生资料。课程指定的公开演示凭据按 [账号指南](course-demo-auth.md) 预置；`.env.local`、个人密码、云管理密钥或硅基流动 Key 不提交。
