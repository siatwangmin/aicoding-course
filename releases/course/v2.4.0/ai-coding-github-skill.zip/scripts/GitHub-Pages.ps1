﻿#Requires -Version 5.1
# Shared CLI operations; the caller supplies Invoke-SetupNative from ai-coding-env.
function Resolve-CourseGitHubCli {
    $command=Get-Command gh.exe -CommandType Application -ErrorAction SilentlyContinue
    if($command){return $command.Source}
    $candidates=@()
    if($env:LOCALAPPDATA){$candidates+=Join-Path $env:LOCALAPPDATA 'Programs\gh-cli\bin\gh.exe'}
    if($env:ProgramFiles){$candidates+=Join-Path $env:ProgramFiles 'GitHub CLI\gh.exe'}
    foreach($candidate in $candidates){if(Test-Path -LiteralPath $candidate -PathType Leaf){return $candidate}}
    throw 'GitHub CLI not found. Restore the official gh installation and retry; do not replace Pages configuration with BrowserUse.'
}

function Get-CoursePagesConfiguration([string]$Gh,[string]$Repository,[string]$Branch,[string]$WorkingDirectory) {
    if($Repository -notmatch '^[a-zA-Z0-9-]+/[a-zA-Z0-9._-]+$' -or $Branch -notmatch '^[a-zA-Z0-9/_-]+$'){throw 'Explicit repository and branch required.'}
    $r=Invoke-SetupNative $Gh @('api',('repos/'+$Repository+'/pages')) 30 $WorkingDirectory
    $body=if($r.Stdout){$r.Stdout}else{$r.Output}
    if($r.ExitCode -ne 0){
        if(($r.Output+' '+$r.Stderr) -match 'HTTP 404'){
            # A hidden/inaccessible repository can also return 404. Prove access first.
            $access=Invoke-SetupNative $Gh @('api',('repos/'+$Repository)) 30 $WorkingDirectory
            if($access.ExitCode -ne 0){throw 'Repository access is unverified; Pages 404 is not proof that a site is absent.'}
            return $null
        }
        throw 'Pages configuration query failed; do not interpret authorization/network errors as an absent site.'
    }
    $page=$body|ConvertFrom-Json
    if($page.source.branch -cne $Branch -or $page.source.path -ne '/' -or $page.build_type -ne 'legacy'){
        throw 'Existing Pages source differs from the selected branch/root route; preserve it and resolve the project target before publishing.'
    }
    return $page
}

function Enable-CoursePagesSite([string]$Gh,[string]$Repository,[string]$Branch,[string]$WorkingDirectory) {
    $page=Get-CoursePagesConfiguration $Gh $Repository $Branch $WorkingDirectory
    if($page){return $page}
    $r=Invoke-SetupNative $Gh @('api',('repos/'+$Repository+'/pages'),'--method','POST','-f','build_type=legacy','-f',('source[branch]='+$Branch),'-f','source[path]=/') 30 $WorkingDirectory
    if($r.ExitCode -ne 0){throw 'Pages enablement is unverified. Inspect identity, repository permissions and current site before retrying; no browser configuration fallback.'}
    $page=Get-CoursePagesConfiguration $Gh $Repository $Branch $WorkingDirectory
    if(-not $page){throw 'Pages creation returned without a readable site; inspect current state before retrying.'}
    return $page
}
