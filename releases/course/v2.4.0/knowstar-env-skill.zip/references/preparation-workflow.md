# 完整环境准备与恢复

仅在准备目录 A 使用本地 env、github、cloudbase 技能。当前网页按阅读顺序显示编号，内部id沿历史保存，按 course-steps 的 displayId 先定位，不把旧编号直接当当前步骤。

1. 从 .course-setup/materials.json 和运行时/存储/报告恢复；无资料按 setup-guide 下载校验小包，安装用户级 project、A内 env/github/cloudbase，并缓存公共执行包。
2. 调 scripts/Start-CourseToolPreparation.ps1 -WorkingDirectory <A> -Action Start，后台处理工具下载、安装、引擎、实际存储与镜像验证。已有原引擎直接复用，不切换或重建。前台不等待后台结束。
3. 前台依次接续A内GitHub准备账号/邮箱/CLI授权，再CloudBase账号/实名/官方工具授权/PG环境与公开连接。已有有效项复用；本人仅完成必要身份、条款、费用或重启。
4. 账号步骤间及等待本人时用同入口 -Action Status 检查attention。软件失败保留账号结果，重启保存接续点并由本人决定，不自动重启、不重复发起并行安装。
5. 后台Verified后，前台用 Save-PreparationEvidence -Stage tools核真实证据并登记，再 Register-CourseServices。github/cloudbase按实际观察逐项Save-PreparationEvidence。最后逐项汇总工具、当前作用域技能、真实Trae加载和平台结果。

Invoke-CoursePreparation的RequiredStages为github/cloudbase/tools/summary；明确工具排障只保留tools/summary。旧记录的AI阶段保留历史但不再参加门槛，不要求供应商账号、Key或模型调用。前台写准备进度，后台写自己的状态，未知/失败不记通过。

公共执行包保存已核脚本和能力包缓存，位于技能发现目录外。用户级只安装project；平台与案例只有当前目录明确需要时才安装。文件复制不证明Trae加载，公开配置不证明业务客户端读写，管理授权不证明部署或产品通过。

新准备使用Podman CLI与独立Compose；已有Docker/Podman按原绑定和固定镜像恢复。实际存储路径、镜像身份、断网检查、退出码和当前结果均要核验，不手填成功时间。超过预计等待说明原因及当前动作。

完整准备后返回汇总，初始化交用户级project；不创建业务工程、表、函数或APK。卸载按references/uninstall.md的独立入口与Plan/Apply/Verify/Resume处理。资料升级按references/course-updates.md，不重走环境安装。

存储优先非系统盘（如D:/ENV），只有系统盘时使用C:/ENV；已有环境沿已确认 storageRoot，不因默认变化迁移。完整准备不能工具就绪即停止；项目初始化时再按当前已确认需求接入。
