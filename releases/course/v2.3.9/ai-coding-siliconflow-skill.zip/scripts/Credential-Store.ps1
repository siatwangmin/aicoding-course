﻿#Requires -Version 5.1
function Get-AiCredentialPath {
    if(-not $env:USERPROFILE -or -not [IO.Path]::IsPathRooted($env:USERPROFILE)){throw 'User profile unavailable.'}
    return Join-Path $env:USERPROFILE '.ai-coding\credentials\siliconflow-course-default.json'
}
function Assert-AiPlainPath([string]$Path){
    $cursor=[IO.Path]::GetFullPath($Path)
    while($cursor){
        if((Test-Path -LiteralPath $cursor) -and ((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Credential path traverses a link.'}
        $next=Split-Path $cursor -Parent;if($next -eq $cursor){break};$cursor=$next
    }
}
function Save-AiCredential([Security.SecureString]$Secret,[switch]$Replace){
    $path=Get-AiCredentialPath;Assert-AiPlainPath $path
    if((Test-Path -LiteralPath $path) -and -not $Replace){throw 'Existing credential preserved; replacement requires explicit selection.'}
    $directory=Split-Path $path -Parent;[void](New-Item -ItemType Directory -Path $directory -Force)
    $sid=[Security.Principal.WindowsIdentity]::GetCurrent().User
    $acl=[IO.Directory]::GetAccessControl($directory,[Security.AccessControl.AccessControlSections]::Access)
    $acl.SetAccessRuleProtection($true,$false)
    foreach($rule in @($acl.Access)){[void]$acl.RemoveAccessRuleSpecific($rule)}
    $acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($sid,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))
    [IO.Directory]::SetAccessControl($directory,$acl)
    $value=@{schemaVersion=2;credentialRef='siliconflow/course-default';revision=[guid]::NewGuid().ToString();userSid=$sid.Value;ciphertext=($Secret|ConvertFrom-SecureString);baseUrl='https://api.siliconflow.cn/v1';savedAt=(Get-Date).ToString('o')}
    $temp=$path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
    try{
        [IO.File]::WriteAllText($temp,($value|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
        if(Test-Path -LiteralPath $path){[IO.File]::Replace($temp,$path,($temp+'.backup'))}else{[IO.File]::Move($temp,$path)}
    }finally{foreach($file in @($temp,($temp+'.backup'))){if(Test-Path -LiteralPath $file){Remove-Item -LiteralPath $file -Force}}}
    return [pscustomobject]@{credentialRef=$value.credentialRef;revision=$value.revision;status='saved';serviceStatus='pending'}
}
function Get-AiSecureCredential{
    $path=Get-AiCredentialPath;Assert-AiPlainPath $path
    $record=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json
    if($record.schemaVersion -ne 2 -or $record.userSid -ne [Security.Principal.WindowsIdentity]::GetCurrent().User.Value){throw 'Credential schema or owner mismatch.'}
    return ConvertTo-SecureString $record.ciphertext
}
