import { readFile, writeFile, lstat } from 'node:fs/promises';
import { resolve, join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

async function rejectLink(path) {
  if ((await lstat(path)).isSymbolicLink()) throw new Error('UNSAFE_CONFIG_PATH');
}

export async function readConfig(workspace) {
  const directory = join(resolve(workspace), '.ai-setup');
  const path = join(directory, 'siliconflow.env');
  await rejectLink(directory);
  await rejectLink(path);
  const values = {};
  for (const line of (await readFile(path, 'utf8')).replace(/^\uFEFF/, '').split(/\r?\n/)) {
    const match = line.match(/^\s*(SILICONFLOW_BASE_URL|SILICONFLOW_API_KEY)\s*=\s*(.*?)\s*$/);
    if (match) values[match[1]] = match[2].replace(/^(['"])(.*)\1$/, '$2');
  }
  const key = values.SILICONFLOW_API_KEY;
  if (!key || key.length < 16 || /\s/.test(key)) throw new Error('KEY_MISSING_OR_INVALID');
  let url;
  try { url = new URL(values.SILICONFLOW_BASE_URL); } catch { throw new Error('BASE_URL_INVALID'); }
  if (url.protocol !== 'https:' || url.hostname !== 'api.siliconflow.cn' || url.port || url.username || url.password || url.search || url.hash || !['/v1', '/v1/', '/v1/chat/completions'].includes(url.pathname)) throw new Error('BASE_URL_INVALID');
  return { directory, key, baseUrl: 'https://api.siliconflow.cn/v1' };
}

export async function verify(config, models, invoke, fetcher = fetch, image, previous, kinds = ['text', 'vision']) {
  if (!kinds.length || kinds.some(kind => !['text', 'vision'].includes(kind))) throw new Error('INVALID_TASK_KIND');
  if (!models.textModel || !models.visionModel) throw new Error('MODEL_CONFIG_MISSING');
  const report = { checkedAt: new Date().toISOString(), provider: 'siliconflow', baseUrl: config.baseUrl,
    credentialFingerprint: createHash('sha256').update(config.key).digest('hex'),
    credentials: 'not_verified', text: { model: models.textModel, status: 'not_verified' }, vision: { model: models.visionModel, status: 'not_verified' } };
  async function request(path, body) {
    try {
      const response = await fetcher(config.baseUrl + path, {
        method: body ? 'POST' : 'GET', headers: { Authorization: `Bearer ${config.key}`, ...(body ? { 'Content-Type': 'application/json' } : {}) },
        ...(body ? { body: JSON.stringify(body) } : {}), signal: AbortSignal.timeout(30_000),
      });
      const data = await response.json().catch(() => null);
      if (!response.ok) return { error: 'HTTP_' + response.status };
      return { data };
    } catch (error) { return { error: ['TimeoutError', 'AbortError'].includes(error?.name) ? 'TIMEOUT' : 'NETWORK_ERROR' }; }
  }
  const listing = await request('/models?sub_type=chat');
  if (listing.error || !Array.isArray(listing.data?.data)) { report.credentials = 'failed'; report.error = listing.error || 'INVALID_MODEL_LIST'; return report; }
  report.credentials = 'passed';
  const available = new Set(listing.data.data.map(item => item.id));
  const reusable = (kind, model) => previous?.credentialFingerprint === report.credentialFingerprint && previous?.[kind]?.model === model && previous?.[kind]?.status === 'passed' && typeof previous[kind].calledAt === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(previous[kind].calledAt);
  for (const [kind, model] of [['text', models.textModel], ['vision', models.visionModel]]) {
    if (!kinds.includes(kind)) {
      if (reusable(kind, model)) report[kind] = { model, status: 'passed', calledAt: previous[kind].calledAt, evidence: 'previous_call_not_rechecked' };
      continue;
    }
    if (!available.has(model)) { report[kind].status = 'failed'; report[kind].error = 'MODEL_NOT_AVAILABLE'; continue; }
    if (!invoke) {
      if (reusable(kind, model)) {
        report[kind] = { model, status: 'passed', calledAt: previous[kind].calledAt, evidence: 'previous_call_reused' };
      }
      continue;
    }
    const content = kind === 'text' ? 'Calculate 6 times 7. Return only the number.' : [
      { type: 'image_url', image_url: { url: 'data:image/png;base64,' + image.toString('base64') } },
      { type: 'text', text: 'Read the expression in this image. Return only its text, do not solve it.' },
    ];
    const result = await request('/chat/completions', { model, messages: [{ role: 'user', content }], stream: false, max_tokens: 256, enable_thinking: false });
    const output = result.data?.choices?.[0]?.message?.content;
    // Permit harmless answer wrappers, but reject equations, other numbers and contradictions.
    const normalized = typeof output === 'string' ? output.normalize('NFKC').trim().replace(/^```(?:text)?\s*|\s*```$/g, '').replace(/\*\*/g, '').trim() : '';
    const textValid = /^(?:(?:the\s+)?(?:answer|result)(?:\s+is)?\s*[:：]?\s*|答案(?:是|为)?\s*[:：]?\s*|结果(?:是|为)?\s*[:：]?\s*)?42[.!。！]?$/i.test(normalized);
    const valid = typeof output === 'string' && (kind === 'text' ? textValid : /6\s*[x×*]\s*7/.test(output));
    report[kind].status = !result.error && valid ? 'passed' : 'failed';
    report[kind].calledAt = new Date().toISOString();
    if (report[kind].status === 'failed') report[kind].error = result.error || 'OUTPUT_CHECK_FAILED';
    if (report[kind].status === 'failed') report[kind].diagnostic = result.error ? 'CHECK_TRANSPORT_AUTH_QUOTA_OR_LIMIT' : 'SERVICE_RESPONDED_BUT_EXPECTED_OUTPUT_NOT_CONFIRMED';
  }
  return report;
}

async function main() {
  const args = process.argv.slice(2);
  const get = flag => args[args.indexOf(flag) + 1];
  if (!args.includes('--workspace') || !args.includes('--models')) throw new Error('WORKSPACE_AND_MODELS_REQUIRED');
  let supplied;
  if (args.includes('--config-stdin')) {
    let input = '';
    for await (const chunk of process.stdin) { input += chunk; if (input.length > 100000) throw new Error('CONFIG_TOO_LARGE'); }
    supplied = JSON.parse(input);
    if (typeof supplied.key !== 'string' || supplied.key.length < 16 || /\s/.test(supplied.key) || supplied.baseUrl !== 'https://api.siliconflow.cn/v1') throw new Error('INVALID_PRIVATE_CONFIG');
  }
  const config = supplied ? { key: supplied.key, baseUrl: supplied.baseUrl, directory: '/tmp' } : await readConfig(get('--workspace'));
  const models = supplied ? supplied.models : JSON.parse(await readFile(resolve(get('--models')), 'utf8'));
  const image = await readFile(resolve(dirname(fileURLToPath(import.meta.url)), '../assets/test-expression.png'));
  const reportPath = join(config.directory, 'verification.json');
  try { await rejectLink(reportPath); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  let previous = supplied?.previous;
  if (!supplied) { try { previous = JSON.parse(await readFile(reportPath, 'utf8')); } catch {} }
  const kinds = args.includes('--kind') ? [get('--kind')] : ['text', 'vision'];
  const report = await verify(config, models, args.includes('--invoke'), fetch, image, previous, kinds);
  await writeFile(reportPath, JSON.stringify(report, null, 2) + '\n', { mode: 0o600 });
  console.log(JSON.stringify(report));
  process.exitCode = report.credentials === 'passed' && !kinds.some(kind => report[kind].status === 'failed') ? 0 : 1;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) main().catch(() => {
  console.error('AI preparation check failed. Check the private file, model configuration and tool runtime. No secrets were printed.');
  process.exitCode = 1;
});
