// Server-side SiliconFlow adapter. Official /models proves availability, not vision capability.
// Capability/pricing comes from the official model catalogue; schema changes fail closed.
function failure(code){return Object.assign(new Error(code),{code});}
function parseCatalogue(html){
  const models=new Map();
  function walk(value){
    if(!value||typeof value!=='object')return;
    if(typeof value.targetModelName==='string'&&typeof value.vlm==='boolean'&&value.type&&value.subType){
      models.set(value.targetModelName,{id:value.targetModelName,vision:value.vlm,type:value.type,subType:value.subType,status:value.status,currency:value.currency||'',pricing:Array.isArray(value.pricing)?value.pricing.map(p=>({price:String(p.price),unit:String(p.unitOfGood||''),kind:String(p.specification||'')})):[]});
    }
    for(const child of Object.values(value))walk(child);
  }
  for(const match of html.matchAll(/self\.__next_f\.push\((\[[\s\S]*?\])\)/g)){
    let entry;try{entry=JSON.parse(match[1]);}catch{continue;}
    if(typeof entry[1]!=='string'||!entry[1].includes('"vlm"'))continue;
    const payload=entry[1].slice(entry[1].indexOf(':')+1);
    try{walk(JSON.parse(payload));}catch{continue;}
  }
  if(!models.size)throw failure('MODEL_CAPABILITY_UNVERIFIED');
  return models;
}
async function checkApiKey({apiKey,fetchImpl=globalThis.fetch}){
  if(!apiKey)throw failure('MODEL_KEY_REQUIRED');
  try{
    const list=await fetchImpl('https://api.siliconflow.cn/v1/models',{headers:{Authorization:`Bearer ${apiKey}`},signal:AbortSignal.timeout(10000)});
    if(!list.ok)throw failure('MODEL_LIST_UNAVAILABLE');
    const body=await list.json();
    if(!Array.isArray(body.data))throw failure('MODEL_LIST_UNAVAILABLE');
    return new Set(body.data.map(x=>x.id));
  }catch(error){throw failure(error?.code||'MODEL_VALIDATION_UNAVAILABLE');}
}
async function validateModels({textModel,visionModel,apiKey,fetchImpl=globalThis.fetch}){
  const available=await checkApiKey({apiKey,fetchImpl});
  let catalogue;
  try{
    const page=await fetchImpl('https://www.siliconflow.cn/models',{signal:AbortSignal.timeout(10000)});
    if(!page.ok)throw failure('MODEL_CAPABILITY_UNVERIFIED');
    catalogue=parseCatalogue(await page.text());
  }catch(error){throw failure(error?.code||'MODEL_VALIDATION_UNAVAILABLE');}
  const selected=[textModel,visionModel];
  if(selected.some(id=>!available.has(id)))throw failure('MODEL_NOT_AVAILABLE');
  const text=catalogue.get(textModel),vision=catalogue.get(visionModel);
  if(!text||!vision||[text,vision].some(m=>m.status!=='normal'||m.type!=='text'||m.subType!=='chat'||!m.pricing.length))throw failure('MODEL_CAPABILITY_UNVERIFIED');
  if(!vision.vision)throw failure('MODEL_VISION_UNSUPPORTED');
  return {text,vision,source:'https://www.siliconflow.cn/models',checkedAt:new Date().toISOString()};
}
module.exports={parseCatalogue,validateModels,checkApiKey};
