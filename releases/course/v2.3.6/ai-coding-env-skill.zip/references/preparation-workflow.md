# 完整课前准备与恢复

课前准备默认连续完成本课程所需工具、云服务、GitHub、AI账号与汇总；不能工具就绪即停止。本人明确只做工具排障/复查或缩小学习范围时保持该范围。账号准备保存可复用结果；没有作品时不创建业务工程、项目专用表/函数/APK。项目初始化时再按当前已确认需求接入。

1. 保存A和所选引擎，读取materials/runtime/原工具与服务记录。缺资料按setup-guide零资料入口下载/安装用户级技能，保留已有内容。
2. 使用 scripts/Start-CourseToolPreparation.ps1 -WorkingDirectory <A> -Action Start 启动独立后台进程，立即返回前台；已有记录决定引擎，新环境为Podman。后台依次完成存储计划、固定安装包下载与校验、安装、引擎Verify、实际存储核验、镜像与容器工具链验证。不可把进程已启动或下载完成当工具通过。
3. 前台首先调用ai-coding-github核本人登录/邮箱；推送和Pages权限在B绑定时另核，不把头像当管理授权。保留官方登录缓存，不索取token。工具尚在下载或安装时也立即开始本步骤。
4. 然后调用ai-coding-siliconflow引导本人注册/登录、查看当前优惠及费用，由本人决定是否领取、是否充值。保存无秘密 account-readiness.json；不提前存Key或调用模型。V4程序设置就绪后由本人填写Key和模型。
5. 最后调用ai-coding-cloudbase复用本人账号/实名/官方工具授权/环境，真实核PG能力及公开连接；无目标时才在本人已决定费用范围准备环境。账号注册固定 GitHub→硅基流动→CloudBase，已有效项跳过，不因工具等待改变顺序。
6. 每个账号步骤前后及等待本人操作时运行后台入口 -Action Status，读取 attention；UAC/条款等必须本人确认时及时提醒，只给当前一个动作，不替本人批准。重启提示先保存账号进度和工作，等待本人决定何时重启；软件任务等待授权不阻止可继续的账号步骤。失败保留日志、缓存及账号结果，修复后同一A重新Start；不要另起一套并发安装。重启回原任务接续，不能强制或自动重启。
7. 工具未就绪时 Register-CourseServices.ps1 将允许的账号摘要留在A待登记，不阻止账号检查或登记阶段证据。后台状态Verified后由前台调用 Save-PreparationEvidence.ps1 -WorkingDirectory <A> -Stage tools，核真实报告后登记，再运行 Register-CourseServices.ps1 将账号结果关联到已验证准备。仅前台写preparation-progress.json，后台写tools-background.json与自己的阶段日志，避免覆盖账号记录。最后E-05实际复查所选引擎/完整用户级Skill/存储/全部服务状态，两路齐备才汇总通过。步骤勾选不代替工具结果。

每阶段记录本次结果、检查时间、实际入口、当前本人动作与下一阶段。发生本人授权/费用/条款/重启时一次引导一个动作并保存接续点；完成后继续。正常技术操作不暂停让本人重复发提示，也不自动批准其身份/费用。

用scripts/Invoke-CoursePreparation.ps1 -WorkingDirectory <A> -Action Status取得下一阶段；新课程准备默认requiredStages为github/ai/cloudbase/tools/summary；旧明确范围保持，工具排障显式传-RequiredStages tools,summary。前台按github,ai,cloudbase执行，工具后台并行，待tools真实登记后再summary；Status的backgroundTools给出后台状态与attention，账号未完时nextStage不被工具等待占用。完整课程按github,ai,cloudbase,tools,summary汇总，账号阶段不作为额外可选项。后续Status/Record沿原记录恢复；只有本人明确提出独立工具排障或缩小任务范围时才调整RequiredStages，不因默认范围未另行指定而跳过账号准备。tools实际核验后调用 Save-PreparationEvidence.ps1 -WorkingDirectory <A> -Stage tools，脚本定位真实报告并登记；不手填路径。其余阶段每完成一个真实检查，调用同一入口的 -Stage <阶段> -Check <检查名> -Outcome passed|failed|pending -Kind command|tool|browser|learner -Reference <脱敏工具结果或页面/本人确认引用>。脚本自动取时、保存观察、列缺项；本阶段齐备后自动产规范证据并登记。AI阶段须有真实本人确认，summary的Trae加载必须实际观察；脚本不替代这些动作。

已有明确来源可以 -ObservationFile <A内实际观察文件> 导入，检查原时间/来源而不刷成新成功；旧Record -EvidencePath仍兼容，省略路径则用当前阶段标准位置。没有实际检查不能调用passed，不让本人填写JSON。缺项由Agent接续nextSkill。重启后运行本A已生成的 .course-setup/resume-preparation.ps1；它使用验证过的解释器绝对路径及原参数，不依赖PATH、不重新搬盘。

cloudbase checks为identityVerified/managementAccessVerified/pgCapabilityVerified/publicConfigSaved；github为identityVerified/emailVerified；summary为skillsVerified/traeLoadObserved/currentResultsReviewed。没有观察到Trae加载不得填true。证据改动/超过24小时需当前复查后重新登记，模型调用有效旧证据仍可按授权范围复用；刷新记录不意味着重调付费模型。

恢复先查A与用户级准备索引，仅补失效项；多环境冲突保留工程并核对目标。Podman不在PATH使用实际验证的绝对路径；缺CLI/Compose按官方安装链补齐，不把Desktop安装等同Ready。引擎离线恢复所选引擎，不切另一个；TLS失败核可信CA/出口，不禁用证书。下载慢按实测恢复，不能承诺可越过客户端网络策略。

PS5.1清单必须完整写入头部、技能逐项行及未验证项；核本次退出码/时间/内容，不能只看文件存在。旧通过留历史，本次失败不得沿用。费用/模型变化先核已授权范围，普通恢复不反复要求本人批准。

给学员的结果用功能语言：“软件正在后台安装，先准备GitHub账号”“账号已准备，正在完成工具检查”等；不把技术检查变成学员作业，不承诺固定审批次数或理想耗时。完整课前通过与作品可运行/已部署/手机通过分开。


2.1 镜像获取前先验实际存储：新 machine 的 VHDX、受管程序与 dataHome 必须落在统一选定的 storageRoot（优先非系统盘，如 D:/ENV；只有 C 盘时用 C:/ENV），再执行大镜像拉取/导入。已有有效本地镜像直接核验，不联系仓库。旧离线镜像在原归档摘要、固定配置ID、原connection和实际镜像ID均匹配时可复用历史归档证据，报告明确 ArchiveEvidenceReused，不声称本轮重验归档或在线RepoDigest。已有 C 盘环境沿确认的 storageRoot 复用，位置、空间及权限核验通过后可继续获取镜像；迁移仅按明确选择执行，不为更换默认目录重建环境。


重启收尾和当前CLI/Compose绑定纳入tools判定；报告已通过但绑定被删时按原准备恢复，不能用旧报告替代。迁移复查restartStatus，完成后同步状态与时间。用真实时钟记录，首次/健康复用/旧环境迁移分别说明；本人拒绝领券或充值后立即接续。


## 当前准备与项目接入分工（2.2.3）

环境准备完成本课程所需工具、云服务、GitHub、AI账号及必要授权并汇总；明确工具排障或缩小范围时才仅做该范围。项目初始化按当前已确认需求复用并接入能力，可在初始化时启用所需云服务/GitHub/AI；需求未明确时先建本地工程，不自动创建未来资源。AI Key在程序设置入口就绪后由本人填写；准备、接入、调用、发布和本人试用分别留证。

## 学员短提示的执行边界（2.2.4）

学员按 setup-guide 发一句环境准备即执行本指南，不要求复制技术约束。已有 requiredStages 是恢复依据；E-05必须逐项汇总编程工具、CloudBase、GitHub、AI账号及必要授权，不能把工具完成当全部完成。A 工作目录与新安装根目录优先非系统盘（如 D:/ENV），只有 C 盘时用 C:/ENV；大型环境数据沿已确认 storageRoot，不得因为文案目录变化迁移既有环境。先统一缓存三个安装包再进入安装，详细命令和授权接续见 windows-podman-setup.md。

AI 准备时本人可在官方页面创建、查看及自行保管 Key；助手不索取、不写入聊天/准备报告。程序设置就绪后本人再输入，服务端保管与模型调用分别验证。

## 稳定入口与升级（2.3）

学员说“按照课程准备说明完成环境准备”即启动后台工具准备，前台依GitHub、硅基流动、CloudBase顺序注册与授权，最后汇总全部结果。开始安装时显示解析后的课程版本/候选状态；结束汇总实际使用版本和各阶段结果。未指定版本的新安装取 latest，已有 A 恢复沿原版本；只有主动更新才解析新 latest。

更新用 scripts/Update-CourseMaterials.ps1，方法见 references/course-updates.md。资料升级与环境/账号准备分开，不因新课程号重复 Prepare 或拉镜像。公共 Skill 位于用户级，必须检查全局实际内容，A 中的旧报告不冒充当前共享 Skill 版本。
