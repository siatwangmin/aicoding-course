---
name: ai-coding-project
description: 在新目录初始化或恢复作品，复用课前准备的同一课程镜像，接入 GitHub、CloudBase、AI 并准备 Android。只建工程和服务接入，不预设业务。
---

# 项目初始化与恢复

用户说“调用ai-coding-project技能创建项目工程。”即可开始并连续完成本节，不要求技术长提示。保存位置已明确不重复问。本人只选择作品位置、必要授权和费用；名称用途未定保持中性占位，设计确认后补展示信息，不改 slug/appId/端口。

“创建工程/在新文件夹开始作品/恢复已有作品”也触发本技能。先判空目录或已有工程，读实际根规则、manifest和进度；准备缺项恢复env，服务缺项恢复对应服务技能，不在B临场发明另一套环境。根AGENTS是入口，Trae项目规则只引用它；按[Trae官方规则](https://docs.trae.cn/ide_rules)使用 `.trae/rules/course-entry.md` 的 alwaysApply，并在新会话观察实际加载。文件存在不代表已加载。

## 新目录 B

标准技术编排入口为 scripts/Initialize-Project.ps1 -ProjectDirectory <B>（必要时 -PreparationDirectory <A>、可用 -Port）。它负责发现/脱敏摘要挂载/创建或升级/连接/运行与Web构建，生成初始化接续计划。返回pending后由本助手立即继续下面服务技能与浏览器检查，不把技术入口的结束当整节完成；它不代办账号授权，也不要求本人第二条提示。下面步骤用于理解/排障，正常优先使用入口，保留实际工程。

1. 读取已有 AGENTS/manifest/源码，已有工程按恢复流程，不能覆盖或重建。新工程检查空目录。
2. 从当前用户 ai-coding-env/scripts/Course-Context.ps1 的 Find-CourseProjectPreparation 优先按已有 B 绑定、全新 B 按用户级索引定位 A。缺旧登记时在明确 A 调 Register-CoursePreparation.ps1；无有效证据恢复环境助手，只补缺项。不扫描 HOME 找秘密。
3. 复查实际所选引擎、准备镜像和 D 盘数据位置；镜像来自准备记录，不能换 latest、另建镜像或在宿主机装 Node/Java。新准备用 Podman CLI + 独立 Docker Compose；已有 Docker/Podman 工程保留原选择，不自动切换。
4. 用已验证镜像挂载空 B 为 /project、技能根为 /skill:ro、脱敏 preparation.json 为 /prepared.json:ro，覆盖入口 node，运行 scripts/create-project.mjs --target /project --image <实际引用> --preparation /prepared.json --runtime <准备记录的runtime> --port <可用端口>。A暂不可访问时用环境脚本 Export-CoursePreparation.ps1 从允许的用户摘要物化文件，复查实际引擎/镜像后挂载；不挂不存在的A路径。Podman 再传 NetworkMode；不把整个 A 或凭证目录挂进容器。模板依赖从镜像复制，不联网重新选工具链。
5. 宿主运行 scripts/Connect-Project.ps1 -ProjectDirectory <B>，读取索引并合并公开 CloudBase 连接值和 AI 后续配置路线（旧工程保留 credentialRef），保留配置冲突。它只记录配置，不冒充当前授权已通过。
6. 连续调用 ai-coding-github、ai-coding-cloudbase、ai-coding-siliconflow 的项目接入模式，检查当前官方授权、资源归属、客户端前提与服务证据。在已授权范围准备专用静态仓库，禁止改旧 remote。所需本人动作一次一个，完成后接续。Android 交 ai-coding-android 核对 appId、工具链和构建入口，暂不生成未经确认产品。
7. 技术入口启动/复用原app并核镜像/源码/独立依赖卷，在容器内构建；再检查起始网页和实际热更新。按 [证据格式](implementation/initialization-evidence.md) 使用 scripts/Test-ProjectInitialization.ps1 记录并校验当前接入/实际存储证据，不要求宿主装Node。必要服务、规则加载或存储未通过，初始化整体保持待完成。最后集中交付起始网页、作品位置、已打开设计目录与准确缺项，不要求本人再发“打开设计文件夹”。

## 记录与开发交接

项目根 AGENTS 是入口；技术规范在 docs/engineering，需求/原型在 docs/design，助手技术 spec 在 docs/specs，结果在 docs/progress。服务实际检查保存到 .ai-coding/initialization.json，配置与检查状态分开。秘密只引用用户级凭证，机器私有记录忽略 Git/压缩/镜像。

新B同时生成工程workflow、spec模板和Trae引用入口；旧B通过Upgrade增量接入，实际设计路径从manifest读取。技术spec须给出默认技术方案、复用、具体改动和有序步骤/失败分支，不能只列检查。中性起始页不做业务；以后用户确认名称/用途/能力变化时同步展示与manifest，保留稳定标识。

同时生成非秘密 config/ai-models.defaults.json，默认文本 deepseek-ai/DeepSeek-V4-Flash、图片理解 Qwen/Qwen3.8-27B，来源为用户级 ai-coding-siliconflow/assets/default-models.json 的构建同步副本。旧B只补缺失默认文件，保留已有选择。P-01不提前创建设置UI/业务表/AI函数；V4按工程ai规范接服务端可配置模型和“设置 → AI 模型”。模型不是案例专属字段，服务Key不放该文件。

工程生成后调用 ai-coding-development；Android 构建调用 ai-coding-android。每轮材料已确认后连续实现，技术文档不转为学员作业。PRD 与 Canvas 是业务来源；明确选案例才合并案例规则，不因 Skill 已安装或存在 case-profile.json 推断选择。

## 恢复已有作品

保留源码、remote、稳定标识、运行时、端口、凭证和进度。先读根/局部 AGENTS、manifest、实际 Compose 和最新记录，健康容器复用。旧版 manifest 缺新字段时从明确准备结果增量补齐并备份原文件；用 connect 工具接入配置，不能运行空目录生成器重建。工程规范按实际目录落地，不能为符合 app/ 示例迁移源码。

已有 manifest 时先用 [Upgrade-Project.ps1](scripts/Upgrade-Project.ps1) 增量接入，再 Connect-Project；无 manifest 先检查真实结构并记录，不猜字段或运行空目录生成器。旧工程已有设计位置与产品约束保持，升级脚本不会重启容器。

技术默认与验证细节读 ai-coding-development；[capabilities.md](implementation/capabilities.md) 是能力索引。云函数在 CloudBase 运行、APK 在手机运行；本机编译和开发服务使用准备镜像。

新 Podman 工程通过用户级 ai-coding-env/scripts/Course-Runtime.ps1 的共同入口执行，复用其受管 Docker Compose EXE、显式 connection、API 转发验证与超时，不依赖 Desktop 或默认 PATH。构建失败保留原镜像/工程/身份并按对应层恢复。旧 Docker 工程继续按原绑定。

## 估时与等待

读取本技能 assets/course-timing.json，按当前阶段/步骤说明首次或复用的预计时间。长下载、编译、部署说明真实等待原因及本人是否需要操作；超过预计上限说明已完成部分、阻塞和处理，有依据才更新剩余时间。教学估算不代替实际证据，不展示虚假百分比；实际等待计入墙钟。

## 2.1 环境与项目执行约定

通用资料与案例资料可以统一下载、Skill 可以统一安装；已安装不代表已选案例。仅明确选择后加载案例需求，不能由 case-profile.json 的存在推断。A 保存原报告，用户级登记跨目录发现，默认 D:\AI-Practice 保存大资源，B 独立保存项目绑定。已有 B 按 preparationId 恢复，不受全局新选择影响；正常复用不拉镜像、不重装、不复制 A 资料。

日常安装依赖、更新锁文件、运行项目脚本和依赖恢复，调用当前用户 ai-coding-env/scripts/Invoke-CourseProject.ps1；按需读取该技能 references/project-execution.md 的命令及失败分支。已有关联 Web/发布/Android 脚本继续复用公共运行检查。宿主只负责编辑、Git、引擎控制、官方授权及手机连接，不安装项目编译工具链。

AI 的 E-08/P-01/V4 分工按当前用户 ai-coding-development/implementation/ai-service-setup.md：本人注册、查看可用优惠、决定充值、在程序配置 Key 和模型；助手负责工程与保密。P-01仅默认文件与后续设置路线，不以Key解密或模型调用作为新工程初始化门槛。
