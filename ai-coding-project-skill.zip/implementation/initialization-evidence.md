# 初始化证据

Connect-Project 只接入配置。助手实际操作对应服务技能/官方工具和浏览器后，将脱敏结果保存成 JSON，再用 `scripts/initialization.mjs record --project <B> --service <名称> --evidence <结果JSON>` 绑定当前项目配置和镜像。不要让学员填写或勾选这些状态。

新标准入口为PowerShell：`scripts/Test-ProjectInitialization.ps1 -ProjectDirectory <B> -Action Record -Service <名称> -EvidencePath <结果JSON>`；最后同脚本 `-Action Check`，实际复查本机运行与D盘位置、网页及各服务证据。前述Node入口保留旧控制器兼容，不要求宿主新装Node；新模板/新版技能统一用PowerShell控制，项目编译仍在准备镜像。

结果格式：`{"status":"verified","checkedAt":"ISO时间","checks":{"本项检查":true},"evidence":["实际工具结果或浏览器观察的脱敏位置/摘要"]}`。没有真实结果不得生成 verified。

| 名称 | checks 必须全部具备的字段 |
| --- | --- |
| githubPages | identityVerified、authorizationVerified、targetVerified |
| cloudbase | envIdVerified、managementAccessVerified、clientConfigVerified |
| ai | 新工程 application-settings：defaultModelsVerified、configurationRouteRecorded；旧模式兼容 credentialDecrypted、serviceEvidenceVerified、feesScopeKnown |
| android | configVerified、toolchainVerified |
| browser | pageSeen、hotReloadVerified |

这些是初始化准备检查，不表示云 CRUD、产品模型函数、APK 或真机通过。没有有效旧服务证据时，只在授权范围补测；不能为了写检查 JSON 重复产生付费调用。

最后 `check --project <B>` 会重新核对本机引擎/镜像/Compose/网页，并核对证据与当前绑定相符。必要项缺失返回 2 并记录 pending。配置或镜像变化使旧证据失效。证据目录忽略 Git/打包/镜像，日常开发从项目自身配置恢复。

初始化时的检查记录最多复用24小时，不是服务令牌有效期承诺；执行实际推送/部署前仍由对应官方工具核当前授权。AI凭证revision由Connect接入并参与绑定比较，替换后先Connect再记录新证据；有效历史模型调用可在本人已授权范围复用，刷新初始化准备证据不意味着重复计费调用。

新工程 AI 证据绑定实际默认文件 SHA256，不要求已有 Key/模型调用。Key 和服务调用在 V4 验收，不能把初始化通过写成 AI 已可用。
