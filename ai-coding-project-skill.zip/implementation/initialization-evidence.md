# 初始化与能力验收

P-01先验证本地底座，并按当前已确认需求接入能力。本地检查包括：当前原镜像/依赖/挂载与构建、实际存储位置、本地浏览器与热更新、当前会话读取根规则/用户Skill。本地底座调用Test-ProjectInitialization.ps1 -ProjectDirectory <B>；当前已请求的外部能力另用-Scope Capability核验，未请求能力不作前置门槛。只有真实观察才能记录browser的pageSeen/hotReloadVerified与rules的projectEntryObserved/skillsObserved，文件存在不代表实际加载。

记录实际证据用同入口-Action Record -Service <服务> -EvidencePath <真实文件>。JSON包含status=verified、checkedAt当前检查时间、checks、非空evidence；脚本绑定实际项目/当前配置摘要，不接受缺项或旧证据。服务证据与本地初始化分别保存，不互相标通过。

| 服务 | 接入证据检查 |
| --- | --- |
| github / githubPages | identityVerified、authorizationVerified、targetVerified；分别绑定代码/静态目标 |
| cloudbase | envIdVerified、managementAccessVerified、clientConfigVerified |
| ai | application-settings的defaultModelsVerified、configurationRouteRecorded；只证明接入准备，真实配置/调用另验；旧credential模式保留原检查 |
| android | configVerified、toolchainVerified；构建/安装/本人试用另验 |

按需接入先读capability-activation.md。能力检查用-Scope Capability -Service <服务>，保存.ai-coding/capabilities/<服务>.json；缺服务只返回该能力pending，不改变initializationStatus。不启用的能力没有验收作业。技术构建/当前规则/热更新未验证时本地初始化仍pending。

## 学员文案与材料路径（2.2.4）

短提示调用本技能即按本文件和 capability-activation.md 连续完成，不能把页面删除的技术条目视作取消工程规范。读取已有 manifest / Spec 的需求材料路径；新材料推荐需求说明文档.md，兼容 PRD.md、需求说明.md，旧项目不改名。初始化时按已确认需求接入，账号准备不等于作品资源授权；实际配置、授权、调用、部署、本人试用分开记录。
