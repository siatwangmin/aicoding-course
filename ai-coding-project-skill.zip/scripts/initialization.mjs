import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { context, json, atomicJson, verifyImage, within } from './project-context.mjs';

const required = {
  githubPages: ['identityVerified','authorizationVerified','targetVerified'],
  cloudbase: ['envIdVerified','managementAccessVerified','clientConfigVerified'],
  ai: ['credentialDecrypted','serviceEvidenceVerified','feesScopeKnown'],
  android: ['configVerified','toolchainVerified'],
  browser: ['pageSeen','hotReloadVerified']
};
function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === 'object') return Object.fromEntries(Object.keys(value).sort().map(key => [key,canonical(value[key])]));
  return value;
}
function validEvidence(value, name) {
  return value.status === 'verified' && value.checkedAt && Number.isFinite(Date.parse(value.checkedAt)) &&
    Date.parse(value.checkedAt) <= Date.now() && Date.now()-Date.parse(value.checkedAt)<=24*60*60*1000 && Array.isArray(value.evidence) && value.evidence.length > 0 &&
    required[name].every(key => value.checks?.[key] === true);
}
function validBinding(name,binding,project) {
  if (!binding) return false;
  if (name === 'githubPages') return typeof binding.repository === 'string' && /^(?:https:\/\/github\.com\/)?[a-zA-Z0-9-]+\/[a-zA-Z0-9._-]+$/.test(binding.repository);
  if (name === 'cloudbase') return typeof binding.envId === 'string' && binding.envId.length > 0;
  if (name === 'ai') return typeof binding.credentialRef === 'string' && binding.credentialRef.length > 0;
  if (name === 'android') return binding.appId === project.appId;
  return binding.image === project.image && binding.port === project.port;
}
export async function recordEvidence(root, name, evidencePath) {
  if (!Object.hasOwn(required,name)) throw new Error('UNKNOWN_SERVICE');
  const ctx = await context(root), evidence = await json(evidencePath);
  if (!validEvidence(evidence,name)) throw new Error('INCOMPLETE_EVIDENCE');
  const services = await json(join(ctx.root,'.ai-coding/services.json'));
  const binding = name === 'browser' ? { image:ctx.project.image, port:ctx.project.port } : services[name];
  if (!validBinding(name,binding,ctx.project)) throw new Error('MISSING_BINDING');
  await atomicJson(join(ctx.root,'.ai-coding/evidence',name+'.json'), { ...evidence,binding,toolchainImage:ctx.project.image });
}

export async function checkInitialization(root, run, fetcher = fetch) {
  const ctx = await context(root);
  const result = { schemaVersion: 2, checkedAt: new Date().toISOString(), status: 'pending', checks: {}, missing: [] };
  try { result.checks.toolchain = verifyImage(ctx, run); } catch (error) { result.missing.push(error.message); }
  try {
    const storage=await json(join(ctx.root,'.course-setup/storage.json'));
    const age=Date.now()-Date.parse(storage.checkedAt);
    if(storage.status!=='verified'||storage.runtime!==ctx.project.containerRuntime||storage.desiredRoot!==(ctx.project.storageRoot||'D:\\AI-Coding')||!Number.isFinite(age)||age<0||age>24*60*60*1000)throw new Error('STORAGE_REQUIRED');
    result.checks.storage='verified';
  }catch{result.missing.push('ACTUAL_STORAGE_LOCATION_CHECK_REQUIRED');}
  if (!Number.isInteger(ctx.project.port) || ctx.project.port < 1024 || ctx.project.port > 65535) throw new Error('INVALID_PROJECT_PORT');
  try {
    const page = await fetcher('http://127.0.0.1:' + ctx.project.port, { signal: AbortSignal.timeout(5000), redirect: 'error' });
    result.checks.localPage = page.ok ? 'reachable' : 'failed';
    if (!page.ok) result.missing.push('LOCAL_PAGE_FAILED');
  } catch { result.missing.push('LOCAL_PAGE_UNREACHABLE'); }
  const services = await json(join(ctx.root, '.ai-coding/services.json'));
  for (const name of ['githubPages', 'cloudbase', 'ai', 'android']) {
    try {
      const evidence = await json(within(ctx.root, '.ai-coding/evidence/' + name + '.json'));
      if (!validBinding(name,services[name],ctx.project) || !validEvidence(evidence,name) || evidence.toolchainImage !== ctx.project.image ||
          JSON.stringify(canonical(evidence.binding)) !== JSON.stringify(canonical(services[name]))) throw new Error('EVIDENCE_OR_BINDING_MISMATCH');
      result.checks[name] = 'verified';
    } catch { result.missing.push(name.toUpperCase() + '_CURRENT_CHECK_REQUIRED'); }
  }
  // A reachable page is not proof of browser interaction or actual mounted hot reload.
  try {
    const browser = await json(join(ctx.root, '.ai-coding/evidence/browser.json'));
    if (!validEvidence(browser,'browser') || browser.binding?.image !== ctx.project.image || browser.binding?.port !== ctx.project.port) throw new Error('BROWSER_REQUIRED');
    result.checks.browser = 'verified';
  } catch { result.missing.push('BROWSER_AND_HOT_RELOAD_CHECK_REQUIRED'); }
  result.status = result.missing.length ? 'pending' : 'verified';
  await atomicJson(join(ctx.root, '.ai-coding/initialization.json'), result);
  await atomicJson(join(ctx.root, '.ai-coding/project.json'), { ...ctx.project, initializationStatus: result.status });
  return result;
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2), i = args.indexOf('--project');
  if (i < 0 || !args[i+1] || !['record','check'].includes(args[0])) throw new Error('Use: check --project <root>, or record --project <root> --service <name> --evidence <path>');
  const action = args[0] === 'record' ? recordEvidence(args[i+1],args[args.indexOf('--service')+1],args[args.indexOf('--evidence')+1]) : checkInitialization(args[i+1]);
  action.then(value => { if(value) { console.log(JSON.stringify(value)); if (value.status !== 'verified') process.exitCode=2; } })
    .catch(error => { console.error(error.message); process.exitCode=1; });
}
