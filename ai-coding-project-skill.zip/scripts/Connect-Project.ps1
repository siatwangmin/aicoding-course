﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,[string]$PreparationDirectory)
$ErrorActionPreference='Stop'
$context=Join-Path $env:USERPROFILE '.trae-cn\skills\ai-coding-env\scripts\Course-Context.ps1'
if(-not(Test-Path -LiteralPath $context)){throw 'User-level ai-coding-env missing; repair installation.'}; . $context
$root=(Resolve-Path -LiteralPath $ProjectDirectory).Path; Assert-CoursePlainPath $root
$project=Read-CourseJson (Join-Path $root '.ai-coding\project.json')
$source=Find-CourseProjectPreparation $root $PreparationDirectory
if($project.image -ne $source.record.image -or $project.containerRuntime -ne $source.record.containerRuntime){throw 'Project/preparation conflict; existing project preserved.'}
$bindingPath=Join-Path $root '.ai-coding\services.json'; $binding=Read-CourseJson $bindingPath
$config=Join-Path $source.workspace '.cloudbase-setup\connection.env'; $client=@{}
if(Test-Path -LiteralPath $config){
    Assert-CoursePlainPath $config
    foreach($line in [IO.File]::ReadAllLines($config)){
        if($line -match '^\s*(VITE_CLOUDBASE_ENV_ID|VITE_CLOUDBASE_PUBLISHABLE_KEY)\s*=\s*([^\r\n]+)\s*$'){$client[$Matches[1]]=$Matches[2].Trim().Trim('"',"'")}
    }
}
if($client.Count -ne 2){
    $registryPath=Join-Path (Get-CourseUserRoot) 'services.json'
    if(Test-Path -LiteralPath $registryPath){
        $registered=@((Read-CourseJson $registryPath).preparations|Where-Object {$_.preparationId -eq $source.record.preparationId})
        if($registered.Count -eq 1 -and $registered[0].cloudbase){
            $client.VITE_CLOUDBASE_ENV_ID=$registered[0].cloudbase.envId
            $client.VITE_CLOUDBASE_PUBLISHABLE_KEY=$registered[0].cloudbase.publishableKey
        }
    }
}
if($client.Count -eq 2 -and $client.Values -notcontains ''){
    $sourceRoot=[IO.Path]::GetFullPath((Join-Path $root $project.sourceDirectory))
    if($sourceRoot -ne $root -and -not $sourceRoot.StartsWith($root.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Source escapes project.'}
    $envPath=Join-Path $sourceRoot '.env'; Assert-CoursePlainPath $envPath
    $text=if(Test-Path -LiteralPath $envPath){[IO.File]::ReadAllText($envPath)}else{"VITE_DATA_MODE=local`n"}
    foreach($key in $client.Keys){
        if($client[$key] -notmatch '^[a-zA-Z0-9._:-]+$'){throw 'Invalid public connection value.'}
        $pattern='(?m)^'+[regex]::Escape($key)+'=.*$'
        if($text -match $pattern -and [regex]::Match($text,$pattern).Value -ne ($key+'='+$client[$key])){throw 'Existing client configuration differs; preserved.'}
        if($text -notmatch $pattern){$text+="`n$key=$($client[$key])`n"}
    }
    [IO.File]::WriteAllText($envPath,$text,[Text.UTF8Encoding]::new($false))
    $binding.cloudbase.envId=$client.VITE_CLOUDBASE_ENV_ID; $binding.cloudbase.bindingStatus='configured'
}
$vault=Join-Path (Get-CourseUserRoot) 'credentials\siliconflow-course-default.json'
if(Test-Path -LiteralPath $vault){
    if($binding.ai.credentialRef -and $binding.ai.credentialRef -ne 'siliconflow/course-default'){throw 'Existing project credential binding differs; preserved.'}
    $credential=Read-CourseJson $vault; $binding.ai.credentialRef='siliconflow/course-default';$binding.ai.bindingStatus='configured'
    if($credential.revision){$binding.ai|Add-Member -MemberType NoteProperty -Name credentialRevision -Value $credential.revision -Force}
}
$registryPath=Join-Path (Get-CourseUserRoot) 'services.json'
if(Test-Path -LiteralPath $registryPath){
    $registered=@((Read-CourseJson $registryPath).preparations|Where-Object {$_.preparationId -eq $source.record.preparationId})
    if($registered.Count -eq 1 -and $registered[0].github -and $binding.githubPages){
        $login=$registered[0].github.login
        if($binding.githubPages.owner -and $binding.githubPages.owner -ne $login){throw 'Existing GitHub owner differs; preserved.'}
        $binding.githubPages|Add-Member -MemberType NoteProperty -Name owner -Value $login -Force
    }
}
Write-CourseJson $bindingPath $binding
$project|Add-Member -MemberType NoteProperty -Name preparationId -Value $source.record.preparationId -Force
Write-CourseJson (Join-Path $root '.ai-coding\project.json') $project
Write-CourseJson (Join-Path $root '.ai-coding\preparation.json') @{schemaVersion=2;preparationId=$source.record.preparationId;source=$source.path;connectedAt=(Get-Date).ToString('o');image=$source.record.image}
Write-CourseJson (Join-Path $root '.ai-coding\local.json') @{schemaVersion=2;preparationPath=$source.path;githubPreparation=(Join-Path $source.workspace '.github-setup\github-setup.md');aiEvidence=(Join-Path $source.workspace '.ai-setup\verification.json')}
Write-Output 'Configuration connected. Current service authorization and real checks remain pending.'
