﻿#Requires -Version 5.1
# Library. Install only course-managed guidance; preserve unrelated project rules.
function Install-ProjectGuidance([string]$Root,[string]$BackupDirectory) {
    $assets=Join-Path $PSScriptRoot '..\assets'
    foreach($pair in @(@('trae-entry.md','.trae\rules\course-entry.md'),@('spec-template.md','docs\specs\_template.md'),@('default-models.json','config\ai-models.defaults.json'))){
        $target=Join-Path $Root $pair[1]; Assert-CoursePlainPath $target
        if(Test-Path -LiteralPath $target){
            if($pair[0] -in @('spec-template.md','default-models.json')){continue}
            if([IO.File]::ReadAllText($target) -notmatch '课程执行入口是根目录 AGENTS.md'){throw 'Existing course-entry rule is not course-managed; preserved.'}
            if($BackupDirectory){Copy-Item -LiteralPath $target -Destination (Join-Path $BackupDirectory 'trae-entry.md')}
        }
        [void](New-Item -ItemType Directory -Path (Split-Path $target -Parent) -Force)
        Copy-Item -LiteralPath (Join-Path $assets $pair[0]) -Destination $target -Force
    }
}
