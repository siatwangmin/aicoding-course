#!/usr/bin/env node
// Run with the prepared toolchain container; no host npm install is needed.
import { access, cp, mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';

const args = process.argv.slice(2);
const option = (key, fallback) => {
  const index = args.indexOf(key);
  if (index < 0) return fallback;
  if (!args[index + 1] || args[index + 1].startsWith('--')) throw new Error(`Missing value: ${key}`);
  return args[index + 1];
};
const target = resolve(option('--target', '/project'));
const template = resolve(option('--template', '/opt/knowstar/template'));
const name = option('--name', '我的作品');
const slug = option('--slug', 'my-project');
const image = option('--image', '');
const containerRuntime = option('--runtime', 'docker');
if (!['docker', 'podman'].includes(containerRuntime)) throw new Error('Invalid container runtime');
const networkMode = option('--network-mode', 'pasta');
if (!['pasta', 'bridge'].includes(networkMode)) throw new Error('Invalid network mode');
const port = Number(option('--port', '5187'));
if (!/^[a-z][a-z0-9-]{1,47}$/.test(slug)) throw new Error('Invalid project slug');
if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('Invalid port');
if (!image) throw new Error('The prepared image reference is required');
if (process.versions.node !== '22.12.0') throw new Error('Use the prepared toolchain Node 22.12.0');
await access(join(template, 'package-lock.json'));
await mkdir(target, { recursive: true });
if ((await readdir(target)).length) throw new Error('Target must be empty; existing work was preserved');
const app = join(target, 'app');
await mkdir(app);
for (const relative of ['package.json', 'package-lock.json', '.npmrc', '.nvmrc', 'tsconfig.json', 'vite.config.ts', 'tailwind.config.js', 'postcss.config.js', 'src/main.tsx']) {
  await mkdir(dirname(join(app, relative)), { recursive: true });
  await cp(join(template, relative), join(app, relative));
}
const packageJson = JSON.parse(await readFile(join(app, 'package.json'), 'utf8'));
packageJson.name = slug;
await writeFile(join(app, 'package.json'), JSON.stringify(packageJson, null, 2) + '\n');
const lock = JSON.parse(await readFile(join(app, 'package-lock.json'), 'utf8'));
lock.name = slug;
lock.packages[''].name = slug;
await writeFile(join(app, 'package-lock.json'), JSON.stringify(lock, null, 2) + '\n');
const appId = `com.aicoding.${slug.replaceAll('-', '')}`;
const files = {
  'src/App.tsx': 'export default function App() { return <main className="starter"><h1>工作空间已就绪</h1><p>下一步：告诉 AI 谁会使用这个作品、要解决什么问题，并提供你确认的需求和设计。</p></main>; }\n',
  'src/style.css': '@tailwind base;\n@tailwind components;\n@tailwind utilities;\n\n:root { color: #222; background: #fff; font-family: system-ui, sans-serif; } body { margin: 0; } .starter { max-width: 48rem; margin: 10vh auto; padding: 2rem; }\n',
  'index.html': '<!doctype html>\n<html lang="zh-CN"><head><meta charset="UTF-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /><title>我的作品</title></head><body><div id="root"></div><script type="module" src="/src/main.tsx"></script></body></html>\n',
  'capacitor.config.ts': "import type { CapacitorConfig } from '@capacitor/cli';\nconst config: CapacitorConfig = " + JSON.stringify({ appId, appName: name, webDir: 'dist', server: { hostname: 'localhost', androidScheme: 'https' } }, null, 2) + ';\nexport default config;\n',
  '.env.example': 'VITE_DATA_MODE=local\nVITE_CLOUDBASE_ENV_ID=\nVITE_CLOUDBASE_PUBLISHABLE_KEY=\n',
  '.gitignore': 'node_modules/\ndist/\nandroid/\n.env\n.env.*\n!.env.example\ncloudbaserc.json\n*.apk\n*.aab\n*.keystore\n*.jks\n.local/\n',
  'README.md': '# 我的作品\n\n这是刚创建的空白工作空间。每一轮先说清功能目标，在 Gemini 新建或更新 PRD.md，在 Canvas 更新并试用设计，确认后交给 Trae 分步实现与测试，再亲自验收、记录反馈。后续增加云端、安卓或 AI 功能也用同一流程。课程工具不预设业务、登录方式或 AI 功能。\n',
  'AGENTS.md': '# 通用项目工作约定\n\n面向非技术用户，用功能、动作和可见结果沟通。工具检查使用 ai-coding-env，项目启动与恢复使用 ai-coding-project。技术选择采用已准备环境的默认能力。先读取项目需求、原型和现有代码；未确认产品目标时不生成业务页面。\n\n每轮功能迭代，包括本机、云端、安卓和各项 AI 功能，都先明确本轮目标，引导用户与 Gemini 新建或更新 PRD.md，在 Canvas 新建或更新 HTML 并试用确认，再分步实现与实际测试，最后给用户验收入口与动作并记录结果。不索要技术规格书。文件已存在仍需核对本轮变化；本轮材料已确认时直接使用，不重复审批。实现偏差直接修复与复测；用户改变功能或规则时先更新需求和设计。保留原版材料与已有进度。\n\n连续完成本轮已确认的技术工作，分步实现不等于逐项等待用户批准。按变更风险执行必要检查，不重复无变化的完整构建；交付时集中给用户入口与验收动作。案例 Skill 约定集中验收节奏时按案例执行。保持用户已有设计。业务规则、云端环境、账号策略、AI 任务及模型来自本项目需求或显式项目配置，不从工具箱名称推断。个人密码、管理令牌与服务端密钥不进入聊天、代码或产物；显式允许公开的演示配置按所选案例规则处理。\n',
};
files['AGENTS.md'] += `\n## 容器工具\n\n当前选择 ${containerRuntime === 'podman' ? 'Podman Desktop' : 'Docker Desktop'}；读取根目录 .ai-coding/project.json 的 containerRuntime 与工具准备记录，使用 ${containerRuntime} compose/exec。恢复时沿用已有选择，不安装另一套，不覆盖用户资料。Podman 的 rootless/pasta、代理与离线镜像证据按 ai-coding-env 的 windows-podman-setup.md 执行；构建、网页、云端与真机分别记录。\n`;
files['README.md'] += `\n当前容器工具：${containerRuntime === 'podman' ? 'Podman Desktop' : 'Docker Desktop'}。在作品根目录运行 \`${containerRuntime} compose up -d --wait\`，由助手检查起始网页。\n`;
for (const [relative, content] of Object.entries(files)) await writeFile(join(app, relative), content);
await mkdir(join(app, 'docs/design'), { recursive: true });
await mkdir(join(app, 'docs/progress'), { recursive: true });
await mkdir(join(target, '.ai-coding'), { recursive: true });
const project = { name, slug, appId, sourceDirectory: 'app', image, port, containerRuntime, networkMode: containerRuntime === 'podman' ? networkMode : 'bridge', capabilities: [], businessProfile: null };
await writeFile(join(target, '.ai-coding/project.json'), JSON.stringify(project, null, 2) + '\n');
await writeFile(join(target, '.env'), `AI_CODING_IMAGE=${image}\nAI_CODING_PORT=${port}\nAI_CODING_RUNTIME=${containerRuntime}\nAI_CODING_NETWORK_MODE=${networkMode}\nCOMPOSE_PROJECT_NAME=${slug}-${randomUUID().slice(0, 8)}\n`);
await writeFile(join(target, '.gitignore'), '.env\n.local/\n.cloudbase-setup/\n.github-setup/\n.ai-setup/\n.course-setup/\n.docker-setup/\n.podman-setup/\ntoolchain-verification.json\nenvironment-checklist.md\napp/node_modules/\napp/dist/\napp/android/\n*.apk\n');
const resources = resolve(dirname(fileURLToPath(import.meta.url)), '..');
await cp(join(resources, containerRuntime === 'podman' ? 'assets/compose.podman.yaml' : 'assets/compose.yaml'), join(target, 'compose.yaml'));
console.log(JSON.stringify({ status: 'created', project, next: 'Start the project container and verify the blank page' }));
