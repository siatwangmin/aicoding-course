#!/usr/bin/env node
// Run with the prepared toolchain container; no host npm install is needed.
import { access, cp, mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';

const args = process.argv.slice(2);
const option = (key, fallback) => {
  const index = args.indexOf(key);
  if (index < 0) return fallback;
  if (!args[index + 1] || args[index + 1].startsWith('--')) throw new Error(`Missing value: ${key}`);
  return args[index + 1];
};
const target = resolve(option('--target', '/project'));
const template = resolve(option('--template', '/opt/knowstar/template'));
const name = option('--name', '我的作品');
const nameSource = args.includes('--name') ? 'user' : 'placeholder';
const slug = option('--slug', `aicoding-${randomUUID().slice(0, 8)}`);
const image = option('--image', '');
const preparationPath = option('--preparation', '');
let preparation = null;
if (preparationPath) {
  preparation = JSON.parse((await readFile(resolve(preparationPath), 'utf8')).replace(/^\uFEFF/, ''));
  if (preparation.schemaVersion !== 2 || !preparation.verifiedAt || preparation.image !== image) throw new Error('Preparation image mismatch or unverified');
}
const containerRuntime = option('--runtime', 'docker');
if (!['docker', 'podman'].includes(containerRuntime)) throw new Error('Invalid container runtime');
const networkMode = option('--network-mode', 'pasta');
if (!['pasta', 'bridge'].includes(networkMode)) throw new Error('Invalid network mode');
const port = Number(option('--port', '5187'));
if (!/^[a-z][a-z0-9-]{1,47}$/.test(slug)) throw new Error('Invalid project slug');
if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('Invalid port');
if (!image) throw new Error('The prepared image reference is required');
if (process.versions.node !== '22.12.0') throw new Error('Use the prepared toolchain Node 22.12.0');
if (preparation && preparation.containerRuntime !== containerRuntime) throw new Error('Preparation runtime conflict');
await access(join(template, 'package-lock.json'));
await mkdir(target, { recursive: true });
if ((await readdir(target)).length) throw new Error('Target must be empty; existing work was preserved');
const app = join(target, 'app');
await mkdir(app);
for (const relative of ['package.json', 'package-lock.json', '.npmrc', '.nvmrc', 'tsconfig.json', 'vite.config.ts', 'tailwind.config.js', 'postcss.config.js', 'src/main.tsx']) {
  await mkdir(dirname(join(app, relative)), { recursive: true });
  await cp(join(template, relative), join(app, relative));
}
const packageJson = JSON.parse(await readFile(join(app, 'package.json'), 'utf8'));
packageJson.name = slug;
await writeFile(join(app, 'package.json'), JSON.stringify(packageJson, null, 2) + '\n');
const lock = JSON.parse(await readFile(join(app, 'package-lock.json'), 'utf8'));
lock.name = slug;
lock.packages[''].name = slug;
await writeFile(join(app, 'package-lock.json'), JSON.stringify(lock, null, 2) + '\n');
const appId = `com.aicoding.${slug.replaceAll('-', '')}`;
const files = {
  'src/App.tsx': 'export default function App() { return <main className="starter"><h1>工作空间已就绪</h1><p>下一步：完成需求和页面原型设计，确认后交给 Trae 继续实现。</p></main>; }\n',
  'src/style.css': '@tailwind base;\n@tailwind components;\n@tailwind utilities;\n\n:root { color: #222; background: #fff; font-family: system-ui, sans-serif; } body { margin: 0; } .starter { max-width: 48rem; margin: 10vh auto; padding: 2rem; }\n',
  'index.html': '<!doctype html>\n<html lang="zh-CN"><head><meta charset="UTF-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /><title>我的作品</title></head><body><div id="root"></div><script type="module" src="/src/main.tsx"></script></body></html>\n',
  'capacitor.config.ts': "import type { CapacitorConfig } from '@capacitor/cli';\nconst config: CapacitorConfig = " + JSON.stringify({ appId, appName: name, webDir: 'dist', server: { hostname: 'localhost', androidScheme: 'https' } }, null, 2) + ';\nexport default config;\n',
  '.env.example': 'VITE_DATA_MODE=local\nVITE_CLOUDBASE_ENV_ID=\nVITE_CLOUDBASE_PUBLISHABLE_KEY=\n',
  '.gitignore': 'node_modules/\ndist/\nandroid/\n.env\n.env.*\n!.env.example\ncloudbaserc.json\n*.apk\n*.aab\n*.keystore\n*.jks\n.local/\n',
  'README.md': '# 我的作品\n\n这是刚创建的空白工作空间。每一轮先说清功能目标，在 Gemini 新建或更新 PRD.md，在 Canvas 更新并试用设计，确认后交给 Trae 分步实现与测试，再亲自验收、记录反馈。后续增加云端、安卓或 AI 功能也用同一流程。课程工具不预设业务、登录方式或 AI 功能。\n',
  'AGENTS.md': '# 源码执行入口\n\n先读取上一级根 AGENTS.md、.ai-coding/project.json、工程基线与当前进度。此目录只补源码局部约束，不复制通用教程。\n',
};
files['AGENTS.md'] += `\n当前工具：${containerRuntime === 'podman' ? 'Podman Desktop' : 'Docker Desktop'}。沿用根manifest/Compose与准备镜像，不能宿主构建或重建工程绕过失败。\n`;
files['README.md'] += '\n项目名称和用途可以在需求与原型设计确认后补充，现在无需填写。\n';
files['README.md'] += `\n当前容器工具：${containerRuntime === 'podman' ? 'Podman Desktop' : 'Docker Desktop'}。在作品根目录运行 \`${containerRuntime} compose up -d --wait\`，由助手检查起始网页。\n`;
for (const [relative, content] of Object.entries(files)) await writeFile(join(app, relative), content);
await mkdir(join(app, 'docs/design'), { recursive: true });
await mkdir(join(app, 'docs/progress'), { recursive: true });
await mkdir(join(target, '.ai-coding'), { recursive: true });
const project = { schemaVersion: 2, baselineVersion: '2.0.0', initializationStatus: 'pending', toolchain: preparation ? { capabilities: preparation.capabilities || null, imageDigest: preparation.imageDigest, verificationMethod: preparation.verificationMethod || 'registry-digest', imageId: preparation.imageId || null, archiveSha256: preparation.archiveSha256 || null, verifiedAt: preparation.verifiedAt } : null, connection: preparation?.connection || null, name, nameSource, purpose: null, identityStatus: 'pending-design', storageRoot: preparation?.storageRoot || 'D:\\AI-Coding', slug, appId, sourceDirectory: 'app', designDirectory: 'docs/design', specDirectory: 'docs/specs', progressDirectory: 'docs/progress', image, port, containerRuntime, networkMode: containerRuntime === 'podman' ? networkMode : 'bridge', capabilities: ['local', 'github-pages', 'cloudbase', 'android', 'ai'], android: { webDir: 'dist', iconReviewRequired: false }, businessProfile: null };
await writeFile(join(target, '.ai-coding/project.json'), JSON.stringify(project, null, 2) + '\n');
await writeFile(join(target, '.env'), `AI_CODING_IMAGE=${image}\nAI_CODING_PORT=${port}\nAI_CODING_RUNTIME=${containerRuntime}\nAI_CODING_NETWORK_MODE=${networkMode}\nCOMPOSE_PROJECT_NAME=${slug}-${randomUUID().slice(0, 8)}\n`);
await writeFile(join(target, '.gitignore'), '.env\n.local/\n.cloudbase-setup/\n.github-setup/\n.ai-setup/\n.course-setup/\n.docker-setup/\n.podman-setup/\ntoolchain-verification.json\nenvironment-checklist.md\napp/node_modules/\napp/dist/\napp/android/\n*.apk\n');
const resources = resolve(dirname(fileURLToPath(import.meta.url)), '..');
await cp(join(resources, containerRuntime === 'podman' ? 'assets/compose.podman.yaml' : 'assets/compose.yaml'), join(target, 'compose.yaml'));
await cp(join(resources, 'assets/AGENTS.project.md'), join(target, 'AGENTS.md'));
await mkdir(join(target, '.trae/rules'), { recursive: true });
await cp(join(resources, 'assets/trae-entry.md'), join(target, '.trae/rules/course-entry.md'));
await cp(join(resources, 'assets/engineering'), join(target, 'docs/engineering'), { recursive: true });
await mkdir(join(target, 'config'), { recursive: true });
await cp(join(resources, 'assets/default-models.json'), join(target, 'config/ai-models.defaults.json'));
await mkdir(join(target, 'docs/design'), { recursive: true });
await mkdir(join(target, 'docs/specs'), { recursive: true });
await cp(join(resources, 'assets/spec-template.md'), join(target, 'docs/specs/_template.md'));
await mkdir(join(target, 'docs/progress'), { recursive: true });
await writeFile(join(target, 'docs/progress/current.md'), '# 当前进度\n\n工程已生成；起始网页、服务绑定与当前授权待检查。初始化尚未整体通过。下一步调用项目助手完成接入和实际检查。\n');
await writeFile(join(target, 'README.md'), '# 我的作品\n\n助手从 AGENTS.md 恢复。源码在 app/，需求设计放 docs/design，工程基线在 docs/engineering。运行与构建使用准备阶段镜像。本人只确认需求、授权与亲自试用。\n');
await writeFile(join(target, '.ai-coding/services.json'), JSON.stringify({ schemaVersion: 2,
  githubPages: { repository: null, bindingStatus: 'pending', authorizationStatus: 'pending' },
  cloudbase: { envId: null, bindingStatus: 'pending', authorizationStatus: 'pending', clientStatus: 'pending' },
  ai: { provider: 'siliconflow', credentialRef: null, bindingStatus: 'pending', serviceStatus: 'pending' },
  android: { skill: 'ai-coding-android', appId, preparationStatus: 'configured', buildStatus: 'pending', learnerTried: 'pending' }
}, null, 2) + '\n');
const exclusions = '.ai-coding/dependencies.json\n.ai-coding/initialization-plan.json\n.ai-coding/runtime-check.json\n.ai-coding/local.json\n.ai-coding/preparation.json\n.ai-coding/initialization.json\n.ai-coding/evidence/\n.ai-setup/\n.cloudbase-setup/\n.github-setup/\n.course-setup/\n.local/\n**/.env\n**/.env.*\n!**/.env.example\n*.apk\n*.aab\n*.jks\n*.keystore\n';
await writeFile(join(target, '.gitignore'), (await readFile(join(target, '.gitignore'), 'utf8')) + exclusions);
await writeFile(join(target, '.dockerignore'), exclusions);
await writeFile(join(target, '.containerignore'), exclusions);
console.log(JSON.stringify({ status: 'created', project, next: 'Start the project container and verify the blank page' }));
