﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,[string]$PreparationDirectory,[string]$Name,[int]$Port=5187)
$ErrorActionPreference='Stop'
. (Join-Path $env:USERPROFILE '.trae-cn\skills\ai-coding-env\scripts\Course-Runtime.ps1')
$root=[IO.Path]::GetFullPath($ProjectDirectory);Assert-CoursePlainPath $root
$timer=[Diagnostics.Stopwatch]::StartNew();$started=(Get-Date).ToUniversalTime().ToString('o');$operationId=[guid]::NewGuid().ToString('N');$outcome='failed'
$lifecycleLease=$null
if(-not(Test-Path -LiteralPath $root)){[void](New-Item -ItemType Directory -Path $root)}
Write-CourseEvent $root @{operationId=$operationId;stage='P-01';action='Initialize';status='running';startedAt=$started}
try{
$prepared=Find-CourseProjectPreparation $root $PreparationDirectory;$p=$prepared.record
if(Get-Command Enter-CourseOperation -ErrorAction SilentlyContinue){$lifecycleLease=Enter-CourseOperation $prepared.workspace 'InitializeProject'}
if(-not(Test-Path -LiteralPath $root)){[void](New-Item -ItemType Directory -Path $root)}
if(Test-Path -LiteralPath (Join-Path $root '.ai-coding\project.json')){
    & (Join-Path $PSScriptRoot 'Upgrade-Project.ps1') -ProjectDirectory $root -PreparationDirectory $PreparationDirectory|Out-Host
}else{
    # The generator validates design-only input and resumes its own staged transaction; never moves user design files.
    if($p.containerRuntime -eq 'docker'){
        $engine=Get-SetupDocker
        if(-not $engine.Ready){Start-SetupDockerDesktop;for($i=0;$i -lt 10;$i++){Start-Sleep -Seconds 2;$engine=Get-SetupDocker;if($engine.Ready){break}}}
        if(-not $engine.Ready){throw 'Prepared Docker engine unavailable; restore the same runtime, no host fallback.'}
        $cli=(Get-SetupDockerPaths).Cli;$prefix=@('--host',$engine.Endpoint)
    }else{
        . (Join-Path $env:USERPROFILE '.trae-cn\skills\ai-coding-env\scripts\Course-Podman.ps1')
        $machine=$p.connection -replace '-root$','';if(-not $machine){throw 'Recorded Podman connection required.'}
        $paths=Get-PodmanPaths
        if(-not $paths.Cli){throw 'Restore the prepared Podman CLI before project generation.'}
        $ready=Invoke-SetupNative $paths.Cli @('--connection',$p.connection,'info','--format','json') 20
        if($ready.ExitCode -ne 0){
            $existing=Invoke-SetupNative $paths.Cli @('machine','inspect',$machine) 15
            if($existing.ExitCode -ne 0){throw 'Prepared Podman machine missing; preserve the empty project.'}
            $started=Invoke-SetupNative $paths.Cli @('machine','start',$machine) 180
            if($started.ExitCode -ne 0){throw 'Prepared Podman machine could not be started.'}
        }
        # Recovery diagnostics must not populate the empty B before generation.
        $recovery=if(Test-Path -LiteralPath $prepared.workspace){$prepared.workspace}else{Join-Path ([IO.Path]::GetTempPath()) ('course-podman-recovery-'+[guid]::NewGuid().ToString('N'))}
        $engine=Get-SetupPodman $machine $recovery;$cli=$engine.Cli;$prefix=@('--connection',$engine.Connection)
        if($engine.Connection -ne $p.connection){throw 'Podman connection differs from preparation; preserve and resolve.'}
    }
    $inspection=Invoke-SetupNative $cli ($prefix+@('image','inspect',$p.image)) 30 $root
    if($inspection.ExitCode -ne 0){throw 'Restore the exact prepared image before initialization.'}
    $actual=@($(if($inspection.Stdout){$inspection.Stdout}else{$inspection.Output})|ConvertFrom-Json)[0]
    $digest=@($actual.RepoDigests|Where-Object {$_ -like ('*@'+$p.imageDigest)}).Count -gt 0
    $offline=$p.verificationMethod -eq 'archive-sha256+image-config' -and $actual.Id -eq $p.imageId -and $p.archiveSha256 -match '^[a-f0-9]{64}$'
    if($actual.Os -ne 'linux' -or $actual.Architecture -ne 'amd64' -or (-not $digest -and -not $offline)){throw 'Prepared image identity mismatch.'}
    $tempRoot=Join-Path (Get-CourseUserRoot) 'temporary';Protect-CourseDirectory $tempRoot
    $snapshot=Join-Path $tempRoot ([guid]::NewGuid().ToString('N')+'.json')
    try{
        & (Join-Path $env:USERPROFILE '.trae-cn\skills\ai-coding-env\scripts\Export-CoursePreparation.ps1') -PreparationDirectory $PreparationDirectory -Destination $snapshot|Out-Host
        $skill=(Resolve-Path (Join-Path $PSScriptRoot '..')).Path
        $arguments=$prefix+@('run','--rm','--pull=never','--network','none','--mount',("type=bind,source=$root,target=/project"),'--mount',("type=bind,source=$skill,target=/skill,readonly"),'--mount',("type=bind,source=$snapshot,target=/prepared.json,readonly"),'--entrypoint','node',$p.image,'/skill/scripts/create-project.mjs','--target','/project','--image',$p.image,'--preparation','/prepared.json','--runtime',$p.containerRuntime,'--port',[string]$Port)
        if($p.containerRuntime -eq 'podman'){$arguments+=@('--network-mode',$p.networkMode)}
        if($Name){$arguments+=@('--name',$Name)}
        $created=Invoke-SetupNative $cli $arguments 90 $root
        if($created.ExitCode -ne 0){
            $diagnostic=Join-Path $root '.local\project-generation.log'
            [void](New-Item -ItemType Directory -Path (Split-Path $diagnostic -Parent) -Force)
            [IO.File]::WriteAllText($diagnostic,$created.Output,[Text.UTF8Encoding]::new($false))
            throw 'Project generation failed; preserve generated files and inspect .local/project-generation.log.'
        }
    }finally{if(Test-Path -LiteralPath $snapshot){Remove-Item -LiteralPath $snapshot -Force}}
}
& (Join-Path $PSScriptRoot 'Connect-Project.ps1') -ProjectDirectory $root -PreparationDirectory $PreparationDirectory|Out-Host
$ctx=Get-CourseProjectRuntime $root -Start
& (Join-Path $env:USERPROFILE '.trae-cn\skills\ai-coding-env\scripts\Invoke-CourseProject.ps1') -ProjectDirectory $root -Action RunScript -Script build -ReuseBuild|Out-Host
$progress=Join-Path $root '.ai-coding\initialization-plan.json'
Write-CourseJson $progress @{schemaVersion=2;checkedAt=(Get-Date).ToString('o');status='pending';localBuild='verified';nextSkills=@('ai-coding-github','ai-coding-cloudbase','ai-coding-siliconflow','ai-coding-android');remaining=@('current service authorization and bindings','browser and mounted hot reload','Trae rule/skill load observation','initialization evidence gate')}
$outcome='pending'
[pscustomobject]@{status='pending';projectDirectory=$root;url=('http://127.0.0.1:'+$ctx.Project.port);designDirectory=$ctx.Project.designDirectory;continuation=$progress}|ConvertTo-Json
# Agent continues the listed service skills in the same task; no second learner prompt.

}finally{if($lifecycleLease){Exit-CourseOperation $lifecycleLease};Write-CourseEvent $root @{operationId=$operationId;stage='P-01';action='Initialize';status=$outcome;startedAt=$started;finishedAt=(Get-Date).ToUniversalTime().ToString('o');durationMs=$timer.ElapsedMilliseconds;evidence='.ai-coding/initialization-plan.json'}}
