#!/bin/sh
set -eu
# Read-only toolchain probe. It never creates or mounts a user's product folder.
node --version
npm --version
java -version
test "$(node --version)" = "v22.12.0"
test -d "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/opt/android-sdk}}"
cd /opt/knowstar/template
npm ls --depth=0 tailwindcss postcss autoprefixer @capacitor/android @cloudbase/js-sdk @cloudbase/node-sdk
test -x android/gradlew
test -d /root/.gradle/caches
node -e 'for (const name of ["typescript", "vite", "@ionic/react", "idb"]) require.resolve(name); console.log("Toolchain dependencies available")'
node /course-check/inspect-capabilities.mjs
printf 'TOOLCHAIN_READY\n'
