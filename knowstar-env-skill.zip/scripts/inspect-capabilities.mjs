import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
const base='/opt/knowstar/template';
const packages={};
for(const name of ['@ionic/react','typescript','vite','@capacitor/core','@capacitor/android','@cloudbase/js-sdk','@cloudbase/node-sdk','tailwindcss']){
  packages[name]=JSON.parse(readFileSync(base+'/node_modules/'+name+'/package.json','utf8')).version;
}
const java=spawnSync('java',['-version'],{encoding:'utf8'});
if(java.status!==0)throw new Error('JAVA_UNAVAILABLE');
const android=process.env.ANDROID_HOME||process.env.ANDROID_SDK_ROOT||'/opt/android-sdk';
const wrapper=base+'/android/gradle/wrapper/gradle-wrapper.properties';
const gradle=existsSync(wrapper)?readFileSync(wrapper,'utf8').match(/gradle-([\d.]+)-/)?.[1]:null;
const result={schemaVersion:2,node:process.versions.node,npm:spawnSync('npm',['--version'],{encoding:'utf8'}).stdout.trim(),java:java.stderr.match(/version "([^"]+)/)?.[1],gradle,
  platform:process.platform,arch:process.arch,androidPlatforms:readdirSync(android+'/platforms'),buildTools:readdirSync(android+'/build-tools'),packages,
  gradleCachePresent:existsSync('/root/.gradle/caches'),templatePath:base,androidBuildCommand:'knowstar-android-build'};
console.log('CAPABILITIES_JSON:'+JSON.stringify(result));
