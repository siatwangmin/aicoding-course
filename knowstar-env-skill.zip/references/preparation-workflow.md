# 完整环境准备与恢复

准备目录 A 使用本地 env，并按准备任务调用用户级 GitHub、CloudBase 技能。当前网页按阅读顺序显示编号，内部id沿历史保存，按 course-steps 的 displayId 先定位，不把旧编号直接当当前步骤。

1. 从 .course-setup/materials.json 和运行时/存储/报告恢复；无资料按 setup-guide 下载校验小包，安装用户级 project/github/cloudbase/android、A 本地 env，并缓存公共执行包。
2. 调 scripts/Start-CourseToolPreparation.ps1 -WorkingDirectory <A> -Action Start，后台处理工具下载、Git for Windows、GitHub CLI、引擎、实际存储与镜像验证。gh已有安装只核验复用，缺失时在原storageRoot的programs/github-cli安装受管便携版，下载摘要与创建归属随安装登记；gh 不改 PATH；受管 Git 的 cmd 目录加入用户 PATH，不要求 winget 或重装已有 Git。已有原引擎直接复用，不切换或重建。前台不等待后台结束。
3. 前台在 A 的准备上下文依次接续用户级 GitHub准备账号/邮箱/CLI授权，再CloudBase账号/实名/官方工具授权/PG环境与公开连接。已有有效项复用；本人仅完成必要身份、条款、费用或重启。
4. 账号步骤间及等待本人时用同入口 -Action Status 检查attention。软件失败保留账号结果，重启保存接续点并由本人决定，不自动重启、不重复发起并行安装。
5. 后台Verified后，前台用 Save-PreparationEvidence -Stage tools核真实证据并登记，再 Register-CourseServices。github/cloudbase按实际观察逐项Save-PreparationEvidence。最后逐项汇总工具、当前作用域技能、真实Trae加载和平台结果。

宿主 Node.js/npm/npx 由后台 NodeJs 阶段准备：已有可用 22/24 LTS 核验复用，否则在原 storageRoot/programs/nodejs 安装固定 24 LTS。公开 ZIP 优先 npmmirror、其次南大镜像、最后官方源，每个来源均核固定 SHA-256；npm 用户级 registry 设置为 https://registry.npmmirror.com/。NodeJsVerify 复核实际版本和生效源，.course-setup/nodejs.json 缺失、失败或过期不能记工具通过。开始 CloudBase 的本地 npx/CLI 前先核该记录；尚未完成可继续本人账号步骤。受管目录加入用户 PATH，当前 Trae 进程仍可能保留旧 PATH，按记录中 path 的父目录更新当前进程 PATH 后调用 npm.cmd/npx.cmd；新终端或重开 Trae 会载入用户 PATH。不能把容器 node 或 IDE 内置 Node 当作宿主 npx 已就绪；远程 MCP 无需本地 Node。

Invoke-CoursePreparation的RequiredStages为github/cloudbase/tools/summary；明确工具排障只保留tools/summary。旧记录的AI阶段保留历史但不再参加门槛，不要求供应商账号、Key或模型调用。前台写准备进度，后台写自己的状态，未知/失败不记通过。

公共执行包保存已核脚本和能力包缓存，位于技能发现目录外。四项用户级技能可跨作品发现，资源与授权按作品独立绑定；案例仅在明确选择时安装到项目。文件复制不证明Trae加载，公开配置不证明业务客户端读写，管理授权不证明部署或产品通过。

新准备使用Podman CLI与独立Compose；已有Docker/Podman按原绑定和固定镜像恢复。实际存储路径、镜像身份、断网检查、退出码和当前结果均要核验，不手填成功时间。超过预计等待说明原因及当前动作。

完整准备后返回汇总，初始化交用户级project；不创建业务工程、表、函数或APK。卸载按references/uninstall.md的独立入口与Plan/Apply/Verify/Resume处理。资料升级按references/course-updates.md，不重走环境安装。

存储优先非系统盘（如D:/ENV），只有系统盘时使用C:/ENV；已有环境沿已确认 storageRoot，不因默认变化迁移。完整准备不能工具就绪即停止；项目初始化只建立本地工程，平台资源在后续实际任务中按当前已确认需求接入。

Git for Windows 由 Git/GitVerify 阶段完成。缺失时依次使用 npmmirror、华为云国内镜像、GitHub 官方源，所有来源核固定官方 SHA-256 和解包后的 git.exe 摘要；不替换 GitHub 登录/API/推送地址。验证版本、实际路径和受管文件树后写 .course-setup/git.json，未通过不能将工具阶段标为完成。旧目录可单独调用 Setup-Git.ps1 -WorkingDirectory <A> 补齐，再核验；已有全局 Git 配置、凭证、仓库和 SSH 路线保持原样。受管 cmd 目录只新增一个用户 PATH 项，已有进程需重开；公共入口可按绑定直接定位。
