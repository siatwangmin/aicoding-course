---
name: ai-coding-env
description: 准备、恢复或卸载环境；按安装归属生成清单，保护作品与共享资源，支持独立脚本和双击卸载。新准备使用 Podman CLI 和独立 Docker Compose，已有工程沿原绑定恢复。
---

# 通用开发环境助手

使用者报网页步骤编号时，先按 [当前网页编号定位](references/preparation-workflow.md#当前网页编号定位) 或当前版本步骤数据的displayId定位，再用稳定id查询内部检查。网页编号随阅读顺序显示，历史进度的stepId保持原义，不按同名编号直接跳转。

用户请求卸载或清理测试安装时，先读 [卸载与接续](references/uninstall.md)，调用 Plan → Apply → Verify，失败用独立 runner Resume。按已明确范围执行，不重新安装环境、不临场拼删除命令；旧归属未知保留并报告。其他准备请求继续以下主线。

完整准备请求先读 [连续准备](references/preparation-workflow.md)：后台自动下载安装与验证工具，前台立即按 GitHub→硅基流动→CloudBase 顺序引导账号注册及必要授权，两路全部通过才汇总。人工确认时提醒，不让本人重复发“继续”。明确只做工具排障或缩小任务范围时保持该范围，不扩成无关平台开通或业务工程。

## 发现和准备

1. 保存当前目录 A，先读已有 .ai-coding/project.json、.course-setup/materials.json、container-runtime.json、toolchain-verification.json 和用户级准备索引。旧工程沿原 runtime/connection；无 runtime 的历史报告按 Docker 兼容。新准备默认 Podman CLI + 独立 Docker Compose，不安装或启动两个 Desktop，不为编排安装 Python。
2. 无资料时按 setup-guide.md 使用 scripts/Get-CourseMaterials.ps1 -ContainerRuntime podman，核固定版本/摘要、安全解压，按 course-contract/skills.json 安装七项通用技能及明确选定案例。备份旧用户副本与项目同名副本，项目发现目录不得留同名 Skill。下载/安装完成后继续技术验收。
3. 新路线读 [Windows Podman 准备与恢复](references/windows-podman-setup.md)，调用 scripts/Start-CourseToolPreparation.ps1 -WorkingDirectory <A> -Action Start；后台自动执行存储计划、Setup-Podman 的下载/安装/Verify、实际存储核验及 Verify-Toolchain。前台立即开始GitHub注册，不等待该工具链完成。账号步骤间及等待本人时用 -Action Status 检查 attention；缺 WSL/虚拟化需本人动作时一次一个，重启由本人决定，同一A继续。旧 Setup-PodmanDesktop.ps1 只转交。
4. Docker 旧工程读 [旧 Docker Windows 路线](references/windows-docker-setup.md)，按原提权/本机 Desktop endpoint/固定镜像规则恢复。不得把 Docker 专用必需项套给新 Podman，不因 Podman 失败自动安装 Docker；已有成果不能因默认改变而重建。
5. 工具镜像身份来自 [固定配置](assets/toolchain.json)：在线精确 RepoDigest，批准离线归档当次 SHA256+配置 ID+平台。标签/旧记录不通过；断网容器 check-environment.sh 退出码 0 且 TOOLCHAIN_READY 才有有效 VerifiedAt。固定镜像内已有 Node/JDK/Android，不在宿主装项目编译工具链、不换镜像或重建工程。

## 实际运行与失败恢复

用 scripts/Course-Native.ps1、Course-Runtime.ps1 的共同入口；固定 CLI 绝对路径、connection 和受管 Compose EXE，子进程注入 PODMAN_COMPOSE_PROVIDER，摘要不符即停止。保留 config --format json、显式健康等待超时、Linux 依赖卷/锁文件/源码挂载核验。Podman info、Compose version、API 和真实容器操作分别记录，不以其中一项替代全链路。

machine 未启用时恢复同名既有 machine；API 缺失按 Podman reference 的版本边界恢复 machine 自己管道，不抢 docker_engine，不停共享工程。缺运行时/镜像/依赖分别修对应层；代理分宿主、machine、容器和目标服务实测，不关闭 TLS、防火墙，不用 host 网络或宿主编译绕过失败。停止条件与实际错误写入报告。

## 记录与接续

A 保存原始 .podman-setup（旧 Docker 为 .docker-setup）、toolchain-verification.json、environment-checklist.md。失败 VerifiedAt=null，旧成功留历史但不能替代本次检查。用户级 .ai-coding 仅存发现索引、工具/服务引用与受保护凭证；大型环境数据优先非系统盘（如 D:/ENV），只有 C 盘时用 C:/ENV；B 存项目事实。仅按明确旧来源安全导入凭证，验证加密存储前保留来源，不扫描 HOME 找秘密。

实际验收后用 Register-CoursePreparation.ps1 登记。Prepare-CourseStorage.ps1 -Verify 核程序/Compose 和 WSL VHD 实际位置，计划路径不算通过；已有 C 盘 machine 不自动搬迁或重建。完整准备工具阶段还要求存储真实验证通过。

按准备完整 SkillNames 调 Install-CourseSkills.ps1 -VerifyOnly，核用户根部 SKILL.md 名称、完整名单及无项目同名副本；缺项由助手修复，不交给使用者审日志。源码维护、用户级安装和真实 Trae 新会话加载分别记录；未观察加载保留 pending。

本流程启动 scripts/Start-CourseToolPreparation.ps1 -Action Start 后，工具下载安装与验证在独立后台进程运行；前台立即依次调用 GitHub、硅基流动、CloudBase 对应Skill引导注册和必要授权，三项均须完成。用 -Action Status 检查后台 attention，在UAC、条款或重启需要本人操作时及时提醒；软件失败保留账号结果，同一A接续。最后两路都通过才汇总，按 [连续准备](references/preparation-workflow.md) 保存每阶段真实结果。平台授权、服务调用、费用范围、部署、本人试用分别记录，不由安装或配置结果替代。新流程本人在 V4 程序设置中填写 Key，仅服务端受限存储；旧用户级加密来源保留作兼容，秘密不进前端产物/Git/APK/日志。

正常技术工作由助手连续执行；本人仅做需求设计、必要身份/条款/费用/位置/重启与真实试用。结束给清单链接、可打开的入口、当前一个必要动作和未验证项，不让本人勾选助手结果。完成准备后，新 B 的 P-01 由 ai-coding-project 负责。

## 估时与等待

读取本技能 assets/course-timing.json，按当前阶段/步骤说明首次或复用的预计时间。长下载、编译、部署说明真实等待原因及本人是否需要操作；超过预计上限说明已完成部分、阻塞和处理，有依据才更新剩余时间。时间估算不代替实际证据，不展示虚假百分比；实际等待计入墙钟。

## 2.1 环境与项目执行约定

通用资料与案例资料可以统一下载、Skill 可以统一安装；已安装不代表已选案例。仅明确选择后加载案例需求，不能由 case-profile.json 的存在推断。A 保存原报告，用户级登记跨目录发现，新安装优先非系统盘（如 D:\ENV），只有 C 盘时用 C:\ENV 保存大资源，B 独立保存项目绑定。已有 B 按 preparationId 恢复，不受全局新选择影响；正常复用不拉镜像、不重装、不复制 A 资料。

日常安装依赖、更新锁文件、运行项目脚本和依赖恢复，调用当前用户 ai-coding-env/scripts/Invoke-CourseProject.ps1；按需读取该技能 references/project-execution.md 的命令及失败分支。已有关联 Web/发布/Android 脚本继续复用公共运行检查。宿主只负责编辑、Git、引擎控制、官方授权及手机连接，不安装项目编译工具链。

AI 的 E-08/P-01/V4 分工按当前用户 ai-coding-development/implementation/ai-service-setup.md：本人注册、查看可用优惠、决定充值、在程序配置 Key 和模型；助手负责工程与保密。P-01先完成本地基础，再按本项目已确认需求接入能力；首次启用AI时再生成默认文件、接设置路线，Key解密或模型调用不作为初始化门槛。


2.1.1恢复：函数库 Course-Docker.ps1/Course-Podman.ps1 导入不改调用者参数。需要定位环境时用 scripts/Test-CourseReadiness.ps1（A使用 -PreparationDirectory，B使用 -ProjectDirectory），按索引定位，不猜默认目录。新A的旧离线证据由选定准备来源读取并复验真实镜像，不能手工复制通过结论。迁移重启未验或受管绑定丢失时整体准备仍待办。


## 当前准备与项目接入分工（2.2.3）

环境准备完成所需工具、云服务、GitHub、AI账号及必要授权并汇总；明确工具排障或缩小范围时才仅做该范围。项目初始化按当前已确认需求复用并接入能力，可在初始化时启用所需云服务/GitHub/AI；需求未明确时先建本地工程，不自动创建未来资源。AI Key在程序设置入口就绪后由本人填写；准备、接入、调用、发布和本人试用分别留证。

更新资料、只更新技能或恢复升级中断时，读取 [资料与技能升级](references/course-updates.md)，使用独立更新入口；不重走环境安装。
