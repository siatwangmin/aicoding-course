# Android 交付门槛

1. 已确认本轮手机需求/原型，实际Web前置可追溯；仅需要云功能时检查相应前置。
2. 本项目准备镜像、runtime、appId、dataMode、环境与登录策略保持一致。Web 编译后 sync 再 Gradle；单跑 Gradle 不能证明网页更新。
3. APK 记录路径、hash、构建时间、源码/配置摘要、工具镜像身份、appId、versionCode/versionName。未提交源码也使用内容摘要，不仅依赖 Git commit。
   使用Build-Android.ps1核Web/原生/APK内资源清单与构建ID，版本相对上次交付递增；原生输入单独摘要。图标已确认时解包预览实际对照，不用文件存在或包名/版本正确代替内容。未完成图标核对只报content-verified待核，不能交付通过。
4. 分开记录 build-verified、installed、launched、learner-tried、sync-verified。脚本只设置真实构建状态，其余默认 pending/not-applicable，后续实际证据更新，不提供“全部通过”开关。
5. 按受影响需求检查触控、键盘遮挡、返回、长内容、文件选择、会话恢复；案例额外动作从案例技能读取。
6. 需要共享数据时验证手机→网页和网页→手机；受控失败保留输入/重试不重复。手机离线不能假称云端同步成功。
7. 交付文件位置、传输入口、一个当前手机动作和预期画面。本人安装/试用反馈原文摘要和设备信息写入项目进度；无设备则保持未验证。
