import { readFile, stat, rename } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { context, within, plainPath, atomicJson, verifyImage, sourceDigest, command, engineArgs } from './project-context.mjs';

async function buildConfiguration(source) {
  const hash = createHash('sha256');
  const publicValues = {};
  for (const file of ['.env', '.env.local', '.env.production', '.env.production.local']) {
    let text;
    try { text = await readFile(await plainPath(join(source, file)), 'utf8'); } catch (error) { if (error.code === 'ENOENT') continue; throw error; }
    if (/^\s*(?:VITE_)?(?:SILICONFLOW_API_KEY|TENCENTCLOUD_SECRET_ID|TENCENTCLOUD_SECRET_KEY|CLOUDBASE_SECRET_KEY)\s*=/m.test(text)) throw new Error('SERVER_SECRET_IN_CLIENT_ENV');
    hash.update(file); hash.update(text);
    for (const line of text.split(/\r?\n/)) {
      const match = line.match(/^\s*(VITE_DATA_MODE|VITE_CLOUDBASE_ENV_ID)\s*=\s*([^\r\n]*)/);
      if (match) publicValues[match[1]] = match[2].trim();
    }
  }
  return { digest: hash.digest('hex'), publicValues };
}

export async function buildAndroid(root, run = command) {
  const ctx = await context(root), { project: p, source } = ctx;
  const image = verifyImage(ctx, run);
  const capacitor = await readFile(await plainPath(join(source, 'capacitor.config.ts')), 'utf8');
  if (!capacitor.includes(p.appId)) throw new Error('CAPACITOR_APP_ID_MISMATCH');
  const digest = await sourceDigest(source);
  const config = await buildConfiguration(source);
  const apk = within(source, 'android/app/build/outputs/apk/debug/app-debug.apk');
  await plainPath(apk);
  let previousApkPath=null;
  // Preserve an older artifact and require the build to produce a new file.
  try { await stat(apk); previousApkPath=apk+'.previous-'+Date.now();await rename(apk,previousApkPath); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  const startedAt = new Date().toISOString();
  const resultPath = join(ctx.root, 'docs/progress/android-build.json');
  const record = { schemaVersion: 2, startedAt, appId: p.appId, sourceDigest: digest, configDigest: config.digest, publicConfig: config.publicValues, ...image,
    status: 'building', previousApkPath, installed: 'pending', launched: 'pending', learnerTried: 'pending', syncVerified: 'pending' };
  await atomicJson(resultPath, record);
  try {
    run(p.containerRuntime, [...engineArgs(p), 'compose', 'run', '--rm', '--no-deps', 'app', 'knowstar-android-build'], ctx.root, { stdio: 'inherit' });
    if ((await sourceDigest(source)) !== digest) throw new Error('SOURCE_CHANGED_DURING_BUILD');
    if ((await buildConfiguration(source)).digest !== config.digest) throw new Error('CONFIG_CHANGED_DURING_BUILD');
    const bytes = await readFile(await plainPath(apk));
    if (bytes.length < 4 || bytes[0] !== 0x50 || bytes[1] !== 0x4b) throw new Error('INVALID_APK_ARCHIVE');
    // Android tooling is supplied by the prepared image, not the host.
    const metadata = run(p.containerRuntime, [...engineArgs(p), 'compose', 'run', '--rm', '--no-deps', '--entrypoint', 'sh', 'app', '-c',
      'AAPT=$(find "$ANDROID_HOME/build-tools" -name aapt -type f | sort | tail -1); test -n "$AAPT"; "$AAPT" dump badging /workspace/android/app/build/outputs/apk/debug/app-debug.apk'], ctx.root);
    const match = metadata.match(/package: name='([^']+)' versionCode='([^']+)' versionName='([^']+)'/);
    if (!match || match[1] !== p.appId) throw new Error('APK_PACKAGE_MISMATCH');
    Object.assign(record, { status: 'build-verified', finishedAt: new Date().toISOString(), apkPath: apk,
      sha256: createHash('sha256').update(bytes).digest('hex'), bytes: bytes.length, versionCode: match[2], versionName: match[3] });
  } catch (error) { record.status = 'failed'; record.error = error.message; await atomicJson(resultPath, record); throw error; }
  await atomicJson(resultPath, record);
  return record;
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2), index = args.indexOf('--project');
  if (args[0] !== 'build' || index < 0 || !args[index+1]) throw new Error('Use: build --project <root>');
  buildAndroid(args[index+1]).then(value => console.log(JSON.stringify(value))).catch(error => { console.error(error.message); process.exitCode=1; });
}
