﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProjectDirectory,[switch]$Finalize)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $executionRoot 'scripts/Course-Runtime.ps1')
$ProjectDirectory=Resolve-CourseProjectRoot $ProjectDirectory
$manifest=Read-CourseJson (Join-Path $ProjectDirectory '.ai-coding/project.json')
$sourceConfig=Join-Path (Join-Path $ProjectDirectory $manifest.sourceDirectory) 'capacitor.config.ts'
if(-not(Test-Path -LiteralPath $sourceConfig)){
    & (Join-Path $env:USERPROFILE '.trae-cn/skills/ai-coding-project/scripts/Enable-ProjectCapability.ps1') -ProjectDirectory $ProjectDirectory -Capability android -Reason 'Android build requested'|Out-Host
}
$lifecycleLease=$null
if(Get-Command Enter-CourseOperation -ErrorAction SilentlyContinue){$lifecycleLease=Enter-CourseOperation $ProjectDirectory 'AndroidBuild'}
try{
$ctx=Get-CourseProjectRuntime $ProjectDirectory -Start
$state=Join-Path $ctx.Root '.local\android-delivery';Assert-CoursePlainPath $state
[void](New-Item -ItemType Directory -Path $state -Force)
$lock=$null
try{
    $lock=[IO.File]::Open((Join-Path $state 'build.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    Write-CourseJson (Join-Path $state 'project.json') @{appId=$ctx.Project.appId;image=$ctx.Project.image;android=@{webDir=$ctx.Project.android.webDir;iconReviewRequired=($ctx.Project.android.iconReviewRequired -eq $true)}}
    function Invoke-ArtifactStage([string]$Action){
        $arguments=$ctx.Prefix+@('run','--rm','--network','none','--mount',("type=bind,source="+$ctx.Source+",target=/workspace"),'--mount',("type=bind,source="+$state+",target=/delivery"),'--mount',("type=bind,source="+$PSScriptRoot+",target=/course,readonly"),'--entrypoint','node',$ctx.Project.image,'/course/artifacts.mjs',$Action)
        $result=Invoke-SetupNative $ctx.Cli $arguments 90 $ctx.Root
        if($result.ExitCode -ne 0){throw ('ANDROID_ARTIFACT_STAGE_FAILED:'+ $Action+':'+$result.Output)}
    }
    function Invoke-AndroidStep([string[]]$Arguments,[int]$Timeout=180){
        $result=Invoke-SetupNative $ctx.Cli ($ctx.Prefix+@('compose','exec','-T','app')+$Arguments) $Timeout $ctx.Root
        [IO.File]::WriteAllText((Join-Path $state ('step-'+[guid]::NewGuid().ToString('N')+'.log')),$result.Output,[Text.UTF8Encoding]::new($false))
        if($result.ExitCode -ne 0){throw 'ANDROID_BUILD_STEP_FAILED; original output is not a successful artifact.'}
    }
    if(-not $Finalize){
        Invoke-AndroidStep @('sh','-c','if [ ! -d android ]; then npx --no-install cap add android; fi')
        Invoke-ArtifactStage 'prepare'
        Invoke-AndroidStep @('npm','run','build')
        Invoke-ArtifactStage 'web'
        Invoke-AndroidStep @('npx','--no-install','cap','sync','android')
        Invoke-ArtifactStage 'synced'
        Invoke-AndroidStep @('sh','-c','cd android && ./gradlew :app:assembleDebug --offline --no-daemon') 600
        Invoke-ArtifactStage 'verify'
    }
    $record=Read-CourseJson (Join-Path $state 'current.json')
    if(-not $record.iconReviewRequired -or (Test-Path -LiteralPath (Join-Path $state 'icon-review.json'))){Invoke-ArtifactStage 'deliver'}
    $record=Read-CourseJson (Join-Path $state 'current.json')
    if($record.deliveryFile){$record|Add-Member -MemberType NoteProperty -Name apkPath -Value (Join-Path $state $record.deliveryFile) -Force}
    $record|Add-Member -MemberType NoteProperty -Name iconPreviewDirectory -Value $state -Force
    Write-CourseJson (Join-Path $ctx.Root 'docs\progress\android-build.json') $record
    if($record.status -ne 'build-verified'){Write-Output 'Content verified; confirmed-icon comparison remains pending. Inspect previews, record evidence, then use -Finalize.';exit 2}
    Write-Output ('APK: '+$record.apkPath)
    Write-Output ('SHA-256: '+$record.apkSha256)
    Write-Output 'Build/content verified. Phone installation, learner trial and synchronization remain pending.'
}catch{
    if($lock -and (Test-Path -LiteralPath (Join-Path $state 'current.json'))){
        $record=Read-CourseJson (Join-Path $state 'current.json');$record.status='failed'
        Write-CourseJson (Join-Path $state 'current.json') $record
        Write-CourseJson (Join-Path $ctx.Root 'docs\progress\android-build.json') $record
    }
    throw
}finally{if($lock){$lock.Dispose()}}
}finally{if($lifecycleLease){Exit-CourseOperation $lifecycleLease}}
