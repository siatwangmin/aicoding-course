// Container-only stages. No host npm/JDK and no nested Docker control.
import { readFile, writeFile, mkdir, readdir, stat, rename, copyFile, access } from 'node:fs/promises';
import { createHash, randomUUID } from 'node:crypto';
import { join, relative, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import { atomicJson, plainPath, within, sourceDigest } from './project-context.mjs';

const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
export async function tree(root,skip=()=>false){
  const files={};
  async function walk(dir){
    for(const e of (await readdir(dir,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){
      const path=join(dir,e.name),rel=relative(root,path).replaceAll('\\','/');
      if(skip(rel,e.name))continue;
      if(e.isSymbolicLink())throw new Error('ARTIFACT_LINK_REFUSED');
      if(e.isDirectory())await walk(path);else files[rel]=sha(await readFile(path));
    }
  }
  await plainPath(root);await walk(root);return files;
}
const nativeSkip=(rel,name)=>['build','.gradle','.git'].includes(name)||rel.startsWith('app/src/main/assets/public/')||rel==='app/src/main/assets/public'||rel.startsWith('capacitor-cordova-android-plugins')||['capacitor.settings.gradle','app/capacitor.build.gradle','app/src/main/assets/capacitor.config.json','app/src/main/assets/capacitor.plugins.json','app/src/main/res/xml/config.xml'].includes(rel);
async function inputs(source){
  const configs={};
  for(const name of ['.env','.env.local','.env.production','.env.production.local']){
    try{const bytes=await readFile(await plainPath(join(source,name)));if(/^\s*(?:VITE_)?(?:SILICONFLOW_API_KEY|TENCENTCLOUD_SECRET_ID|TENCENTCLOUD_SECRET_KEY|CLOUDBASE_SECRET_KEY)\s*=/m.test(bytes.toString()))throw new Error('SERVER_SECRET_IN_CLIENT');configs[name]=sha(bytes);}
    catch(e){if(e.code!=='ENOENT')throw e;}
  }
  return {sourceDigest:await sourceDigest(source),configDigest:sha(JSON.stringify(configs)),nativeDigest:sha(JSON.stringify(await tree(join(source,'android'),nativeSkip)))};
}
async function load(path){return JSON.parse((await readFile(await plainPath(path),'utf8')).replace(/^\uFEFF/,''));}
function run(exe,args){const r=spawnSync(exe,args,{encoding:null,shell:false,maxBuffer:64*1024*1024});if(r.error||r.status!==0)throw new Error('ARTIFACT_COMMAND_FAILED:'+exe);return r.stdout;}
async function unchanged(source,record){const now=await inputs(source);if(Object.keys(now).some(k=>now[k]!==record[k]))throw new Error('BUILD_INPUTS_CHANGED');}
export async function stage(action,{source,state,project}){
  source=await plainPath(source);state=await plainPath(state);await mkdir(state,{recursive:true});
  const current=join(state,'current.json'),apk=join(source,'android/app/build/outputs/apk/debug/app-debug.apk');
  let record;
  if(action==='prepare'){
    const p=project,gradle=await plainPath(join(source,'android/app/build.gradle'));
    const capacitor=await readFile(await plainPath(join(source,'capacitor.config.ts')),'utf8');
    if(!capacitor.includes(p.appId))throw new Error('CAPACITOR_APP_ID_MISMATCH');
    let text=await readFile(gradle,'utf8');const code=text.match(/\bversionCode\s+(\d+)/),name=text.match(/\bversionName\s+['"]([^'"]+)/);
    if(!code||!name)throw new Error('EXPLICIT_VERSION_ADAPTER_REQUIRED');
    let previous,last;try{previous=await load(current);}catch(e){if(e.code!=='ENOENT')throw e;}
    try{last=await load(join(state,'last-delivery.json'));}catch(e){if(e.code!=='ENOENT')throw e;}
    if(last&&last.appId!==p.appId)throw new Error('DELIVERY_APP_ID_CONFLICT');
    const before=await inputs(source);
    const reusable=previous&&['failed','building'].includes(previous.status)&&previous.appId===p.appId&&Object.keys(before).every(k=>previous[k]===before[k]);
    const next=reusable?Number(previous.versionCode):Math.max(Number(code[1]),Number(last?.versionCode||0)+1);
    if(!Number.isSafeInteger(next)||next<1||next>2100000000)throw new Error('INVALID_VERSION_CODE');
    await copyFile(gradle,join(state,'build.gradle.before'));
    text=text.replace(/\bversionCode\s+\d+/,'versionCode '+next);await writeFile(gradle,text);
    let previousApkPath=null;try{await stat(apk);previousApkPath=apk+'.previous-'+Date.now();await rename(apk,previousApkPath);}catch(e){if(e.code!=='ENOENT')throw e;}
    record={schemaVersion:2,status:'building',buildId:reusable?previous.buildId:Date.now()+'-'+randomUUID().slice(0,8),startedAt:new Date().toISOString(),appId:p.appId,image:p.image,
      versionCode:String(next),versionName:name[1],webDir:p.android?.webDir||'dist',iconReviewRequired:p.android?.iconReviewRequired===true,
      previousApkPath,...await inputs(source),installed:'pending',launched:'pending',learnerTried:'pending',syncVerified:'pending'};
    await atomicJson(current,record);return record;
  }
  record=await load(current);
  if(action==='failed'){record.status='failed';await atomicJson(current,record);return record;}
  await unchanged(source,record);
  if(action==='web'){
    const dist=await plainPath(within(source,record.webDir));await access(join(dist,'index.html'));
    await atomicJson(join(dist,'course-build.json'),{buildId:record.buildId,sourceDigest:record.sourceDigest});
    record.webFiles=await tree(dist);record.webDigest=sha(JSON.stringify(record.webFiles));
  }else if(action==='synced'){
    if(!record.webFiles)throw new Error('WEB_MANIFEST_REQUIRED');
    const synced=await tree(join(source,'android/app/src/main/assets/public'));
    for(const [file,hash] of Object.entries(record.webFiles))if(synced[file]!==hash)throw new Error('CAPACITOR_WEB_CONTENT_MISMATCH:'+file);
  }else if(action==='verify'){
    if(!record.webFiles)throw new Error('WEB_MANIFEST_REQUIRED');
    const bytes=await readFile(await plainPath(apk));if(bytes.length<4||bytes[0]!==0x50||bytes[1]!==0x4b)throw new Error('INVALID_APK');
    for(const [file,hash] of Object.entries(record.webFiles))if(sha(run('unzip',['-p',apk,'assets/public/'+file]))!==hash)throw new Error('APK_WEB_CONTENT_MISMATCH:'+file);
    const sdk=process.env.ANDROID_HOME||'/opt/android-sdk';const tools=(await readdir(sdk+'/build-tools')).sort();
    const badging=run(join(sdk,'build-tools',tools.at(-1),'aapt'),['dump','badging',apk]).toString();
    const match=badging.match(/package: name='([^']+)' versionCode='([^']+)' versionName='([^']+)'/);
    if(!match||match[1]!==record.appId||match[2]!==record.versionCode||match[3]!==record.versionName)throw new Error('APK_IDENTITY_OR_VERSION_MISMATCH');
    const icons=[...new Set([...badging.matchAll(/application-icon-[^:]+:'([^']+)'/g)].map(m=>m[1]))];record.iconPreviews=[];
    for(const [i,path] of icons.entries()){
      const raw=run('unzip',['-p',apk,path]);const ext=raw.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))?'png':'bin';
      const name='icon-'+i+'.'+ext;await writeFile(join(state,name),raw);record.iconPreviews.push({file:name,resource:path,sha256:sha(raw)});
    }
    if(record.iconReviewRequired&&!icons.length)throw new Error('APK_ICON_NOT_RESOLVED');
    record.status='content-verified';record.apkSha256=sha(bytes);record.bytes=bytes.length;record.finishedAt=new Date().toISOString();
    record.iconReview=record.iconReviewRequired?'pending':'not-required-in-current-scope';
  }else if(action==='deliver'){
    if(record.status!=='content-verified')throw new Error('CONTENT_VERIFICATION_REQUIRED');
    if(sha(await readFile(await plainPath(apk)))!==record.apkSha256)throw new Error('APK_CHANGED_AFTER_VERIFICATION');
    if(record.iconReviewRequired){const review=await load(join(state,'icon-review.json'));if(review.status!=='verified'||review.apkSha256!==record.apkSha256||!review.designSource||!review.checkedAt)throw new Error('ICON_DESIGN_REVIEW_REQUIRED');record.iconReview='verified';}
    const name=record.appId+'-v'+record.versionName+'-'+record.versionCode+'-'+record.buildId+'.apk';
    await copyFile(apk,join(state,name));record.deliveryFile=name;record.status='build-verified';await atomicJson(join(state,'last-delivery.json'),record);
  }else throw new Error('UNKNOWN_ARTIFACT_STAGE');
  await atomicJson(current,record);return record;
}
if(process.argv[1]&&resolve(process.argv[1])===new URL(import.meta.url).pathname){
  stage(process.argv[2],{source:'/workspace',state:'/delivery',project:await load('/delivery/project.json')}).then(r=>console.log(JSON.stringify(r))).catch(e=>{console.error(e.message);process.exitCode=1;});
}
