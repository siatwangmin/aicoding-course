# AI 服务验证入口

新准备使用 scripts/Save-SiliconFlowKey.ps1 隐藏输入和用户级加密存储；明确旧来源才用 -ImportLegacy，保留旧文件。项目只保存 credentialRef。

脚本 Invoke-SiliconFlowVerification.ps1 由宿主本人身份解密，通过 stdin 传入项目/准备登记的 Docker 镜像运行 Node 检查。课前-ModelsPath使用本Skill的assets/default-models.json；已有作品使用服务端当前有效textModel/visionModel的非秘密摘要，未配置才用B/config/ai-models.defaults.json。-Kind按本轮需要，-Invoke仅在已确认费用范围；不能拿旧默认文件证明当前模型。输出verification.json只有脱敏状态、模型与指纹，配置存在、列表可用和真实调用分别记录；模型ID变化使对应旧调用证据失效。

verify-siliconflow.mjs 的旧 --workspace env 入口只兼容旧检查，不用于新项目创建明文副本。服务验证不创建产品函数、不证明页面或手机接通。受控测试不请求真实模型。

## 2.1 适用范围

本页脚本用于明确旧工程的服务验证与兼容恢复。新课程 E-08 只验本人账号/费用认知，P-01不以Key/调用为门槛；V4按 ai-coding-development/implementation/ai-service-setup.md 由本人在程序配置。
