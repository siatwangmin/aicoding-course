# Agent 的最小检查

脚本 `scripts/verify-siliconflow.mjs` 只使用 Node 自带能力，不安装依赖。模型选择来自当前课程的非秘密 JSON 配置，结构为 `{"textModel":"课程模型 ID","visionModel":"课程模型 ID"}`；缺配置就定位已选课程说明，不猜模型。使用前读取[模型列表接口](https://docs.siliconflow.cn/docs/api/models-get)与[调用接口](https://docs.siliconflow.cn/docs/api/chat-completions-post)，以当前响应为准。

先检查凭证与模型可见性（没有生成请求）：

```text
node <本技能>/scripts/verify-siliconflow.mjs --workspace <workspace> --models <课程非秘密模型配置.json>
```

V4 只复查所需能力时追加 `--kind vision`（识图）或 `--kind text`（文字），其他模型的问题不阻断本轮，未复查的旧证据明确标记。课前 E-08 默认检查两种能力。

本人已核对额度和费用并同意最小试调用后执行：

```text
node <本技能>/scripts/verify-siliconflow.mjs --workspace <workspace> --models <课程非秘密模型配置.json> --invoke
```

测试使用随 Skill 提供的虚构题图，要求识出 `6 x 7`，文本要求返回数字 `42`。每个模型最多一个生成请求、输出上限 256 Token、30 秒超时，不自动重试、不输出模型原文。模型输出、权限或额度不符合要求时，记录失败，不能只凭 HTTP 200 判通过。调用可能按本人当前模型价格扣费。

Windows 没有 Node 时复用已验收的课程容器运行时，不能临时安装宿主 npm。将 Skill、模型配置只读挂载；私有准备目录单独挂载到容器工作区的 .ai-setup，仅为写脱敏报告允许该目录读写，不挂载其他私人目录。不要把整个含 Key 的 workspace 作为 Docker build context，不在命令行嵌入 Key，不把私有文件复制进镜像；不使用全量 env 输出。若容器路径/文件权限不满足，先修复工具路线，不能在浏览器前端试放 Key。

`SILICONFLOW_BASE_URL` 只接受官方国内 HTTPS 地址；兼容旧配置以 `/v1/chat/completions` 结尾，检查时统一归一为 `/v1`。产品云函数旧代码的 `SILICONFLOW_BASE_URL` 代表完整请求地址，传递时必须转换为 `https://api.siliconflow.cn/v1/chat/completions`，不能重复拼接路径。

脚本报告保存于 workspace 的 `.ai-setup/verification.json`；退出码 0 才表示本次指定检查通过。未加 `--invoke` 且无同凭证、同模型的已通过生成证据时，文本与识图是 `not_verified`；有效旧证据复用并保留原调用时间，不能把复查时间冒充新调用时间。记录包含凭证的不可逆指纹用于识别更换，不能把旧记录当成新凭证的验收。脚本不读取账户余额；本人费用确认的证据由陪练另行记录。
