---
name: ai-coding-siliconflow
description: 引导学员本人注册登录硅基流动、核对优惠及费用，在作品设置中配置自己的 API Key 和模型；支持明确旧来源的加密凭证恢复。用于 E-08、V4 服务配置或授权故障，不替代产品开发技能。
---

# 硅基流动账号与程序配置陪练

先读当前用户 ai-coding-development/implementation/ai-service-setup.md；模型规则同时读 model-settings.md。每次只给一个必要本人动作。已有本人账号复用，不因换 B 重注册，不接收密码、验证码或 Key，不截图秘密。官方入口为 https://cloud.siliconflow.cn/，费用和优惠以本人账号当前页面为准，不承诺赠额或自动充值。

E-08 由本人登录、领取实际可用优惠并作费用决定；助手在 A/.ai-setup/account-readiness.json 保存 schemaVersion=2、mode=account-readiness、checkedAt、learnerConfirmedAt、status、checks.identityVerified/billingReviewed 和非秘密 evidence。未观察的项目不填 true；拒绝充值记录决定，不把充值作为一律必需。余额是否足够当前任务在 V4 按实际价格检查。课前不要求保存 Key 或付费调用。完成后 Register-CourseServices 及完整课前流程继续汇总，不能只完成本节便宣称全部准备通过。

P-01 生成 config/ai-models.defaults.json 并记录 V4 设置路线，不创建 UI/函数，不要求现成 Key/模型调用证据。默认文本 deepseek-ai/DeepSeek-V4-Flash、图片 Qwen/Qwen3.8-27B，来源 assets/default-models.json；显式服务端选择优先，不擅自轮换模型。

V4 由开发助手先做好“设置 → AI 服务”及受保护后端，再引导本人创建/复用 Key，在程序遮罩输入框填写、选模型、按已确认费用测试连接。Key 经现有 HTTPS 身份链路提交，只存服务端专用受限存储；不回传完整值、不存客户端或APK。网页和手机共用服务端配置。程序通过 callFunction→CloudBase函数→硅基流动HTTPS，不能改前端直连或内置AI。

## 旧环境兼容

仅明确需要恢复旧工程时，按 references/verification.md 使用既有 Save-SiliconFlowKey.ps1、Credential-Store.ps1 和 Invoke-SiliconFlowVerification.ps1。打开安全隐藏输入后再提示本人填写；DPAPI/ACL、明确旧env导入、引用、模型/费用核验保留，不扫描 HOME、不覆盖有效凭证、不自动迁到程序。旧环境脚本能力不代替新课程的本人应用配置步骤。

401 核当前 Key，额度不足由本人决定，429有界等待，其他网络或平台故障最多重试一次；不盲目重注册、生成 Key、换模型。存在 Key、列表可见、HTTP200、真实输出、业务页面及手机通过分别记录，失败脱敏且不虚称完成。

## 估时与等待

读取本技能 assets/course-timing.json，按当前阶段/步骤说明首次或复用的预计时间。长下载、编译、部署说明真实等待原因及本人是否需要操作；超过预计上限说明已完成部分、阻塞和处理，有依据才更新剩余时间。教学估算不代替实际证据，不展示虚假百分比；实际等待计入墙钟。
