---
name: ai-coding-siliconflow
description: 在 Trae 中陪非技术学员课前登录硅基流动、核对本人额度与模型费用、创建或复用 API Key，使用用户级加密存储并验证调用。用于课程 E-08 或恢复 AI 服务准备；不开发产品、不部署云函数。
---

# 硅基流动准备陪练

先判E-08准备、P-01凭证引用接入或现有服务恢复；读原来源与B绑定，已有账号/有效Key直接复用。动作顺序为核账号与费用→实际开启隐藏输入→提示本人等待输入提示后粘贴→加密保存→按已授权范围最小调用→登记。不能先说“把Key粘到终端”，不能让本人先粘到命令行再运行脚本。交互入口不可用就明确给一个本人动作，不假称输入窗口已打开。

配置失败查路径/引用/解密，401查当前凭证，429按限速恢复，输出校验失败区分格式与错误答案；不换模型/新建Key/重注册盲试。真实调用只在已授权模型与费用范围，普通配置恢复不额外索批准。P-01只接引用及复查证据，V4具体实现沿本项目callFunction→CloudBase函数→HTTPS硅基流动，不前端直连秘密或改内置AI。

使用 Trae BrowserUse 打开和读取实际页面，每次只给一个本人动作及预期结果。已有本人账号、有效 Key 与记录直接复用。先定位项目绑定的 credentialRef 与当前 workspace 的已有 `.ai-setup/siliconflow-setup.md`、`verification.json`；不要遍历用户目录寻找凭证。账号不是作品的公开演示账号。

## 本人登录与费用

按[官方快速开始](https://docs.siliconflow.cn/docs/userguide/quickstart)，打开[硅基流动控制台](https://cloud.siliconflow.cn/)。登录、验证码、实名要求、条款由本人处理；不接收密码、验证码或 Key，不拍摄秘密页面。会话属于其他人时先明确账号，不擅自注销或继续操作。BrowserUse 不可用时给当前一个官方入口和动作，记录“本人反馈，待复核”。

读取本人当前余额、赠送额度的有效期、限速与本课程所选模型的当前价格；费用以真实页面为准，不承诺免费。课前尚无作品时使用本技能 assets/default-models.json（文本 deepseek-ai/DeepSeek-V4-Flash、图片理解 Qwen/Qwen3.8-27B）。已有作品先读服务端当前模型配置及revision，未配置才用B/config/ai-models.defaults.json；不因案例名推断模型。额度不足或模型不可用时说明影响，由本人决定费用或在“设置 → AI 模型”选择替代；不自动购买、开通付费或轮换模型盲试。本人看清费用并同意最小试调用后才调用模型。

## 用户级安全保存与项目接入

1. 使用 scripts/Save-SiliconFlowKey.ps1 -WorkingDirectory <A> 打开本人可交互隐藏输入；Key 使用当前用户 DPAPI 加密并限制访问，保存到用户级 .ai-coding/credentials，Skill 内不存秘密。Key 不作命令参数、不进聊天、前端、APK、镜像或日志。没有安全交互入口时只给本人一个必要动作。
2. 旧 A/.ai-setup/siliconflow.env 通过同脚本 -ImportLegacy 安全导入，明确路径、不扫描 HOME；保留旧文件，目标已存在先复用，不覆盖。替换需本人明确决定才用 -Replace。
3. A 只留 credential-reference.json 与脱敏服务证据。B 初始化通过 ai-coding-project 绑定 credentialRef，不复制 Key。用户/机器改变时重新授权或安全导入，引用不能冒充凭证可用。
4. 验证运行 scripts/Invoke-SiliconFlowVerification.ps1 -WorkingDirectory <A或B> -ModelsPath <明确模型配置>，需要付费最小调用且本人已授权时加 -Invoke；按需 -Kind text/vision。脚本将私有配置通过 stdin 送入已准备 Docker 镜像，输出仅脱敏结果，不导出明文 env。旧 Node 文件读取入口仅兼容既有准备检查，不用于新项目复制秘密。
5. 项目初始化模式核对引用可解密和既有模型/费用证据，只补当前缺项；不重复注册、不提前创建产品函数。模型 ID 来自本项目有效配置（未配置用默认文件）。服务复查可将当前非秘密textModel/visionModel与revision记录为受控临时摘要，显式传给-ModelsPath，不能拿旧默认文件冒充生效配置。部署秘密使用当前工具的保密参数/受限临时配置，禁止在可见参数中展开。

## 验证及记录

按[检查脚本说明](references/verification.md)使用已准备 Node 工具链：先校验配置并请求 `/models`，再在本人确认费用后做课程文本与识图模型的最小调用。不依赖 CloudBase，也不创建占位云函数。存在 Key、模型出现在列表中、HTTP 200 均不能代替实际输出检查。

把登录、额度/价格核对时间、本人是否同意试调用、保存路径、证据来源与待办写入 `.ai-setup/siliconflow-setup.md`；脚本的 `verification.json` 只包含脱敏状态、模型 ID 和错误码，不包含请求头、Key、原图或模型原文。分别标记“已保存 / 凭证有效 / 文本通过 / 识图通过”，未执行的标为未验证。旧记录不能替代当前凭证和所需模型的检查。

401 检查 Key；403/余额不足检查账号资格与额度；模型不存在联系课程负责人；429 等待限速恢复。网络或平台错误最多重试一次，不循环注册、创建 Key、换服务。失败原因只输出状态码或脱敏错误码。

课前目标是模型服务可用；尚未证明网页、CloudBase 云函数或 APK 已接通。完成后简短说明：“AI 服务已准备好，后续直接复用；作品功能将在 AI 阶段验收。”

完整课前env或P-01调用时直接返回编排并继续最后汇总/接入，不要求本人再发“继续”。独立请求只交付本阶段结果。

准备/服务检查结束后调用当前用户 ai-coding-env/scripts/Register-CourseServices.ps1 -WorkingDirectory <A>，将允许的非秘密连接值与脱敏服务证据登记到用户级服务记录；GitHub 再传官方当前身份 -GithubLogin。它不保存登录令牌，也不把登记当作授权通过。B 优先读自己的绑定与用户级登记，原始历史可追溯到 A。

本人已确认的最小试调用费用范围，由助手记录为 A/.ai-setup/fee-scope.json（schemaVersion=2、confirmedAt、allowedModels、maxTestCalls），随 Register-CourseServices 登记到用户级服务记录。只记录本人实际授权，不自行扩大；B 复用同一范围，变化才补本人决定，不要求学员填写模型或 JSON。
