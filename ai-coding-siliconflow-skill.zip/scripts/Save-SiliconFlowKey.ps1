﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$WorkingDirectory,[switch]$Replace,[switch]$ImportLegacy)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Credential-Store.ps1')
$workspace=(Resolve-Path -LiteralPath $WorkingDirectory).Path; Assert-AiPlainPath $workspace
$secret=$null; $value=$null; $importedLegacy=$false
try {
    if ((Test-Path -LiteralPath (Get-AiCredentialPath)) -and -not $Replace) {
        $secret=Get-AiSecureCredential
        Write-Output 'Existing encrypted credential preserved. Service verification remains separate.'
    } else {
        if ($ImportLegacy) {
            $legacy=Join-Path $workspace '.ai-setup\siliconflow.env'; Assert-AiPlainPath $legacy
            $text=[IO.File]::ReadAllText($legacy)
            $match=[regex]::Match($text,'(?m)^SILICONFLOW_API_KEY\s*=\s*([^\r\n]+)')
            if(-not $match.Success){throw 'Legacy key missing.'}
            $value=$match.Groups[1].Value.Trim().Trim('"',"'")
            if($value.Length -lt 16 -or $value -match '\s'){throw 'Invalid legacy key.'}
            $secret=ConvertTo-SecureString $value -AsPlainText -Force
        } else { $secret=Read-Host 'Paste SiliconFlow API Key (hidden)' -AsSecureString }
        if($secret.Length -lt 16){throw 'Invalid key format.'}
        Save-AiCredential $secret -Replace:$Replace | ConvertTo-Json
        $importedLegacy=[bool]$ImportLegacy
    }
    $recordDir=Join-Path $workspace '.ai-setup'; Assert-AiPlainPath $recordDir
    [void](New-Item -ItemType Directory -Path $recordDir -Force)
    $reference=Join-Path $recordDir 'credential-reference.json'; Assert-AiPlainPath $reference
    [IO.File]::WriteAllText($reference,(@{schemaVersion=2;credentialRef='siliconflow/course-default';migratedFromLegacy=$importedLegacy;savedAt=(Get-Date).ToString('o')}|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
    foreach($ignoreName in @('.gitignore','.dockerignore','.containerignore')){
        $ignore=Join-Path $workspace $ignoreName;Assert-AiPlainPath $ignore
        $existing=if(Test-Path -LiteralPath $ignore){[IO.File]::ReadAllText($ignore)}else{''}
        if($existing -notmatch '(?m)^/?\.ai-setup/\s*$'){[IO.File]::AppendAllText($ignore,"`n.ai-setup/`n",[Text.UTF8Encoding]::new($false))}
    }
    Write-Output 'Credential reference ready. Legacy file retained; no model call was made.'
} finally {if($secret){$secret.Dispose()};$value=$null;$text=$null}
