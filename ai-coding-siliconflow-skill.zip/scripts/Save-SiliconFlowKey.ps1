#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$WorkingDirectory, [switch]$Replace)

$ErrorActionPreference = 'Stop'
$workspace = (Resolve-Path -LiteralPath $WorkingDirectory).Path
$directory = Join-Path $workspace '.ai-setup'
$path = Join-Path $directory 'siliconflow.env'
foreach ($target in @($workspace, $directory, $path)) {
    if ((Test-Path -LiteralPath $target) -and ((Get-Item -LiteralPath $target -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) {
        throw 'The credential location must not be a link.'
    }
}
[void](New-Item -ItemType Directory -Path $directory -Force)
$sid = [Security.Principal.WindowsIdentity]::GetCurrent().User
$acl = [IO.Directory]::GetAccessControl($directory, [Security.AccessControl.AccessControlSections]::Access)
$acl.SetAccessRuleProtection($true, $false)
foreach ($rule in @($acl.Access)) { [void]$acl.RemoveAccessRuleSpecific($rule) }
$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($sid, 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow'))
[IO.Directory]::SetAccessControl($directory, $acl)
foreach ($ignoreName in @('.gitignore', '.dockerignore')) {
    $ignore = Join-Path $workspace $ignoreName
    if ((Test-Path -LiteralPath $ignore) -and ((Get-Item -LiteralPath $ignore -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Ignore files must not be links.' }
    $existing = if (Test-Path -LiteralPath $ignore) { [IO.File]::ReadAllText($ignore) } else { '' }
    if ($existing -notmatch '(?m)^/?\.ai-setup/\s*$') { [IO.File]::AppendAllText($ignore, "`n.ai-setup/`n", [Text.UTF8Encoding]::new($false)) }
}
if ((Test-Path -LiteralPath $path) -and -not $Replace) {
    # Correct permissions of an old file without reading or overwriting its key.
    $fileAcl = [IO.File]::GetAccessControl($path, [Security.AccessControl.AccessControlSections]::Access)
    $fileAcl.SetAccessRuleProtection($true, $false)
    foreach ($rule in @($fileAcl.Access)) { [void]$fileAcl.RemoveAccessRuleSpecific($rule) }
    $fileAcl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($sid, 'FullControl', 'Allow'))
    [IO.File]::SetAccessControl($path, $fileAcl)
    Write-Output 'Existing credential preserved. Validate it before reuse.'
    return
}
$secret = Read-Host 'Paste your SiliconFlow API Key (hidden)' -AsSecureString
$pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
try {
    $value = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer).Trim()
    if ($value.Length -lt 16 -or $value -match '[\r\n\s]') { throw 'Invalid key format. No credential was saved.' }
    if (-not (Test-Path -LiteralPath $path)) { [IO.File]::WriteAllText($path, '', [Text.UTF8Encoding]::new($false)) }
    $fileAcl = [IO.File]::GetAccessControl($path, [Security.AccessControl.AccessControlSections]::Access)
    $fileAcl.SetAccessRuleProtection($true, $false)
    foreach ($rule in @($fileAcl.Access)) { [void]$fileAcl.RemoveAccessRuleSpecific($rule) }
    $fileAcl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($sid, 'FullControl', 'Allow'))
    [IO.File]::SetAccessControl($path, $fileAcl)
    [IO.File]::WriteAllText($path, "SILICONFLOW_BASE_URL=https://api.siliconflow.cn/v1`nSILICONFLOW_API_KEY=$value`n", [Text.UTF8Encoding]::new($false))
    Write-Output 'Credential saved privately. Actual model calls remain to be verified.'
} finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer)
    $value = $null
    $secret.Dispose()
}
