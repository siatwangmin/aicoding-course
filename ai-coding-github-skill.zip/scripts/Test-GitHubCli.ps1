﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$WorkingDirectory,[Parameter(Mandatory=$true)][string]$ExpectedLogin)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=Resolve-CourseExecutionRoot $WorkingDirectory
. (Join-Path $executionRoot 'scripts/Course-Native.ps1')
. (Join-Path $PSScriptRoot 'GitHub-Pages.ps1')
. (Join-Path $PSScriptRoot 'GitHub-Readiness.ps1')
$gh=Resolve-CourseGitHubCli
$git=(Get-Command git -CommandType Application -ErrorAction Stop).Source
$result=Get-CourseGitHubReadiness $gh $git $ExpectedLogin (Resolve-Path -LiteralPath $WorkingDirectory).Path
$result|ConvertTo-Json -Depth 5
if($result.status -ne 'verified'){exit 2}
