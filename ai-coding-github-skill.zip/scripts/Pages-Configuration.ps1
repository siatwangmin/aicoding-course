﻿#Requires -Version 5.1
# Compatibility entrypoint: Pages configuration is owned by ai-coding-github.
. (Join-Path $PSScriptRoot 'GitHub-Pages.ps1')
