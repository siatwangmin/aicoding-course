﻿#Requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$ProjectDirectory,
    [Parameter(Mandatory=$true)][ValidateSet('browser','learner')][string]$Kind,
    [Parameter(Mandatory=$true)][string]$EvidencePath
)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $executionRoot 'scripts/Course-ProjectRoot.ps1')
. (Join-Path $PSScriptRoot 'Pages-Publication.ps1')
$root=Resolve-CourseProjectRoot $ProjectDirectory
$evidence=(Resolve-Path -LiteralPath $EvidencePath).Path;Assert-CoursePlainPath $evidence
if(-not $evidence.StartsWith($root.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'PAGES_ACCEPTANCE_EVIDENCE_OUTSIDE_PROJECT'}
$lease=Enter-PagesLease $root
try {
    $record=Read-PagesRecord $root
    if($record.status -ne 'assets-verified' -or $record.checks.deployment -ne 'passed' -or $record.checks.assets -ne 'passed'){throw 'PAGES_TECHNICAL_VERIFICATION_REQUIRED'}
    $proof=Read-CourseJson $evidence
    foreach($key in @('publicationId','commit','buildId','url')){if(-not $proof.$key -or $proof.$key -cne $record.$key){throw 'PAGES_ACCEPTANCE_IDENTITY_MISMATCH'}}
    if($proof.kind -cne $Kind -or $proof.status -notin @('passed','failed')){throw 'PAGES_ACCEPTANCE_RESULT_REQUIRED'}
    if(-not $proof.observation -or ($Kind -eq 'learner' -and $proof.source -cne 'user')){throw 'PAGES_ACCEPTANCE_OBSERVATION_REQUIRED'}
    if($Kind -eq 'browser' -and $proof.status -eq 'passed'){
        foreach($key in @('styles','resources','interaction')){if($proof.checks.$key -isnot [bool] -or -not $proof.checks.$key){throw 'PAGES_BROWSER_CHECKS_REQUIRED'}}
    }
    $record.checks.$Kind=$proof.status
    $record|Add-Member NoteProperty ($Kind+'Evidence') @{path=$evidence;sha256=(Get-FileHash -LiteralPath $evidence).Hash.ToLowerInvariant();observation=$proof.observation;source=$proof.source;checks=$proof.checks;recordedAt=[DateTimeOffset]::UtcNow.ToString('o')} -Force
    if($Kind -eq 'learner'){$record.learnerTried=$proof.status}
    Save-PagesRecord $root $record
    $record|ConvertTo-Json -Depth 20
} finally {$lease.Dispose()}
