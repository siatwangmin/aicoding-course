﻿#Requires -Version 5.1
# The detached process opens its own log; it must not inherit the caller's redirected pipes.
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$ProjectDirectory,
    [Parameter(Mandatory=$true)][ValidatePattern('^[a-f0-9]{32}$')][string]$ExpectedPublicationId,
    [ValidateRange(1,900)][int]$WaitSeconds=600
)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $executionRoot 'scripts/Course-ProjectRoot.ps1')
$root=Resolve-CourseProjectRoot $ProjectDirectory
$log=Join-Path $root ('.local/pages-jobs/'+$ExpectedPublicationId+'/worker.log')
Assert-CoursePlainPath $log
[void](New-Item -ItemType Directory -Path (Split-Path $log -Parent) -Force)
& (Join-Path $PSScriptRoot 'Publish-Pages.ps1') -ProjectDirectory $root -Recover -MonitorWorker -ExpectedPublicationId $ExpectedPublicationId -WaitSeconds $WaitSeconds *> $log
