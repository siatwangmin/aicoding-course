﻿#Requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$ProjectDirectory,
    [string]$HtmlPath,[string]$ResourceRoot,
    [switch]$Publish,[switch]$Recover,[switch]$Background,[switch]$Status,
    [ValidateRange(1,900)][int]$WaitSeconds=600,
    [Parameter(DontShow=$true)][switch]$MonitorWorker,
    [Parameter(DontShow=$true)][string]$ExpectedPublicationId
)
$ErrorActionPreference='Stop'
if(($Publish -and $Recover) -or ($Status -and ($Publish -or $Recover -or $Background)) -or ($Background -and -not($Publish -or $Recover)) -or ($MonitorWorker -and (-not $Recover -or -not $ExpectedPublicationId -or $Background))){throw 'PAGES_ARGUMENT_CONFLICT'}
. (Join-Path $PSScriptRoot 'Course-Execution.ps1')
$executionRoot=Resolve-CourseExecutionRoot $ProjectDirectory
. (Join-Path $executionRoot 'scripts/Course-ProjectRoot.ps1')
. (Join-Path $executionRoot 'scripts/Course-Native.ps1')
. (Join-Path $PSScriptRoot 'Pages-Configuration.ps1')
. (Join-Path $PSScriptRoot 'Pages-Publication.ps1')
$root=Resolve-CourseProjectRoot $ProjectDirectory
if($env:AI_CODING_PAGES_TIMING_DIRECTORY -and -not [IO.Path]::GetFullPath($env:AI_CODING_PAGES_TIMING_DIRECTORY).StartsWith($root.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'PAGES_TIMING_DIRECTORY_OUTSIDE_PROJECT'}
$recordPath=Join-Path $root 'docs/progress/pages-publish.json'
if($Status){
    $record=Read-PagesRecord $root
    $record|Add-Member NoteProperty workerActive (Test-PagesWorker $record) -Force
    $record|ConvertTo-Json -Depth 20
    return
}
$lease=$null;$preflight=$null;$record=$null
try {
    $lease=Enter-PagesLease $root $(if($MonitorWorker){30}else{0})
    $services=Read-CourseJson (Join-Path $root '.ai-coding/services.json')
    $repo=([string]$services.githubPages.repository) -replace '^https://github.com/',''
    if($repo -notmatch '^[a-zA-Z0-9-]+/[a-zA-Z0-9._-]+$'){throw 'Confirmed dedicated static repository required.'}
    $prior=if(Test-Path -LiteralPath $recordPath){Read-PagesRecord $root}else{$null}
    if($MonitorWorker -and $prior.publicationId -cne $ExpectedPublicationId){throw 'PAGES_WORKER_PUBLICATION_CHANGED'}
    if(-not $MonitorWorker -and $prior -and (Test-PagesWorker $prior)){
        if($Recover){$prior|ConvertTo-Json -Depth 20;return}
        throw 'PAGES_WORKER_ACTIVE: query -Status; the existing deployment continues.'
    }
    $template=Read-CourseJson (Join-Path $PSScriptRoot '../assets/pages-acceptance.json')
    if($Recover){
        Assert-PagesRecord $root $repo $prior
        $record=$prior
        # Migrate old records without inferring that old success is current evidence.
        if(-not $record.publicationId){$record|Add-Member NoteProperty publicationId ([guid]::NewGuid().ToString('N'))}
        if($record.publicationId -cnotmatch '^[a-f0-9]{32}$'){throw 'PAGES_PUBLICATION_ID_INVALID'}
        if(-not $record.startedAt){$record|Add-Member NoteProperty startedAt ([DateTimeOffset]::UtcNow.ToString('o'))}
        if(-not $record.checks){$record|Add-Member NoteProperty checks $template.checks;$record|Add-Member NoteProperty browserChecklist $template.browserChecklist}
        $record|Add-Member NoteProperty errorCode $null -Force
        $record.checks.deployment='pending';$record.checks.assets='pending'
        Save-PagesRecord $root $record
    } else {
        # An explicitly removed site is terminal history, not a pending commit to recover.
        # The new target must still pass current ownership, permission and content checks.
        if($prior -and $prior.commit -and $prior.status -notin @('assets-verified','removed')){throw 'Prior Pages publication requires -Recover before another push.'}
        if(-not $HtmlPath){throw 'Confirmed prototype HTML path required.'}
        $html=(Resolve-Path -LiteralPath $HtmlPath).Path;Assert-CoursePlainPath $html
        if(-not $ResourceRoot){$ResourceRoot=Split-Path $html -Parent}
        $ResourceRoot=(Resolve-Path -LiteralPath $ResourceRoot).Path;Assert-CoursePlainPath $ResourceRoot
        if(-not $html.StartsWith($ResourceRoot.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Prototype must belong to the supplied public resource root.'}
        $record=[pscustomobject]@{
            schemaVersion=3;publicationId=[guid]::NewGuid().ToString('N');repository=$repo;status='preparing'
            startedAt=[DateTimeOffset]::UtcNow.ToString('o');targetSeconds=$template.targetSeconds
            checks=$template.checks;browserChecklist=$template.browserChecklist;deliveryText=$template.deliveryText
            designSource=$html;commit=$null;branch=$null;url=$null;buildId=$null;stagingDirectory=$null
            manifestSha256=$null;errorCode=$null;learnerTried='pending'
        }
        Save-PagesRecord $root $record
    }
    $gh=$null
    if($Publish -or $Recover){
        $gh=Resolve-CourseGitHubCli
        # Remote checks are read-only and overlap runtime/static preparation.
        $preflight=Start-PagesPreflight $executionRoot $PSScriptRoot $gh $repo $root $(if($Recover){$record.branch}else{''})
    }
    . (Join-Path $executionRoot 'scripts/Course-Runtime.ps1')
    $runtimeSpan=Start-PagesTiming $(if($MonitorWorker){'background-runtime-check'}else{'local-runtime-check'})
    $runtimeOutcome='failed'
    try {$ctx=Get-CourseProjectRuntime $root -Start:(-not $MonitorWorker);$runtimeOutcome='completed'}
    finally {Stop-PagesTiming $runtimeSpan $runtimeOutcome}
    if(-not $Recover){
        $relativeHtml=$html.Substring($ResourceRoot.TrimEnd('\').Length+1).Replace('\','/')
        $out=Join-Path $root ('.local/pages-stage/'+$record.publicationId);Assert-CoursePlainPath $out
        [void](New-Item -ItemType Directory -Path $out -Force)
        $staticSpan=Start-PagesTiming 'static-preparation'
        $staticOutcome='failed'
        try {
            $prepared=Invoke-SetupNative $ctx.Cli ($ctx.Prefix+@('run','--rm','--network','none','--mount',("type=bind,source=$ResourceRoot,target=/input,readonly"),'--mount',("type=bind,source=$out,target=/public"),'--mount',("type=bind,source=$PSScriptRoot,target=/course,readonly"),'--entrypoint','node',$ctx.Project.image,'/course/publish-assets.mjs','static','--root','/input','--html',('/input/'+$relativeHtml),'--out','/public')) 90 $root
            if($prepared.ExitCode -eq 0){$staticOutcome='completed'}
        } finally {Stop-PagesTiming $staticSpan $staticOutcome}
        if($prepared.ExitCode -ne 0){throw 'PAGES_STATIC_PREPARATION_FAILED: inspect public paths and resources; no push performed.'}
        $manifestPath=Join-Path $out 'course-publish.json';$manifest=Read-CourseJson $manifestPath
        $record.buildId=$manifest.buildId;$record.stagingDirectory=$out
        $record.manifestSha256=(Get-FileHash -LiteralPath $manifestPath).Hash.ToLowerInvariant()
        $record.status='prepared';Save-PagesRecord $root $record
        if(-not $Publish){$record|ConvertTo-Json -Depth 20;return}
    }
    $task=$preflight;$preflight=$null;$target=Complete-PagesPreflight $task
    if($Recover){
        if($target.branch -cne $record.branch){throw 'PAGES_RECOVERY_BRANCH_CHANGED'}
        Assert-PagesRemoteCommit $gh $record $root
        if(-not $MonitorWorker){[void](Enable-CoursePagesSite $gh $repo $record.branch $root)}
    } else {
        $git=Resolve-CourseGitHubGit $executionRoot;$branch=$target.branch
        $checkout=Join-Path $root ('.local/pages-repository-'+$record.publicationId);Assert-CoursePlainPath $checkout
        [void](Invoke-PagesNative $git @('clone',('https://github.com/'+$repo+'.git'),$checkout) 180 $root)
        [void](Invoke-PagesNative $git @('-C',$checkout,'checkout','-B',$branch) 30 $root)
        $oldManifest=Join-Path $checkout 'course-publish.json';$managed=@()
        if(Test-Path -LiteralPath $oldManifest){$old=Read-CourseJson $oldManifest;$managed=@($old.files.PSObject.Properties.Name)+@('course-publish.json')}
        $files=@($manifest.files.PSObject.Properties.Name)+@('course-publish.json')
        $tracked=(Invoke-PagesNative $git @('-C',$checkout,'ls-files') 30 $root).Split(@("`r`n","`n"),[StringSplitOptions]::RemoveEmptyEntries)
        if(@($tracked|Where-Object {$managed -notcontains $_ -and $_ -notin @('README.md','LICENSE')}).Count){throw 'Unknown repository content preserved; select a dedicated managed static target.'}
        foreach($name in @($managed+$files|Select-Object -Unique)){
            $destination=[IO.Path]::GetFullPath((Join-Path $checkout $name));Assert-CoursePlainPath $destination
            if(-not $destination.StartsWith($checkout+'\',[StringComparison]::OrdinalIgnoreCase) -or $name -match '[\x00-\x1f\x7f\\]|(^|/)\.(?!nojekyll$)'){throw 'Unsafe public repository path.'}
            if(Test-Path -LiteralPath $destination){
                if($managed -notcontains $name){throw 'Unknown existing public content preserved.'}
                if($name -ne 'course-publish.json' -and (Get-FileHash -LiteralPath $destination).Hash.ToLowerInvariant() -cne $old.files.$name){throw 'Existing managed content changed independently; preserved.'}
            }
        }
        foreach($name in $managed){if($files -notcontains $name){$destination=Join-Path $checkout $name;if(Test-Path -LiteralPath $destination){Remove-Item -LiteralPath $destination -Force}}}
        foreach($name in $files){$destination=Join-Path $checkout $name;[void](New-Item -ItemType Directory -Path (Split-Path $destination -Parent) -Force);Copy-Item -LiteralPath (Join-Path $out $name) -Destination $destination -Force}
        [void](Invoke-PagesNative $git (@('-C',$checkout,'add','--')+@($files+$managed|Select-Object -Unique)) 30 $root)
        [void](Invoke-PagesNative $git @('-C',$checkout,'commit','-m',('Publish confirmed prototype '+$manifest.buildId)) 30 $root)
        $record.commit=(Invoke-PagesNative $git @('-C',$checkout,'rev-parse','HEAD') 30 $root).Trim();$record.branch=$branch
        # Persist before push; a lost response is reconciled with the remote commit.
        $record.status='push-started';Save-PagesRecord $root $record
        [void](Invoke-PagesNative $git @('-C',$checkout,'push','origin',$branch) 180 $root)
        $record.status='pushed';Save-PagesRecord $root $record
        [void](Enable-CoursePagesSite $gh $repo $branch $root)
    }
    $page=Get-CoursePagesConfiguration $gh $repo $record.branch $root
    if(-not $page -or $page.html_url -notmatch '^https://[^\s]+/$' -or ([uri]$page.html_url).UserInfo){throw 'Official Pages URL unavailable.'}
    $record|Add-Member NoteProperty url $page.html_url -Force
    $record.status='deployment-pending';Save-PagesRecord $root $record
    if($Background){
        Start-PagesMonitor $root $PSCommandPath $record $WaitSeconds
        $record|ConvertTo-Json -Depth 20
        return
    }
    $record=Invoke-PagesMonitor $ctx $gh $record $WaitSeconds
    $record|ConvertTo-Json -Depth 20
    if($record.status -ne 'assets-verified'){exit 2}
} catch {
    if($record){
        $code=($_.Exception.Message -split ':')[0]
        if($code -cnotmatch '^PAGES_[A-Z_]+$'){$code='PAGES_OPERATION_FAILED'}
        $record|Add-Member NoteProperty errorCode $code -Force
        $record.status=if($record.commit){'check-failed'}else{'preparation-failed'}
        Save-PagesRecord $root $record
    }
    throw
} finally {
    if($preflight){$preflight.runner.Stop();$preflight.runner.Dispose()}
    if($lease){$lease.Dispose()}
}
