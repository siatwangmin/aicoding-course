﻿#Requires -Version 5.1
# Read-only CLI/account preparation checks. Never returns tokens or raw auth output.
function Get-CourseGitHubReadiness([string]$Gh,[string]$Git,[string]$ExpectedLogin,[string]$WorkingDirectory) {
    $checks=[ordered]@{cliAvailable=$false;cliAuthVerified=$false;gitCredentialConfigured=$false}
    $login=$null;$source=$null;$reason='cli-unavailable'
    $version=Invoke-SetupNative $Gh @('--version') 15 $WorkingDirectory
    if($version.ExitCode -eq 0){
        $checks.cliAvailable=$true;$reason='cli-login-required'
        $status=Invoke-SetupNative $Gh @('auth','status','--hostname','github.com','--json','hosts') 30 $WorkingDirectory
        if($status.ExitCode -eq 0){
            try{
                $body=if($status.Stdout){$status.Stdout}else{$status.Output}
                $accounts=@(($body|ConvertFrom-Json).hosts.'github.com'|Where-Object {$_.active -eq $true -and $_.state -eq 'success'})
                if($accounts.Count -eq 1){
                    $account=$accounts[0];$source=[string]$account.tokenSource
                    # A process-only GH_TOKEN or a plaintext fallback is not durable preparation.
                    if($source -eq 'keyring'){
                        $identity=Invoke-SetupNative $Gh @('api','--hostname','github.com','user','--jq','.login') 30 $WorkingDirectory
                        if($identity.ExitCode -eq 0){
                            $login=([string]$(if($identity.Stdout){$identity.Stdout}else{$identity.Output})).Trim()
                            if($login -and $login -ieq $account.login -and $ExpectedLogin -and $login -ieq $ExpectedLogin){$checks.cliAuthVerified=$true;$reason='git-credential-setup-required'}
                            else{$reason='identity-mismatch-or-unconfirmed'}
                        }else{$reason='api-identity-unverified'}
                    }else{$reason='durable-secure-cli-login-required'}
                }
            }catch{$reason='cli-auth-status-unreadable'}
        }
    }
    $config=Invoke-SetupNative $Git @('config','--get-urlmatch','credential.helper','https://github.com') 15 $WorkingDirectory
    $helper=if($config.Stdout){$config.Stdout}else{$config.Output}
    # This proves configuration only; repository write/Pages rights are checked on demand.
    if($config.ExitCode -eq 0 -and $helper -match '(?im)(^|\s)manager(?:-core)?\s*$|gh(?:\.exe)?["'']?\s+auth\s+git-credential'){$checks.gitCredentialConfigured=$true}
    $ready=@($checks.Values|Where-Object {$_ -ne $true}).Count -eq 0
    if($ready){$reason='ready'}
    return [pscustomobject]@{schemaVersion=1;status=$(if($ready){'verified'}else{'pending'});checkedAt=[datetimeoffset]::UtcNow.ToString('o');login=$login;credentialSource=$source;checks=[pscustomobject]$checks;reason=$reason;repositoryWriteVerified=$false;pagesPermissionVerified=$false}
}
