# github.io 静态展示

默认调用当前项目 ai-coding-github/references/pages-cli.md。Git、仓库创建、Pages 开启/查询/恢复均走 Git/GitHub CLI，BrowserUse 只用于必要本人账号授权和最后页面体验；不点击 Settings → Pages，不要求更换使用者提示词。CLI 失败先恢复工具、身份、权限或网络，不自动退回浏览器配置。

从本轮确认材料定位完整 HTML，保留原版，将发布副本整理为 index.html、必要公开资源和 .nojekyll。静态展示只发布原型，不接真实账号、数据同步或 AI，不上传源码工程、PRD、准备记录、APK、凭证或 node_modules。

先读项目 services.json 的 githubPages 绑定，复用本人专用静态仓库；授权失效交 ai-coding-github 恢复，不改作品 remote、不强推或覆盖未知内容。无专用目标时在已授权范围内准备，以稳定 slug 命名，不要求使用者填写 Git 参数。

实施前在spec/进度记录确认HTML来源、静态输出位置、允许文件及目标；使用文件API整理副本，不靠shell管道生成文件名。拒绝控制字符/越界路径，核index.html大小写及资源相对路径；大型二进制先核目标平台实际限制，不把改走API当万能修复。原型静态发布不运行项目npm构建或上传源码。

流程为“当前身份/目标核验→本轮副本与资源→检查提交清单→推送→等待实际部署终态→核部署commit与线上资源→本人打开”。404先查部署分支/commit、文件名和资源路径；授权过期只恢复授权，平台排队记录等待，不重复创建仓库/改remote。源码备份和腾讯云正式发布是独立目标。

检查资源相对路径、静态副本、实际提交清单与秘密，再推送并检查 Pages 的实际部署提交和返回 URL。部署等待单独记录。打开 github.io 检查样式/资源/一项交互，最后请本人打开确认。记录 repository、branch、commit、designSource、URL 和结果；CloudBase 另验，不能互相代替。

标准入口 scripts/Publish-Pages.ps1 -ProjectDirectory <B> -HtmlPath <确认HTML>（需要时 -ResourceRoot <公开资源根>）先生成独立静态副本和资源清单，不改远端；本人已请求该目标发布时加 -Publish，使用现有官方gh/Git授权，只操作services中专用仓库。脚本拒绝未知仓库内容/受控文件独立改动，等待相同commit部署并逐资源核线上hash。中断后用 -Recover查询/核已推commit，不重发push。动态资源无法从HTML/样式确定时由助手按原材料补齐公开副本并实际浏览器核验，不让使用者排查路径。

Pages 配置由 ai-coding-github/scripts/GitHub-Pages.ps1 的 Resolve-CourseGitHubCli、Get-CoursePagesConfiguration、Enable-CoursePagesSite 维护，Publish-Pages 及 Recover 共用它。发布前核已有Pages的branch、根路径和构建模式，不覆盖其他来源或Actions工作流；只有明确404可视为尚未开通，授权或网络失败先恢复。push前先保存commit/branch及push-started状态，网络中断后按原commit核远端；若尚未到远端或分支已变，保留记录由助手检查当前状态，不盲目重推。


沿 Publish-Pages.ps1 准备/发布/Recover；CloudBase按确认的官方路线与Publish-CloudBase产物核验。先核真实输出目录与资源清单，部署等待查原任务终态，不重复上传源码或提交新任务。相关测试/版本适配与接续读 [efficient-execution.md](efficient-execution.md)。
