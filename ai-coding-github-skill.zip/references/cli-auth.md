# 环境准备中的 GitHub CLI 授权

E-07 在本人账号/邮箱验证之后完成 GitHub CLI 的可复用授权，不等到发布网页才首次登录。使用者不需要创建、复制或交出 API Key/PAT；由助手运行官方 CLI，本人在 GitHub 的设备授权页面完成必要授权。已授权状态直接核验和复用，不重新注册或每阶段重复登录。这个步骤不创建仓库、不推送文件、不启用 Pages。

## 实施

1. 用 scripts/GitHub-Pages.ps1 的 Resolve-CourseGitHubCli 查已登记的受管工具或已有官方安装，执行 `gh --version`。统一后台工具准备已包含 GitHub CLI；后台尚在运行时先查询状态并继续账号/邮箱步骤，不另开安装。旧准备缺 gh 时从已验证公共执行包调用 scripts/Setup-GitHubCli.ps1 -WorkingDirectory <A>，复用原 storageRoot 和归属登记。它下载固定官方便携包，默认从 GitCode 下载，失败后按 GHFast → gh-proxy.com → 原始 GitHub 回退，并核归档和 gh.exe 的固定摘要；不要求 winget、管理员权限或手改 PATH。下载加速只承载公开安装包，官方登录与 API 不经过加速站；安装成功不代表 GitHub 网络或授权通过。已装工具只核验复用，不替换或接管卸载。
2. 本人账号确定后运行 `gh auth status --hostname github.com`（不加 `--show-token`）和 `gh api --hostname github.com user --jq .login`。CLI 身份必须与已确认账号一致；其他账号会话保留，不自动登出或切换身份。Git 凭证管理器已有凭证、浏览器已登录，均不等于 gh 已持久授权。
3. CLI 尚未授权时运行 `gh auth login --hostname github.com --git-protocol https --web`。CLI 给出一次性设备码，由本人在 GitHub 官方设备授权页面填写并确认，助手负责说明当前动作和完成后接续；不让本人抄长期 token，不将设备码归档到准备报告。本人完成后重新检查实际 API 身份。
4. 登录后的长期凭证交由操作系统凭证存储保管。默认不用 `--with-token`、`gh auth token`、`--show-token` 或 `--insecure-storage`。GitHub CLI 在系统凭证存储不可用时可能回退明文；此时先恢复凭证存储，保持准备未完成，不把明文文件复制进 A/B。环境变量 GH_TOKEN 只对相应进程有效，上一轮临时复用 Git 凭证成功不能证明重开终端后仍有 gh 登录。通过 `gh auth status --json hosts` 只在内存检查 active/success/keyring，输出脱敏结果，不打印原始 token 字段。
5. 已配置有效的 Git Credential Manager 或 gh helper 时保留。缺少 GitHub HTTPS 凭证助手时执行 `gh auth setup-git --hostname github.com`，仅配置该官方主机，不使用 `--force`，不清空其他站点/单位配置，不改项目 remote 或已有 SSH 路线。配置存在只证明 Git 有凭证入口；具体仓库推送和 Pages 管理权限留给项目绑定/发布核验。
6. 在新进程运行 `scripts/Test-GitHubCli.ps1 -WorkingDirectory <A> -ExpectedLogin <本人用户名>`。该脚本只读检查 gh 版本、持久安全登录、实际 API 身份与 Git 凭证配置，不登录、不创建资源、不更改 Git 配置。status 为 verified 才将 cliAvailable/cliAuthVerified/gitCredentialConfigured 通过 Save-PreparationEvidence.ps1 逐项登记为 command 证据。账号/邮箱检查另行登记；不要手写总体通过。

准备记录只存用户名、gh 实际路径/版本、检查时间、凭证来源类别、非秘密检查结果和待办，不保存 token、密码、完整邮箱、设备码或 hosts.yml。中断后从原记录继续；只有旧账号/邮箱证据的准备，在复查时补这三个 CLI 项，不能凭旧的“GitHub 已准备”直接跳过。

发布时只复查当前授权，并核所选仓库归属/写权限与 Pages 权限；失效才回本流程补登录。账号准备不等于任何仓库或套餐权限已验收，禁止为了准备创建未来项目。

官方依据：[gh auth login](https://cli.github.com/manual/gh_auth_login)、[gh auth status](https://cli.github.com/manual/gh_auth_status)、[gh auth setup-git](https://cli.github.com/manual/gh_auth_setup-git)。

Git for Windows 独立于 gh，由准备后台 Git/GitVerify 阶段验证。先核 A/.course-setup/git.json；缺少时从公共执行包调用 Setup-Git.ps1 -WorkingDirectory <A>，国内源优先并核官方摘要。调用 Git 时加载公共 scripts/Course-Git.ps1 后使用 Resolve-CourseGit，支持当前 Trae 尚未刷新 PATH 的受管安装，不再假定系统已安装 Git。需要兼容调用 gh 子进程时，将 Git 的 cmd 目录加入当前进程 PATH；不替换已有凭证配置或项目 remote。
