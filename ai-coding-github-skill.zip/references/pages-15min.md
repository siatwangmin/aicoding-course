# 约 15 分钟完成 Pages 发布

前提：网页与公开范围已确认，Git/gh、既有镜像和本人授权可复用，专用目标已在 B 的 `services.githubPages` 绑定。未绑定时先按 pages-cli.md 准备目标；首次安装、注册、授权、页面修改与额外平台排队据实计时。预算是优化目标，不能跳过验收来满足时限。

| 预算 | 执行内容 | 编排方式 |
| --- | --- | --- |
| 0–3 分钟 | gh 身份、权限与 Pages 来源检查；同时核本地运行时、准备静态副本和摘要 | 两条线路并行，远端预检只读 |
| 3–5 分钟 | 汇合检查 → 明确文件清单 → commit → 先保存状态再 push → 查询或开通 Pages | 同一目标顺序写入，项目级独占锁 |
| 5–11 分钟 | 平台部署、状态查询；前台准备浏览器验收与交付信息 | 独立隐藏进程查询，前台可响应 |
| 11–14 分钟 | 核本次 commit、首页响应与全部资源摘要；浏览器检查样式、资源和关键交互 | 资源最多 4 路并发；浏览器可与技术核验并行，但须确认展示本轮内容 |
| 14–15 分钟 | 汇总证据、交付实际网址并请本人打开确认 | 本人未反馈时如实保留 pending |

```mermaid
flowchart TD
  A[确认网页与目标] --> B[远端只读预检]
  A --> C[本地运行时与静态模板]
  B --> D[汇合检查并提交推送]
  C --> D
  D --> E[查询或开通 Pages]
  E --> F[后台查询同一 commit]
  E --> G[前台准备验收]
  F --> H{本轮构建成功}
  H -->|否| R[保留 pending 或失败并按原记录接续]
  H -->|是| I[并发核首页及资源摘要]
  H -->|是| J
  G --> J[浏览器实际体验]
  I --> K[汇总本轮验收并交付实际网址]
  J --> K
```

## 标准入口

以下由助手调用，使用者无需填写命令。路径取当前 Skill 与 B 的实际绝对路径。

```powershell
# 已明确要求发布时：准备并推送，启动后台部署查询和资源核验。
& <Skill>/scripts/Publish-Pages.ps1 -ProjectDirectory <B> -HtmlPath <确认HTML> -Publish -Background

# 换窗口查询，不启动运行时，不触发网络或写操作。
& <Skill>/scripts/Publish-Pages.ps1 -ProjectDirectory <B> -Status

# 后台已结束或中断时按原 commit 接续，不新建 commit、不重复 push。
& <Skill>/scripts/Publish-Pages.ps1 -ProjectDirectory <B> -Recover -Background
```

后台采用有界查询窗口（默认 600 秒）。平台排队保留 `deployment-pending`，资源未一致保留 `assets-pending`，构建失败为 `deployment-failed`，检查失败为 `check-failed`。状态输出的 `workerActive` 由 PID 与进程启动时间共同核对；仍在运行时只查状态，停止后排查并恢复。后台受理及进程退出码均不能单独证明部署通过。不要为平台等待再次运行 `-Publish`。

每轮的 publicationId、repository、branch、commit、buildId、manifestSha256、URL、起止检查时间和四项验收共同保存。当前状态为 `docs/progress/pages-publish.json`，每轮快照为 `docs/progress/pages-runs/<publicationId>.json`，后台日志为 `.local/pages-jobs/<publicationId>/`。对同一项目的提交、恢复和验收登记串行执行；文件锁在进程退出时自动释放。

## 模板与验收

`assets/pages-acceptance.json` 提供时间目标、浏览器清单、四项 pending 状态与交付语。静态打包脚本统一生成 `index.html`、`.nojekyll` 与公开摘要清单，不上传整个工作区。模板只定义结构，实际仓库、commit、URL 和结果来自本轮运行。

代码只自动填写 deployment、assets；browser、learner 必须有实际观察。浏览器证据保存为 B 内 JSON，以下是字段示意，身份值取本轮记录，观察内容由助手实际检查后填写：

```json
{
  "publicationId": "本轮 publicationId",
  "commit": "本轮 commit",
  "buildId": "本轮 buildId",
  "url": "本轮实际 https 地址",
  "kind": "browser",
  "status": "passed",
  "observation": "实际检查的页面、样式、资源与关键交互结果",
  "checks": {"styles": true, "resources": true, "interaction": true}
}
```

用 `Save-PagesAcceptance.ps1 -ProjectDirectory <B> -Kind browser -EvidencePath <B内证据JSON>` 登记。本人反馈使用相同四项身份与 `kind=learner`、`source=user`、实际 `observation`、`status=passed|failed`，再以 `-Kind learner` 登记。脚本要求技术核验已通过，拒绝其他轮次、其他网址、B 外证据和缺失观察；记录证据路径及摘要，不能代替真实浏览器检查或本人反馈。

前台在后台部署期间继续准备验收，并在终态后读取记录、完成实际检查。最终回复始终给出本轮实际可点击网址及“打开此地址查看作品”；部署、浏览器或本人体验未通过时逐项说明，不把旧页面或后台启动当成完成。
