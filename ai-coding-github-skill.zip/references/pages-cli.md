# GitHub Pages：默认 CLI 路线

适用于“发布到 github.io / GitHub Pages”和 V2-PAGES。用户请求发布后直接连续执行，无需本人改提示词或指定命令。E-07 账号准备不触发发布；源码备份也不自动开通 Pages。BrowserUse 仅用于注册/邮箱验证、必要本人登录授权和最终页面体验，不点击仓库 Settings → Pages。CLI 失败先恢复工具、身份、权限或网络，不自动改走浏览器设置。

## 身份、目标与工具

1. 读 B 的 `.ai-coding/services.json` 中 `githubPages`、本轮 PRD/HTML 与发布记录。源码仓库 `github` 和静态仓库 `githubPages` 分开，不改作品 remote。已有待完成发布先按原 repository/branch/commit 恢复。
2. 用本技能 `scripts/GitHub-Pages.ps1` 的 `Resolve-CourseGitHubCli` 定位 gh；先查 PATH，支持已安装但未进入当前 PATH 的官方用户安装和 Program Files 安装。缺工具时恢复官方 gh，不新增项目编译工具链。
3. 用 `gh auth status` 和 `gh api user --jq .login` 核当前实际 API 身份；再核 `gh api repos/OWNER/REPO` 的资源归属和权限。浏览器头像、Git 可推送与 gh API 授权分别核验。已配置的官方 Git 凭证管理器可以复用，令牌仅传给当前子进程环境，不打印、不写文件或仓库 URL、不扫描 HOME 找秘密；环境准备阶段应已按 [CLI 授权准备](cli-auth.md) 完成持久登录；本阶段只补失效项。没有可复用授权时运行 `gh auth login --hostname github.com --git-protocol https --web`，本人完成设备授权后接续。不要索取本人抄写 PAT。
4. 复用已绑定的专用静态仓库。当前请求已包含首次发布且没有目标时，用已确认项目 slug 生成 `<slug>-pages`，在本人免费公开仓库路线内执行 `gh repo create OWNER/REPO --public --add-readme`，随后登记项目 github-pages 能力；不要把已有私有仓库改为公开。名称已存在先核内容和归属，不覆盖未知仓库或盲目换名重建。创建 API 成功不代表静态页面已部署。

账号、仓库权限或套餐限制缺失时保留当前结果，只引导必要本人动作。细粒度 token 创建 Pages 需要仓库 Pages 和 Administration 写权限；不为绕过限制自动升级套餐或扩大授权。接口与权限依据 [Pages REST API](https://docs.github.com/en/rest/pages/pages)、[gh api](https://cli.github.com/manual/gh_api)、[gh repo create](https://cli.github.com/manual/gh_repo_create) 和当前官方返回。

## 静态副本、推送与开通

在本轮 Spec/进度记 HTML 来源、独立公开副本、允许资源、目标仓库和实际分支。只发布 `index.html`、必要公开资源、`.nojekyll` 和公开产物清单，不发布工程源码、PRD、准备报告、凭证或 APK。资源适配仓库子路径，保留设计原稿；原型发布不运行项目 npm 构建。

沿本技能 `references/publishing.md` 和 `scripts/Publish-Pages.ps1` 准备副本、发布并核验，复用本技能CLI配置函数。独立使用本技能时也可用 Git/gh 处理已经检查的静态目录，并以明确文件清单提交，按下述步骤验证；不要上传整个工作区。

先查现有 Pages 配置，再推送已检查的静态提交。默认发布源是实际分支根目录，`build_type=legacy` 表示 GitHub 的分支发布，并非需要自行创建 Actions 工作流。命令示例（PowerShell，实际值由助手从绑定取得）：

```powershell
$repo = 'OWNER/REPO'
$branch = 'main'
gh api "repos/$repo/pages"

# 仅在 Pages 返回 404 且仓库访问已独立核实后首次执行。
# 对应分支必须已存在，并含本轮确认的静态提交。
gh api --method POST "repos/$repo/pages" `
  -f 'build_type=legacy' `
  -f "source[branch]=$branch" `
  -f 'source[path]=/'

gh api "repos/$repo/pages" --jq '{url: .html_url, source: .source, build_type: .build_type}'
gh api "repos/$repo/pages/builds/latest" --jq '{status: .status, commit: .commit, error: .error.message}'
```

脚本调用方式：先加载环境技能 `scripts/Course-Native.ps1`，再加载本技能 `scripts/GitHub-Pages.ps1`，以 `Enable-CoursePagesSite <gh绝对路径> OWNER/REPO <实际分支> <工作目录>` 查询或首次开通并读回核验。函数对正确的已有配置只读复用；404 还需证明仓库可访问；403、网络错误或权限隐藏的仓库不算未开通。首次 POST 失败先查当前官方状态，不自动重复写入。

已有分支、`/docs` 或 `workflow` 来源与默认路线冲突时保留配置，由助手沿已确认既有路线适配，或明确解决发布目标后再改；不要直接 PUT 覆盖其他网站。分支发布脚本拒绝这些冲突，不会代替已存在的 Actions 发布实现。恢复也先核原分支当前 HEAD，不能把后续别人提交当本轮发布成功。

## 完成与恢复

- push 前保存 repository、branch、commit 和 `push-started`；网络中断先查询远端，不盲目再次推送。本技能的 `-Recover` 沿已有提交检查和开通，不创建新提交。
- 用 Pages 构建接口确认本轮 commit 为 `built`；旧提交成功不算本轮成功。排队/构建中有界轮询，超时记 pending 并接续原任务；`errored` 查该构建错误。不要以重新提交、换仓库或强推处理平台等待。
- 从 API 返回的 `html_url` 检查 HTTP 成功、HTML 响应类型及本轮首页/每个资源的摘要和公开清单。本技能的 publish-assets.mjs 支持逐资源核验，只有地址返回 200 不足以证明本轮内容上线。
- 最终打开网址检查样式、资源及一项关键交互，请本人打开确认；这一步与部署配置分开。只有 CLI 检查时如实标记浏览器交互/本人体验待验，不能声称已看见页面。
- 保存实际 URL、来源配置、commit、产物摘要、部署结果和待办。CloudBase 与 Pages 分别验收；准备账号、API 授权、推送、部署、界面检查和本人试用也分别记录。
- 面向使用者的完成回复必须直接给出本轮 `html_url` 对应的完整网页地址与可点击链接，说明打开即可查看作品；使用自定义域名时给出实际生效地址。不能仅输出仓库或构建记录链接，也不能因脚本或进度文件已有 URL 就省略回复中的地址。部署或验证待完成时仍展示已取得的地址并明确标记状态。
